// js/configSwitch.js - Config Switch tool: enable/disable Workflow Rules,
// Flows/Process Builder, Validation Rules, Apex Triggers, and Users. Every
// change is preceded by a saved backup of the affected items' current state,
// and any backup can be restored.
// SECURITY_NOTE: Salesforce values are rendered with textContent only.

const ConfigSwitchCore = (() => {
  const MD_NS = "http://soap.sforce.com/2006/04/metadata";
  const USER_BATCH_SIZE = 200;

  function escapeXml(value) {
    return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }

  function decodeXml(value) {
    const named = { lt: "<", gt: ">", amp: "&", quot: "\"", apos: "'" };
    return String(value ?? "").replace(/&(#x[0-9a-f]+|#\d+|lt|gt|amp|quot|apos);/gi, (match, entity) => {
      if (entity[0] !== "#") return named[entity.toLowerCase()];
      const code = entity[1].toLowerCase() === "x" ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    });
  }

  // Removes namespace prefixes from element names so responses can be read
  // the same way whichever prefix Salesforce chose.
  function stripPrefixes(xml) {
    return String(xml ?? "").replace(/<(\/?)[A-Za-z_][\w.-]*:(?=[A-Za-z_])/g, "<$1");
  }

  // Inner XML of each <tag> element (null for self-closing elements).
  function blocks(xml, tag) {
    const pattern = new RegExp(`<${tag}\\b[^>]*?(?:\\/>|>([\\s\\S]*?)<\\/${tag}>)`, "g");
    return Array.from(String(xml ?? "").matchAll(pattern), (match) => (match[1] === undefined ? null : match[1]));
  }

  function childText(xml, tag) {
    const inner = blocks(xml, tag)[0];
    return inner == null ? "" : decodeXml(inner.trim());
  }

  function chunk(values, size) {
    const chunks = [];
    for (let index = 0; index < values.length; index += size) chunks.push(values.slice(index, index + size));
    return chunks;
  }

  function soapFault(xml) {
    return childText(stripPrefixes(xml), "faultstring");
  }

  function readMetadataPayload(type, fullNames) {
    return `<met:type>${escapeXml(type)}</met:type>${fullNames.map((name) => `<met:fullNames>${escapeXml(name)}</met:fullNames>`).join("")}`;
  }

  // Returns one entry per <records> element, in response order (null when
  // Salesforce returned an empty record for a name it couldn't find).
  function parseReadMetadata(xml) {
    return blocks(stripPrefixes(xml), "records").map((inner) => {
      const fullName = inner == null ? "" : childText(inner, "fullName");
      return fullName ? { fullName, inner } : null;
    });
  }

  function setActive(inner, value) {
    const pattern = /<active>\s*(true|false)\s*<\/active>/g;
    const matches = String(inner ?? "").match(pattern);
    if (!matches || matches.length !== 1) throw new Error("The rule's metadata has no single <active> setting, so it can't be switched safely.");
    return inner.replace(pattern, `<active>${value ? "true" : "false"}</active>`);
  }

  function updateMetadataPayload(type, inners) {
    return inners.map((inner) => `<met:metadata xsi:type="met:${escapeXml(type)}" xmlns="${MD_NS}">${inner}</met:metadata>`).join("");
  }

  function parseSaveResults(xml) {
    return blocks(stripPrefixes(xml), "result").filter((inner) => inner != null).map((inner) => {
      const errors = blocks(inner, "errors").filter((entry) => entry != null)
        .map((entry) => [childText(entry, "statusCode"), childText(entry, "message")].filter(Boolean).join(": "));
      return { fullName: childText(inner, "fullName"), success: childText(inner, "success") === "true", error: errors.join("; ") };
    });
  }

  function parseListMetadata(xml) {
    return blocks(stripPrefixes(xml), "result").filter((inner) => inner != null).map((inner) => childText(inner, "fullName")).filter(Boolean);
  }

  function parseDeployStatus(xml) {
    const result = blocks(stripPrefixes(xml), "result").find((inner) => inner != null);
    if (!result) throw new Error("Salesforce returned no deployment status.");
    const details = blocks(result, "details").find((inner) => inner != null) || "";
    const top = result.replace(/<details\b[\s\S]*<\/details>/, "");
    const runTestResult = blocks(details, "runTestResult").find((inner) => inner != null) || "";
    return {
      id: childText(top, "id"),
      done: childText(top, "done") === "true",
      success: childText(top, "success") === "true",
      status: childText(top, "status"),
      error: childText(top, "errorMessage"),
      testsCompleted: Number(childText(top, "numberTestsCompleted") || 0),
      testsTotal: Number(childText(top, "numberTestsTotal") || 0),
      componentFailures: blocks(details, "componentFailures").filter((inner) => inner != null).map((inner) => ({
        fullName: childText(inner, "fullName"), type: childText(inner, "componentType"), problem: childText(inner, "problem")
      })),
      testFailures: blocks(runTestResult, "failures").filter((inner) => inner != null).map((inner) => ({
        name: childText(inner, "name"), method: childText(inner, "methodName"), message: childText(inner, "message")
      }))
    };
  }

  function deployPayload(zipBase64, testLevel) {
    return `<met:ZipFile>${zipBase64}</met:ZipFile><met:DeployOptions><met:allowMissingFiles>false</met:allowMissingFiles><met:autoUpdatePackage>false</met:autoUpdatePackage><met:checkOnly>false</met:checkOnly><met:ignoreWarnings>false</met:ignoreWarnings><met:performRetrieve>false</met:performRetrieve><met:purgeOnDelete>false</met:purgeOnDelete><met:rollbackOnError>true</met:rollbackOnError><met:singlePackage>true</met:singlePackage><met:testLevel>${escapeXml(testLevel)}</met:testLevel></met:DeployOptions>`;
  }

  function triggerPackageFiles(triggers, apiVersion) {
    const files = {
      "package.xml": `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="${MD_NS}">\n    <types>\n${triggers.map((trigger) => `        <members>${escapeXml(trigger.name)}</members>\n`).join("")}        <name>ApexTrigger</name>\n    </types>\n    <version>${escapeXml(apiVersion)}</version>\n</Package>\n`
    };
    triggers.forEach((trigger) => {
      if (!/^\d+\.\d$/.test(String(trigger.apiVersion))) throw new Error(`The API version of trigger ${trigger.name} couldn't be read.`);
      if (typeof trigger.body !== "string" || !trigger.body) throw new Error(`The source code of trigger ${trigger.name} couldn't be read.`);
      files[`triggers/${trigger.name}.trigger`] = trigger.body;
      files[`triggers/${trigger.name}.trigger-meta.xml`] = `<?xml version="1.0" encoding="UTF-8"?>\n<ApexTrigger xmlns="${MD_NS}">\n    <apiVersion>${escapeXml(trigger.apiVersion)}</apiVersion>\n    <status>${escapeXml(trigger.status)}</status>\n</ApexTrigger>\n`;
    });
    return files;
  }

  function splitFullName(fullName) {
    const index = fullName.indexOf(".");
    const raw = index >= 0 ? fullName.slice(index + 1) : fullName;
    let name = raw;
    try { name = decodeURIComponent(raw); } catch { name = raw; }
    return { object: index >= 0 ? fullName.slice(0, index) : "", name };
  }

  function ruleItem(type, id, record) {
    if (!record) return null;
    const { object, name } = splitFullName(record.fullName);
    const active = childText(record.inner, "active");
    if (active !== "true" && active !== "false") throw new Error(`The active state of ${record.fullName} couldn't be read from Salesforce.`);
    return {
      id,
      name,
      detail: object,
      object,
      description: childText(record.inner, "description"),
      errorMessage: type === "ValidationRule" ? childText(record.inner, "errorMessage") : "",
      triggerType: type === "WorkflowRule" ? childText(record.inner, "triggerType") : "",
      inner: record.inner,
      state: { active: active === "true" }
    };
  }

  function mergeUsers(userRecords, loginRecords, loginUnavailable) {
    const logins = new Map();
    (loginRecords || []).forEach((login) => logins.set(login.UserId, login));
    return (userRecords || []).map((record) => {
      const login = logins.get(record.Id);
      return {
        id: record.Id,
        name: record.Name || "",
        detail: record.Username || "",
        username: record.Username || "",
        email: record.Email || "",
        profile: record.Profile?.Name || "",
        userType: record.UserType || "",
        lastLogin: record.LastLoginDate || "",
        loginId: login ? login.Id : "",
        frozenUnknown: Boolean(loginUnavailable),
        state: { isActive: record.IsActive === true, isFrozen: login ? login.IsFrozen === true : null }
      };
    });
  }

  function buildUserBatches(changes) {
    const batches = [];
    [["User", "isActive", "IsActive"], ["UserLogin", "isFrozen", "IsFrozen"]].forEach(([objectType, field, apiField]) => {
      const items = changes.filter((change) => change.field === field);
      chunk(items, USER_BATCH_SIZE).forEach((batchChanges) => {
        batches.push({
          changes: batchChanges,
          body: {
            allOrNone: false,
            records: batchChanges.map((change) => ({ attributes: { type: objectType }, Id: objectType === "User" ? change.item.id : change.item.loginId, [apiField]: change.value }))
          }
        });
      });
    });
    return batches;
  }

  function formatErrors(errors) {
    const messages = (errors || []).map((error) => [error.statusCode, error.message].filter(Boolean).join(": ")).filter(Boolean);
    return messages.join("; ") || "Salesforce reported a failure without details.";
  }

  function readBatchOutcomes(batch, responseData) {
    const rows = Array.isArray(responseData) ? responseData : [];
    return batch.changes.map((change, index) => {
      const row = rows[index];
      if (!row) return { change, success: false, error: "Salesforce returned no result for this record. Refresh to check its current state." };
      return { change, success: row.success === true, error: row.success === true ? "" : formatErrors(row.errors) };
    });
  }

  const yesNo = (value) => (value ? "Yes" : "No");
  const activeFilters = (isActive) => [
    { value: "all", label: "All", test: () => true },
    { value: "active", label: "Active", test: (item) => isActive(item) },
    { value: "inactive", label: "Inactive", test: (item) => !isActive(item) }
  ];
  const toggleActions = (noun) => [
    { key: "enable", label: "Enable", decide: (item) => (item.state.active ? { skip: "Already active." } : { field: "active", value: true }) },
    { key: "disable", label: "Disable", decide: (item) => (!item.state.active ? { skip: "Already inactive." } : { field: "active", value: false }) }
  ].map((action) => ({ ...action, title: `${action.label} the selected ${noun}` }));
  const describeToggle = (change) => (change.value ? "enable" : "disable");
  const TRIGGER_TYPES = { onCreateOnly: "Created", onCreateOrTriggeringUpdate: "Created, and edited to meet criteria", onAllChanges: "Created, and every time edited" };
  const FLOW_TYPES = { Workflow: "Process Builder", AutoLaunchedFlow: "Autolaunched Flow", Flow: "Screen Flow", CustomEvent: "Platform Event Process", InvocableProcess: "Invocable Process" };

  function flowStatus(item) {
    return item.state.activeVersion == null ? "Inactive" : `Active (version ${item.state.activeVersion})`;
  }

  const isSystemAdmin = (item) => /^system administrator$/i.test(String(item.profile || "").trim());
  const SYSADMIN_FREEZE_REASON = "Users with the System Administrator profile can't be frozen.";
  const SYSADMIN_DEACTIVATE_REASON = "Users with the System Administrator profile can't be deactivated.";

  const KINDS = {
    users: {
      key: "users",
      panelId: "configUsersPanel",
      storageKey: "sfConfigSwitchUserBackups",
      noun: "user(s)",
      requiresCurrentUser: true,
      stateFields: ["isActive", "isFrozen"],
      searchText: (item) => [item.name, item.username, item.email, item.profile, item.userType].join(" "),
      filters: [
        { value: "all", label: "All users", test: () => true },
        { value: "active", label: "Active", test: (item) => item.state.isActive },
        { value: "inactive", label: "Inactive", test: (item) => !item.state.isActive },
        { value: "frozen", label: "Frozen", test: (item) => item.state.isFrozen === true },
        { value: "notFrozen", label: "Not frozen", test: (item) => item.state.isFrozen === false }
      ],
      columns: [
        { label: "Name", value: (item, ctx) => (item.id === ctx.currentUserId ? `${item.name} (you)` : item.name) },
        { label: "Username", value: (item) => item.username, title: (item) => (item.email ? `Email: ${item.email}` : "") },
        { label: "Profile", value: (item) => item.profile, title: (item) => (isSystemAdmin(item) ? "Protected: System Administrators can't be frozen or deactivated here." : "") },
        { label: "User type", value: (item) => item.userType },
        { label: "Active", value: (item) => yesNo(item.state.isActive) },
        {
          label: "Frozen",
          value: (item) => (item.frozenUnknown ? "Unknown" : item.state.isFrozen === null ? "N/A" : yesNo(item.state.isFrozen)),
          title: (item) => (item.frozenUnknown ? "Frozen status couldn't be read." : item.state.isFrozen === null ? "Salesforce has no login record (UserLogin) for this user." : "")
        },
        { label: "Last login", value: (item, ctx) => ctx.formatDate(item.lastLogin) }
      ],
      actions: [
        { key: "activate", label: "Activate", title: "Activate the selected users", decide: (item) => (item.state.isActive ? { skip: "Already active." } : { field: "isActive", value: true }) },
        { key: "deactivate", label: "Deactivate", title: "Deactivate the selected users", decide: (item) => (isSystemAdmin(item) ? { skip: SYSADMIN_DEACTIVATE_REASON } : !item.state.isActive ? { skip: "Already inactive." } : { field: "isActive", value: false }) },
        {
          key: "freeze", label: "Freeze", title: "Frozen users can't log in but stay active and keep their license",
          decide: (item) => (isSystemAdmin(item) ? { skip: SYSADMIN_FREEZE_REASON } : !item.loginId ? { skip: "Salesforce has no login record (UserLogin) for this user, so it can't be frozen." } : item.state.isFrozen ? { skip: "Already frozen." } : { field: "isFrozen", value: true })
        },
        {
          key: "unfreeze", label: "Unfreeze", title: "Allow the selected frozen users to log in again",
          decide: (item) => (!item.loginId ? { skip: "Salesforce has no login record (UserLogin) for this user, so it can't be unfrozen." } : item.state.isFrozen === false ? { skip: "Already not frozen." } : { field: "isFrozen", value: false })
        }
      ],
      blockReason: (item, ctx) => (item.id === ctx.currentUserId ? "This is your own user; it can't be changed here." : ""),
      restorable: (field, value) => typeof value === "boolean",
      restoreBlockReason: (item, field, value) => (field === "isFrozen" && value === true && isSystemAdmin(item) ? SYSADMIN_FREEZE_REASON : field === "isActive" && value === false && isSystemAdmin(item) ? SYSADMIN_DEACTIVATE_REASON : field === "isFrozen" && !item.loginId ? "No login record (UserLogin) exists, so the frozen state can't be restored." : ""),
      describe: (change) => (change.field === "isActive" ? (change.value ? "activate" : "deactivate") : (change.value ? "freeze" : "unfreeze")),
      warnings: (actionKey, plan) => {
        const lines = [];
        const admins = plan.changes.filter((change) => isSystemAdmin(change.item)).length;
        if (admins) lines.push(`Warning: ${admins} of these change(s) affect System Administrators.`);
        if (actionKey === "deactivate" || actionKey === "freeze" || plan.changes.some((change) => change.value === false && change.field === "isActive" || change.value === true && change.field === "isFrozen")) {
          lines.push("Integration or API users stop working when they are deactivated or frozen.");
        }
        return lines;
      }
    },
    workflows: {
      key: "workflows",
      panelId: "configWorkflowsPanel",
      storageKey: "sfConfigSwitchBackups:workflows",
      noun: "workflow rule(s)",
      metadataType: "WorkflowRule",
      stateFields: ["active"],
      searchText: (item) => [item.object, item.name, item.description].join(" "),
      filters: activeFilters((item) => item.state.active),
      columns: [
        { label: "Object", value: (item) => item.object },
        { label: "Rule", value: (item) => item.name, title: (item) => item.id },
        { label: "Active", value: (item) => yesNo(item.state.active) },
        { label: "Evaluated when", value: (item) => TRIGGER_TYPES[item.triggerType] || item.triggerType },
        { label: "Description", value: (item) => item.description }
      ],
      actions: toggleActions("workflow rules"),
      restorable: (field, value) => typeof value === "boolean",
      describe: describeToggle,
      warnings: () => []
    },
    flows: {
      key: "flows",
      panelId: "configFlowsPanel",
      storageKey: "sfConfigSwitchBackups:flows",
      noun: "flow(s)",
      stateFields: ["activeVersion"],
      searchText: (item) => [item.label, item.name, item.typeLabel].join(" "),
      filters: [
        { value: "all", label: "All", test: () => true },
        { value: "active", label: "Active", test: (item) => item.state.activeVersion != null },
        { value: "inactive", label: "Inactive", test: (item) => item.state.activeVersion == null },
        { value: "processBuilder", label: "Process Builder only", test: (item) => item.processType === "Workflow" },
        { value: "flows", label: "Flows only", test: (item) => item.processType !== "Workflow" }
      ],
      columns: [
        { label: "Label", value: (item) => item.label },
        { label: "API name", value: (item) => item.name },
        { label: "Type", value: (item) => item.typeLabel },
        { label: "Status", value: flowStatus },
        { label: "Latest version", value: (item) => (item.latestVersion == null ? "" : String(item.latestVersion)) }
      ],
      actions: [
        {
          key: "enable", label: "Enable", title: "Activate the latest version of each selected inactive flow",
          decide: (item) => (item.state.activeVersion != null ? { skip: `Already active (version ${item.state.activeVersion}).` } : item.latestVersion == null ? { skip: "The flow has no version to activate." } : { field: "activeVersion", value: item.latestVersion })
        },
        {
          key: "disable", label: "Disable", title: "Deactivate the selected flows",
          decide: (item) => (item.state.activeVersion == null ? { skip: "Already inactive." } : { field: "activeVersion", value: null })
        }
      ],
      restorable: (field, value) => value === null || Number.isInteger(value),
      describe: (change) => (change.value == null ? "deactivate" : `activate version ${change.value} of`),
      warnings: (actionKey) => {
        if (actionKey === "enable") return ["Inactive flows are activated at their latest version. Flows that are already active are not changed."];
        if (actionKey === "restore") return ["Flows are returned to the exact version that was active (or to inactive) when the backup was taken."];
        return [];
      }
    },
    validation: {
      key: "validation",
      panelId: "configValidationPanel",
      storageKey: "sfConfigSwitchBackups:validation",
      noun: "validation rule(s)",
      metadataType: "ValidationRule",
      stateFields: ["active"],
      searchText: (item) => [item.object, item.name, item.errorMessage, item.description].join(" "),
      filters: activeFilters((item) => item.state.active),
      columns: [
        { label: "Object", value: (item) => item.object },
        { label: "Rule", value: (item) => item.name, title: (item) => item.id },
        { label: "Active", value: (item) => yesNo(item.state.active) },
        { label: "Error message", value: (item) => item.errorMessage },
        { label: "Description", value: (item) => item.description }
      ],
      actions: toggleActions("validation rules"),
      restorable: (field, value) => typeof value === "boolean",
      describe: describeToggle,
      warnings: () => []
    },
    triggers: {
      key: "triggers",
      panelId: "configTriggersPanel",
      storageKey: "sfConfigSwitchBackups:triggers",
      noun: "trigger(s)",
      stateFields: ["status"],
      searchText: (item) => [item.name, item.object].join(" "),
      filters: activeFilters((item) => item.state.status === "Active"),
      columns: [
        { label: "Trigger", value: (item) => item.name },
        { label: "Object", value: (item) => item.object },
        { label: "Status", value: (item) => item.state.status },
        { label: "API version", value: (item) => (item.apiVersion == null ? "" : String(item.apiVersion)) }
      ],
      actions: [
        { key: "enable", label: "Enable", title: "Set the selected triggers to Active (Metadata API deployment)", decide: (item) => (item.state.status === "Active" ? { skip: "Already active." } : item.state.status !== "Inactive" ? { skip: `Status is ${item.state.status}; it can't be enabled.` } : { field: "status", value: "Active" }) },
        { key: "disable", label: "Disable", title: "Set the selected triggers to Inactive (Metadata API deployment)", decide: (item) => (item.state.status === "Inactive" ? { skip: "Already inactive." } : item.state.status !== "Active" ? { skip: `Status is ${item.state.status}; it can't be disabled.` } : { field: "status", value: "Inactive" }) }
      ],
      blockReason: (item) => (item.namespace ? `Belongs to the ${item.namespace} managed package; managed triggers can't be deployed from this org.` : ""),
      restorable: (field, value) => value === "Active" || value === "Inactive",
      describe: (change) => (change.value === "Active" ? "enable" : "disable"),
      warnings: (actionKey, plan, org) => [
        org.isSandbox
          ? "Sandbox: the change is deployed with no Apex tests run (NoTestRun)."
          : "PRODUCTION: Salesforce requires a deployment that runs all local Apex tests (RunLocalTests). This can take several minutes; if any test fails, no trigger is changed.",
        "All selected triggers are deployed together: if one fails, none are changed."
      ]
    }
  };

  function filterItems(kind, items, search, filterValue) {
    const term = String(search || "").trim().toLowerCase();
    const filter = kind.filters.find((entry) => entry.value === filterValue) || kind.filters[0];
    return items.filter((item) => filter.test(item) && (!term || kind.searchText(item).toLowerCase().includes(term)));
  }

  function planAction(kind, items, actionKey, ctx) {
    const action = kind.actions.find((entry) => entry.key === actionKey);
    if (!action) throw new Error(`Unknown action: ${actionKey}`);
    const changes = [];
    const skipped = [];
    items.forEach((item) => {
      const blocked = kind.blockReason ? kind.blockReason(item, ctx) : "";
      if (blocked) {
        skipped.push({ item, reason: blocked });
        return;
      }
      const decision = action.decide(item, ctx);
      if (decision.skip) skipped.push({ item, reason: decision.skip });
      else changes.push({ id: item.id, name: item.name, detail: item.detail, field: decision.field, value: decision.value, item });
    });
    return { changes, skipped };
  }

  function planRestore(kind, backup, currentById, ctx) {
    const changes = [];
    const skipped = [];
    (backup.items || []).forEach((saved) => {
      const current = currentById.get(saved.id);
      if (!current) {
        skipped.push({ item: saved, reason: "No longer found in this org." });
        return;
      }
      const blocked = kind.blockReason ? kind.blockReason(current, ctx) : "";
      if (blocked) {
        skipped.push({ item: current, reason: blocked });
        return;
      }
      kind.stateFields.forEach((field) => {
        if (!saved.state || !(field in saved.state)) return;
        const value = saved.state[field];
        if (!kind.restorable(field, value) || current.state[field] === value) return;
        const reason = kind.restoreBlockReason ? kind.restoreBlockReason(current, field, value) : "";
        if (reason) skipped.push({ item: current, reason });
        else changes.push({ id: current.id, name: current.name, detail: current.detail, field, value, item: current });
      });
    });
    return { changes, skipped };
  }

  function createBackup({ kind, org, action, items, now, sourceBackupId }) {
    const createdAt = (now || new Date()).toISOString();
    return {
      id: `${createdAt}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt,
      type: kind.key,
      orgId: org.orgId,
      orgName: org.name,
      hostname: org.hostname,
      action,
      sourceBackupId: sourceBackupId || "",
      items: items.map((item) => ({ id: item.id, name: item.name, detail: item.detail || "", state: { ...item.state } })),
      result: null
    };
  }

  // Backups saved by the first version of the Users tab stored a `users` list.
  function normalizeBackup(backup) {
    if (!backup || Array.isArray(backup.items) || !Array.isArray(backup.users)) return backup;
    return {
      ...backup,
      type: "users",
      items: backup.users.map((user) => ({ id: user.id, name: user.name, detail: user.username || "", state: { isActive: user.isActive, isFrozen: user.isFrozen } }))
    };
  }

  // Normalizes an imported backup file and refuses anything that doesn't
  // belong to this tab and org or has no restorable state.
  function validateBackupFile(kind, data, orgId) {
    const backup = normalizeBackup(data);
    if (!backup || typeof backup !== "object" || !Array.isArray(backup.items)) throw new Error("This file isn't a Config Switch backup.");
    if (backup.type !== kind.key) throw new Error(`This backup is for the ${backup.type ? `"${backup.type}"` : "unknown"} tab, not ${kind.key}.`);
    if (!backup.orgId || backup.orgId !== orgId) throw new Error(`This backup was taken in a different org${backup.orgName ? ` (${backup.orgName})` : ""} and can't be restored here.`);
    const items = backup.items.filter((item) => item && typeof item.id === "string" && item.id && item.state && typeof item.state === "object"
      && kind.stateFields.some((field) => field in item.state && kind.restorable(field, item.state[field])));
    if (!items.length) throw new Error("The backup contains no items with a state that can be restored.");
    if (items.length !== backup.items.length) throw new Error(`${backup.items.length - items.length} item(s) in the backup are malformed, so it won't be used.`);
    return {
      ...backup,
      id: String(backup.id || ""),
      createdAt: String(backup.createdAt || ""),
      items: items.map((item) => ({ id: item.id, name: String(item.name || item.id), detail: String(item.detail || ""), state: { ...item.state } }))
    };
  }

  return {
    KINDS, MD_NS, escapeXml, decodeXml, stripPrefixes, blocks, childText, chunk, soapFault,
    readMetadataPayload, parseReadMetadata, setActive, updateMetadataPayload, parseSaveResults, parseListMetadata,
    parseDeployStatus, deployPayload, triggerPackageFiles, splitFullName, ruleItem, mergeUsers, buildUserBatches,
    formatErrors, readBatchOutcomes, filterItems, planAction, planRestore, createBackup, normalizeBackup, validateBackupFile, FLOW_TYPES
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = ConfigSwitchCore;

if (typeof document !== "undefined" && typeof SFPanel !== "undefined") ((SFPanel) => {
  const core = ConfigSwitchCore;
  const DEPLOY_POLL_MS = 2000;
  const DEPLOY_MAX_POLLS = 900;
  const orgCache = new Map();

  const dataPath = (suffix) => `/services/data/${SFPanel.API_VERSION}${suffix}`;
  const quoteIds = (ids) => ids.map((id) => `'${String(id).replace(/[^A-Za-z0-9]/g, "")}'`).join(",");

  async function request(hostname, method, path, body) {
    return SFPanel.sendMessage({ type: "restRequest", hostname, method, path, body });
  }

  async function queryAll(hostname, soql, tooling = false) {
    let result = await request(hostname, "GET", dataPath(`${tooling ? "/tooling" : ""}/query/?q=${encodeURIComponent(soql)}`));
    const records = [...(result.data.records || [])];
    while (result.data.nextRecordsUrl) {
      result = await request(hostname, "GET", result.data.nextRecordsUrl);
      records.push(...(result.data.records || []));
    }
    return records;
  }

  async function metadataCall(hostname, action, payload) {
    const body = `<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:met="${core.MD_NS}" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><env:Header/><env:Body><met:${action}>${payload}</met:${action}></env:Body></env:Envelope>`;
    const result = await SFPanel.sendMessage({ type: "metadataRequest", hostname, action, body });
    const text = String(result.data || "");
    const fault = core.soapFault(text);
    if (fault) throw new Error(`Salesforce Metadata API error: ${fault}`);
    return text;
  }

  async function mapLimited(values, limit, fn) {
    const results = new Array(values.length);
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(limit, values.length) }, async () => {
      while (next < values.length) {
        const index = next++;
        results[index] = await fn(values[index], index);
      }
    }));
    return results;
  }

  function getOrg(hostname) {
    if (!orgCache.has(hostname)) {
      const pending = SFPanel.sendMessage({ type: "getOrgInfo", hostname }).then((info) => ({
        orgId: info.orgId, name: info.name, isSandbox: info.isSandbox === true, userId: info.userId || "", userInfoError: info.userInfoError || "", hostname
      }));
      pending.catch(() => orgCache.delete(hostname));
      orgCache.set(hostname, pending);
    }
    return orgCache.get(hostname);
  }

  // ------------------------------ Users ---------------------------------
  const USER_FIELDS = "Id, Name, Username, Email, IsActive, UserType, Profile.Name, LastLoginDate";
  const usersIo = {
    async load(ctx) {
      const userRecords = await queryAll(ctx.hostname, `SELECT ${USER_FIELDS} FROM User ORDER BY Name`);
      let loginRecords = [];
      let loginError = "";
      try {
        loginRecords = await queryAll(ctx.hostname, "SELECT Id, UserId, IsFrozen FROM UserLogin");
      } catch (error) {
        loginError = `Frozen status couldn't be read, so Freeze and Unfreeze are disabled: ${error.message}`;
      }
      return {
        items: core.mergeUsers(userRecords, loginRecords, Boolean(loginError)),
        notices: loginError ? [loginError] : [],
        disabledActions: loginError ? { freeze: loginError, unfreeze: loginError } : {}
      };
    },
    async fetchFresh(ctx, ids) {
      const userRecords = [];
      const loginRecords = [];
      for (const idChunk of core.chunk(ids, 200)) {
        userRecords.push(...await queryAll(ctx.hostname, `SELECT ${USER_FIELDS} FROM User WHERE Id IN (${quoteIds(idChunk)})`));
        loginRecords.push(...await queryAll(ctx.hostname, `SELECT Id, UserId, IsFrozen FROM UserLogin WHERE UserId IN (${quoteIds(idChunk)})`));
      }
      return new Map(core.mergeUsers(userRecords, loginRecords).map((user) => [user.id, user]));
    },
    async apply(ctx, changes) {
      const outcomes = [];
      for (const batch of core.buildUserBatches(changes)) {
        try {
          const response = await request(ctx.hostname, "PATCH", dataPath("/composite/sobjects"), batch.body);
          outcomes.push(...core.readBatchOutcomes(batch, response.data));
        } catch (error) {
          batch.changes.forEach((change) => outcomes.push({ change, success: false, error: `Request failed; outcome unknown. Refresh to check the current state. ${error.message}` }));
        }
      }
      return outcomes;
    }
  };

  // ------------------- Workflow Rules and Validation Rules -------------------
  async function readRules(ctx, type, fullNames, onProgress) {
    let done = 0;
    const chunkResults = await mapLimited(core.chunk(fullNames, 10), 3, async (names) => {
      const records = core.parseReadMetadata(await metadataCall(ctx.hostname, "readMetadata", core.readMetadataPayload(type, names)));
      done += names.length;
      onProgress?.(done, fullNames.length);
      return names.map((name) => {
        const record = records.find((entry) => entry && entry.fullName === name);
        return [name, core.ruleItem(type, name, record)];
      });
    });
    return new Map(chunkResults.flat().filter(([, item]) => item));
  }

  async function applyRuleChanges(ctx, type, changes) {
    const outcomes = [];
    for (const batch of core.chunk(changes, 10)) {
      const ready = [];
      batch.forEach((change) => {
        try {
          ready.push({ change, inner: core.setActive(change.item.inner, change.value) });
        } catch (error) {
          outcomes.push({ change, success: false, error: error.message });
        }
      });
      if (!ready.length) continue;
      try {
        const results = core.parseSaveResults(await metadataCall(ctx.hostname, "updateMetadata", core.updateMetadataPayload(type, ready.map((entry) => entry.inner))));
        const saved = ready.filter(({ change }) => results.some((result) => result.fullName === change.id && result.success));
        let verified = new Map();
        let verificationError = "";
        if (saved.length) {
          try {
            verified = await readRules(ctx, type, saved.map(({ change }) => change.id));
          } catch (error) {
            verificationError = error.message;
          }
        }
        ready.forEach(({ change }) => {
          const result = results.find((entry) => entry.fullName === change.id);
          if (result?.success) {
            const current = verified.get(change.id);
            const success = current?.state.active === change.value;
            outcomes.push({
              change, success,
              error: success ? "" : verificationError
                ? `Salesforce accepted the save, but the current state couldn't be verified: ${verificationError}`
                : current ? `Salesforce accepted the save, but ${change.id} is still ${current.state.active ? "active" : "inactive"}.`
                  : "Salesforce accepted the save, but the rule couldn't be read back to verify its state."
            });
            return;
          }
          outcomes.push(result
            ? { change, success: result.success, error: result.success ? "" : (result.error || "Salesforce reported a failure without details.") }
            : { change, success: false, error: "Salesforce returned no result for this rule. Refresh to check its current state." });
        });
      } catch (error) {
        ready.forEach(({ change }) => outcomes.push({ change, success: false, error: `Request failed; outcome unknown. Refresh to check the current state. ${error.message}` }));
      }
    }
    return outcomes;
  }

  const workflowsIo = {
    async load(ctx) {
      const listed = core.parseListMetadata(await metadataCall(ctx.hostname, "listMetadata", `<met:queries><met:type>WorkflowRule</met:type></met:queries><met:asOfVersion>${SFPanel.API_VERSION.replace(/^v/i, "")}</met:asOfVersion>`));
      const names = Array.from(new Set(listed)).sort((a, b) => a.localeCompare(b));
      const byId = await readRules(ctx, "WorkflowRule", names, (done, total) => ctx.progress(`Reading workflow rules (${done} of ${total})...`));
      const missing = names.filter((name) => !byId.has(name));
      return {
        items: names.map((name) => byId.get(name)).filter(Boolean),
        notices: missing.length ? [`${missing.length} listed workflow rule(s) couldn't be read: ${missing.slice(0, 10).join(", ")}${missing.length > 10 ? ", ..." : ""}`] : []
      };
    },
    fetchFresh: (ctx, ids) => readRules(ctx, "WorkflowRule", ids),
    apply: (ctx, changes) => applyRuleChanges(ctx, "WorkflowRule", changes)
  };

  const validationIo = {
    async load(ctx) {
      const records = await queryAll(ctx.hostname, "SELECT Id, ValidationName, Active, Description, ErrorMessage, NamespacePrefix, EntityDefinition.QualifiedApiName FROM ValidationRule", true);
      const names = records.map((record) => {
        const object = record.EntityDefinition?.QualifiedApiName || "";
        if (!object) throw new Error(`The object for validation rule ${record.ValidationName} couldn't be read.`);
        const ruleName = `${record.NamespacePrefix ? `${record.NamespacePrefix}__` : ""}${record.ValidationName}`;
        return `${object}.${ruleName}`;
      });
      const byId = await readRules(ctx, "ValidationRule", names, (done, total) => ctx.progress(`Reading validation rules (${done} of ${total})...`));
      const missing = names.filter((name) => !byId.has(name));
      if (missing.length) throw new Error(`The current state of these validation rules couldn't be read: ${missing.join(", ")}.`);
      const items = names.map((name) => byId.get(name)).sort((a, b) => a.object.localeCompare(b.object) || a.name.localeCompare(b.name));
      return { items };
    },
    fetchFresh: (ctx, ids) => readRules(ctx, "ValidationRule", ids),
    apply: (ctx, changes) => applyRuleChanges(ctx, "ValidationRule", changes)
  };

  // --------------------------- Flows / Process Builder ---------------------------
  const FLOW_FIELDS = "Id, DeveloperName, NamespacePrefix, LatestVersionId, ActiveVersion.VersionNumber, LatestVersion.VersionNumber";

  function flowItem(record, version, known) {
    const name = `${record.NamespacePrefix ? `${record.NamespacePrefix}__` : ""}${record.DeveloperName}`;
    const processType = version?.ProcessType || known?.processType || "";
    return {
      id: record.Id,
      name,
      label: version?.MasterLabel || known?.label || name,
      detail: name,
      processType,
      typeLabel: processType ? (core.FLOW_TYPES[processType] || processType) : "Unknown",
      latestVersion: record.LatestVersion?.VersionNumber ?? null,
      state: { activeVersion: record.ActiveVersion?.VersionNumber ?? null }
    };
  }

  const flowsIo = {
    async load(ctx) {
      const definitions = await queryAll(ctx.hostname, `SELECT ${FLOW_FIELDS} FROM FlowDefinition`, true);
      const versions = new Map();
      const notices = [];
      try {
        const latestIds = definitions.map((record) => record.LatestVersionId).filter(Boolean);
        for (const idChunk of core.chunk(latestIds, 200)) {
          (await queryAll(ctx.hostname, `SELECT Id, MasterLabel, ProcessType FROM Flow WHERE Id IN (${quoteIds(idChunk)})`, true)).forEach((version) => versions.set(version.Id, version));
        }
      } catch (error) {
        notices.push(`Flow labels and types couldn't be read, so API names are shown and the type filters can't be used: ${error.message}`);
      }
      const items = definitions.map((record) => flowItem(record, versions.get(record.LatestVersionId)))
        .sort((a, b) => a.label.localeCompare(b.label));
      return { items, notices };
    },
    async fetchFresh(ctx, ids) {
      const map = new Map();
      for (const idChunk of core.chunk(ids, 200)) {
        (await queryAll(ctx.hostname, `SELECT ${FLOW_FIELDS} FROM FlowDefinition WHERE Id IN (${quoteIds(idChunk)})`, true))
          .forEach((record) => map.set(record.Id, flowItem(record, null, ctx.knownById.get(record.Id))));
      }
      return map;
    },
    async apply(ctx, changes) {
      const outcomes = [];
      for (const [index, change] of changes.entries()) {
        ctx.progress(`Updating flows (${index + 1} of ${changes.length})...`);
        const path = dataPath(`/tooling/sobjects/FlowDefinition/${encodeURIComponent(change.id)}`);
        let current;
        try {
          current = await request(ctx.hostname, "GET", path);
        } catch (error) {
          outcomes.push({ change, success: false, error: `The flow definition couldn't be read, so it wasn't changed. ${error.message}` });
          continue;
        }
        const metadata = current.data?.Metadata;
        if (!metadata || typeof metadata !== "object") {
          outcomes.push({ change, success: false, error: "Salesforce returned no flow definition metadata, so it wasn't changed." });
          continue;
        }
        try {
          await request(ctx.hostname, "PATCH", path, { Metadata: { ...metadata, activeVersionNumber: change.value } });
          outcomes.push({ change, success: true, error: "" });
        } catch (error) {
          outcomes.push({ change, success: false, error: `Request failed; outcome unknown. Refresh to check the current state. ${error.message}` });
        }
      }
      return outcomes;
    }
  };

  // ------------------------------ Apex Triggers ------------------------------
  async function customObjectNames(hostname, ids) {
    const names = new Map();
    for (const idChunk of core.chunk(ids, 200)) {
      (await queryAll(hostname, `SELECT Id, DeveloperName, NamespacePrefix FROM CustomObject WHERE Id IN (${quoteIds(idChunk)})`, true))
        .forEach((record) => names.set(record.Id, `${record.NamespacePrefix ? `${record.NamespacePrefix}__` : ""}${record.DeveloperName} (custom object)`));
    }
    return names;
  }

  function triggerItem(record, objectNames, known) {
    const table = record.TableEnumOrId || "";
    return {
      id: record.Id,
      name: record.Name,
      detail: known?.object || objectNames?.get(table) || table,
      object: known?.object || objectNames?.get(table) || table,
      namespace: record.NamespacePrefix || "",
      apiVersion: record.ApiVersion ?? null,
      body: record.Body,
      state: { status: record.Status }
    };
  }

  const triggersIo = {
    async load(ctx) {
      const records = await queryAll(ctx.hostname, "SELECT Id, Name, TableEnumOrId, Status, NamespacePrefix, ApiVersion FROM ApexTrigger", true);
      const notices = [];
      let objectNames = new Map();
      const customIds = Array.from(new Set(records.map((record) => record.TableEnumOrId).filter((value) => /^01I[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?$/.test(value || ""))));
      if (customIds.length) {
        try {
          objectNames = await customObjectNames(ctx.hostname, customIds);
        } catch (error) {
          notices.push(`Custom object names couldn't be read, so their IDs are shown: ${error.message}`);
        }
      }
      const items = records.map((record) => triggerItem(record, objectNames)).sort((a, b) => a.name.localeCompare(b.name));
      return { items, notices };
    },
    async fetchFresh(ctx, ids) {
      const map = new Map();
      for (const idChunk of core.chunk(ids, 50)) {
        (await queryAll(ctx.hostname, `SELECT Id, Name, TableEnumOrId, Status, NamespacePrefix, ApiVersion, Body FROM ApexTrigger WHERE Id IN (${quoteIds(idChunk)})`, true))
          .forEach((record) => map.set(record.Id, triggerItem(record, null, ctx.knownById.get(record.Id))));
      }
      return map;
    },
    async apply(ctx, changes) {
      const failAll = (error) => changes.map((change) => ({ change, success: false, error }));
      let files;
      try {
        files = core.triggerPackageFiles(changes.map((change) => ({ name: change.item.name, body: change.item.body, apiVersion: Number(change.item.apiVersion).toFixed(1), status: change.value })), SFPanel.API_VERSION.replace(/^v/i, ""));
      } catch (error) {
        return failAll(`${error.message} No trigger was changed.`);
      }
      const zip = new JSZip();
      Object.entries(files).forEach(([name, content]) => zip.file(name, content));
      const encoded = await zip.generateAsync({ type: "base64" });
      const testLevel = ctx.org.isSandbox ? "NoTestRun" : "RunLocalTests";
      ctx.progress(`Submitting trigger deployment (${testLevel})...`);
      let id;
      try {
        const started = core.parseDeployStatus(await metadataCall(ctx.hostname, "deploy", core.deployPayload(encoded, testLevel)));
        id = started.id;
      } catch (error) {
        return failAll(`The deployment couldn't be submitted; outcome unknown. Check Setup > Deployment Status, then Refresh. ${error.message}`);
      }
      if (!/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(id || "")) return failAll("Salesforce didn't return a deployment ID; outcome unknown. Check Setup > Deployment Status, then Refresh.");
      for (let attempt = 0; attempt < DEPLOY_MAX_POLLS; attempt++) {
        await new Promise((resolve) => setTimeout(resolve, DEPLOY_POLL_MS));
        let status;
        try {
          status = core.parseDeployStatus(await metadataCall(ctx.hostname, "checkDeployStatus", `<met:asyncProcessId>${id}</met:asyncProcessId><met:includeDetails>true</met:includeDetails>`));
        } catch (error) {
          ctx.progress(`Deployment ${id}: status check failed (${error.message}); retrying...`);
          continue;
        }
        if (!status.done) {
          ctx.progress(`Deployment ${id}: ${status.status || "In progress"}${status.testsTotal ? ` (tests ${status.testsCompleted} of ${status.testsTotal})` : ""}...`);
          continue;
        }
        if (status.success && status.status === "Succeeded") return changes.map((change) => ({ change, success: true, error: "" }));
        const testSummary = status.testFailures.slice(0, 5).map((failure) => `${failure.name}.${failure.method}: ${failure.message}`).join("; ");
        const general = `Deployment ${id} ${status.status || "failed"}; no trigger was changed. ${status.error || testSummary || ""}`.trim();
        return changes.map((change) => {
          const failure = status.componentFailures.find((entry) => entry.fullName === change.item.name);
          return { change, success: false, error: failure ? `${failure.problem} (deployment ${id}; no trigger was changed)` : general };
        });
      }
      return failAll(`Deployment ${id} was still running after ${Math.round((DEPLOY_MAX_POLLS * DEPLOY_POLL_MS) / 60000)} minutes; outcome unknown. Check Setup > Deployment Status, then Refresh.`);
    }
  };

  const IO = { users: usersIo, workflows: workflowsIo, flows: flowsIo, validation: validationIo, triggers: triggersIo };

  // ------------------------------ Generic UI ------------------------------
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(props).forEach(([key, value]) => {
      if (key === "dataset") Object.assign(node.dataset, value);
      else if (key === "attrs") Object.entries(value).forEach(([name, attr]) => node.setAttribute(name, attr));
      else node[key] = value;
    });
    children.forEach((child) => node.appendChild(child));
    return node;
  }

  function formatDate(value) {
    if (!value) return "Never";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
  }

  function createController(kind) {
    const panel = document.getElementById(kind.panelId);
    if (!panel) return null;
    const io = IO[kind.key];
    const st = { items: [], org: null, loadedHostname: null, busy: false, token: 0, disabledActions: {}, selected: new Set() };
    let restoreButtons = [];

    const searchInput = el("input", { type: "search", placeholder: "Search", attrs: { "aria-label": `Search ${kind.noun}` } });
    const filterSelect = el("select", { attrs: { "aria-label": "Filter" } }, kind.filters.map((filter) => el("option", { value: filter.value, textContent: filter.label })));
    filterSelect.value = kind.filters[0].value;
    const refreshButton = el("button", { type: "button", textContent: "Refresh", title: "Reload from Salesforce" });
    const backupNowButton = el("button", { type: "button", textContent: "Back up now", title: `Reload the list, then save the current state of all ${kind.noun.replace("(s)", "s")} as a backup and download it as a JSON file.` });
    const restoreFileButton = el("button", { type: "button", textContent: "Restore from file…", title: "Choose a backup JSON file downloaded from this tab and restore the state saved in it." });
    const restoreFileInput = el("input", { type: "file", accept: ".json,application/json", hidden: true, attrs: { "aria-hidden": "true", tabindex: "-1" } });
    const countEl = el("span", { className: "config-switch-count" });
    const selectedCountEl = el("span", { className: "config-switch-count", textContent: "0 selected" });
    const actionButtons = kind.actions.map((action) => el("button", { type: "button", textContent: action.label, title: action.title || "", dataset: { switchAction: action.key } }));
    const statusEl = el("div", { className: "config-switch-status", hidden: true, attrs: { role: "status", "aria-live": "polite" } });
    const selectAll = el("input", { type: "checkbox", title: "Select or clear all items shown by the current search and filter", attrs: { "aria-label": "Select all shown" } });
    const bodyEl = el("tbody");
    const backupCountEl = el("span");
    const backupBodyEl = el("tbody");
    const backupScroll = el("div", { className: "config-switch-backup-scroll" }, [
      el("table", { className: "config-switch-table config-switch-backup-table" }, [
        el("thead", {}, [el("tr", {}, ["Date", "Backup taken", "Items", "Result", "Actions"].map((label) => el("th", { textContent: label })))]),
        backupBodyEl
      ])
    ]);
    const backupDetails = el("details", { className: "config-switch-backups" }, [
      el("summary", {}, [el("span", { textContent: "Backups and restore " }), backupCountEl]),
      el("p", { className: "config-switch-help", textContent: "A backup of the affected items is saved here automatically before every change; use Back up now to save the state of all items at any time. Restore returns the items to the saved state (and backs up their current state first). Backups are kept in this browser until you delete them; use Download to keep a copy, and Restore from file to use it later." }),
      backupScroll
    ]);
    const splitHandle = el("div", { className: "config-switch-split", title: "Drag up or down to resize the backups section", attrs: { role: "separator", "aria-orientation": "horizontal", "aria-label": "Resize backups section", tabindex: "0" } });

    panel.textContent = "";
    panel.append(
      el("div", { className: "config-switch-toolbar" }, [searchInput, filterSelect, refreshButton, backupNowButton, restoreFileButton, restoreFileInput, countEl]),
      el("div", { className: "config-switch-actions", attrs: { role: "group", "aria-label": "Change selected items" } }, [selectedCountEl, ...actionButtons]),
      statusEl,
      el("div", { className: "config-switch-scroll" }, [
        el("table", { className: "config-switch-table" }, [
          el("thead", {}, [el("tr", {}, [el("th", { className: "config-switch-check" }, [selectAll]), ...kind.columns.map((column) => el("th", { textContent: column.label }))])]),
          bodyEl
        ])
      ]),
      splitHandle,
      backupDetails
    );

    (function initBackupResize() {
      const MIN_HEIGHT = 60;
      let startY = 0;
      let startHeight = 0;
      let dragging = false;
      const maxHeight = () => Math.max(MIN_HEIGHT, (panel.getBoundingClientRect?.().height || 600) - 220);
      function setHeight(height) {
        backupDetails.open = true;
        backupScroll.style.maxHeight = "none";
        backupScroll.style.height = `${Math.round(Math.min(maxHeight(), Math.max(MIN_HEIGHT, height)))}px`;
      }
      const currentHeight = () => (backupDetails.open ? backupScroll.getBoundingClientRect?.().height || 0 : 0);
      splitHandle.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        startY = event.clientY;
        startHeight = currentHeight();
        dragging = true;
        splitHandle.setPointerCapture?.(event.pointerId);
      });
      splitHandle.addEventListener("pointermove", (event) => {
        if (dragging) setHeight(startHeight + startY - event.clientY);
      });
      const stop = () => { dragging = false; };
      splitHandle.addEventListener("pointerup", stop);
      splitHandle.addEventListener("pointercancel", stop);
      splitHandle.addEventListener("keydown", (event) => {
        const movement = event.key === "ArrowUp" ? 30 : event.key === "ArrowDown" ? -30 : 0;
        if (!movement) return;
        event.preventDefault();
        setHeight(currentHeight() + movement);
      });
    })();

    const ctxBase = () => ({ currentUserId: st.org?.userId || "", formatDate });

    function setStatus(message, { kind: statusKind = "info", details = [], loading = false } = {}) {
      statusEl.textContent = "";
      statusEl.hidden = !message;
      statusEl.className = `config-switch-status ${statusKind}`;
      statusEl.setAttribute("role", statusKind === "error" ? "alert" : "status");
      statusEl.setAttribute("aria-busy", String(loading));
      if (!message) return;
      const line = el("div", { className: "config-switch-status-line" });
      if (loading) line.appendChild(el("span", { className: "export-loading-spinner", attrs: { "aria-hidden": "true" } }));
      line.appendChild(el("span", { textContent: message }));
      statusEl.appendChild(line);
      if (details.length) statusEl.appendChild(el("ul", {}, details.map((detail) => el("li", { textContent: detail }))));
    }

    function readBackups() {
      const raw = localStorage.getItem(kind.storageKey);
      if (!raw) return [];
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch {
        throw new Error("Saved backups can't be read (stored data is corrupt). No changes will be made until this is resolved.");
      }
      if (!Array.isArray(parsed)) throw new Error("Saved backups have an unexpected format. No changes will be made until this is resolved.");
      return parsed.map(core.normalizeBackup);
    }

    function writeBackups(backups) {
      localStorage.setItem(kind.storageKey, JSON.stringify(backups));
    }

    function saveBackup(backup) {
      const backups = readBackups();
      backups.unshift(backup);
      writeBackups(backups);
      if (!readBackups().some((entry) => entry.id === backup.id)) throw new Error("The backup could not be verified after saving.");
    }

    function updateBackupResult(backupId, result) {
      const backups = readBackups();
      const backup = backups.find((entry) => entry.id === backupId);
      if (!backup) return;
      backup.result = result;
      writeBackups(backups);
    }

    function changesBlockedReason() {
      if (!st.org) return "Not connected.";
      if (kind.requiresCurrentUser && !st.org.userId) return "Your own user couldn't be identified, so changes are disabled to avoid locking you out.";
      return "";
    }

    function visibleItems() {
      return core.filterItems(kind, st.items, searchInput.value, filterSelect.value);
    }

    function selectedVisibleItems() {
      return visibleItems().filter((item) => st.selected.has(item.id));
    }

    function updateControls() {
      const ctx = ctxBase();
      const selectable = visibleItems().filter((item) => !(kind.blockReason && kind.blockReason(item, ctx)));
      const selectedShown = selectable.filter((item) => st.selected.has(item.id)).length;
      selectAll.checked = selectable.length > 0 && selectedShown === selectable.length;
      selectAll.indeterminate = selectedShown > 0 && selectedShown < selectable.length;
      selectAll.disabled = st.busy || !selectable.length;
      const hiddenSelected = st.selected.size - selectedShown;
      selectedCountEl.textContent = `${selectedShown} selected${hiddenSelected ? ` (${hiddenSelected} hidden by search/filter, not included)` : ""}`;
      const blocked = changesBlockedReason();
      const targets = selectedVisibleItems();
      actionButtons.forEach((button, index) => {
        const reason = st.disabledActions[button.dataset.switchAction] || blocked;
        const plan = targets.length && !reason ? core.planAction(kind, targets, button.dataset.switchAction, ctx) : null;
        const nothingToDo = plan && !plan.changes.length;
        button.disabled = st.busy || !targets.length || Boolean(reason) || nothingToDo;
        button.title = reason || (nothingToDo ? `None of the selected ${kind.noun.replace("(s)", "s")} need this change.` : kind.actions[index].title || "");
      });
      refreshButton.disabled = st.busy;
      backupNowButton.disabled = st.busy || !st.org;
      restoreFileButton.disabled = st.busy || Boolean(blocked);
      restoreFileButton.title = blocked || "Choose a backup JSON file downloaded from this tab and restore the state saved in it.";
      restoreButtons.forEach((button) => { button.disabled = st.busy || Boolean(blocked); });
    }

    function renderItems() {
      const ctx = ctxBase();
      const shown = visibleItems();
      bodyEl.textContent = "";
      countEl.textContent = st.items.length ? `${shown.length} of ${st.items.length} shown` : "";
      if (!shown.length) {
        const td = el("td", { className: "config-switch-empty", colSpan: kind.columns.length + 1, textContent: st.items.length ? "Nothing matches the current search or filter." : st.loadedHostname ? `No ${kind.noun.replace("(s)", "s")} found.` : "Not loaded." });
        bodyEl.appendChild(el("tr", {}, [td]));
      }
      shown.forEach((item) => {
        const blocked = kind.blockReason ? kind.blockReason(item, ctx) : "";
        const row = el("tr");
        const checkbox = el("input", { type: "checkbox", checked: st.selected.has(item.id), disabled: Boolean(blocked) || st.busy, title: blocked, attrs: { "aria-label": `Select ${item.name}` } });
        checkbox.addEventListener("change", () => {
          if (checkbox.checked) st.selected.add(item.id);
          else st.selected.delete(item.id);
          row.classList.toggle("selected", checkbox.checked);
          updateControls();
        });
        row.classList.toggle("selected", checkbox.checked);
        row.appendChild(el("td", {}, [checkbox]));
        kind.columns.forEach((column) => row.appendChild(el("td", { textContent: column.value(item, ctx) ?? "", title: column.title ? column.title(item, ctx) : "" })));
        bodyEl.appendChild(row);
      });
      updateControls();
    }

    function renderBackups() {
      backupBodyEl.textContent = "";
      restoreButtons = [];
      const emptyRow = (text, className = "config-switch-empty") => backupBodyEl.appendChild(el("tr", {}, [el("td", { className, colSpan: 5, textContent: text })]));
      let backups;
      try {
        backups = readBackups();
      } catch (error) {
        backupCountEl.textContent = "";
        emptyRow(error.message, "config-switch-empty error");
        return;
      }
      const forOrg = backups.filter((backup) => st.org && backup.orgId === st.org.orgId);
      backupCountEl.textContent = `(${forOrg.length})`;
      if (!forOrg.length) {
        emptyRow(st.org ? "No backups for this org yet. A backup is saved automatically before every change." : "Connect to an org to see its backups.");
        updateControls();
        return;
      }
      forOrg.forEach((backup) => {
        const actionLabel = backup.action === "manual" ? "Manual backup" : backup.action === "restore" ? "Before restore" : `Before ${(kind.actions.find((action) => action.key === backup.action)?.label || backup.action).toLowerCase()}`;
        const restore = el("button", { type: "button", textContent: "Restore", title: "Return these items to the state saved in this backup. Their current state is backed up first.", dataset: { restore: backup.id } });
        restore.addEventListener("click", () => restoreBackup(backup.id));
        restoreButtons.push(restore);
        const download = el("button", { type: "button", textContent: "Download", title: "Download this backup as a JSON file." });
        download.addEventListener("click", () => downloadBackup(backup));
        const remove = el("button", { type: "button", textContent: "Delete", title: "Delete this backup from the extension." });
        remove.addEventListener("click", () => deleteBackup(backup.id));
        const count = backup.items.length;
        backupBodyEl.appendChild(el("tr", {}, [
          el("td", { textContent: formatDate(backup.createdAt) }),
          el("td", { textContent: actionLabel }),
          el("td", { textContent: `${count} ${count === 1 ? "item" : "items"}`, title: backup.items.map((item) => item.detail ? `${item.name} (${item.detail})` : item.name).join("\n") }),
          el("td", { textContent: backup.action === "manual" ? "Saved only" : backup.result ? `${backup.result.succeeded} succeeded, ${backup.result.failed} failed` : "Not applied" }),
          el("td", { className: "config-switch-backup-actions" }, [restore, download, remove])
        ]));
      });
      updateControls();
    }

    function downloadBackup(backup) {
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" }));
      const link = el("a", { href: url, download: `${kind.key}-backup-${String(backup.orgName || backup.orgId).replace(/[^\w.-]+/g, "_")}-${backup.createdAt.replace(/[:.]/g, "-")}.json` });
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function deleteBackup(backupId) {
      if (!confirm("Delete this backup? You will no longer be able to restore from it.")) return;
      try {
        writeBackups(readBackups().filter((backup) => backup.id !== backupId));
      } catch (error) {
        setStatus(error.message, { kind: "error" });
      }
      renderBackups();
    }

    function ioContext(token) {
      return {
        hostname: st.org.hostname,
        org: st.org,
        knownById: new Map(st.items.map((item) => [item.id, item])),
        progress: (message) => { if (token === st.token) setStatus(message, { loading: true }); }
      };
    }

    // finalStatus keeps an action's outcome visible after the list reloads.
    async function load(finalStatus) {
      const hostname = SFPanel.getHostname();
      const token = ++st.token;
      if (!hostname) {
        Object.assign(st, { items: [], org: null, loadedHostname: null, disabledActions: {}, busy: false });
        st.selected.clear();
        setStatus("Connect to a Salesforce org to use Config Switch.", { kind: "error" });
        renderItems();
        renderBackups();
        return;
      }
      st.busy = true;
      renderItems();
      setStatus("Loading...", { loading: true });
      try {
        const org = await getOrg(hostname);
        if (token !== st.token) return;
        st.org = org;
        const result = await io.load(ioContext(token));
        if (token !== st.token || hostname !== SFPanel.getHostname()) return;
        st.items = result.items;
        st.disabledActions = result.disabledActions || {};
        st.loadedHostname = hostname;
        const ids = new Set(st.items.map((item) => item.id));
        const ctx = ctxBase();
        st.items.forEach((item) => { if (kind.blockReason && kind.blockReason(item, ctx)) st.selected.delete(item.id); });
        Array.from(st.selected).forEach((id) => { if (!ids.has(id)) st.selected.delete(id); });
        const problems = [...(result.notices || [])];
        const blocked = kind.requiresCurrentUser && !org.userId ? `${changesBlockedReason()} ${org.userInfoError}`.trim() : "";
        if (blocked) problems.unshift(blocked);
        if (finalStatus?.message) setStatus(finalStatus.message, { kind: problems.length ? "error" : finalStatus.kind, details: [...finalStatus.details, ...problems] });
        else if (problems.length) setStatus(problems[0], { kind: "error", details: problems.slice(1) });
        else setStatus("");
        return true;
      } catch (error) {
        if (token !== st.token) return;
        if (finalStatus?.message) setStatus(finalStatus.message, { kind: "error", details: [...finalStatus.details, `The list couldn't be reloaded: ${error.message}`] });
        else setStatus(`Couldn't load ${kind.noun.replace("(s)", "s")}: ${error.message}`, { kind: "error" });
      } finally {
        if (token === st.token) {
          st.busy = false;
          renderItems();
          renderBackups();
        }
      }
    }

    function describe(change) {
      return `${kind.describe(change)} ${change.name}${change.detail && change.detail !== change.name ? ` (${change.detail})` : ""}`;
    }

    function confirmText(title, plan, actionKey) {
      const lines = plan.changes.map(describe);
      const shown = lines.slice(0, 15);
      if (lines.length > shown.length) shown.push(`...and ${lines.length - shown.length} more`);
      const text = [`${title} in ${st.org.name}${st.org.isSandbox ? " (sandbox)" : " (PRODUCTION)"}?`, "", ...shown, ""];
      if (plan.skipped.length) text.push(`${plan.skipped.length} item(s) will be skipped (already in that state or not changeable).`);
      text.push(...kind.warnings(actionKey, plan, st.org), "A backup of the current state is saved before any change.");
      return text.join("\n");
    }

    function outcomeStatus(label, plan, outcomes) {
      const succeeded = outcomes.filter((outcome) => outcome.success).length;
      const failed = outcomes.length - succeeded;
      const details = [
        ...outcomes.filter((outcome) => !outcome.success).map((outcome) => `Failed to ${describe(outcome.change)}: ${outcome.error}`),
        ...plan.skipped.map((skip) => `Skipped ${skip.item.name || skip.item.id}${skip.item.detail && skip.item.detail !== skip.item.name ? ` (${skip.item.detail})` : ""}: ${skip.reason}`)
      ];
      return { message: `${label}: ${succeeded} succeeded, ${failed} failed${plan.skipped.length ? `, ${plan.skipped.length} skipped` : ""}.`, kind: failed ? "error" : "success", details, succeeded, failed };
    }

    function reportNothingToDo(label, plan) {
      setStatus(`${label}: no changes needed.`, { details: plan.skipped.map((skip) => `${skip.item.name || skip.item.id}: ${skip.reason}`) });
    }

    async function applyPlan(plan, action, sourceBackupId, label, token) {
      const affected = Array.from(new Map(plan.changes.map((change) => [change.id, change.item])).values());
      const backup = core.createBackup({ kind, org: st.org, action, items: affected, sourceBackupId });
      try {
        saveBackup(backup);
      } catch (error) {
        throw new Error(`The backup couldn't be saved, so no changes were made. ${error.message}`);
      }
      renderBackups();
      setStatus(`${label}: backup saved. Applying ${plan.changes.length} change(s)...`, { loading: true });
      const outcomes = await io.apply(ioContext(token), plan.changes);
      const status = outcomeStatus(label, plan, outcomes);
      updateBackupResult(backup.id, { succeeded: status.succeeded, failed: status.failed, completedAt: new Date().toISOString() });
      return status;
    }

    async function runAction(actionKey) {
      if (st.busy || changesBlockedReason()) return;
      const action = kind.actions.find((entry) => entry.key === actionKey);
      const label = `${action.label} ${kind.noun.replace("(s)", "s")}`;
      const token = st.token;
      st.busy = true;
      renderItems();
      setStatus(`${label}: reading the current state of the selected items...`, { loading: true });
      let finalStatus = null;
      try {
        const ids = selectedVisibleItems().map((item) => item.id);
        const fresh = await io.fetchFresh(ioContext(token), ids);
        const missing = ids.filter((id) => !fresh.has(id)).map((id) => ({ item: st.items.find((item) => item.id === id) || { id, name: id }, reason: "No longer found in this org." }));
        const plan = core.planAction(kind, ids.filter((id) => fresh.has(id)).map((id) => fresh.get(id)), actionKey, ctxBase());
        plan.skipped.push(...missing);
        if (!plan.changes.length) {
          reportNothingToDo(label, plan);
          return;
        }
        if (!confirm(confirmText(`${action.label} ${plan.changes.length} ${kind.noun}`, plan, actionKey))) {
          setStatus(`${label}: cancelled. No changes were made.`);
          return;
        }
        finalStatus = await applyPlan(plan, actionKey, "", label, token);
      } catch (error) {
        setStatus(`${label}: ${error.message}`, { kind: "error" });
      } finally {
        st.busy = false;
        renderItems();
      }
      if (finalStatus) await load(finalStatus);
    }

    async function restoreBackup(backupId) {
      if (st.busy || changesBlockedReason()) return;
      let backup;
      try {
        backup = readBackups().find((entry) => entry.id === backupId);
      } catch (error) {
        setStatus(error.message, { kind: "error" });
        return;
      }
      if (!backup) return setStatus("That backup no longer exists.", { kind: "error" });
      if (backup.orgId !== st.org.orgId) return setStatus("That backup belongs to a different org and can't be restored here.", { kind: "error" });
      await restoreFrom(backup, "Restore", `the backup of ${formatDate(backup.createdAt)}`);
    }

    async function restoreFromFile(file) {
      if (!file || st.busy || changesBlockedReason()) return;
      const label = "Restore from file";
      let backup;
      try {
        let data;
        try {
          data = JSON.parse(await file.text());
        } catch {
          throw new Error("The file isn't valid JSON.");
        }
        backup = core.validateBackupFile(kind, data, st.org.orgId);
      } catch (error) {
        setStatus(`${label}: ${file.name || "file"} can't be used. ${error.message} No changes were made.`, { kind: "error" });
        return;
      }
      await restoreFrom(backup, label, `${file.name || "the file"}${backup.createdAt ? ` (backup of ${formatDate(backup.createdAt)})` : ""}`);
    }

    async function restoreFrom(backup, label, sourceText) {
      const token = st.token;
      st.busy = true;
      renderItems();
      setStatus(`${label}: reading the current state of ${backup.items.length} item(s)...`, { loading: true });
      let finalStatus = null;
      try {
        const fresh = await io.fetchFresh(ioContext(token), backup.items.map((item) => item.id));
        const plan = core.planRestore(kind, backup, fresh, ctxBase());
        if (!plan.changes.length) {
          reportNothingToDo(label, plan);
          return;
        }
        if (!confirm(confirmText(`Restore ${plan.changes.length} change(s) from ${sourceText}`, plan, "restore"))) {
          setStatus(`${label}: cancelled. No changes were made.`);
          return;
        }
        finalStatus = await applyPlan(plan, "restore", backup.id, label, token);
      } catch (error) {
        setStatus(`${label}: ${error.message}`, { kind: "error" });
      } finally {
        st.busy = false;
        renderItems();
        renderBackups();
      }
      if (finalStatus) await load(finalStatus);
    }

    async function backupNow() {
      if (st.busy || !st.org) return;
      if (!(await load()) || !st.org) return;
      if (!st.items.length) {
        setStatus(`Back up now: there are no ${kind.noun.replace("(s)", "s")} to back up.`);
        return;
      }
      const backup = core.createBackup({ kind, org: st.org, action: "manual", items: st.items });
      backup.result = null;
      let saveError = "";
      try {
        saveBackup(backup);
      } catch (error) {
        saveError = error.message;
      }
      downloadBackup(backup);
      renderBackups();
      const count = `${backup.items.length} ${backup.items.length === 1 ? "item" : "items"}`;
      if (saveError) setStatus(`Back up now: the backup of ${count} was downloaded, but it couldn't be saved in this browser. ${saveError}`, { kind: "error" });
      else setStatus(`Back up now: saved the current state of ${count} and downloaded it as a JSON file.`, { kind: "success" });
    }

    selectAll.addEventListener("change", () => {
      const ctx = ctxBase();
      visibleItems().forEach((item) => {
        if (kind.blockReason && kind.blockReason(item, ctx)) return;
        if (selectAll.checked) st.selected.add(item.id);
        else st.selected.delete(item.id);
      });
      renderItems();
    });
    searchInput.addEventListener("input", renderItems);
    filterSelect.addEventListener("change", renderItems);
    refreshButton.addEventListener("click", () => load());
    backupNowButton.addEventListener("click", () => backupNow());
    restoreFileButton.addEventListener("click", () => {
      restoreFileInput.value = "";
      restoreFileInput.click();
    });
    restoreFileInput.addEventListener("change", () => restoreFromFile(restoreFileInput.files?.[0]));
    actionButtons.forEach((button) => button.addEventListener("click", () => runAction(button.dataset.switchAction)));

    const controller = {
      panel,
      ensureLoaded() {
        if (SFPanel.getActiveTab() !== "configSwitch" || panel.hidden) return;
        if (st.loadedHostname !== SFPanel.getHostname() && !st.busy) load();
      },
      reset() {
        st.token++;
        Object.assign(st, { items: [], org: null, loadedHostname: null, disabledActions: {}, busy: false });
        st.selected.clear();
        setStatus("");
        renderItems();
        renderBackups();
      }
    };
    panel.addEventListener("tabpanelshow", () => controller.ensureLoaded());
    renderItems();
    renderBackups();
    return controller;
  }

  const controllers = Object.values(core.KINDS).map(createController).filter(Boolean);

  SFPanel.registerTab("configSwitch", {
    onShow() {
      if (SFPanel.canUseTab("configSwitch")) controllers.forEach((controller) => controller.ensureLoaded());
    },
    onHostnameChange() {
      controllers.forEach((controller) => controller.reset());
      controllers.forEach((controller) => controller.ensureLoaded());
    }
  });
})(SFPanel.forTools("configSwitch"));
