// js/apex.js — Apex Explorer: Classes/Triggers list (left) with a multi-tab editor.
// Each tab owns its Monaco model, including its buffer and undo history.

((SFPanel) => {
  const typeTabs = document.querySelectorAll("[data-apex-type]");
  const searchInput = document.getElementById("apexSearch");
  const newButton = document.getElementById("apexNew");
  const refreshButton = document.getElementById("apexRefresh");
  const listEl = document.getElementById("apexList");
  const resizeHandle = document.getElementById("apexResizeHandle");
  const tabBarEl = document.getElementById("apexTabBar");
  const emptyStateEl = document.getElementById("apexEmptyState");
  const codeEl = document.getElementById("apexCode");
  const saveButton = document.getElementById("apexSave");
  const runTestsButton = document.getElementById("apexRunTests");
  const runAllTestsButton = document.getElementById("apexRunAllTests");
  const cancelAllTestsButton = document.getElementById("apexCancelAllTests");
  const runAnonymousButton = document.getElementById("apexRunAnonymous");
  const anonymousLayoutToggle = document.getElementById("apexAnonymousLayoutToggle");
  const tabMenu = document.getElementById("apexTabMenu");
  const newForm = document.getElementById("apexNewForm");
  const newNameInput = document.getElementById("apexNewName");
  const newObjectGroup = document.getElementById("apexNewObjectGroup");
  const newObjectSelect = document.getElementById("apexNewObjectSelect");
  const newEventsGroup = document.getElementById("apexNewEventsGroup");
  const newEventCheckboxes = document.querySelectorAll('input[name="apexTriggerEvent"]');
  const newPreviewEl = document.getElementById("apexNewPreview");
  const newCancelButton = document.getElementById("apexNewCancel");
  const problemsPanel = document.getElementById("apexProblemsPanel");
  const problemsTitle = document.getElementById("apexProblemsTitle");
  const problemsList = document.getElementById("apexProblemsList");
  const codeProblemsResizeHandle = document.getElementById("apexCodeProblemsResizeHandle");
  const apexSplit = document.querySelector("#tab-apex .apex-split");
  const coverageWorkspace = document.getElementById("apexCoverageWorkspace");
  const logsWorkspace = document.getElementById("apexLogsWorkspace");
  const startLogCaptureButton = document.getElementById("apexStartLogCapture");
  const stopLogCaptureButton = document.getElementById("apexStopLogCapture");
  const refreshLogsButton = document.getElementById("apexRefreshLogs");
  const clearLogsButton = document.getElementById("apexClearLogs");
  const logsStatus = document.getElementById("apexLogsStatus");
  const logsList = document.getElementById("apexLogsList");
  const logsResizeHandle = document.getElementById("apexLogsResizeHandle");
  const logDebugOnly = document.getElementById("apexLogDebugOnly");
  const logSearch = document.getElementById("apexLogSearch");
  const logBody = document.getElementById("apexLogBody");
  const coverageEmpty = document.getElementById("apexCoverageEmpty");
  const coverageReport = document.getElementById("apexCoverageReport");
  const testRunActivity = document.getElementById("apexTestRunActivity");
  const clearCoverageButton = document.getElementById("apexClearCoverage");
  const testRunList = document.getElementById("apexTestRunList");
  const testMenuButton = document.getElementById("apexTestMenuButton");
  const testMenu = document.getElementById("apexTestMenu");
  const newRunPanel = document.getElementById("apexNewRunPanel");
  const cancelNewRunButton = document.getElementById("apexCancelNewRun");
  const startNewRunButton = document.getElementById("apexStartNewRun");
  const testLog = document.getElementById("apexTestLog");
  const testLogsResizeHandle = document.getElementById("apexTestLogsResizeHandle");
  const testCoverageResizeHandle = document.getElementById("apexTestCoverageResizeHandle");
  const testRunSelector = document.getElementById("apexTestRunSelector");
  const testRunHistoryMenu = document.getElementById("apexTestRunHistoryMenu");
  const newRunSearch = document.getElementById("apexNewRunSearch");
  const newRunSelectAll = document.getElementById("apexNewRunSelectAll");
  const newRunClassList = document.getElementById("apexNewRunClassList");

  let currentType = "ApexClass";
  let loadedHostname = null;
  const recordsByType = new Map(); // type -> records[]
  const bodyCache = new Map(); // "type:id" -> last known saved body, used to reopen tabs instantly
  const openTabs = []; // { key, type, record, doc, savedValue }
  let activeTabKey = null;
  let tabMenuTarget = null;
  let editor = null;
  let errorLineHandles = [];
  let anonymousTabSequence = 0;
  let activeAllTestRun = null;
  let allTestReport = null;
  let coverageOverviewHostname = null;
  let debugLogPollTimer = null;
  let selectedDebugLogId = null;
  let displayedDebugLogs = [];
  let selectedDebugLogBody = "";
  let debugLogCapture = null;
  const testRunHistory = [];
  let selectableTestClasses = [];

  function keyFor(type, id) {
    return `${type}:${id}`;
  }

  function setStatus(message, isError = true) {
    if (!message) {
      problemsList.textContent = getActiveTab()?.type === "AnonymousApex" ? "No execution result." : "No problems.";
      problemsList.style.color = "";
      return;
    }
    if (isError) {
      problemsPanel.open = true;
    }
    problemsTitle.textContent = getActiveTab()?.type === "AnonymousApex" ? "Result" : "Problems";
    problemsList.textContent = message;
    problemsList.style.color = isError ? "#c00" : "inherit";
  }

  function setCoverageStatus(message, isError = false) {
    testRunActivity.textContent = "";
    testRunActivity.hidden = !message;
    testRunActivity.classList.toggle("is-error", Boolean(message && isError));
    testRunActivity.classList.toggle("is-loading", Boolean(message && !isError && activeAllTestRun));
    if (!message) return;
    if (!isError && activeAllTestRun) {
      const spinner = document.createElement("span");
      spinner.className = "apex-anonymous-spinner";
      spinner.setAttribute("aria-hidden", "true");
      testRunActivity.appendChild(spinner);
    }
    testRunActivity.appendChild(document.createTextNode(message));
  }

  function getActiveTab() {
    return openTabs.find((tab) => tab.key === activeTabKey) || null;
  }

  function isTabDirty(tab) {
    return tab.doc.getValue() !== tab.savedValue;
  }

  function hasAnyUnsavedChanges() {
    return openTabs.some(isTabDirty);
  }

  function getEditor() {
    if (editor) return editor;
    editor = window.SFMonaco.createApexEditor(codeEl);
    return editor;
  }

  function clearErrorMarkers() {
    if (editor) errorLineHandles.forEach((handle) => editor.removeLineClass(handle, "background", "apex-error-line"));
    errorLineHandles = [];
  }

  function hideProblems() {
    const isAnonymous = getActiveTab()?.type === "AnonymousApex";
    problemsTitle.textContent = isAnonymous ? "Result" : "Problems";
    problemsList.textContent = isAnonymous ? "No execution result." : "No problems.";
    clearErrorMarkers();
  }

  // Strips block/line comments and string literals so annotation detection can't be
  // fooled by things like "// @isTest" in a comment or a string containing the text.
  function stripApexNoise(code) {
    return code
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/\/\/.*$/gm, "")
      .replace(/'(?:\\.|[^'\\])*'/g, "");
  }

  function updateToolbarState() {
    const tab = getActiveTab();
    const isAnonymous = tab?.type === "AnonymousApex";
    saveButton.disabled = !tab || isAnonymous || !isTabDirty(tab);
    const isTestClass = tab && tab.type === "ApexClass" && /@istest\b/i.test(stripApexNoise(tab.doc.getValue()));
    runTestsButton.hidden = !isTestClass;
    runAnonymousButton.hidden = !isAnonymous;
    anonymousLayoutToggle.hidden = !isAnonymous;
  }

  function closeTabMenu() {
    tabMenu.hidden = true;
    tabMenuTarget = null;
  }

  function openTabMenu(tab, anchorEl) {
    if (tabMenuTarget === tab && !tabMenu.hidden) {
      closeTabMenu();
      return;
    }
    tabMenuTarget = tab;
    const rect = anchorEl.getBoundingClientRect();
    tabMenu.style.left = `${Math.round(rect.left)}px`;
    tabMenu.style.top = `${Math.round(rect.bottom + 2)}px`;
    tabMenu.hidden = false;
  }

  function renderTabBar() {
    closeTabMenu();
    tabBarEl.textContent = "";
    openTabs.filter((tab) => tab.type === currentType).forEach((tab) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "apex-tab";
      chip.classList.toggle("active", tab.key === activeTabKey);

      const dot = document.createElement("span");
      dot.className = "apex-tab-dirty-dot";
      dot.hidden = !isTabDirty(tab);
      dot.textContent = "●";

      const label = document.createElement("span");
      label.className = "apex-tab-label";
      label.textContent = tab.record.Name;

      const menuButton = document.createElement("span");
      menuButton.className = "apex-tab-menu-button";
      menuButton.textContent = "▾";
      menuButton.setAttribute("role", "button");
      menuButton.setAttribute("aria-label", `More actions for ${tab.record.Name}`);
      menuButton.addEventListener("click", (event) => {
        event.stopPropagation();
        openTabMenu(tab, menuButton);
      });

      const close = document.createElement("span");
      close.className = "apex-tab-close";
      close.textContent = "×";
      close.setAttribute("aria-label", `Close ${tab.record.Name}`);
      close.addEventListener("click", (event) => {
        event.stopPropagation();
        closeTabs([tab]);
      });

      chip.append(dot, label, menuButton, close);
      chip.addEventListener("click", () => activateTab(tab));
      tabBarEl.appendChild(chip);
    });
    if (currentType === "AnonymousApex") {
      const addButton = document.createElement("button");
      addButton.type = "button";
      addButton.className = "apex-tab-add";
      addButton.textContent = "+";
      addButton.title = "New Anonymous Apex tab";
      addButton.setAttribute("aria-label", "New Anonymous Apex tab");
      addButton.addEventListener("click", openAnonymousTab);
      tabBarEl.appendChild(addButton);
    }
  }

  function activateTab(tab) {
    activeTabKey = tab.key;
    codeEl.hidden = false;
    emptyStateEl.hidden = true;
    const cm = getEditor();
    cm.swapDoc(tab.doc);
    hideProblems();
    cm.refresh();
    cm.focus();
    renderTabBar();
    renderList();
    updateToolbarState();
  }

  function showEmptyState() {
    activeTabKey = null;
    codeEl.hidden = true;
    emptyStateEl.hidden = false;
    hideProblems();
    renderTabBar();
    renderList();
    updateToolbarState();
  }

  // Shared close path for a single tab or a bulk close (Close Others/Close All),
  // asking once even when multiple unsaved tabs are being discarded together.
  function closeTabs(tabsToClose) {
    const dirtyCount = tabsToClose.filter(isTabDirty).length;
    if (dirtyCount > 0) {
      const message =
        dirtyCount === 1
          ? "Discard unsaved changes to this file?"
          : `Discard unsaved changes to ${dirtyCount} files?`;
      if (!window.confirm(message)) return;
    }

    const closingActiveTab = tabsToClose.some((tab) => tab.key === activeTabKey);
    tabsToClose.forEach((tab) => {
      const index = openTabs.indexOf(tab);
      if (index !== -1) openTabs.splice(index, 1);
    });

    if (!closingActiveTab) {
      renderTabBar();
      return;
    }
    const next = [...openTabs].reverse().find((tab) => tab.type === currentType);
    if (next) activateTab(next);
    else showEmptyState();
  }

  tabMenu.querySelectorAll(".apex-tab-menu-item").forEach((item) => {
    item.addEventListener("click", () => {
      const tab = tabMenuTarget;
      closeTabMenu();
      if (!tab) return;
      if (item.dataset.action === "close-others") {
        closeTabs(openTabs.filter((other) => other.key !== tab.key));
      } else if (item.dataset.action === "close-all") {
        closeTabs([...openTabs]);
      }
    });
  });

  document.addEventListener("click", (event) => {
    if (!tabMenu.hidden && !tabMenu.contains(event.target) && !event.target.closest(".apex-tab-menu-button")) {
      closeTabMenu();
    }
  });

  function openTabForRecord(type, record, body) {
    const key = keyFor(type, record.Id);
    const existing = openTabs.find((tab) => tab.key === key);
    if (existing) {
      activateTab(existing);
      return existing;
    }
    const tab = { key, type, record, savedValue: body };
    tab.doc = window.SFMonaco.createApexDocument(body, () => {
      renderTabBar();
      updateToolbarState();
    });
    openTabs.push(tab);
    activateTab(tab);
    return tab;
  }

  function openAnonymousTab() {
    anonymousTabSequence += 1;
    const key = `AnonymousApex:${anonymousTabSequence}`;
    const body = "System.debug('Hello from Anonymous Apex');\n";
    const tab = { key, type: "AnonymousApex", record: { Id: String(anonymousTabSequence), Name: `Code ${anonymousTabSequence}` }, savedValue: body };
    tab.doc = window.SFMonaco.createApexDocument(body, () => {
      renderTabBar();
      updateToolbarState();
    });
    openTabs.push(tab);
    activateTab(tab);
  }

  function parseApiError(err) {
    const match = err.message.match(/^Salesforce API error (\d+): ([\s\S]*)$/);
    if (!match) return [{ message: err.message }];
    try {
      const parsed = JSON.parse(match[2]);
      return Array.isArray(parsed) ? parsed : [parsed];
    } catch {
      return [{ message: match[2] }];
    }
  }

  function extractLineColumn(message) {
    const lineCol = message.match(/line\s+(\d+)(?:,?\s*column\s+(\d+))?/i) || message.match(/\(:?\s*(\d+)\s*,\s*(\d+)\s*\)/);
    if (!lineCol) return null;
    return { line: Number(lineCol[1]), column: Number(lineCol[2]) || 1 };
  }

  function showCompileErrors(entries) {
    problemsPanel.open = true;
    problemsTitle.textContent = "Problems";
    problemsList.textContent = "";
    clearErrorMarkers();

    entries.forEach((entry) => {
      const message = entry.message || String(entry);
      const position = extractLineColumn(message);
      const row = document.createElement("div");
      row.className = "apex-problem is-error";
      const text = document.createElement("div");
      text.className = "apex-problem-message";
      text.textContent = position ? `Line ${position.line}: ${message}` : message;
      if (position && editor) {
        text.addEventListener("click", () => {
          editor.setCursor({ line: position.line - 1, ch: position.column - 1 });
          editor.focus();
        });
        const handle = editor.addLineClass(position.line - 1, "background", "apex-error-line");
        errorLineHandles.push(handle);
      }
      row.appendChild(text);
      problemsList.appendChild(row);
    });
  }

  function showTestResults(result) {
    problemsPanel.open = true;
    problemsTitle.textContent = `Test Results — ${result.successes.length} passed, ${result.failures.length} failed`;
    problemsList.textContent = "";

    result.successes.forEach((success) => {
      const row = document.createElement("div");
      row.className = "apex-problem is-pass";
      row.textContent = `✓ ${success.methodName}`;
      problemsList.appendChild(row);
    });


    result.failures.forEach((failure) => {
      const row = document.createElement("div");
      row.className = "apex-problem is-error";
      const text = document.createElement("div");
      text.className = "apex-problem-message";
      text.textContent = `✗ ${failure.methodName} — click to expand`;
      const detail = document.createElement("pre");
      detail.className = "apex-problem-detail";
      detail.textContent = `${failure.message || ""}\n${failure.stackTrace || ""}`.trim();
      detail.hidden = true;
      text.addEventListener("click", () => {
        detail.hidden = !detail.hidden;
      });
      row.append(text, detail);
      problemsList.appendChild(row);
    });
  }

  function openFailureClass(failure) {
    if (!failure.ApexClassId) return;
    switchType("ApexClass");
    selectRecord({ Id: failure.ApexClassId, Name: failure.ApexClass?.Name || failure.ApexClassName || "Failed class" });
  }

  function coverageKey(item) {
    return item.ApexClassOrTriggerId || item.ApexClassOrTrigger?.Id || item.ApexClassOrTrigger?.Name || "";
  }

  function coverageTotals(coverage) {
    return coverage.reduce((totals, item) => ({
      covered: totals.covered + (item.NumLinesCovered || 0),
      uncovered: totals.uncovered + (item.NumLinesUncovered || 0)
    }), { covered: 0, uncovered: 0 });
  }

  function coveragePercentage(totals) {
    const total = totals.covered + totals.uncovered;
    return total ? Math.round((totals.covered / total) * 100) : 0;
  }

  function appendReportTable(parent, columns, rows) {
    const table = document.createElement("table");
    table.className = "apex-results-table";
    const head = document.createElement("thead");
    const headRow = document.createElement("tr");
    columns.forEach((column) => {
      const cell = document.createElement("th");
      cell.textContent = column;
      headRow.appendChild(cell);
    });
    head.appendChild(headRow);
    const body = document.createElement("tbody");
    rows.forEach((cells) => {
      const row = document.createElement("tr");
      cells.forEach((cell) => {
        const value = document.createElement("td");
        if (cell instanceof Node) value.appendChild(cell);
        else value.textContent = cell;
        row.appendChild(value);
      });
      body.appendChild(row);
    });
    table.append(head, body);
    parent.appendChild(table);
    makeTableColumnsResizable(table);
  }

  function makeTableColumnsResizable(table) {
    const headers = Array.from(table.querySelectorAll("th"));
    headers.forEach((header, index) => {
      if (index === headers.length - 1) return;
      const handle = document.createElement("span");
      handle.className = "apex-table-column-resize";
      handle.setAttribute("role", "separator");
      handle.setAttribute("aria-label", `Resize ${header.textContent} column`);
      handle.tabIndex = 0;
      header.appendChild(handle);
      let startX = 0;
      let startWidth = 0;
      const resize = (clientX) => {
        const width = Math.max(64, startWidth + clientX - startX);
        header.style.width = `${Math.round(width)}px`;
      };
      handle.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        startX = event.clientX;
        startWidth = header.getBoundingClientRect().width;
        const move = (moveEvent) => resize(moveEvent.clientX);
        const end = () => {
          document.removeEventListener("pointermove", move);
          document.removeEventListener("pointerup", end);
        };
        document.addEventListener("pointermove", move);
        document.addEventListener("pointerup", end);
      });
      handle.addEventListener("keydown", (event) => {
        const step = event.key === "ArrowLeft" ? -20 : event.key === "ArrowRight" ? 20 : 0;
        if (!step) return;
        event.preventDefault();
        header.style.width = `${Math.max(64, Math.round(header.getBoundingClientRect().width + step))}px`;
      });
    });
  }

  function renderTestRunSelector() {
    testRunHistoryMenu.textContent = "";
    testRunHistory.forEach((report, index) => {
      const option = document.createElement("button");
      option.type = "button";
      option.className = "apex-test-history-item";
      const failures = report.results.filter((result) => result.Outcome !== "Pass").length;
      option.textContent = `${report.completedAt.toLocaleString()} - ${failures ? `${failures} failed` : "Passed"}`;
      option.classList.toggle("active", report === allTestReport);
      option.addEventListener("click", () => {
        allTestReport = testRunHistory[index];
        testRunHistoryMenu.hidden = true;
        testRunSelector.setAttribute("aria-expanded", "false");
        renderAllTestResults();
      });
      testRunHistoryMenu.appendChild(option);
    });
    testRunSelector.disabled = !testRunHistory.length;
  }

  function renderNewRunClassList() {
    const term = newRunSearch.value.trim().toLowerCase();
    const selectedIds = new Set(Array.from(newRunClassList.querySelectorAll("input:checked")).map((input) => input.value));
    newRunClassList.textContent = "";
    const visible = selectableTestClasses.filter((record) => !term || record.Name.toLowerCase().includes(term));
    visible.forEach((record) => {
      const label = document.createElement("label");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.value = record.Id;
      checkbox.checked = selectedIds.has(record.Id);
      checkbox.addEventListener("change", updateNewRunSelection);
      label.append(checkbox, document.createTextNode(record.Name));
      newRunClassList.appendChild(label);
    });
    if (!visible.length) newRunClassList.textContent = "No test classes found.";
    updateNewRunSelection();
  }

  function updateNewRunSelection() {
    const boxes = Array.from(newRunClassList.querySelectorAll("input[type=checkbox]"));
    startNewRunButton.disabled = !boxes.some((box) => box.checked);
    newRunSelectAll.checked = boxes.length > 0 && boxes.every((box) => box.checked);
  }

  async function openNewRunDialog() {
    newRunPanel.hidden = false;
    newRunSearch.value = "";
    newRunSelectAll.checked = false;
    newRunClassList.textContent = "Loading test classes...";
    startNewRunButton.disabled = true;
    try {
      const response = await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent("SELECT Id, Name, Body FROM ApexClass ORDER BY Name")}`
      });
      selectableTestClasses = (response.data.records || []).filter((record) => /@istest\b/i.test(stripApexNoise(record.Body || "")));
      renderNewRunClassList();
    } catch (error) {
      newRunClassList.textContent = "Unable to load test classes.";
      setCoverageStatus(error.message || "Unable to load test classes.", true);
    }
  }

  function createClassButton(failure) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "apex-results-link";
    button.textContent = failure.ApexClass?.Name || failure.ApexClassName || "Unknown class";
    button.addEventListener("click", () => openFailureClass(failure));
    return button;
  }

  function createLogButton(logId) {
    if (!logId) return "";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "apex-results-link";
    button.textContent = "View Log";
    button.addEventListener("click", async () => {
      setCoverageStatus("Loading test log...", false);
      try {
        const response = await SFPanel.sendMessage({
          type: "restRequest",
          hostname: SFPanel.getHostname(),
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ApexLog/${encodeURIComponent(logId)}/Body`
        });
        testLog.textContent = typeof response.data === "string" ? response.data : "Salesforce returned an empty log.";
        const logPane = document.querySelector(".apex-test-log-pane");
        if (logPane.classList.contains("is-collapsed")) {
          logPane.classList.remove("is-collapsed");
          logPane.querySelector("[data-apex-test-pane-toggle]").setAttribute("aria-expanded", "true");
          testLogsResizeHandle.hidden = false;
        }
        setCoverageStatus("", false);
      } catch (error) {
        setCoverageStatus(`Unable to load test log: ${error.message || String(error)}`, true);
      }
    });
    return button;
  }

  async function createTestTrace(hostname, startedAt) {
    const orgInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
    const userId = String(orgInfo.userId || "");
    if (!userId) return {};
    const expiresAt = new Date(startedAt.getTime() + 15 * 60 * 1000);
    const traceQuery = `SELECT Id FROM TraceFlag WHERE TracedEntityId = '${userId}' AND StartDate <= ${expiresAt.toISOString()} AND ExpirationDate >= ${startedAt.toISOString()} LIMIT 1`;
    const existing = await SFPanel.sendMessage({
      type: "restRequest", hostname, method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(traceQuery)}`
    });
    if ((existing.data.records || []).length) return { userId };
    const debugLevel = await SFPanel.sendMessage({
      type: "restRequest", hostname, method: "POST",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/DebugLevel`,
      body: { DeveloperName: `SFToolTests${Date.now()}`, MasterLabel: "SF Tool Tests", ApexCode: "FINEST", ApexProfiling: "INFO", Callout: "INFO", Database: "INFO", System: "DEBUG", Validation: "INFO", Visualforce: "INFO", Workflow: "INFO" }
    });
    const traceFlag = await SFPanel.sendMessage({
      type: "restRequest", hostname, method: "POST",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/TraceFlag`,
      body: { TracedEntityId: userId, DebugLevelId: debugLevel.data.id, LogType: "DEVELOPER_LOG", StartDate: startedAt.toISOString(), ExpirationDate: expiresAt.toISOString() }
    });
    return { userId, traceFlagId: traceFlag.data.id, debugLevelId: debugLevel.data.id };
  }

  async function attachCapturedLogs(results, hostname, userId, startedAt) {
    if (!userId) return results;
    const logs = await SFPanel.sendMessage({
      type: "restRequest", hostname, method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(`SELECT Id, Operation, Request, StartTime FROM ApexLog WHERE LogUserId = '${userId}' AND StartTime >= ${startedAt.toISOString()} ORDER BY StartTime DESC LIMIT 100`)}`
    });
    const availableLogs = logs.data.records || [];
    return results.map((result) => {
      if (result.ApexLogId) return result;
      const className = String(result.ApexClass?.Name || "").toLowerCase();
      const log = availableLogs.find((item) => `${item.Operation || ""} ${item.Request || ""}`.toLowerCase().includes(className));
      return log ? { ...result, ApexLogId: log.Id } : result;
    });
  }

  function createErrorDetail(result) {
    const text = `${result.Message || ""}\n${result.StackTrace || ""}`.trim();
    if (!text) return "";
    const detail = document.createElement("details");
    detail.className = "apex-test-result-detail";
    const summary = document.createElement("summary");
    summary.textContent = result.Message || "View error";
    const content = document.createElement("pre");
    content.textContent = text;
    detail.append(summary, content);
    return detail;
  }

  function renderAllTestResults() {
    if (!allTestReport) return;
    const { results, beforeCoverage, afterCoverage } = allTestReport;
    const classResults = new Map();
    results.forEach((result) => {
      const key = result.ApexClassId || result.ApexClass?.Name || "Unknown class";
      if (!classResults.has(key)) {
        classResults.set(key, {
          id: result.ApexClassId,
          name: result.ApexClass?.Name || result.ApexClassName || "Unknown class",
          passed: 0,
          failures: []
        });
      }
      const classResult = classResults.get(key);
      if (result.Outcome === "Pass") classResult.passed += 1;
      else classResult.failures.push(result);
    });
    const failures = results.filter((result) => result.Outcome !== "Pass");
    const beforeTotals = coverageTotals(beforeCoverage);
    const afterTotals = coverageTotals(afterCoverage);
    testRunList.textContent = "";
    renderTestRunSelector();
    const testsHeading = document.createElement("h3");
    testsHeading.textContent = "Test Results";
    testRunList.appendChild(testsHeading);
    appendReportTable(testRunList, ["Class", "Method", "Result", "Error", "Log"], results.map((result) => [
      createClassButton(result),
      result.MethodName || "",
      result.Outcome || "Unknown",
      createErrorDetail(result),
      createLogButton(result.ApexLogId)
    ]));
    coverageReport.textContent = "";
    const summary = document.createElement("div");
    summary.className = "apex-coverage-summary";
    summary.textContent = `Overall Coverage: ${coveragePercentage(afterTotals)}%.`;
    coverageReport.appendChild(summary);
    const beforeByClass = new Map(beforeCoverage.map((item) => [coverageKey(item), item]));
    const afterByClass = new Map(afterCoverage.map((item) => [coverageKey(item), item]));
    const coverageKeys = new Set([...beforeByClass.keys(), ...afterByClass.keys()]);
    const coverageRows = [...coverageKeys].map((key) => {
      const before = beforeByClass.get(key) || {};
      const after = afterByClass.get(key) || {};
      return [
        after.ApexClassOrTrigger?.Name || before.ApexClassOrTrigger?.Name || "Unknown",
        `${coveragePercentage({ covered: before.NumLinesCovered || 0, uncovered: before.NumLinesUncovered || 0 })}%`,
        `${coveragePercentage({ covered: after.NumLinesCovered || 0, uncovered: after.NumLinesUncovered || 0 })}%`,
        String(after.NumLinesCovered || 0),
        String(after.NumLinesUncovered || 0)
      ];
    });
    if (!coverageRows.length) {
      coverageRows.push(["Salesforce returned no aggregate coverage records.", "", "", "", ""]);
    }
    appendReportTable(coverageReport, ["Class / Trigger", "Before", "After", "Covered Lines", "Uncovered Lines"], coverageRows);
    coverageEmpty.hidden = true;
    coverageReport.hidden = false;
    testRunList.hidden = false;
  }

  function showAllTestResults(results, beforeCoverage, afterCoverage, startedAt, testLevel, classIds) {
    allTestReport = { results, beforeCoverage, afterCoverage, startedAt, completedAt: new Date(), testLevel, classIds };
    testRunHistory.unshift(allTestReport);
    setCoverageStatus("", false);
    renderAllTestResults();
    switchType("ApexCoverage");
  }

  function clearCoverageReport() {
    allTestReport = null;
    coverageReport.textContent = "";
    coverageReport.hidden = true;
    coverageEmpty.hidden = false;
    coverageEmpty.textContent = "Current org coverage is shown when this view opens.";
    testRunList.textContent = "";
    testRunList.hidden = true;
    testRunHistory.length = 0;
    renderTestRunSelector();
    coverageOverviewHostname = null;
    setCoverageStatus("", false);
    if (currentType === "ApexCoverage") loadCoverageOverview();
  }

  function renderCoverageOverview(coverage) {
    const totals = coverageTotals(coverage);
    coverageReport.textContent = "";
    const summary = document.createElement("div");
    summary.className = "apex-coverage-summary";
    summary.textContent = `Overall Coverage: ${coveragePercentage(totals)}%.`;
    coverageReport.appendChild(summary);
    const rows = coverage.map((item) => [
      item.ApexClassOrTrigger?.Name || "Unknown",
      `${coveragePercentage({ covered: item.NumLinesCovered || 0, uncovered: item.NumLinesUncovered || 0 })}%`,
      String(item.NumLinesCovered || 0),
      String(item.NumLinesUncovered || 0)
    ]);
    if (!rows.length) rows.push(["Salesforce has no aggregate coverage records for this org.", "", "", ""]);
    appendReportTable(coverageReport, ["Class / Trigger", "Coverage", "Covered Lines", "Uncovered Lines"], rows);
    testRunList.textContent = "";
    testRunList.hidden = true;
    coverageEmpty.hidden = true;
    coverageReport.hidden = false;
  }

  function stopDebugLogPolling() {
    if (debugLogPollTimer !== null) window.clearInterval(debugLogPollTimer);
    debugLogPollTimer = null;
  }

  function renderDebugLogs(records) {
    displayedDebugLogs = records;
    logsList.textContent = "";
    if (!records.length) {
      logsList.textContent = "No debug logs found. Configure a trace flag to capture new activity.";
      return;
    }
    const table = document.createElement("table");
    table.className = "apex-results-table apex-logs-table";
    const head = document.createElement("thead");
    const headRow = document.createElement("tr");
    ["Time", "Operation", "Status", "Size"].forEach((label) => {
      const header = document.createElement("th");
      header.textContent = label;
      headRow.appendChild(header);
    });
    head.appendChild(headRow);
    const body = document.createElement("tbody");
    records.forEach((record) => {
      const row = document.createElement("tr");
      row.className = "apex-log-row";
      row.dataset.logId = record.Id;
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", String(record.Id === selectedDebugLogId));
      const started = record.StartTime ? new Date(record.StartTime).toLocaleString() : "Unknown time";
      [started, record.Operation || "Unknown operation", record.Status || "Unknown", `${record.LogLength || 0} bytes`].forEach((value) => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
      row.addEventListener("click", () => loadDebugLogBody(record.Id));
      body.appendChild(row);
    });
    table.append(head, body);
    logsList.appendChild(table);
    makeTableColumnsResizable(table);
  }

  function updateDebugLogCaptureControls() {
    const polling = debugLogPollTimer !== null;
    startLogCaptureButton.disabled = polling;
    stopLogCaptureButton.disabled = !polling;
  }

  async function startDebugLogCapture() {
    const hostname = SFPanel.getHostname();
    if (!hostname) return;
    if (debugLogCapture?.traceFlagId) {
      startDebugLogPolling();
      logsStatus.textContent = "Live refresh started.";
      return;
    }
    startLogCaptureButton.disabled = true;
    logsStatus.textContent = "Enabling debug log capture...";
    try {
      const orgInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
      const userId = String(orgInfo.userId || "");
      if (!userId) throw new Error("Unable to identify the signed-in Salesforce user.");
      const startedAt = new Date();
      const expiresAt = new Date(startedAt.getTime() + 30 * 60 * 1000);
      const traceQuery = `SELECT Id FROM TraceFlag WHERE TracedEntityId = '${userId}' AND StartDate <= ${expiresAt.toISOString()} AND ExpirationDate >= ${startedAt.toISOString()} LIMIT 1`;
      const existing = await SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(traceQuery)}`
      });
      if ((existing.data.records || []).length) {
        logsStatus.textContent = "A Salesforce debug trace is already active for the current user.";
        startDebugLogPolling();
        return;
      }
      const debugLevel = await SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/DebugLevel`,
        body: {
          DeveloperName: `SFToolLiveLog${Date.now()}`,
          MasterLabel: "SF Tool Live Debug Log",
          ApexCode: "FINEST",
          ApexProfiling: "INFO",
          Callout: "INFO",
          Database: "INFO",
          System: "DEBUG",
          Validation: "INFO",
          Visualforce: "INFO",
          Workflow: "FINEST"
        }
      });
      const traceFlag = await SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/TraceFlag`,
        body: {
          TracedEntityId: userId,
          DebugLevelId: debugLevel.data?.id,
          LogType: "DEVELOPER_LOG",
          StartDate: startedAt.toISOString(),
          ExpirationDate: expiresAt.toISOString()
        }
      });
      debugLogCapture = { hostname, traceFlagId: traceFlag.data?.id, debugLevelId: debugLevel.data?.id };
      updateDebugLogCaptureControls();
      logsStatus.textContent = "Debug capture is active for 30 minutes.";
      startDebugLogPolling();
    } catch (error) {
      logsStatus.textContent = error.message || "Unable to enable debug log capture.";
      updateDebugLogCaptureControls();
    }
  }

  async function stopDebugLogCapture() {
    stopDebugLogPolling();
    updateDebugLogCaptureControls();
    logsStatus.textContent = "Live refresh stopped.";
  }

  async function loadDebugLogBody(logId) {
    const hostname = SFPanel.getHostname();
    if (!hostname || !logId) return;
    selectedDebugLogId = logId;
    selectedDebugLogBody = "";
    logBody.textContent = "Loading debug log...";
    try {
      const response = await SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ApexLog/${encodeURIComponent(logId)}/Body`
      });
      selectedDebugLogBody = typeof response.data === "string" ? response.data : "Salesforce returned an empty debug log.";
      renderFilteredDebugLogBody();
      logsList.querySelectorAll(".apex-log-row").forEach((row) => row.setAttribute("aria-selected", String(row.dataset.logId === logId)));
    } catch (error) {
      logBody.textContent = `Unable to load debug log: ${error.message || String(error)}`;
    }
  }

  function renderFilteredDebugLogBody() {
    if (!selectedDebugLogBody) {
      logBody.textContent = "Select a debug log to view its contents.";
      return;
    }
    const searchTerm = logSearch.value.trim().toLowerCase();
    const lines = selectedDebugLogBody.split(/\r?\n/).filter((line) => {
      if (logDebugOnly.checked && !line.includes("USER_DEBUG")) return false;
      return !searchTerm || line.toLowerCase().includes(searchTerm);
    });
    logBody.textContent = lines.length ? lines.join("\n") : "No matching log lines.";
  }

  async function refreshDebugLogs() {
    const hostname = SFPanel.getHostname();
    if (!hostname) return;
    refreshLogsButton.disabled = true;
    logsStatus.textContent = "Refreshing logs...";
    try {
      const query = "SELECT Id, Operation, Status, StartTime, LogLength FROM ApexLog ORDER BY StartTime DESC LIMIT 100";
      const response = await SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(query)}`
      });
      renderDebugLogs(response.data.records || []);
      logsStatus.textContent = `Updated ${new Date().toLocaleTimeString()}`;
    } catch (error) {
      logsList.textContent = "Unable to load debug logs.";
      logsStatus.textContent = error.message || "Unable to load debug logs.";
    } finally {
      refreshLogsButton.disabled = false;
    }
  }

  async function clearDebugLogs() {
    const hostname = SFPanel.getHostname();
    if (!hostname || !displayedDebugLogs.length) return;
    const wasPolling = debugLogPollTimer !== null;
    stopDebugLogPolling();
    refreshLogsButton.disabled = true;
    clearLogsButton.disabled = true;
    logsStatus.textContent = "Clearing debug logs...";
    try {
      await Promise.all(displayedDebugLogs.map((record) => SFPanel.sendMessage({
        feature: "debug_logs",
        type: "restRequest",
        hostname,
        method: "DELETE",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ApexLog/${encodeURIComponent(record.Id)}`
      })));
      displayedDebugLogs = [];
      selectedDebugLogId = null;
      selectedDebugLogBody = "";
      logsList.textContent = "No debug logs found. Configure a trace flag to capture new activity.";
      logBody.textContent = "Select a debug log to view its contents.";
      logsStatus.textContent = "Debug logs cleared.";
    } catch (error) {
      logsStatus.textContent = error.message || "Unable to clear all debug logs.";
    } finally {
      refreshLogsButton.disabled = false;
      clearLogsButton.disabled = false;
      if (wasPolling && SFPanel.getActiveTab() === "debugLogs") startDebugLogPolling();
    }
  }

  function startDebugLogPolling() {
    stopDebugLogPolling();
    refreshDebugLogs();
    debugLogPollTimer = window.setInterval(refreshDebugLogs, 5000);
    updateDebugLogCaptureControls();
  }

  async function loadCoverageOverview() {
    const hostname = SFPanel.getHostname();
    if (!hostname || allTestReport || coverageOverviewHostname === hostname) return;
    coverageEmpty.hidden = false;
    coverageEmpty.textContent = "Loading current org coverage...";
    setCoverageStatus("", false);
    try {
      const response = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent("SELECT ApexClassOrTriggerId, ApexClassOrTrigger.Name, NumLinesCovered, NumLinesUncovered FROM ApexCodeCoverageAggregate")}`
      });
      coverageOverviewHostname = hostname;
      renderCoverageOverview(response.data.records || []);
    } catch (error) {
      coverageEmpty.textContent = "Unable to load current org coverage.";
      setCoverageStatus(error.message || "Unable to load current org coverage.", true);
    }
  }

  async function cancelQueuedTests(run) {
    await Promise.all(run.queueIds.map((id) => SFPanel.sendMessage({
      type: "restRequest",
      hostname: run.hostname,
      method: "DELETE",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ApexTestQueueItem/${encodeURIComponent(id)}`
    }).catch(() => {})));
  }

  async function cancelAllTests() {
    if (!activeAllTestRun) return;
    activeAllTestRun.cancelRequested = true;
    cancelAllTestsButton.disabled = true;
    setCoverageStatus("Cancellation requested. Waiting for Salesforce to stop queued tests...", false);
    if (activeAllTestRun.queueIds.length && !activeAllTestRun.cancelSent) {
      activeAllTestRun.cancelSent = true;
      await cancelQueuedTests(activeAllTestRun);
    }
  }

  async function runAllTests(testLevel = "RunLocalTests", classIds = []) {
    const hostname = SFPanel.getHostname();
    if (!hostname) return setCoverageStatus("No Salesforce tab detected.", true);
    runAllTestsButton.disabled = true;
    cancelAllTestsButton.disabled = false;
    cancelAllTestsButton.disabled = false;
    const run = { hostname, queueIds: [], cancelRequested: false, cancelSent: false, queueItemsObserved: false, startedAt: new Date(), testLevel, classIds };
    activeAllTestRun = run;
    coverageEmpty.hidden = true;
    testRunList.hidden = true;
    setCoverageStatus("Starting all Apex tests...", false);
    try {
      const beforeCoverageResponse = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent("SELECT ApexClassOrTriggerId, ApexClassOrTrigger.Name, NumLinesCovered, NumLinesUncovered FROM ApexCodeCoverageAggregate")}`
      });
      const beforeCoverage = beforeCoverageResponse.data.records || [];
      try {
        Object.assign(run, await createTestTrace(hostname, run.startedAt));
      } catch (error) {
        setCoverageStatus("Test tracing could not be enabled; results will still run, but logs may be unavailable.", false);
      }
      const submitted = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/runTestsAsynchronous`,
        body: classIds.length
          ? { tests: classIds.map((classId) => ({ classId })) }
          : { testLevel }
      });
      const testRunId = typeof submitted.data === "string"
        ? submitted.data
        : submitted.data?.testRunId || submitted.data?.id || submitted.data?.Id;
      if (!testRunId) throw new Error("Salesforce did not return a test run ID.");
      for (let attempt = 0; attempt < 60; attempt += 1) {
        const queue = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(`SELECT Id, Status FROM ApexTestQueueItem WHERE ParentJobId = '${testRunId}'`)}`
        });
        const queueRecords = queue.data.records || [];
        run.queueIds = queueRecords.map((item) => item.Id).filter(Boolean);
        if (run.queueIds.length) run.queueItemsObserved = true;
        if (run.cancelRequested && run.queueIds.length && !run.cancelSent) {
          run.cancelSent = true;
          await cancelQueuedTests(run);
        }
        if (run.cancelRequested && run.queueItemsObserved && !run.queueIds.length) {
          setCoverageStatus("Test run cancelled and removed from the Salesforce queue.", false);
          return;
        }
        const pending = !run.queueIds.length || queueRecords.some((item) => !["Completed", "Failed", "Aborted"].includes(item.Status));
        if (!pending) break;
        if (attempt === 59) throw new Error("Timed out waiting for Salesforce tests to complete.");
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      if (!run.queueIds.length) throw new Error("Salesforce did not create test queue items.");
      if (run.cancelRequested) {
        if (!run.cancelSent) await cancelQueuedTests(run);
        setCoverageStatus("Test run cancelled.", false);
        return;
      }
      const escapedIds = run.queueIds.map((id) => `'${id}'`).join(",");
      const results = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(`SELECT ApexClassId, ApexClass.Name, MethodName, Outcome, Message, StackTrace, ApexLogId FROM ApexTestResult WHERE QueueItemId IN (${escapedIds})`)}`
      });
      let afterCoverage = [];
      for (let attempt = 0; attempt < 6; attempt += 1) {
        setCoverageStatus(attempt ? "Waiting for Salesforce to calculate code coverage..." : "Loading test results and code coverage...", false);
        const coverage = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent("SELECT ApexClassOrTriggerId, ApexClassOrTrigger.Name, NumLinesCovered, NumLinesUncovered FROM ApexCodeCoverageAggregate")}`
        });
        afterCoverage = coverage.data.records || [];
        if (afterCoverage.length || attempt === 5) break;
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      const resultsWithLogs = await attachCapturedLogs(results.data.records || [], hostname, run.userId, run.startedAt);
      showAllTestResults(resultsWithLogs, beforeCoverage, afterCoverage, run.startedAt, run.testLevel, run.classIds);
    } catch (err) {
      setCoverageStatus(`Test run failed: ${err.message || String(err)}`, true);
    } finally {
      if (run.traceFlagId) SFPanel.sendMessage({ type: "restRequest", hostname, method: "DELETE", path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/TraceFlag/${encodeURIComponent(run.traceFlagId)}` }).catch(() => {});
      if (run.debugLevelId) SFPanel.sendMessage({ type: "restRequest", hostname, method: "DELETE", path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/DebugLevel/${encodeURIComponent(run.debugLevelId)}` }).catch(() => {});
      runAllTestsButton.disabled = false;
      cancelAllTestsButton.disabled = true;
      if (activeAllTestRun === run) activeAllTestRun = null;
    }
  }

  function showAnonymousExecutionLoading() {
    problemsPanel.open = true;
    problemsTitle.textContent = "Result";
    problemsList.textContent = "";
    problemsList.style.color = "";
    const loading = document.createElement("div");
    loading.className = "apex-anonymous-loading";
    loading.setAttribute("role", "status");
    loading.setAttribute("aria-live", "polite");
    const spinner = document.createElement("span");
    spinner.className = "apex-anonymous-spinner";
    spinner.setAttribute("aria-hidden", "true");
    const message = document.createElement("span");
    message.textContent = "Running Anonymous Apex...";
    loading.append(spinner, message);
    problemsList.appendChild(loading);
  }

  function showAnonymousExecutionResult(logBody) {
    problemsPanel.open = true;
    problemsTitle.textContent = "Result";
    problemsList.textContent = "";
    problemsList.style.color = "";

    const logLines = String(logBody).split(/\r?\n/);
    const debugLines = logLines.filter((line) => line.includes("|USER_DEBUG|"));
    const content = document.createElement("pre");
    content.className = "apex-anonymous-log";
    content.textContent = logBody;

    const controls = document.createElement("div");
    controls.className = "apex-anonymous-log-controls";
    const debugOnlyLabel = document.createElement("label");
    debugOnlyLabel.className = "apex-anonymous-debug-only";
    const debugOnly = document.createElement("input");
    debugOnly.type = "checkbox";
    debugOnlyLabel.append(debugOnly, document.createTextNode("Debug Only"));
    const search = document.createElement("input");
    search.type = "search";
    search.className = "apex-anonymous-log-search";
    search.placeholder = "Search log";
    search.setAttribute("aria-label", "Search log");
    const updateLog = () => {
      const searchTerm = search.value.trim().toLowerCase();
      const filteredLines = (debugOnly.checked ? debugLines : logLines).filter(
        (line) => !searchTerm || line.toLowerCase().includes(searchTerm)
      );
      content.textContent = filteredLines.join("\n") || "No matching log entries.";
    };
    debugOnly.addEventListener("change", updateLog);
    search.addEventListener("input", updateLog);
    controls.append(debugOnlyLabel, search);
    problemsList.append(controls, content);
  }

  function renderList() {
    const term = searchInput.value.trim().toLowerCase();
    const records = (recordsByType.get(currentType) || []).filter(
      (record) => !term || (record.Name || "").toLowerCase().includes(term)
    );

    listEl.textContent = "";
    if (!records.length) {
      const empty = document.createElement("li");
      empty.className = "object-row";
      empty.textContent = "No Apex components found.";
      listEl.appendChild(empty);
      return;
    }

    const activeTab = getActiveTab();
    const fragment = document.createDocumentFragment();
    records.forEach((record) => {
      const item = document.createElement("li");
      item.className = "object-row";
      const main = document.createElement("div");
      main.className = "object-row-main";
      main.classList.toggle(
        "active",
        Boolean(activeTab) && activeTab.type === currentType && activeTab.record.Id === record.Id
      );
      const label = document.createElement("span");
      label.className = "object-label";
      label.textContent = record.Name || "Unnamed";

      const sub = document.createElement("span");
      sub.className = "object-name";

      const idLink = document.createElement("a");
      idLink.className = "apex-id-link";
      idLink.textContent = record.Id;
      idLink.title = `Open ${record.Name || "record"} in Salesforce UI`;
      const hostname = SFPanel.getHostname();
      if (hostname && record.Id) {
        const targetUrl = `https://${hostname}/lightning/r/${currentType}/${record.Id}/view`;
        idLink.href = targetUrl;
        idLink.target = "_blank";
        idLink.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: targetUrl });
          } else {
            window.open(targetUrl, "_blank");
          }
        });
      }

      sub.appendChild(idLink);
      main.append(label, sub);
      main.addEventListener("click", () => selectRecord(record));
      item.appendChild(main);
      fragment.appendChild(item);
    });
    listEl.appendChild(fragment);
  }

  async function selectRecord(record) {
    const key = keyFor(currentType, record.Id);
    const existing = openTabs.find((tab) => tab.key === key);
    if (existing) {
      activateTab(existing);
      return;
    }

    if (bodyCache.has(key)) {
      openTabForRecord(currentType, record, bodyCache.get(key));
      return;
    }

    // Open the tab immediately with a placeholder, then replace its content
    // in place once the source has been fetched, instead of waiting to open it.
    const tab = openTabForRecord(currentType, record, "Loading…");
    try {
      if (!/^[A-Za-z0-9]{15,18}$/.test(String(record.Id || ""))) throw new Error("Salesforce returned an invalid Apex record ID.");
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${currentType}/${encodeURIComponent(record.Id)}`
      });
      const body = result.data?.Body;
      if (typeof body !== "string" || !body.trim()) throw new Error("Salesforce returned no source code for this component.");
      bodyCache.set(key, body);
      tab.doc.setValue(body);
      tab.savedValue = body;
      if (activeTabKey === tab.key) getEditor().swapDoc(tab.doc);
    } catch (err) {
      const body = `Unable to load source: ${err.message}`;
      tab.doc.setValue(body);
      tab.savedValue = body;
      if (activeTabKey === tab.key) getEditor().swapDoc(tab.doc);
    } finally {
      renderTabBar();
      if (activeTabKey === tab.key) updateToolbarState();
    }
  }

  async function loadApex() {
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    refreshButton.disabled = true;
    setStatus("Loading…", false);
    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(`SELECT Id, Name, Status, ApiVersion FROM ${currentType} ORDER BY Name`)}`
      });
      recordsByType.set(currentType, result.data.records || []);
      loadedHostname = hostname;
      searchInput.disabled = false;
      renderList();
      setStatus("", false);
    } catch (err) {
      recordsByType.set(currentType, []);
      renderList();
      setStatus(err.message);
    } finally {
      refreshButton.disabled = false;
    }
  }

  function switchType(type) {
    if (type === currentType) return;
    currentType = type;
    const isAnonymous = type === "AnonymousApex";
    const isCoverage = type === "ApexCoverage";
    document.getElementById("tab-apex")?.classList.toggle("anonymous-apex-mode", isAnonymous);
    document.getElementById("tab-apex")?.classList.toggle("coverage-apex-mode", isCoverage);
    apexSplit.hidden = isCoverage;
    coverageWorkspace.hidden = !isCoverage;
    searchInput.value = "";
    searchInput.disabled = isAnonymous || isCoverage;
    newButton.hidden = isAnonymous || isCoverage;
    refreshButton.hidden = isAnonymous || isCoverage;
    if (!isCoverage) cancelAllTestsButton.hidden = true;
    newForm.hidden = true;
    newObjectGroup.hidden = type !== "ApexTrigger";
    newEventsGroup.hidden = type !== "ApexTrigger";
    typeTabs.forEach((tab) => tab.classList.toggle("active", tab.dataset.apexType === type));
    if (isCoverage) {
      loadCoverageOverview();
      return;
    }
    if (isAnonymous) {
      const latestAnonymousTab = [...openTabs].reverse().find((tab) => tab.type === "AnonymousApex");
      if (latestAnonymousTab) activateTab(latestAnonymousTab);
      else openAnonymousTab();
      return;
    }
    const lastTabForType = [...openTabs].reverse().find((tab) => tab.type === type);
    if (lastTabForType) {
      activateTab(lastTabForType);
    } else {
      showEmptyState();
    }
    if (recordsByType.has(type)) renderList();
    else loadApex();
  }

  // Salesforce requires Apex Body updates to go through a MetadataContainer
  // compile workflow (ApexClass/ApexTrigger direct PATCH is create-only).
  async function createMetadataContainer() {
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "POST",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/MetadataContainer`,
      body: { Name: `SFToolExt_${Date.now()}` }
    });
    return result.data.id;
  }

  async function createContainerMember(type, containerId, contentEntityId, body) {
    const memberType = type === "ApexTrigger" ? "ApexTriggerMember" : "ApexClassMember";
    await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "POST",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${memberType}`,
      body: { MetadataContainerId: containerId, ContentEntityId: contentEntityId, Body: body }
    });
  }

  async function requestContainerDeploy(containerId) {
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "POST",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ContainerAsyncRequest`,
      body: { MetadataContainerId: containerId, IsCheckOnly: false }
    });
    return result.data.id;
  }

  async function pollContainerDeploy(requestId) {
    const terminalStates = new Set(["Completed", "Failed", "Error", "Aborted", "Invalidated"]);
    for (let attempt = 0; attempt < 30; attempt++) {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ContainerAsyncRequest/${requestId}`
      });
      if (terminalStates.has(result.data.State)) return result.data;
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    throw new Error("Timed out waiting for Apex compile to finish.");
  }

  async function deleteMetadataContainer(containerId) {
    try {
      await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "DELETE",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/MetadataContainer/${containerId}`
      });
    } catch {
      // Best-effort cleanup only; stale containers don't block future saves.
    }
  }

  function parseDeployErrors(deployRequest) {
    const failures = deployRequest.DeployDetails && deployRequest.DeployDetails.componentFailures;
    if (failures && failures.length) {
      return failures.map((failure) => ({
        message: failure.lineNumber != null ? `Line ${failure.lineNumber}: ${failure.problem}` : failure.problem
      }));
    }
    return [{ message: deployRequest.ErrorMsg || "Compile failed." }];
  }

  async function saveActiveTab() {
    const tab = getActiveTab();
    if (!tab) return;
    saveButton.disabled = true;
    setStatus("Saving…", false);
    let containerId = null;
    try {
      containerId = await createMetadataContainer();
      await createContainerMember(tab.type, containerId, tab.record.Id, tab.doc.getValue());
      const requestId = await requestContainerDeploy(containerId);
      const deployRequest = await pollContainerDeploy(requestId);

      if (deployRequest.State === "Completed") {
        bodyCache.set(tab.key, tab.doc.getValue());
        tab.savedValue = tab.doc.getValue();
        hideProblems();
        renderTabBar();
        setStatus("Saved.", false);
      } else {
        showCompileErrors(parseDeployErrors(deployRequest));
      }
    } catch (err) {
      showCompileErrors(parseApiError(err));
    } finally {
      if (containerId) deleteMetadataContainer(containerId);
      updateToolbarState();
    }
  }

  async function runActiveTabTests() {
    const tab = getActiveTab();
    if (!tab) return;
    runTestsButton.disabled = true;
    setStatus("Running tests…", false);
    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/runTestsSynchronous`,
        body: { tests: [{ classId: tab.record.Id }] }
      });
      showTestResults(result.data);
      setStatus("", false);
    } catch (err) {
      showCompileErrors(parseApiError(err));
    } finally {
      runTestsButton.disabled = false;
    }
  }

  async function runAnonymousApex() {
    const tab = getActiveTab();
    if (!tab || tab.type !== "AnonymousApex") return;
    const source = tab.doc.getValue().trim();
    if (!source) {
      setStatus("Enter Anonymous Apex to run.");
      return;
    }
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }
    runAnonymousButton.disabled = true;
    showAnonymousExecutionLoading();
    let traceFlagId = null;
    let debugLevelId = null;
    try {
      const orgInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
      const userId = String(orgInfo.userId || "");
      if (!userId) throw new Error(`Unable to identify the signed-in Salesforce user for debug logging. ${orgInfo.userInfoError || "No user ID was returned."}`);

      const startedAt = new Date();
      const expirationAt = new Date(startedAt.getTime() + 5 * 60 * 1000);
      const existingTraceQuery = `SELECT Id FROM TraceFlag WHERE TracedEntityId = '${userId}' AND StartDate <= ${expirationAt.toISOString()} AND ExpirationDate >= ${startedAt.toISOString()} LIMIT 1`;
      const existingTrace = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(existingTraceQuery)}`
      });
      if (!(existingTrace.data?.records || []).length) {
        const debugLevel = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "POST",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/DebugLevel`,
          body: {
            DeveloperName: `SFToolAnonymous${Date.now()}`,
            MasterLabel: "SF Tool Anonymous Apex",
            ApexCode: "FINEST",
            ApexProfiling: "INFO",
            Callout: "INFO",
            Database: "INFO",
            System: "DEBUG",
            Validation: "INFO",
            Visualforce: "INFO",
            Workflow: "INFO"
          }
        });
        debugLevelId = debugLevel.data?.id;
        const traceFlag = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "POST",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/TraceFlag`,
          body: {
            TracedEntityId: userId,
            DebugLevelId: debugLevelId,
            LogType: "DEVELOPER_LOG",
            StartDate: startedAt.toISOString(),
            ExpirationDate: expirationAt.toISOString()
          }
        });
        traceFlagId = traceFlag.data?.id;
      }
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/executeAnonymous/?anonymousBody=${encodeURIComponent(source)}`
      });
      const output = result.data || {};
      if (output.success) {
        let logBody = "";
        const logQuery = `SELECT Id FROM ApexLog WHERE LogUserId = '${userId}' AND StartTime >= ${startedAt.toISOString()} ORDER BY StartTime DESC LIMIT 1`;
        for (let attempt = 0; attempt < 4 && !logBody; attempt += 1) {
          if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 500));
          const logResult = await SFPanel.sendMessage({
            type: "restRequest",
            hostname,
            method: "GET",
            path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(logQuery)}`
          });
          const logId = logResult.data?.records?.[0]?.Id;
          if (!logId) continue;
          const logResponse = await SFPanel.sendMessage({
            type: "restRequest",
            hostname,
            method: "GET",
            path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ApexLog/${encodeURIComponent(logId)}/Body`
          });
          logBody = typeof logResponse.data === "string" ? logResponse.data : "";
        }
        if (logBody) showAnonymousExecutionResult(logBody);
        else setStatus("Execution completed successfully. Salesforce did not return a debug log before the capture window ended.", false);
      } else {
        const location = output.line != null ? `Line ${output.line}${output.column != null ? `, column ${output.column}` : ""}: ` : "";
        setStatus(`${location}${output.compileProblem || output.exceptionMessage || "Execution failed."}`);
      }
    } catch (err) {
      setStatus(`Execution failed: ${err.message || String(err)}`);
    } finally {
      if (traceFlagId) {
        SFPanel.sendMessage({ type: "restRequest", hostname, method: "DELETE", path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/TraceFlag/${encodeURIComponent(traceFlagId)}` }).catch(() => {});
      }
      if (debugLevelId) {
        SFPanel.sendMessage({ type: "restRequest", hostname, method: "DELETE", path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/DebugLevel/${encodeURIComponent(debugLevelId)}` }).catch(() => {});
      }
      runAnonymousButton.disabled = false;
    }
  }

  let cachedObjects = null;

  async function ensureObjectsLoaded() {
    if (cachedObjects !== null) return;
    const hostname = SFPanel.getHostname();
    if (!hostname) return;

    if (newObjectSelect) {
      newObjectSelect.innerHTML = '<option value="">Loading sObjects…</option>';
    }

    try {
      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      cachedObjects = (objects || []).slice().sort((a, b) => (a.label || a.name).localeCompare(b.label || b.name));

      if (newObjectSelect) {
        newObjectSelect.innerHTML = '<option value="">Select sObject…</option>';
        cachedObjects.forEach((obj) => {
          const opt = document.createElement("option");
          opt.value = obj.name;
          opt.textContent = `${obj.label} (${obj.name})`;
          newObjectSelect.appendChild(opt);
        });
      }
    } catch (err) {
      if (newObjectSelect) {
        newObjectSelect.innerHTML = '<option value="">Error loading sObjects</option>';
      }
    }
  }

  function updateNewFormPreview() {
    if (!newPreviewEl) return;
    const name = newNameInput.value.trim();

    if (currentType === "ApexClass") {
      const className = name || "MyClass";
      newPreviewEl.textContent = `public class ${className} {\n\n}\n`;
    } else {
      const triggerName = name || "AccountTrigger";
      const sObj = newObjectSelect ? newObjectSelect.value || "Account" : "Account";
      const checkedEvents = Array.from(newEventCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value);
      const eventsText = checkedEvents.length > 0 ? checkedEvents.join(", ") : "before insert";
      newPreviewEl.textContent = `trigger ${triggerName} on ${sObj} (${eventsText}) {\n\n}\n`;
    }
  }

  function openNewForm() {
    const isTrigger = currentType === "ApexTrigger";
    if (newObjectGroup) newObjectGroup.hidden = !isTrigger;
    if (newEventsGroup) newEventsGroup.hidden = !isTrigger;

    if (isTrigger) {
      newNameInput.placeholder = "AccountTrigger";
      newNameInput.value = "";
      newEventCheckboxes.forEach((cb) => {
        cb.checked = cb.value === "before insert";
      });
      ensureObjectsLoaded();
    } else {
      newNameInput.placeholder = "MyClass";
      newNameInput.value = "";
    }

    newForm.hidden = false;
    updateNewFormPreview();

    // Collapse the code section so the form gets focus/space and code area shows min height
    const codeSection = document.querySelector(".apex-code-section");
    if (codeSection) codeSection.open = false;

    newNameInput.focus();
  }

  function closeNewForm() {
    newForm.hidden = true;
    const codeSection = document.querySelector(".apex-code-section");
    if (codeSection) codeSection.open = true;
  }

  async function createRecord(event) {
    event.preventDefault();
    const name = newNameInput.value.trim();
    const identifierPattern = /^[A-Za-z][A-Za-z0-9_]*$/;
    if (!identifierPattern.test(name)) {
      setStatus("Enter a valid API name (letters, numbers, underscore; must start with a letter).");
      return;
    }

    const isTrigger = currentType === "ApexTrigger";
    let body = "";
    let sObjectName = "";

    if (isTrigger) {
      sObjectName = newObjectSelect ? newObjectSelect.value.trim() : "";
      if (!sObjectName) {
        setStatus("Please select an sObject for the trigger.");
        return;
      }
      const events = Array.from(newEventCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value);
      if (events.length === 0) {
        setStatus("Please select at least one trigger event.");
        return;
      }
      body = `trigger ${name} on ${sObjectName} (${events.join(", ")}) {\n\n}\n`;
    } else {
      body = `public class ${name} {\n\n}\n`;
    }

    const requestBody = isTrigger ? { Name: name, Body: body, TableEnumOrId: sObjectName } : { Name: name, Body: body };

    setStatus("Creating…", false);
    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname: SFPanel.getHostname(),
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${currentType}`,
        body: requestBody
      });
      const newRecord = { Id: result.data.id, Name: name, Status: "Active", ApiVersion: null };
      const records = recordsByType.get(currentType) || [];
      records.push(newRecord);
      records.sort((left, right) => left.Name.localeCompare(right.Name));
      recordsByType.set(currentType, records);
      bodyCache.set(keyFor(currentType, newRecord.Id), body);
      closeNewForm();
      openTabForRecord(currentType, newRecord, body);
      setStatus("Created.", false);
    } catch (err) {
      setStatus(`Unable to create: ${err.message}`);
    }
  }

  typeTabs.forEach((tab) => {
    tab.addEventListener("click", () => switchType(tab.dataset.apexType));
  });
  searchInput.addEventListener("input", renderList);
  refreshButton.addEventListener("click", () => {
    recordsByType.delete(currentType);
    loadApex();
  });
  newButton.addEventListener("click", openNewForm);
  newCancelButton.addEventListener("click", closeNewForm);
  newForm.addEventListener("submit", createRecord);
  newNameInput.addEventListener("input", updateNewFormPreview);
  if (newObjectSelect) newObjectSelect.addEventListener("change", updateNewFormPreview);
  newEventCheckboxes.forEach((cb) => cb.addEventListener("change", updateNewFormPreview));
  saveButton.addEventListener("click", saveActiveTab);
  runTestsButton.addEventListener("click", runActiveTabTests);
  runAllTestsButton.addEventListener("click", () => runAllTests());
  cancelAllTestsButton.addEventListener("click", cancelAllTests);
  anonymousLayoutToggle.addEventListener("click", () => {
    const codePane = document.querySelector("#tab-apex .apex-code-pane");
    const horizontal = codePane.classList.toggle("anonymous-horizontal-layout");
    anonymousLayoutToggle.textContent = horizontal ? "Vertical Split" : "Horizontal Split";
    anonymousLayoutToggle.title = horizontal ? "Show editor and result above and below" : "Show editor and result side by side";
    if (editor) editor.refresh();
  });
  clearCoverageButton.addEventListener("click", clearCoverageReport);
  startLogCaptureButton.addEventListener("click", startDebugLogCapture);
  stopLogCaptureButton.addEventListener("click", stopDebugLogCapture);
  refreshLogsButton.addEventListener("click", refreshDebugLogs);
  logDebugOnly.addEventListener("change", renderFilteredDebugLogBody);
  logSearch.addEventListener("input", renderFilteredDebugLogBody);
  clearLogsButton.addEventListener("click", clearDebugLogs);
  (function initDebugLogsResize() {
    const MIN_LIST_WIDTH = 240;
    const MIN_VIEWER_WIDTH = 280;
    const split = document.querySelector(".apex-logs-split");
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function setWidth(width) {
      const maxWidth = Math.max(MIN_LIST_WIDTH, split.getBoundingClientRect().width - MIN_VIEWER_WIDTH - 5);
      const clamped = Math.min(maxWidth, Math.max(MIN_LIST_WIDTH, width));
      split.style.gridTemplateColumns = `${Math.round(clamped)}px 5px minmax(${MIN_VIEWER_WIDTH}px, 1fr)`;
    }

    function beginDrag(clientX) {
      dragStartX = clientX;
      dragStartWidth = logsList.getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    logsResizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
    document.addEventListener("pointermove", (event) => {
      if (isDragging) setWidth(dragStartWidth + event.clientX - dragStartX);
    });
    document.addEventListener("pointerup", endDrag);
    logsResizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowLeft" ? -20 : event.key === "ArrowRight" ? 20 : 0;
      if (!step) return;
      event.preventDefault();
      setWidth(logsList.getBoundingClientRect().width + step);
    });
  })();
  testMenuButton.addEventListener("click", () => {
    const opening = testMenu.hidden;
    testMenu.hidden = !opening;
    testMenuButton.setAttribute("aria-expanded", String(opening));
  });
  testMenu.addEventListener("click", (event) => {
    const action = event.target.dataset.testAction;
    if (!action) return;
    testMenu.hidden = true;
    testMenuButton.setAttribute("aria-expanded", "false");
    if (action === "new") openNewRunDialog();
    else if (action === "rerun") {
      if (!allTestReport) setCoverageStatus("Select or complete a test run before rerunning it.", true);
      else runAllTests(allTestReport.testLevel || "RunLocalTests", allTestReport.classIds || []);
    }
    else if (action === "all") runAllTests("RunLocalTests");
    else if (action === "failed") {
      const classIds = [...new Set((allTestReport?.results || []).filter((result) => result.Outcome !== "Pass").map((result) => result.ApexClassId).filter(Boolean))];
      if (!classIds.length) setCoverageStatus("There are no failed test classes to rerun.", true);
      else runAllTests("RunSpecifiedTests", classIds);
    } else if (action === "abort") cancelAllTests();
    else if (action === "collapse" || action === "expand") {
      testRunList.querySelectorAll(".apex-test-result-detail").forEach((detail) => {
        detail.open = action === "expand";
      });
    }
    else if (action === "clear") clearCoverageReport();
  });
  startNewRunButton.addEventListener("click", () => {
    const classIds = Array.from(newRunClassList.querySelectorAll("input:checked")).map((input) => input.value);
    if (!classIds.length) return;
    newRunPanel.hidden = true;
    runAllTests("RunSpecifiedTests", classIds);
  });
  cancelNewRunButton.addEventListener("click", () => { newRunPanel.hidden = true; });
  newRunSearch.addEventListener("input", renderNewRunClassList);
  newRunSelectAll.addEventListener("change", () => {
    newRunClassList.querySelectorAll("input[type=checkbox]").forEach((box) => {
      box.checked = newRunSelectAll.checked;
    });
    updateNewRunSelection();
  });
  testRunSelector.addEventListener("click", () => {
    if (testRunSelector.disabled) return;
    const opening = testRunHistoryMenu.hidden;
    testRunHistoryMenu.hidden = !opening;
    testRunSelector.setAttribute("aria-expanded", String(opening));
  });
  (function initTestPaneToggles() {
    const resultsPane = document.querySelector(".apex-test-results-pane");
    const logsPane = document.querySelector(".apex-test-log-pane");
    const leftPane = document.querySelector(".apex-test-runs-pane");

    function syncTestPaneLayout() {
      const resultsCollapsed = resultsPane.classList.contains("is-collapsed");
      const logsCollapsed = logsPane.classList.contains("is-collapsed");
      testLogsResizeHandle.hidden = resultsCollapsed || logsCollapsed;
      if (resultsCollapsed && logsCollapsed) {
        leftPane.style.gridTemplateRows = "32px 0 32px";
      } else if (resultsCollapsed) {
        leftPane.style.gridTemplateRows = "32px 0 minmax(90px, 1fr)";
      } else if (logsCollapsed) {
        leftPane.style.gridTemplateRows = "minmax(120px, 1fr) 0 32px";
      } else {
        leftPane.style.gridTemplateRows = "minmax(120px, 1fr) 5px minmax(90px, 0.8fr)";
      }
      resultsPane.querySelector("[data-apex-test-pane-toggle]").setAttribute("aria-expanded", String(!resultsCollapsed));
      logsPane.querySelector("[data-apex-test-pane-toggle]").setAttribute("aria-expanded", String(!logsCollapsed));
    }

    document.querySelectorAll("[data-apex-test-pane-toggle]").forEach((button) => {
      button.addEventListener("click", () => {
        const pane = button.dataset.apexTestPaneToggle === "results" ? resultsPane : logsPane;
        pane.classList.toggle("is-collapsed");
        syncTestPaneLayout();
      });
    });
    syncTestPaneLayout();
  })();

  (function initTestLogsResize() {
    const MIN_TOP_HEIGHT = 120;
    const MIN_LOG_HEIGHT = 90;
    const leftPane = document.querySelector(".apex-test-runs-pane");
    let dragStartY = 0;
    let dragStartHeight = 0;
    let isDragging = false;

    function setHeight(height) {
      const maxHeight = Math.max(MIN_TOP_HEIGHT, leftPane.getBoundingClientRect().height - MIN_LOG_HEIGHT - 5);
      const clamped = Math.min(maxHeight, Math.max(MIN_TOP_HEIGHT, height));
      leftPane.style.gridTemplateRows = `${Math.round(clamped)}px 5px minmax(${MIN_LOG_HEIGHT}px, 1fr)`;
    }

    function beginDrag(clientY) {
      dragStartY = clientY;
      dragStartHeight = leftPane.querySelector(".apex-test-results-pane").getBoundingClientRect().height;
      isDragging = true;
      document.body.style.cursor = "row-resize";
      document.body.style.userSelect = "none";
    }

    function moveDrag(clientY) {
      if (isDragging) setHeight(dragStartHeight + clientY - dragStartY);
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    testLogsResizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientY);
    });
    document.addEventListener("pointermove", (event) => moveDrag(event.clientY));
    document.addEventListener("pointerup", endDrag);
    testLogsResizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowUp" ? -20 : event.key === "ArrowDown" ? 20 : 0;
      if (!step) return;
      event.preventDefault();
      setHeight(leftPane.querySelector(".apex-test-results-pane").getBoundingClientRect().height + step);
    });
  })();

  (function initTestCoverageResize() {
    const MIN_TEST_WIDTH = 280;
    const MIN_COVERAGE_WIDTH = 240;
    const workspace = document.querySelector(".apex-test-workspace");
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function setWidth(width) {
      const maxWidth = Math.max(MIN_TEST_WIDTH, workspace.getBoundingClientRect().width - MIN_COVERAGE_WIDTH - 5);
      const clamped = Math.min(maxWidth, Math.max(MIN_TEST_WIDTH, width));
      workspace.style.gridTemplateColumns = `${Math.round(clamped)}px 5px minmax(${MIN_COVERAGE_WIDTH}px, 1fr)`;
    }

    function beginDrag(clientX) {
      dragStartX = clientX;
      dragStartWidth = workspace.querySelector(".apex-test-runs-pane").getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    function moveDrag(clientX) {
      if (isDragging) setWidth(dragStartWidth + clientX - dragStartX);
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    testCoverageResizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
    document.addEventListener("pointermove", (event) => moveDrag(event.clientX));
    document.addEventListener("pointerup", endDrag);
    testCoverageResizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowLeft" ? -20 : event.key === "ArrowRight" ? 20 : 0;
      if (!step) return;
      event.preventDefault();
      setWidth(workspace.querySelector(".apex-test-runs-pane").getBoundingClientRect().width + step);
    });
  })();
  runAnonymousButton.addEventListener("click", runAnonymousApex);

  (function initResize() {
    const MIN_WIDTH = 120;
    const MIN_CODE_PANE_WIDTH = 200;
    const HANDLE_WIDTH = 5;
    const splitEl = listEl.parentElement;
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function maxWidth() {
      return Math.max(MIN_WIDTH, splitEl.getBoundingClientRect().width - HANDLE_WIDTH - MIN_CODE_PANE_WIDTH);
    }

    function setWidth(width) {
      const clamped = Math.min(maxWidth(), Math.max(MIN_WIDTH, width));
      splitEl.style.gridTemplateColumns = `${clamped}px ${HANDLE_WIDTH}px minmax(0, 1fr)`;
      localStorage.setItem("apexListWidth", String(Math.round(clamped)));
      return clamped;
    }

    // Not restoring a persisted width on load for now — always start at the CSS
    // default (see .apex-split in popup.css) to avoid confusion from stale values.

    function beginDrag(clientX) {
      dragStartX = clientX;
      dragStartWidth = listEl.getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    function moveDrag(clientX) {
      if (!isDragging) return;
      setWidth(dragStartWidth + clientX - dragStartX);
      if (editor) editor.refresh();
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    resizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
    document.addEventListener("pointermove", (event) => moveDrag(event.clientX));
    document.addEventListener("pointerup", endDrag);
    resizeHandle.addEventListener("mousedown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
    document.addEventListener("mousemove", (event) => moveDrag(event.clientX));
    document.addEventListener("mouseup", endDrag);
    resizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowLeft" ? -10 : event.key === "ArrowRight" ? 10 : 0;
      if (!step) return;
      event.preventDefault();
      setWidth(listEl.getBoundingClientRect().width + step);
    });
  })();

  (function initProblemsResize() {
    const MIN_HEIGHT = 32;
    const MIN_CODE_HEIGHT = 100;
    const paneEl = codeProblemsResizeHandle.parentElement;
    let dragStartY = 0;
    let dragStartHeight = 0;
    let isDragging = false;

    function maxHeight() {
      return Math.max(MIN_HEIGHT, paneEl.getBoundingClientRect().height - MIN_CODE_HEIGHT);
    }

    function setHeight(height) {
      const clamped = Math.min(maxHeight(), Math.max(MIN_HEIGHT, height));
      problemsPanel.style.height = `${clamped}px`;
    }

    function beginDrag(clientY) {
      dragStartY = clientY;
      dragStartHeight = problemsPanel.getBoundingClientRect().height;
      isDragging = true;
      document.body.style.cursor = "row-resize";
      document.body.style.userSelect = "none";
    }

    function moveDrag(clientY) {
      if (!isDragging) return;
      setHeight(dragStartHeight - (clientY - dragStartY));
      if (editor) editor.refresh();
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    codeProblemsResizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientY);
    });
    document.addEventListener("pointermove", (event) => moveDrag(event.clientY));
    document.addEventListener("pointerup", endDrag);
    codeProblemsResizeHandle.addEventListener("mousedown", (event) => {
      event.preventDefault();
      beginDrag(event.clientY);
    });
    document.addEventListener("mousemove", (event) => moveDrag(event.clientY));
    document.addEventListener("mouseup", endDrag);
    codeProblemsResizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowDown" ? -10 : event.key === "ArrowUp" ? 10 : 0;
      if (!step) return;
      event.preventDefault();
      setHeight(problemsPanel.getBoundingClientRect().height + step);
    });
  })();

  SFPanel.registerTab("debugLogs", {
    onShow() {},
    onBeforeHide() {
      stopDebugLogPolling();
      return true;
    },
    onHostnameChange() {
      stopDebugLogPolling();
      selectedDebugLogId = null;
      selectedDebugLogBody = "";
      displayedDebugLogs = [];
      logsList.textContent = "";
      logBody.textContent = "Select a debug log to view its contents.";
    }
  });

  SFPanel.registerTab("apex", {
    onShow() {
      if (currentType === "ApexCoverage") loadCoverageOverview();
      else if (loadedHostname !== SFPanel.getHostname()) loadApex();
      if (editor) editor.refresh();
    },
    onBeforeHide() {
      if (!hasAnyUnsavedChanges()) return true;
      return window.confirm("You have unsaved changes in one or more open files. Leave anyway?");
    },
    onHostnameChange() {
      loadedHostname = null;
      coverageOverviewHostname = null;
      clearCoverageReport();
      recordsByType.clear();
      bodyCache.clear();
      openTabs.length = 0;
      showEmptyState();
      if (SFPanel.getActiveTab() === "apex") {
        if (currentType === "ApexCoverage") loadCoverageOverview();
        else loadApex();
      }
    }
  });
})(SFPanel.forTools("apex", "debugLogs"));
