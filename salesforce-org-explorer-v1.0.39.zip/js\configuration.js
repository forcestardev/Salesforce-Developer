// Import and export configuration workbook & metadata.

((SFPanel) => {
  const SALESFORCE_HOST_PATTERN = /(\.salesforce\.com|\.force\.com|\.cloudforce\.com|\.visualforce\.com|\.salesforce-setup\.com|\.my\.site\.com)$/i;
  const importFileInput = document.getElementById("configImportFile");
  const importChooseButton = document.getElementById("configImportChoose");
  const importDownloadTemplateButton = document.getElementById("configImportDownloadTemplate");
  const importCreateButton = document.getElementById("configImportCreate");
  const importRefreshButton = document.getElementById("configImportRefresh");
  const importValidateButton = document.getElementById("configImportValidate");
  const importStatus = document.getElementById("configImportStatus");
  const importFileName = document.getElementById("configImportFileName");
  const importTabs = document.getElementById("configImportTabs");
  const importPreview = document.getElementById("configImportPreview");
  const importIssues = document.getElementById("configImportIssues");
  const importResizeHandle = document.getElementById("configImportResizeHandle");
  const importLog = document.getElementById("configImportLog");
  const exportExcelButton = document.getElementById("configExportExcel");
  const exportJsonButton = document.getElementById("configExportJson");
  const exportStatus = document.getElementById("configExportStatus");
  const exportLoading = document.getElementById("configExportLoading");
  const exportResultTabs = document.getElementById("configExportResultTabs");
  const exportResultObjectTabs = document.getElementById("configExportResultObjectTabs");
  const exportResultObjectSelect = document.getElementById("configExportResultObjectSelect");
  const exportAccessTabs = document.getElementById("configExportAccessTabs");
  const exportResultPreview = document.getElementById("configExportResultPreview");
  const exportResultContent = document.getElementById("configExportResultContent");
  const exportResultObjectScope = document.getElementById("exportResultObjectScope");
  const exportResultOrgScope = document.getElementById("exportResultOrgScope");
  const exportObjectTypesEl = document.getElementById("configExportObjectTypes");
  const exportOrgTypesEl = document.getElementById("configExportOrgTypes");
  const exportSelectAllObjectScope = document.getElementById("exportSelectAllObjectScope");
  const exportSelectAllOrgWide = document.getElementById("exportSelectAllOrgWide");
  const exportStep1 = document.getElementById("exportStep1");
  const exportStep1Next = document.getElementById("exportStep1Next");
  const exportStep2 = document.getElementById("exportStep2");
  const exportStep2Back = document.getElementById("exportStep2Back");
  const exportStep2Next = document.getElementById("exportStep2Next");
  const exportStep3 = document.getElementById("exportStep3");
  const exportStep3Back = document.getElementById("exportStep3Back");
  const exportObjectSearch = document.getElementById("exportObjectSearch");
  const exportShowStandardObjects = document.getElementById("exportShowStandardObjects");
  const exportObjectList = document.getElementById("exportObjectList");
  const exportSelectAllObjects = document.getElementById("exportSelectAllObjects");
  const compareSourceOrg = document.getElementById("compareSourceOrg");
  const compareTargetOrg = document.getElementById("compareTargetOrg");
  const compareTargetEnvironment = document.getElementById("compareTargetEnvironment");
  const compareTargetLogin = document.getElementById("compareTargetLogin");
  const compareTargetSetup = document.getElementById("compareTargetSetup");
  const compareOrgIdentities = document.getElementById("compareOrgIdentities");
  const compareSelectionStatus = document.getElementById("compareSelectionStatus");
  const compareObjectSelection = document.getElementById("compareObjectSelection");
  const compareSelectAllTypes = document.getElementById("compareSelectAllTypes");
  const compareCommonTypesToggle = document.getElementById("compareCommonTypesToggle");
  const compareScopeTypeList = document.getElementById("compareScopeTypeList");
  const compareTypesTitle = document.getElementById("compareTypesTitle");
  const compareMembersTitle = document.getElementById("compareMembersTitle");
  const compareMembersCount = document.getElementById("compareMembersCount");
  const compareSelectAllMembers = document.getElementById("compareSelectAllMembers");
  const compareMemberSearch = document.getElementById("compareMemberSearch");
  const compareMembersEmpty = document.getElementById("compareMembersEmpty");
  const compareMemberList = document.getElementById("compareMemberList");
  const compareSelectedCount = document.getElementById("compareSelectedCount");
  const compareSelectedList = document.getElementById("compareSelectedList");
  const compareResizeHandle1 = document.getElementById("compareResizeHandle1");
  const compareResizeHandle2 = document.getElementById("compareResizeHandle2");
  const compareOrgsLoad = document.getElementById("compareOrgsLoad");
  const compareResultsPage = document.getElementById("compareResultsPage");
  const compareResultsBack = document.getElementById("compareResultsBack");
  const compareStatus = document.getElementById("compareOrgsStatus");
  const compareSplitDirection = document.getElementById("compareSplitDirection");
  const compareResultsResizeHandle = document.getElementById("compareResultsResizeHandle");
  const compareResultsFilters = document.getElementById("compareResultsFilters");
  const compareResults = document.getElementById("compareOrgsResults");
  const compareResultDetails = document.getElementById("compareResultDetails");
  let targetLoginTabId = null;
  let sourceOrgHost = "";
  let targetOrgHost = "";
  let sourceOrgId = "";
  let compareMode = "metadata";
  let compareOrgChoiceGeneration = 0;
  function setCompareMode(mode, objectName) {
    ++compareOrgChoiceGeneration;
    compareMode = mode;
    const objectMode = mode === "objects";
    document.getElementById("compareMetadataPanel").hidden = objectMode;
    document.getElementById("compareObjectConfigPanel").hidden = !objectMode;
    const container = document.getElementById(objectMode ? "tab-compareObjects" : "tab-compareOrgs");
    container.insertBefore(compareOrgIdentities, container.firstChild);
    compareOrgIdentities.after(compareTargetSetup);
    compareOrgIdentities.hidden = objectMode ? false : !compareResultsPage.hidden;
    updateCompareTargetSetup();
    if (objectMode) ObjectConfigCompare.activate(objectName);
  }
  let comparisonInProgress = false;
  let activeCompareScopeType = "";
  const selectedCompareTypes = new Set();
  const compareMemberCache = new Map();
  let compareMemberLoad = null;
  const selectedCompareMembers = new Map();
  let availableCompareTypes = [];
  const commonCompareTypes = new Set([
    "apexclass", "apexpage", "apextrigger", "auradefinitionbundle", "customapplication",
    "customfield", "customlabel", "custommetadata", "customobject", "custompermission",
    "customtab", "dashboard", "emailtemplate", "fieldset", "flexipage", "flow",
    "globalvalueset", "layout", "lightningcomponentbundle", "permissionset", "permissionsetgroup",
    "profile", "quickaction", "recordtype", "report", "staticresource", "validationrule",
    "workflow", "workflowrule"
  ]);
  let lastComparisonResults = null;
  let lastComparisonContext = null;
  let activeCompareResultFilter = "All";
  let activeCompareResultPath = "";
  let activeCompareDetailView = "source";
  let compareResultsVertical = false;
  let activeCompareMergeViews = [];

  function normalizeOrgHostname(hostname) {
    return String(hostname || "")
      .replace(/\.lightning\.force\.com$/i, ".my.salesforce.com")
      .replace(/\.salesforce-setup\.com$/i, ".salesforce.com");
  }

  function updateCompareTargetSetup() {
    if (!compareTargetSetup) return;
    ObjectConfigCompare.setContext(sourceOrgHost, targetOrgHost);
    const targetConnected = Boolean(targetOrgHost && targetOrgHost !== sourceOrgHost);
    compareTargetSetup.hidden = targetConnected;
    if (!targetConnected) {
      compareObjectSelection.hidden = true;
      return;
    }
    if (compareMode === "objects") return;
    compareObjectSelection.hidden = availableCompareTypes.length === 0;
    if (availableCompareTypes.length) {
      renderCompareScopeTypes();
      renderCompareSelectedItems();
    }
  }

  function setCompareStatus(message, isError = true) {
    if (compareMode === "objects") {
      if (message && isError) ObjectConfigCompare.connectionError(message);
      return;
    }
    const status = compareResultsPage?.hidden ? compareSelectionStatus : compareStatus;
    setStatus(status, message, isError);
    status?.classList.toggle("compare-status-busy", comparisonInProgress && Boolean(message));
  }

  function updateCompareSplitDirection() {
    const split = document.querySelector(".compare-results-split");
    const panes = split?.querySelectorAll(".compare-result-pane");
    if (!split || !compareSplitDirection || !panes?.length) return;
    split.classList.toggle("vertical", compareResultsVertical);
    panes.forEach((pane) => { pane.style.flex = ""; });
    compareResultsResizeHandle?.setAttribute("aria-orientation", compareResultsVertical ? "horizontal" : "vertical");
    compareSplitDirection.setAttribute("aria-pressed", String(compareResultsVertical));
    const label = compareResultsVertical ? "Switch to horizontal split" : "Switch to vertical split";
    compareSplitDirection.title = label;
    compareSplitDirection.setAttribute("aria-label", label);
    compareSplitDirection.innerHTML = compareResultsVertical
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="1"></rect><path d="M3 12H21"></path></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="1"></rect><path d="M12 4V20"></path></svg>';
  }

  function showCompareResultsPage() {
    if (compareOrgIdentities) compareOrgIdentities.hidden = true;
    if (compareTargetSetup) compareTargetSetup.hidden = true;
    if (compareSelectionStatus) compareSelectionStatus.hidden = true;
    compareObjectSelection.hidden = true;
    compareResultsPage.hidden = false;
  }

  function restoreComparisonContext() {
    if (!lastComparisonContext) return;
    sourceOrgHost = lastComparisonContext.sourceHost;
    targetOrgHost = lastComparisonContext.targetHost;
    if (compareSourceOrg) compareSourceOrg.value = lastComparisonContext.sourceLabel;
    if (compareTargetOrg) compareTargetOrg.value = lastComparisonContext.targetLabel;
  }

  function returnToCompareSelection() {
    compareResultsPage.hidden = true;
    if (compareOrgIdentities) compareOrgIdentities.hidden = false;
    if (compareSelectionStatus) compareSelectionStatus.hidden = false;
    updateCompareTargetSetup();
    compareObjectSelection.hidden = false;
    renderCompareSelectedItems();
    setCompareStatus("", false);
  }

  let importedItems = [];
  let validationErrors = [];
  let activeImportSection = "All";
  let importSource = null;
  let exportedRows = [];
  let activeExportCategory = "all";
  let currentExportStep = 1;
  let availableExportObjects = [];
  let exportObjectsLoaded = false;
  let activeExportResultTab = "All";
  let activeExportResultObject = "";
  let activeExportAccessType = "";
  let activeExportResultScope = "object";
  const selectedExportObjects = new Set();

  const deployStepOrder = ["target", "scope", "execute", "results"];
  const deployStepBackButton = document.getElementById("deployStepBack");
  const deployStepNextButton = document.getElementById("deployStepNext");
  const deploySelectTargetOrgButton = document.getElementById("deploySelectTargetOrg");
  const deploySourceOrg = document.getElementById("deploySourceOrg");
  const deploySourceOrgField = document.getElementById("deploySourceOrgField");
  const deployTargetOrg = document.getElementById("deployTargetOrg");
  const deployTargetEnvironment = document.getElementById("deployTargetEnvironment");
  const deployTargetStatus = document.getElementById("deployTargetStatus");
  const deployChangeTargetOrgButton = document.getElementById("deployChangeTargetOrg");
  const deployTargetSetup = document.getElementById("deployTargetSetup");
  const deployOpenTargetOrg = document.getElementById("deployOpenTargetOrg");
  const deploySelectMetadata = document.getElementById("deploySelectMetadata");
  const deployUsePackageXml = document.getElementById("deployUsePackageXml");
  const deployOperationControls = Array.from(document.querySelectorAll("input[name='deployOperation']"));
  const deployDestructiveUpload = document.getElementById("deployDestructiveUpload");
  const deployDestructiveFile = document.getElementById("deployDestructiveFile");
  const deployPackagePicker = document.getElementById("deployPackagePicker");
  const deployPackageName = document.getElementById("deployPackageName");
  const deployPackageFile = document.getElementById("deployPackageFile");
  const deployScopePanel = document.getElementById("deployScopePanel");
  const deployScopeStatus = document.getElementById("deployScopeStatus");
  const deployTypeSearch = document.getElementById("deployTypeSearch");
  const deployTypeList = document.getElementById("deployTypeList");
  const deployMemberSearch = document.getElementById("deployMemberSearch");
  const deployMemberList = document.getElementById("deployMemberList");
  const deploySelectAllMembers = document.getElementById("deploySelectAllMembers");
  const deploySelectedList = document.getElementById("deploySelectedList");
  const deployExecutePanel = document.getElementById("deployExecutePanel");
  const deployResultsPanel = document.getElementById("deployResultsPanel");
  const deployRunButton = document.getElementById("deployRunButton");
  const deployQuickButton = document.getElementById("deployQuickButton");
  const deployTestLevels = Array.from(document.querySelectorAll("input[name='deployTestLevel']"));
  const deployTestNames = document.getElementById("deployTestNames");
  const deployReportColumns = ["Operation", "Type", "Name", "Status", "Message", "Line", "Column"];
  const deployOptionControls = {
    allowMissingFiles: document.getElementById("deployAllowMissingFiles"),
    autoUpdatePackage: document.getElementById("deployAutoUpdatePackage"),
    ignoreWarnings: document.getElementById("deployIgnoreWarnings"),
    rollbackOnError: document.getElementById("deployRollbackOnError")
  };
  const deployExecuteStatus = document.getElementById("deployExecuteStatus");
  const deployResultsStatus = document.getElementById("deployResultsStatus");
  const deployHistorySearch = document.getElementById("deployHistorySearch");
  const deployHistoryList = document.getElementById("deployHistoryList");
  const deployHistoryStatus = document.getElementById("deployHistoryStatus");
  const deployHistoryLabel = document.getElementById("deployHistoryLabel");
  const deployCreateBackup = document.getElementById("deployCreateBackup");
  const deployHistoryZipFile = document.getElementById("deployHistoryZipFile");
  const deployHistoryImportLabel = document.getElementById("deployHistoryImportLabel");
  const deployCacheDatabase = "sf-deployment-history";
  const deployCacheStore = "packages";
  const deployCacheMaxPackages = 10;
  const deployCacheMaxBytes = 200 * 1024 * 1024;
  const deployCacheTtl = 30 * 24 * 60 * 60 * 1000;
  let deployBusy = false;
  let deployRun = null;
  let deployManifest = null;
  let deployDestructiveManifest = null;
  let deployReplay = null;
  let deployReplayEntryId = "";
  let deployReplayExpectedChecksum = "";
  let deployHistoryRecords = [];
  let deployCacheWrite = Promise.resolve();
  let deployOptionalBackupChoice = false;
  let deployScopeGeneration = 0;
  let deployScopeKey = "";
  let deployScopeLoading = false;
  let deployActiveType = "";
  let deployMemberLoad = null;
  const deployTypeCatalogs = new Map();
  const deployScopeTypes = new Map();
  const deployMemberCache = new Map();
  const deploySelection = new Map();
  const deployAvailableTargets = new Map();
  let deployTargetInitialized = false;
  let deployTargetSelectionOpen = false;
  let deploySourceHostname = "";
  let deployTargetHostname = "";
  let deployTargetIsSandbox;
  let deployLoginTabId = null;
  let deployLoginGeneration = 0;
  let currentDeployStep = "target";
  let currentDeployPhase = "target";

  function getDeployOperation() {
    return deployOperationControls.find((control) => control.checked)?.value === "delete" ? "delete" : "deploy";
  }

  function deployZipBytes(encoded) {
    const binary = atob(encoded.replace(/\s/g, ""));
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  async function checksumDeployZip(encoded) {
    const digest = await crypto.subtle.digest("SHA-256", deployZipBytes(encoded));
    return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
  }

  function deployCacheSize(record) {
    return Number(record.packageBytes || 0) + Number(record.backupBytes || 0);
  }

  function openDeployCache() {
    return new Promise((resolve, reject) => {
      if (!globalThis.indexedDB) {
        reject(new Error("IndexedDB is unavailable; deployment history cannot be stored."));
        return;
      }
      const request = indexedDB.open(deployCacheDatabase, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(deployCacheStore)) request.result.createObjectStore(deployCacheStore, { keyPath: "id" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Could not open deployment history storage."));
    });
  }

  async function readDeployCache() {
    const db = await openDeployCache();
    return new Promise((resolve, reject) => {
      const request = db.transaction(deployCacheStore, "readonly").objectStore(deployCacheStore).getAll();
      request.onsuccess = () => { const records = request.result || []; db.close?.(); resolve(records); };
      request.onerror = () => { db.close?.(); reject(request.error || new Error("Could not read deployment history.")); };
    });
  }

  async function writeDeployCache(records) {
    const db = await openDeployCache();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(deployCacheStore, "readwrite");
      const store = transaction.objectStore(deployCacheStore);
      store.clear();
      records.forEach((record) => store.put(record));
      transaction.oncomplete = () => { db.close?.(); resolve(); };
      transaction.onerror = transaction.onabort = () => { db.close?.(); reject(transaction.error || new Error("Could not write deployment history.")); };
    });
  }

  function fitDeployCache(records, protectedId = "") {
    const now = Date.now();
    records.forEach((record) => {
      if (record.createdAt && now - Date.parse(record.createdAt) > deployCacheTtl) {
        record.packageZip = "";
        record.backupZip = "";
        record.packageBytes = 0;
        record.backupBytes = 0;
      }
    });
    const cachedCount = () => records.filter((record) => Boolean(record.packageZip)).length;
    const totalBytes = () => records.reduce((sum, record) => sum + deployCacheSize(record), 0);
    const candidates = records.filter((record) => !record.pinned && record.id !== protectedId && (record.packageZip || record.backupZip))
      .sort((left, right) => Date.parse(left.createdAt) - Date.parse(right.createdAt));
    while (cachedCount() > deployCacheMaxPackages || totalBytes() > deployCacheMaxBytes) {
      const candidate = candidates.shift();
      if (!candidate) throw new Error("Deployment cache is full because pinned packages use the available capacity. Unpin or download an item before saving.");
      candidate.packageZip = "";
      candidate.backupZip = "";
      candidate.packageBytes = 0;
      candidate.backupBytes = 0;
    }
    records.sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt));
    const pinned = records.filter((record) => record.pinned);
    if (pinned.length > 200) throw new Error("Deployment history is full of pinned entries. Unpin an entry before saving more history.");
    const keep = new Set(pinned.map((record) => record.id));
    records.filter((record) => !record.pinned).slice(0, 200 - pinned.length).forEach((record) => keep.add(record.id));
    return records.filter((record) => keep.has(record.id));
  }

  function renderDeployHistory() {
    if (!deployHistoryList) return;
    const query = deployHistorySearch?.value.trim().toLowerCase() || "";
    deployHistoryList.replaceChildren();
    const matching = deployHistoryRecords.filter((record) => !query || [
      record.label, record.createdAt, record.source, record.target, record.operation, ...(record.components || [])
    ].join(" ").toLowerCase().includes(query));
    if (!matching.length) {
      const empty = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 7;
      cell.textContent = deployHistoryRecords.length ? "No matching deployments." : "No saved deployments yet.";
      empty.appendChild(cell);
      deployHistoryList.appendChild(empty);
    }
    matching.forEach((record) => {
      const item = document.createElement("tr");
      const values = [
        record.label || "Deployment",
        new Date(record.createdAt).toLocaleString(),
        record.operation === "delete" ? "Delete" : "Deploy",
        record.source || "",
        record.target || "",
        String((record.components || []).length)
      ];
      values.forEach((value, index) => {
        const cell = document.createElement("td");
        if (index === 5) {
          const count = document.createElement("button");
          count.type = "button";
          count.textContent = `${value} ${value === "1" ? "item" : "items"}`;
          count.addEventListener("click", () => {
            const dialog = document.getElementById("deployHistoryComponentsDialog");
            document.getElementById("deployHistoryComponentsTitle").textContent = `${record.label || "Deployment"}: ${value} components`;
            const list = document.getElementById("deployHistoryComponentsList");
            list.replaceChildren();
            (record.components || []).forEach((component) => {
              const entry = document.createElement("li");
              entry.textContent = component;
              list.appendChild(entry);
            });
            dialog.showModal();
          });
          cell.appendChild(count);
        } else cell.textContent = value;
        item.appendChild(cell);
      });
      const actions = document.createElement("td");
      const controls = document.createElement("div");
      controls.className = "deploy-history-actions";
      actions.appendChild(controls);
      item.appendChild(actions);
      const button = (text, callback, disabled = false, title = "") => {
        const control = document.createElement("button");
        control.type = "button";
        control.textContent = text;
        control.disabled = disabled;
        if (title) control.title = title;
        control.addEventListener("click", callback);
        controls.appendChild(control);
        return control;
      };
      button(record.pinned ? "Unpin" : "Pin", () => setDeployHistoryPinned(record.id, !record.pinned), false, record.pinned
        ? "Unpin to allow automatic removal when the cache is full. ZIPs still expire after 30 days. Download ZIP to keep your own copy."
        : "Pin to protect this entry from removal when the cache reaches 10 packages or 200 MB. ZIPs still expire after 30 days. Pinning does not download a copy.");
      const packageDownload = button("ZIP", () => downloadHistoryZip(record.id, "package"), !record.packageZip, "Download deployment ZIP");
      const backupDownload = button("Backup", () => downloadHistoryZip(record.id, "backup"), !record.backupZip, "Download target backup ZIP");
      for (const control of [packageDownload, backupDownload]) {
        control.className = "deploy-history-download";
        control.setAttribute("aria-label", control.title);
        const icon = document.createElement("span");
        icon.className = "deploy-history-download-icon";
        icon.setAttribute("aria-hidden", "true");
        icon.innerHTML = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 1v9m-4-4 4 4 4-4M2 10v4h12v-4"/></svg>';
        const label = document.createElement("span");
        label.textContent = control.textContent;
        control.replaceChildren(icon, label);
      }
      button("Re-deploy", () => prepareDeployReplay(record.id), record.operation === "delete" || !record.checksum);
      deployHistoryList.appendChild(item);
    });
  }

  async function refreshDeployHistory() {
    if (!deployHistoryList) return;
    try {
      const records = await readDeployCache();
      const fingerprint = (record) => [Boolean(record.packageZip), Boolean(record.backupZip), record.packageBytes || 0, record.backupBytes || 0, Boolean(record.pinned)].join(":");
      const original = new Map(records.map((record) => [record.id, fingerprint(record)]));
      const originalOrder = records.map((record) => record.id).join("|");
      const fitted = fitDeployCache(records.filter(isSuccessfulDeployHistory));
      if (originalOrder !== fitted.map((record) => record.id).join("|") ||
          fitted.some((record) => original.get(record.id) !== fingerprint(record))) await writeDeployCache(fitted);
      deployHistoryRecords = fitted;
      setStatus(deployHistoryStatus, "", false);
      renderDeployHistory();
    } catch (error) {
      setStatus(deployHistoryStatus, error.message || "Deployment history is unavailable.");
    }
  }

  function isSuccessfulDeployHistory(record) {
    const result = record.report?.deployment;
    return Boolean(result?.done && result.success && result.status === "Succeeded");
  }

  function persistDeployHistory(record, protectedId = record.id) {
    deployCacheWrite = deployCacheWrite.catch(() => {}).then(async () => {
      const records = (await readDeployCache()).filter(isSuccessfulDeployHistory);
      const existing = records.findIndex((entry) => entry.id === record.id);
      if (existing >= 0) records.splice(existing, 1);
      records.push(record);
      const fitted = fitDeployCache(records, protectedId);
      await writeDeployCache(fitted);
      deployHistoryRecords = fitted;
      renderDeployHistory();
      setStatus(deployHistoryStatus, "", false);
      return fitted;
    }).catch((error) => {
      setStatus(deployHistoryStatus, `History/cache not saved: ${String(error.message || "storage is full")}. Download the package and backup now.`, true);
      throw error;
    });
    return deployCacheWrite;
  }

  async function setDeployHistoryPinned(id, pinned) {
    try {
      const record = deployHistoryRecords.find((entry) => entry.id === id);
      if (!record) return;
      record.pinned = Boolean(pinned);
      await persistDeployHistory(record, id);
    } catch { /* The storage status explains that the pin change was not saved. */ }
  }

  async function downloadHistoryZip(id, kind) {
    try {
      const record = deployHistoryRecords.find((entry) => entry.id === id);
      const encoded = kind === "backup" ? record?.backupZip : record?.packageZip;
      if (!encoded) throw new Error("This ZIP is no longer cached. Re-deploy requires the original deployment ZIP.");
      downloadFile(`${record.label || "deployment"}-${kind === "backup" ? "target-backup" : "package"}.zip`, new Blob([deployZipBytes(encoded)], { type: "application/zip" }), "application/zip");
    } catch (error) {
      setStatus(deployHistoryStatus, error.message || "Could not download the ZIP.");
    }
  }

  async function prepareDeployReplay(id) {
    if (deployBusy || hasPendingDeployOperation()) return;
    const record = deployHistoryRecords.find((entry) => entry.id === id);
    if (!record) return;
    if (!record.packageZip) {
      deployReplayEntryId = id;
      deployReplayExpectedChecksum = record.checksum;
      deployHistoryImportLabel.hidden = false;
      deployHistoryZipFile.hidden = false;
      setStatus(deployHistoryStatus, "Package ZIP is not cached. Choose its original ZIP below; checksum verification is required.", false);
      deployHistoryZipFile?.click();
      return;
    }
    try {
      const replayTarget = deployTargetHostname && deployTargetHostname !== record.source ? deployTargetHostname : record.target;
      const generation = deployScopeGeneration;
      if (await checksumDeployZip(record.packageZip) !== record.checksum) throw new Error("Cached ZIP checksum mismatch. The package was not loaded.");
      if (generation !== deployScopeGeneration) return;
      const zip = await JSZip.loadAsync(record.packageZip, { base64: true });
      if (generation !== deployScopeGeneration) return;
      resetDeployScope();
      deployReplay = { encoded: record.packageZip, zip, record };
      deployReplayEntryId = id;
      deploySourceHostname = record.source;
      deployTargetHostname = replayTarget;
      deployTargetOrg.textContent = replayTarget;
      deployTargetOrg.title = replayTarget;
      deployOpenTargetOrg.value = replayTarget;
      resetDeployOptionsForTarget();
      deploySelection.clear();
      (record.types || []).forEach((entry) => deploySelection.set(entry.type, new Set(entry.members)));
      deployOperationControls.forEach((control) => { control.checked = control.value === "deploy"; });
      deployCreateBackup.checked = deployOptionalBackupChoice;
      deployUsePackageXml.checked = false;
      deploySelectMetadata.checked = true;
      deployManifest = null;
      setDeployStep("scope");
      setStatus(deployHistoryStatus, "Original deployment ZIP loaded. Choose a target org, then review options and execute.", false);
      await refreshDeploySourceOrg();
      const targetInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: replayTarget });
      if (typeof targetInfo.isSandbox !== "boolean") throw new Error("The history target is no longer authenticated. Choose another target org.");
      deployTargetIsSandbox = targetInfo.isSandbox;
      updateDeployStepActions();
    } catch (error) {
      setStatus(deployHistoryStatus, error.message || "Could not load the saved deployment ZIP.");
    }
  }

  async function recoverDeployHistoryReport(id) {
    if (deployBusy || hasPendingDeployOperation()) return;
    const record = deployHistoryRecords.find((entry) => entry.id === id);
    if (!record?.spec || !record.report) return;
    const generation = deployScopeGeneration;
    try {
      let packageInfo = null;
      if (record.packageZip) packageInfo = { encoded: record.packageZip, zip: await JSZip.loadAsync(record.packageZip, { base64: true }) };
      if (generation !== deployScopeGeneration) return;
      let backup = null;
      if (record.backupZip) backup = { encoded: record.backupZip, zip: await JSZip.loadAsync(record.backupZip, { base64: true }) };
      if (generation !== deployScopeGeneration) return;
      resetDeployScope();
      deployRun = {
        spec: record.spec,
        signature: JSON.stringify(record.spec),
        startedAt: record.createdAt,
        status: record.status || "Saved report",
        validation: record.report.validation || null,
        deployment: record.report.deployment || null,
        verification: record.report.verification || { status: "Not run", files: [] },
        error: record.report.error || "",
        package: packageInfo,
        backup,
        historyId: id,
        orgs: { sourceId: record.sourceOrgId || "", targetId: record.targetOrgId || "" },
        log: []
      };
      deploySourceHostname = record.source;
      deployTargetHostname = record.target;
      try { deployTargetIsSandbox = (await SFPanel.sendMessage({ type: "getOrgInfo", hostname: record.target })).isSandbox; } catch { deployTargetIsSandbox = undefined; }
      setDeployStep("results");
      renderDeployReport();
      await refreshDeployReport();
    } catch (error) {
      setStatus(deployHistoryStatus, error.message || "Could not restore deployment report.");
    }
  }

  async function acceptDeployReplayZip() {
    const file = deployHistoryZipFile?.files?.[0];
    if (!file || !deployReplayExpectedChecksum) return;
    try {
      if (deployBusy || hasPendingDeployOperation()) return;
      const generation = deployScopeGeneration;
      const expectedId = deployReplayEntryId;
      if (file.size > 21 * 1024 * 1024) throw new Error("The original deployment ZIP exceeds the 21 MB compressed package limit.");
      const bytes = new Uint8Array(await file.arrayBuffer());
      if (generation !== deployScopeGeneration || expectedId !== deployReplayEntryId) return;
      const digest = await crypto.subtle.digest("SHA-256", bytes);
      const checksum = Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
      if (checksum !== deployReplayExpectedChecksum) throw new Error("The selected ZIP checksum does not match this history entry.");
      const encoded = btoa(Array.from(bytes, (byte) => String.fromCharCode(byte)).join(""));
      const zip = await JSZip.loadAsync(bytes);
      if (generation !== deployScopeGeneration || expectedId !== deployReplayEntryId) return;
      const record = deployHistoryRecords.find((entry) => entry.id === deployReplayEntryId);
      if (!record) throw new Error("The selected history entry no longer exists.");
      const replayTarget = deployTargetHostname && deployTargetHostname !== record.source ? deployTargetHostname : record.target;
      resetDeployScope();
      deployReplay = { encoded, zip, record };
      deploySourceHostname = record.source;
      deployTargetHostname = replayTarget;
      deployTargetOrg.textContent = replayTarget;
      deployTargetOrg.title = replayTarget;
      deployOpenTargetOrg.value = replayTarget;
      resetDeployOptionsForTarget();
      deployCreateBackup.checked = deployOptionalBackupChoice;
      deploySelection.clear();
      (record.types || []).forEach((entry) => deploySelection.set(entry.type, new Set(entry.members)));
      deployOperationControls.forEach((control) => { control.checked = control.value === "deploy"; });
      deployUsePackageXml.checked = false;
      deploySelectMetadata.checked = true;
      deployManifest = null;
      const targetInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: replayTarget });
      if (typeof targetInfo.isSandbox !== "boolean") throw new Error("The history target is no longer authenticated. Choose another target org.");
      deployTargetIsSandbox = targetInfo.isSandbox;
      setDeployStep("scope");
      setStatus(deployHistoryStatus, "ZIP checksum verified. The immutable package is ready to re-deploy.", false);
      deployHistoryImportLabel.hidden = true;
      deployHistoryZipFile.hidden = true;
      updateDeployExecutionActions();
    } catch (error) {
      setStatus(deployHistoryStatus, error.message || "Could not validate the ZIP.");
    }
  }

  function resetDeployOptionsForTarget() {
    deployTestLevels.forEach((control) => { control.checked = control.value === ""; });
    deployTestNames.value = "";
    Object.entries(deployOptionControls).forEach(([name, control]) => {
      control.checked = name === "rollbackOnError";
    });
  }

  function updateDeployBackupRequirement() {
    const deleting = getDeployOperation() === "delete";
    if (deleting) deployCreateBackup.checked = true;
    deployCreateBackup.disabled = deleting || deployBusy || hasPendingDeployOperation();
    document.getElementById("deployBackupRequiredNote").textContent = deleting
      ? "Required before deletion. Metadata only; not a complete rollback."
      : "Optional for deployments. Metadata only; not a complete rollback.";
  }

  function updateDeployStepActions() {
    if (deployTargetSetup) deployTargetSetup.hidden = currentDeployStep !== "target" || !deployTargetSelectionOpen;
    if (deployScopePanel) deployScopePanel.hidden = currentDeployStep !== "scope";
    if (deployPackagePicker) deployPackagePicker.hidden = getDeployOperation() === "delete" || !deployUsePackageXml.checked;
    if (deploySourceOrgField) deploySourceOrgField.hidden = getDeployOperation() === "delete";
    if (deployDestructiveUpload) deployDestructiveUpload.hidden = getDeployOperation() !== "delete" || !deployUsePackageXml.checked;
    document.getElementById("deployXmlModeLabel").textContent = getDeployOperation() === "delete" ? "Use destructiveChanges.xml" : "Use package.xml";
    updateDeployBackupRequirement();
    if (deployExecutePanel) deployExecutePanel.hidden = currentDeployStep !== "execute";
    if (deployResultsPanel) deployResultsPanel.hidden = currentDeployStep !== "results";
    updateDeployExecutionActions();
    if (!deployStepBackButton || !deployStepNextButton) return;
    const stepIndex = deployStepOrder.indexOf(currentDeployStep);
    deployStepBackButton.hidden = stepIndex <= 0;
    deployStepBackButton.disabled = deployBusy || hasPendingDeployOperation();
    const nextLabels = { target: "Next", scope: "Next", retrieve: "Validate", validate: "Deploy", deploy: "Deploying...", verify: "Verifying...", report: "Complete" };
    deployStepNextButton.textContent = nextLabels[currentDeployPhase] || "Next";
    deployStepNextButton.hidden = currentDeployStep === "results";
    if (currentDeployStep === "execute") deployStepNextButton.textContent = "Verify and Report";
    deployStepNextButton.disabled = deployBusy || (currentDeployStep === "execute" && !deployRun) ||
      (currentDeployStep === "target" && (!deployTargetHostname || (getDeployOperation() === "deploy" && !deploySourceHostname))) ||
      (currentDeployStep === "target" && getDeployOperation() === "deploy" && deployUsePackageXml.checked && !deployManifest) ||
      (currentDeployStep === "scope" && (deployScopeLoading || getDeploySelectionCount() === 0));
  }

  function setDeployStep(step) {
    if (deployBusy && step !== currentDeployStep) return;
    const phases = { retrieve: "execute", validate: "execute", deploy: "execute", verify: "results", report: "results" };
    const groupedStep = phases[step] || step;
    const activeIndex = deployStepOrder.indexOf(groupedStep);
    if (activeIndex < 0) return;
    currentDeployStep = groupedStep;
    currentDeployPhase = step;
    document.getElementById("tab-import")?.classList.toggle("deploy-target-step", groupedStep === "target");
    document.querySelectorAll("[data-deploy-step]").forEach((element) => {
      const index = deployStepOrder.indexOf(element.dataset.deployStep);
      element.classList.toggle("completed", index < activeIndex);
      element.classList.toggle("active", index === activeIndex);
    });
    updateDeployStepActions();
    if (groupedStep === "scope") initializeDeployScope();
  }

  async function refreshDeploySourceOrg() {
    if (!deploySourceOrg) return;
    const hostname = deploySourceHostname || SFPanel.getHostname();
    if (!hostname) {
      deploySourceOrg.textContent = "No Salesforce org detected";
      deploySourceOrg.removeAttribute("title");
      return;
    }
    deploySourceHostname = hostname;
    updateDeployStepActions();
    deploySourceOrg.textContent = hostname;
    deploySourceOrg.title = hostname;
    try {
      const response = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
      if (deploySourceHostname === hostname && response.username) {
        deploySourceOrg.textContent = response.username;
      }
    } catch {
      // The hostname remains available when org-info access is unavailable.
    }
    if (!deployTargetInitialized) await loadDeployTargetChoices(true);
  }

  function selectDeployTarget(hostname, info) {
    if ((getDeployOperation() === "deploy" && hostname === deploySourceHostname) || typeof info.isSandbox !== "boolean") return false;
    if (hostname !== deployTargetHostname) {
      resetDeployScope();
      resetDeployOptionsForTarget();
      deployDestructiveFile.value = "";
    }
    deployTargetHostname = hostname;
    deployTargetIsSandbox = info.isSandbox;
    deployTargetOrg.textContent = info.username || info.name || hostname;
    deployTargetOrg.title = hostname;
    deployTargetEnvironment.value = info.isSandbox ? "sandbox" : "production";
    deployOpenTargetOrg.value = hostname;
    deploySelectTargetOrgButton.disabled = false;
    deployTargetSelectionOpen = false;
    setStatus(deployTargetStatus, "", false);
    updateDeployStepActions();
    if (currentDeployStep === "scope") initializeDeployScope();
    return true;
  }

  async function loadDeployTargetChoices(autoSelect = false) {
    deployTargetInitialized = true;
    const generation = deployLoginGeneration;
    const targets = new Map();
    try {
      const hosts = await getSalesforceTabHosts(true);
      for (const hostname of hosts.filter((host) => getDeployOperation() === "delete" || host !== deploySourceHostname)) {
        if (generation !== deployLoginGeneration) return;
        try {
          const info = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
          if (generation !== deployLoginGeneration) return;
          if (typeof info.isSandbox === "boolean") targets.set(hostname, info);
        } catch {
          if (generation !== deployLoginGeneration) return;
        }
      }
    } catch {
      if (generation !== deployLoginGeneration) return;
    }
    if (generation !== deployLoginGeneration) return;
    deployAvailableTargets.clear();
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Select an open org";
    deployOpenTargetOrg.replaceChildren(placeholder);
    for (const [hostname, info] of targets) {
      deployAvailableTargets.set(hostname, info);
      const option = document.createElement("option");
      option.value = hostname;
      option.textContent = info.username || info.name || hostname;
      option.title = hostname;
      deployOpenTargetOrg.appendChild(option);
    }
    deployOpenTargetOrg.disabled = targets.size === 0;
    if (autoSelect && !deployTargetHostname && targets.size) {
      const [hostname, info] = targets.entries().next().value;
      selectDeployTarget(hostname, info);
    } else if (!deployTargetHostname) {
      deployTargetSelectionOpen = true;
      setStatus(deployTargetStatus, targets.size ? "Choose an open target org or log in to another org." : "Log in to a different Salesforce org to select a target.", false);
      updateDeployStepActions();
    }
  }

  function changeDeployTarget() {
    if (deployBusy || hasPendingDeployOperation()) return;
    deployLoginGeneration++;
    deployTargetInitialized = true;
    deployLoginTabId = null;
    deployTargetHostname = "";
    deployTargetIsSandbox = undefined;
    resetDeployScope();
    deployDestructiveFile.value = "";
    resetDeployOptionsForTarget();
    deployTargetOrg.textContent = "Select a target org to continue";
    deployTargetOrg.removeAttribute("title");
    deployOpenTargetOrg.value = "";
    deployTargetEnvironment.value = "";
    deploySelectTargetOrgButton.disabled = true;
    deployTargetSelectionOpen = true;
    setStatus(deployTargetStatus, "Loading open orgs...", false);
    updateDeployStepActions();
    loadDeployTargetChoices();
  }

  async function selectOpenDeployTarget() {
    if (deployBusy || hasPendingDeployOperation()) return;
    const hostname = deployOpenTargetOrg.value;
    const generation = ++deployLoginGeneration;
    deployLoginTabId = null;
    deployTargetHostname = "";
    deployTargetIsSandbox = undefined;
    deployTargetIsSandbox = undefined;
    resetDeployScope();
    updateDeployStepActions();
    if (!deployAvailableTargets.has(hostname) || (getDeployOperation() === "deploy" && hostname === deploySourceHostname)) return;
    try {
      const info = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
      if (generation !== deployLoginGeneration) return;
      if (!selectDeployTarget(hostname, info)) setStatus(deployTargetStatus, "Unable to confirm the selected target org.");
    } catch {
      if (generation === deployLoginGeneration) setStatus(deployTargetStatus, "The selected org is no longer authenticated. Log in again.");
    }
  }

  function getImportTargetHostname() {
    return SFPanel.getActiveTab() === "deploy" ? deployTargetHostname : SFPanel.getHostname();
  }

  async function openDeployTargetLogin() {
    if (deployBusy || hasPendingDeployOperation()) return;
    const environment = deployTargetEnvironment.value;
    const loginUrls = { production: "https://login.salesforce.com/", sandbox: "https://test.salesforce.com/" };
    if (!Object.hasOwn(loginUrls, environment)) {
      setStatus(deployTargetStatus, "Select Production or Sandbox.");
      return;
    }
    const generation = ++deployLoginGeneration;
    deploySelectTargetOrgButton.disabled = true;
    deployTargetHostname = "";
    deployTargetIsSandbox = undefined;
    resetDeployScope();
    deployDestructiveFile.value = "";
    deployLoginTabId = null;
    deployOpenTargetOrg.value = "";
    deployTargetOrg.textContent = "Waiting for target login";
    deployTargetOrg.removeAttribute("title");
    updateDeployStepActions();
    try {
      const loginTab = await chrome.tabs.create({ url: loginUrls[environment], active: true });
      if (generation !== deployLoginGeneration) return;
      if (!loginTab?.id) throw new Error("The browser did not provide the new login tab.");
      deployLoginTabId = loginTab.id;
      setStatus(deployTargetStatus, `Log in to the target ${environment} org.`, false);
    } catch {
      if (generation === deployLoginGeneration) setStatus(deployTargetStatus, "Unable to open the target login page. Try again.");
    } finally {
      if (generation === deployLoginGeneration) deploySelectTargetOrgButton.disabled = false;
    }
  }

  function getDeploySelectionCount() {
    return Array.from(deploySelection.values()).reduce((total, members) => total + members.size, 0);
  }

  function resetDeployScope() {
    deployRun = null;
    deployReplay = null;
    deployDestructiveManifest = null;
    deployScopeGeneration++;
    deployScopeKey = "";
    deployScopeLoading = false;
    deployActiveType = "";
    deployMemberLoad = null;
    deployTypeCatalogs.clear();
    deployScopeTypes.clear();
    deployMemberCache.clear();
    deploySelection.clear();
  }

  function parseDeployPackageXml(text, { allowEmpty = false } = {}) {
    if (text.length > 2 * 1024 * 1024 || /<!DOCTYPE|<!ENTITY/i.test(text)) throw new Error("The manifest is too large or contains unsupported XML declarations.");
    const xml = new DOMParser().parseFromString(text, "application/xml");
    const root = xml.documentElement;
    if (xml.querySelector("parsererror") || root?.localName !== "Package" || root.namespaceURI !== "http://soap.sforce.com/2006/04/metadata") throw new Error("Select a valid Salesforce package.xml manifest.");
    const children = (element, name) => Array.from(element.children).filter((child) => child.localName === name);
    const versions = children(root, "version");
    const version = versions[0]?.textContent.trim();
    if (versions.length !== 1 || !/^\d{1,3}\.0$/.test(version || "")) throw new Error("The manifest must contain one valid API version.");
    const types = new Map();
    let count = 0;
    for (const entry of children(root, "types")) {
      const names = children(entry, "name");
      const name = names[0]?.textContent.trim();
      if (names.length !== 1 || !/^[A-Za-z][A-Za-z0-9_]{0,79}$/.test(name || "")) throw new Error("The manifest contains an invalid metadata type.");
      const members = children(entry, "members").map((member) => member.textContent.trim());
      if (!members.length || members.some((member) => !member || member.length > 500 || /[\u0000-\u001f\u007f]/.test(member))) throw new Error(`Invalid or missing members for ${name}.`);
      if (!types.has(name)) types.set(name, new Set());
      members.forEach((member) => types.get(name).add(member));
      count += members.length;
      if (count > 10000) throw new Error("The manifest contains too many members (maximum 10,000).");
    }
    if (!types.size && !allowEmpty) throw new Error("The manifest contains no metadata types.");
    return { version, types };
  }

  async function loadDeployPackageFile() {
    if (deployBusy) return;
    const file = deployPackageFile.files?.[0];
    if (!file) return;
    resetDeployScope();
    const generation = deployScopeGeneration;
    deployManifest = null;
    deployPackageName.value = file.name;
    updateDeployStepActions();
    try {
      if (file.size > 2 * 1024 * 1024) throw new Error("The manifest must be smaller than 2 MB.");
      const text = await file.text();
      if (generation !== deployScopeGeneration) return;
      deployManifest = parseDeployPackageXml(text);
      setStatus(deployTargetStatus, "", false);
    } catch (error) {
      if (generation === deployScopeGeneration) setStatus(deployTargetStatus, error.message || "Unable to read the manifest.");
    }

    updateDeployStepActions();
  }

  async function loadDeployDestructiveFile() {
    if (deployBusy) return;
    const file = deployDestructiveFile.files?.[0];
    if (!file) return;
    resetDeployScope();
    const generation = deployScopeGeneration;
    try {
      if (file.size > 2 * 1024 * 1024) throw new Error("The destructive manifest must be smaller than 2 MB.");
      const text = await file.text();
      if (generation !== deployScopeGeneration) return;
      deployDestructiveManifest = parseDeployPackageXml(text);
      deploySelection.clear();
      deployDestructiveManifest.types.forEach((members, type) => deploySelection.set(type, new Set(members)));
      setStatus(deployScopeStatus, "Destructive manifest loaded. Review the target-only members before validation.", false);
      await initializeDeployScope();
    } catch (error) {
      if (generation === deployScopeGeneration) setStatus(deployScopeStatus, error.message || "Unable to read destructiveChanges.xml.");
    }
    updateDeployStepActions();
  }

  function getDeploySelectedMembers(type) {
    if (!deploySelection.has(type)) deploySelection.set(type, new Set());
    return deploySelection.get(type);
  }

  function renderDeployScope() {
    const filter = deployTypeSearch.value.trim().toLowerCase();
    deployTypeList.replaceChildren();
    Array.from(deployScopeTypes.values()).sort((left, right) => left.name.localeCompare(right.name)).filter((entry) => !filter || entry.name.toLowerCase().includes(filter) || entry.label.toLowerCase().includes(filter)).forEach((entry) => {
      const item = document.createElement("li");
      item.className = "pkg-list-item";
      item.tabIndex = 0;
      item.textContent = entry.label;
      item.title = entry.name;
      item.classList.toggle("active", entry.name === deployActiveType);
      const activate = () => loadDeployScopeMembers(entry.name);
      item.addEventListener("click", activate);
      item.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } });
      deployTypeList.appendChild(item);
    });
    document.getElementById("deployTypesCount").textContent = `${deployScopeTypes.size} available`;
    deploySelectedList.replaceChildren();
    Array.from(deploySelection).sort(([left], [right]) => left.localeCompare(right)).forEach(([type, members]) => {
      if (!members.size) return;
      const item = document.createElement("li");
      const details = document.createElement("details");
      const summary = document.createElement("summary");
      summary.textContent = `${type} (${members.size})`;
      details.appendChild(summary);
      for (const member of Array.from(members).sort()) {
        const row = document.createElement("div");
        row.textContent = member;
        details.appendChild(row);
      }
      item.appendChild(details);
      deploySelectedList.appendChild(item);
    });
    document.getElementById("deploySelectedCount").textContent = `${getDeploySelectionCount()} selected`;
    renderDeployScopeMembers();
    updateDeployStepActions();
  }

  function getDeployVisibleMembers() {
    const filter = deployMemberSearch.value.trim().toLowerCase();
    return (deployMemberCache.get(deployActiveType) || []).filter((member) => {
      const availableForOperation = getDeployOperation() === "delete" ? member.inTarget !== false : member.inSource !== false;
      return availableForOperation && (!filter || member.apiName.toLowerCase().includes(filter) || member.label.toLowerCase().includes(filter));
    });
  }

  function renderDeployScopeMembers() {
    deployMemberList.replaceChildren();
    document.getElementById("deployMembersTitle").textContent = deployActiveType || "Members";
    deployMemberList.setAttribute("aria-busy", String(!!deployMemberLoad?.loading));
    if (deployMemberLoad?.loading || deployMemberLoad?.error) {
      document.getElementById("deployMembersCount").textContent = deployMemberLoad.loading ? "Loading..." : "0 available";
      deploySelectAllMembers.disabled = true;
      deploySelectAllMembers.checked = false;
      deploySelectAllMembers.indeterminate = false;
      const row = document.createElement("li");
      row.className = "deploy-member-status";
      row.setAttribute("role", deployMemberLoad.loading ? "status" : "alert");
      if (deployMemberLoad.loading) {
        const spinner = document.createElement("span");
        spinner.className = "export-loading-spinner";
        spinner.setAttribute("aria-hidden", "true");
        row.appendChild(spinner);
      }
      const message = document.createElement("span");
      message.textContent = deployMemberLoad.loading ? "Loading members..." : deployMemberLoad.error;
      row.appendChild(message);
      deployMemberList.appendChild(row);
      return;
    }
    const members = getDeployVisibleMembers();
    const selected = getDeploySelectedMembers(deployActiveType);
    document.getElementById("deployMembersCount").textContent = `${members.length} available`;
    members.forEach((member) => {
      const item = document.createElement("li");
      item.className = "pkg-list-item";
      const label = document.createElement("label");
      label.className = "checkbox-row";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = selected.has(member.apiName);
      checkbox.addEventListener("change", () => {
        deployRun = null;
        deployReplay = null;
        if (checkbox.checked) selected.add(member.apiName); else selected.delete(member.apiName);
        renderDeployScope();
      });
      const text = document.createElement("span");
      text.textContent = member.apiName;
      label.append(checkbox, text);
      item.appendChild(label);
      deployMemberList.appendChild(item);
    });
    const selectable = members;
    const count = selectable.filter((member) => selected.has(member.apiName)).length;
    deploySelectAllMembers.disabled = !selectable.length;
    deploySelectAllMembers.checked = selectable.length > 0 && count === selectable.length;
    deploySelectAllMembers.indeterminate = count > 0 && count < selectable.length;
  }

  async function loadDeployScopeMembers(type) {
    const generation = deployScopeGeneration;
    const request = { loading: !deployMemberCache.has(type), error: "" };
    deployMemberLoad = request;
    deployActiveType = type;
    renderDeployScope();
    try {
      if (!deployMemberCache.has(type)) {
        const hosts = getDeployOperation() === "delete" ? [deployTargetHostname] : [deploySourceHostname, deployTargetHostname];
        const lists = await Promise.all(hosts.map((host) => deployTypeCatalogs.get(host)?.has(type) ? listDeployScopeMembers(host, type) : []));
        if (generation !== deployScopeGeneration || deployMemberLoad !== request) return;
        const members = new Map();
        lists.forEach((list, index) => list.forEach((member) => {
          const entry = members.get(member.apiName) || { ...member, inSource: false, inTarget: false };
          if (getDeployOperation() === "delete") entry.inTarget = true;
          else if (index === 0) entry.inSource = true; else entry.inTarget = true;
          members.set(member.apiName, entry);
        }));
        deployMemberCache.set(type, Array.from(members.values()).sort((left, right) => left.apiName.localeCompare(right.apiName)));
      }
    } catch (error) {
      if (generation === deployScopeGeneration && deployMemberLoad === request) request.error = error.message || "Could not load metadata members.";
    } finally {
      if (generation === deployScopeGeneration && deployMemberLoad === request) {
        request.loading = false;
        renderDeployScope();
      }
    }
  }

  async function listDeployScopeMembers(hostname, type) {
    const folderTypes = { Report: "ReportFolder", Dashboard: "DashboardFolder", Document: "DocumentFolder", EmailTemplate: "EmailFolder" };
    if (!Object.hasOwn(folderTypes, type)) return listMetadataMembers(hostname, type, "", "deploy_metadata");
    const folders = await listMetadataMembers(hostname, folderTypes[type], "", "deploy_metadata");
    const names = new Set(folders.map((folder) => folder.apiName));
    if (type === "Document" || type === "EmailTemplate") names.add("unfiled$public");
    const members = new Map();
    for (const folder of names) {
      const entries = await listMetadataMembers(hostname, type, folder, "deploy_metadata");
      entries.forEach((entry) => members.set(entry.apiName, entry));
    }
    return Array.from(members.values());
  }

  async function initializeDeployScope() {
    const operation = getDeployOperation();
    const key = `${deploySourceHostname}|${deployTargetHostname}|${operation}|${deployUsePackageXml.checked ? "xml" : "metadata"}`;
    if (deployScopeKey === key || deployScopeLoading) return;
    if (!deployTargetHostname || (operation === "deploy" && !deploySourceHostname)) return;
    const generation = deployScopeGeneration;
    deployScopeLoading = true;
    updateDeployStepActions();
    setStatus(deployScopeStatus, "Loading metadata types...", false);
    try {
      if (operation === "delete" && deployUsePackageXml.checked && !deployDestructiveManifest) {
        setStatus(deployScopeStatus, "Choose destructiveChanges.xml to review the metadata to delete.", false);
        return;
      } else if (operation === "delete" && deployDestructiveManifest) {
        for (const [type, members] of deployDestructiveManifest.types) {
          deployScopeTypes.set(type, { name: type, label: metadataTypeLabel(type) });
          deploySelection.set(type, new Set(members));
          deployMemberCache.set(type, Array.from(members).map((member) => ({ apiName: member, label: member, inTarget: true })));
        }
      } else if (operation === "delete") {
        const catalog = await getOrgComparableTypes(deployTargetHostname, "deploy_metadata");
        if (generation !== deployScopeGeneration) return;
        deployTypeCatalogs.set(deployTargetHostname, catalog);
        catalog.forEach((entry, type) => deployScopeTypes.set(type, entry));
      } else if (deployUsePackageXml.checked) {
        if (!deployManifest) throw new Error("Choose a valid package.xml first.");
        for (const [type, members] of deployManifest.types) {
          deployScopeTypes.set(type, { name: type, label: metadataTypeLabel(type) });
          deploySelection.set(type, new Set(members));
          deployMemberCache.set(type, Array.from(members).map((member) => ({ apiName: member, label: member })));
        }
      } else {
        const catalogs = await Promise.all([deploySourceHostname, deployTargetHostname].map((host) => getOrgComparableTypes(host, "deploy_metadata")));
        if (generation !== deployScopeGeneration) return;
        [deploySourceHostname, deployTargetHostname].forEach((host, index) => deployTypeCatalogs.set(host, catalogs[index]));
        catalogs.forEach((catalog) => catalog.forEach((entry, type) => deployScopeTypes.set(type, entry)));
      }
      deployScopeKey = key;
      setStatus(deployScopeStatus, "", false);
      renderDeployScope();
    } catch (error) {
      if (generation === deployScopeGeneration) setStatus(deployScopeStatus, error.message || "Could not load metadata types.");
    } finally {
      if (generation === deployScopeGeneration) {
        deployScopeLoading = false;
        updateDeployStepActions();
      }
    }
  }

  function getDeployRequestSpec() {
    const operation = getDeployOperation();
    if (!deployTargetHostname || (operation === "deploy" && (!deploySourceHostname || deploySourceHostname === deployTargetHostname))) throw new Error("Select different source and target orgs first.");
    if (operation === "delete" && deployUsePackageXml.checked && !deployDestructiveManifest) throw new Error("Choose a valid destructiveChanges.xml first.");
    const version = operation === "delete" && deployDestructiveManifest ? deployDestructiveManifest.version : deployUsePackageXml.checked ? deployManifest?.version : String(SFPanel.API_VERSION).replace(/^v/i, "");
    if (!/^\d{1,3}\.0$/.test(version || "")) throw new Error("A valid manifest API version is required.");
    const selectedTypes = deploySelection;
    const types = Array.from(selectedTypes).filter(([type, members]) => type && members.size).sort(([left], [right]) => left.localeCompare(right)).map(([type, members]) => ({ type, members: Array.from(members).sort() }));
    if (!types.length) throw new Error("Select metadata before execution.");
    const testLevel = deployTestLevels.find((control) => control.checked)?.value;
    if (!["", "NoTestRun", "RunLocalTests", "RunAllTestsInOrg", "RunSpecifiedTests"].includes(testLevel)) throw new Error("Select a valid test level.");
    const tests = testLevel === "RunSpecifiedTests" ? deployTestNames.value.split(/[,\r\n]+/).map((name) => name.trim()).filter(Boolean) : [];
    if (testLevel === "RunSpecifiedTests" && (!tests.length || tests.length > 200 || tests.some((name) => !/^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)?$/.test(name)))) throw new Error("Enter valid Apex test class names (maximum 200).");
    const options = Object.fromEntries(Object.entries(deployOptionControls).map(([name, control]) => [name, control.checked]));
    if (operation === "delete" && deployDestructiveManifest && getDeploySelectionCount() === 0) {
      return { source: deploySourceHostname || "target-only", target: deployTargetHostname, version, types, testLevel, tests, options, operation };
    }
    return { source: deploySourceHostname || "target-only", target: deployTargetHostname, version, types, testLevel, tests, options, operation };
  }

  function hasPendingDeployOperation() {
    return Boolean(deployRun?.submissionUncertain || [deployRun?.validation, deployRun?.deployment].some((result) => result?.id && !result.done));
  }

  function hasSuccessfulDeployment() {
    return deployRun?.deployment?.done === true && deployRun.deployment.success === true && deployRun.deployment.status === "Succeeded";
  }

  function deployManifestBody(spec, prefix = "", pretty = false) {
    const indent = pretty ? "  " : "";
    const lines = spec.types.flatMap((entry) => [
      `${indent}<${prefix}types>`,
      ...entry.members.map((member) => `${indent}${indent}<${prefix}members>${escapeMetadataXml(member)}</${prefix}members>`),
      `${indent}${indent}<${prefix}name>${escapeMetadataXml(entry.type)}</${prefix}name>`,
      `${indent}</${prefix}types>`
    ]);
    lines.push(`${indent}<${prefix}version>${escapeMetadataXml(spec.version)}</${prefix}version>`);
    return lines.join(pretty ? "\n" : "");
  }

  function deploySoapChildren(element, name) {
    return Array.from(element?.children || []).filter((child) => child.localName === name);
  }

  function deploySoapText(element, name) {
    return deploySoapChildren(element, name)[0]?.textContent.trim() || "";
  }

  function deploySoapResult(xml) {
    const result = Array.from(xml.getElementsByTagName("*")).find((element) => element.localName === "result");
    if (!result) throw new Error("Salesforce returned no Metadata API result.");
    return result;
  }

  function parseDeployJobResult(result) {
    const details = deploySoapChildren(result, "details")[0];
    const testResult = deploySoapChildren(details, "runTestResult")[0];
    const failures = deploySoapChildren(details, "componentFailures").map((failure) => ({ type: deploySoapText(failure, "componentType"), component: deploySoapText(failure, "fullName") || deploySoapText(failure, "fileName"), problemType: deploySoapText(failure, "problemType"), problem: deploySoapText(failure, "problem"), line: deploySoapText(failure, "lineNumber"), column: deploySoapText(failure, "columnNumber") }));
    const successes = deploySoapChildren(details, "componentSuccesses").map((success) => ({ type: deploySoapText(success, "componentType"), component: deploySoapText(success, "fullName") || deploySoapText(success, "fileName"), status: ["created", "changed", "deleted"].find((state) => deploySoapText(success, state) === "true") || "unchanged", problemType: deploySoapText(success, "problemType"), problem: deploySoapText(success, "problem"), line: deploySoapText(success, "lineNumber"), column: deploySoapText(success, "columnNumber") })).filter((entry) => entry.type && entry.component !== "package.xml");
    const testFailures = deploySoapChildren(testResult, "failures").map((failure) => ({ name: deploySoapText(failure, "name"), method: deploySoapText(failure, "methodName"), message: deploySoapText(failure, "message"), stackTrace: deploySoapText(failure, "stackTrace") }));
    const testSuccesses = deploySoapChildren(testResult, "successes").map((success) => ({ name: deploySoapText(success, "name"), method: deploySoapText(success, "methodName"), time: deploySoapText(success, "time") }));
    const coverageWarnings = deploySoapChildren(testResult, "codeCoverageWarnings").map((warning) => ({ name: deploySoapText(warning, "name"), message: deploySoapText(warning, "message") }));
    const coverage = deploySoapChildren(testResult, "codeCoverage").map((entry) => ({ name: deploySoapText(entry, "name"), type: deploySoapText(entry, "type"), locations: deploySoapText(entry, "numLocations"), uncovered: deploySoapText(entry, "numLocationsNotCovered") }));
    return {
      id: deploySoapText(result, "id"), status: deploySoapText(result, "status"), done: deploySoapText(result, "done") === "true", success: deploySoapText(result, "success") === "true", checkOnly: deploySoapText(result, "checkOnly") === "true",
      componentsDeployed: deploySoapText(result, "numberComponentsDeployed"), componentsTotal: deploySoapText(result, "numberComponentsTotal"), componentErrors: deploySoapText(result, "numberComponentErrors"), testsCompleted: deploySoapText(result, "numberTestsCompleted"), testsTotal: deploySoapText(result, "numberTestsTotal"), testErrors: deploySoapText(result, "numberTestErrors"), stateDetail: deploySoapText(result, "stateDetail"), error: deploySoapText(result, "errorMessage"),       failures, successes, testFailures, testSuccesses, coverageWarnings, coverage
    };
  }

  function setDeployProgress(message) {
    if (deployRun) {
      deployRun.status = message;
      if (deployRun.log.at(-1)?.message !== message) deployRun.log.push({ at: new Date().toISOString(), message });
      if (deployRun.log.length > 100) deployRun.log.shift();
    }
    setStatus(deployExecuteStatus, message, false);
    renderDeployReport();
  }

  async function retrieveDeployPackage(spec, hostname, { allowExpectedMissing = false } = {}) {
    const start = deploySoapResult(await metadataSoapRequest(hostname, "retrieve", `<met:retrieveRequest><met:apiVersion>${escapeMetadataXml(spec.version)}</met:apiVersion><met:singlePackage>true</met:singlePackage><met:unpackaged>${deployManifestBody(spec, "met:")}</met:unpackaged></met:retrieveRequest>`));
    const id = deploySoapText(start, "id");
    if (!/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(id)) throw new Error("Source retrieval did not return a valid request ID.");
    for (let attempt = 0; attempt < 600; attempt++) {
      if (attempt) await new Promise((resolve) => setTimeout(resolve, 1500));
      const result = deploySoapResult(await metadataSoapRequest(hostname, "checkRetrieveStatus", `<met:asyncProcessId>${id}</met:asyncProcessId><met:includeZip>true</met:includeZip>`));
      const status = deploySoapText(result, "status");
      if (deploySoapText(result, "done") !== "true") continue;
      const rawMessages = deploySoapChildren(result, "messages").map((entry) => ({
        file: deploySoapText(entry, "fileName"),
        problem: deploySoapText(entry, "problem")
      }));
      const expectedMissing = [];
      const unexpectedMessages = rawMessages.filter((message) => {
        const text = `${message.file} ${message.problem}`;
        const member = spec.types.flatMap((entry) => entry.members.map((name) => ({ type: entry.type, name })))
          .find((candidate) => candidate.name !== "*" && text.includes(candidate.name)) ||
          spec.types.filter((entry) => entry.members.includes("*") && text.includes(entry.type))
            .map((entry) => ({ type: entry.type, name: "*" }))[0];
        const isMissing = allowExpectedMissing && member && /not found|does not exist|no such|missing|unable to find/i.test(text);
        if (isMissing) expectedMissing.push(member);
        return !isMissing;
      });
      const messages = unexpectedMessages.map((entry) => `${entry.file}: ${entry.problem}`).join("\n");
      if (status !== "Succeeded" || deploySoapText(result, "success") !== "true" || messages) throw new Error(`Metadata retrieval ${status || "failed"}: ${messages || deploySoapText(result, "errorMessage") || "Salesforce did not confirm a complete package."}`);
      const encoded = deploySoapText(result, "zipFile");
      if (!encoded || encoded.length > 28 * 1024 * 1024 || !/^[A-Za-z0-9+/=\r\n]+$/.test(encoded)) throw new Error("Salesforce returned an empty, invalid, or oversized metadata ZIP (maximum 21 MB compressed).");
      const zip = await JSZip.loadAsync(encoded, { base64: true });
      const names = Object.keys(zip.files);
      if (names.length > 10000 || names.some((name) => name.length > 500 || /(^|\/)\.\.(\/|$)|^\//.test(name) || /(^|\/)destructiveChanges(?:Pre|Post)?\.xml$/i.test(name))) throw new Error("The retrieved package contains unsupported paths or destructive changes.");
      const manifestFile = zip.file("package.xml") || zip.file("unpackaged/package.xml");
      if (!manifestFile) throw new Error("The source package has no package.xml.");
      const manifest = parseDeployPackageXml(await manifestFile.async("string"), { allowEmpty: allowExpectedMissing });
      const missing = [];
      for (const entry of spec.types) {
        const actual = manifest.types.get(entry.type);
        const absent = entry.members.filter((member) => member === "*" ? !actual : (!actual || !actual.has(member) && !actual.has("*")));
        if (absent.length && !allowExpectedMissing) throw new Error(`The retrieved package is missing selected ${entry.type} members.`);
        absent.forEach((member) => missing.push({ type: entry.type, name: member }));
      }
      const unresolved = expectedMissing.filter((candidate) => !missing.some((entry) => entry.type === candidate.type && entry.name === candidate.name));
      if (unresolved.length) throw new Error(`Target metadata read-back returned an inconsistent missing-member warning for ${unresolved.map((entry) => entry.name).join(", ")}.`);
      return { encoded, zip, id, missing, warnings: unexpectedMessages };
    }
    throw new Error("Metadata retrieval timed out. No deployment was submitted.");
  }

  async function pollDeployJob(hostname, id, kind) {
    if (!/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(id)) throw new Error("Salesforce returned an invalid deployment ID.");
    for (let attempt = 0; attempt < 1200; attempt++) {
      if (attempt) await new Promise((resolve) => setTimeout(resolve, 1500));
      let result = parseDeployJobResult(deploySoapResult(await metadataSoapRequest(hostname, "checkDeployStatus", `<met:asyncProcessId>${id}</met:asyncProcessId><met:includeDetails>false</met:includeDetails>`)));
      result.id = result.id || id;
      deployRun[kind] = result;
      const components = getDeployComponentProgress(result);
      const tests = getDeployTestProgress(result);
      const progress = [];
      if (!result.done) {
        if (components.total) progress.push(`Components ${components.processed}/${components.total} (${components.percentage}%)`);
        if (tests.total) progress.push(`Tests ${tests.processed}/${tests.total} (${tests.percentage}%)`);
        if (result.stateDetail) progress.push(result.stateDetail);
        if (!progress.length) progress.push("Waiting for Salesforce progress");
      }
      setDeployProgress(`${kind === "validation" ? "Validation" : "Deployment"}: ${result.status || "In Progress"}${progress.length ? ` - ${progress.join("; ")}` : ""}`);
      if (result.done) {
        result = parseDeployJobResult(deploySoapResult(await metadataSoapRequest(hostname, "checkDeployStatus", `<met:asyncProcessId>${id}</met:asyncProcessId><met:includeDetails>true</met:includeDetails>`)));
        result.id = result.id || id;
        deployRun[kind] = result;
        setDeployProgress(`${kind === "validation" ? "Validation" : "Deployment"}: ${result.status || "In Progress"}`);
        if (result.done) return result;
      }
    }
    throw new Error("Salesforce is still processing the request. Use Retrieve Report to check its status; do not submit it again.");
  }

  function hasMatchingDeployValidation() {
    try {
      return Boolean(deployRun?.validation?.success && deployRun.validation.done && deployRun.validation.status === "Succeeded" && !deployRun.deployment && deployRun.signature === JSON.stringify(getDeployRequestSpec()));
    } catch {
      return false;
    }
  }

  function canQuickDeploy() {
    return hasMatchingDeployValidation() && !deployRun.quickDeployRejected && deployProgressCount(deployRun.validation.testsCompleted) > 0 && deployProgressCount(deployRun.validation.testErrors) === 0;
  }

  async function createDeployPayload(spec) {
    if (spec.operation !== "delete") return retrieveDeployPackage(spec, spec.source);
    const zip = new JSZip();
    zip.file("package.xml", `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata"><version>${escapeMetadataXml(spec.version)}</version></Package>`);
    zip.file("destructiveChanges.xml", `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata">${deployManifestBody(spec)}</Package>`);
    const encoded = await zip.generateAsync({ type: "base64", compression: "DEFLATE" });
    return { encoded, zip, id: "", missing: [], warnings: [] };
  }

  async function saveDeployHistoryRecord() {
    if (!deployRun?.package?.encoded || !isSuccessfulDeployHistory({ report: deployRun })) return;
    const record = deployHistoryRecords.find((entry) => entry.id === deployRun.historyId) || {};
    const packageZip = deployRun.package.encoded;
    const backupZip = deployRun.backup?.encoded || record.backupZip || "";
    const id = deployRun.historyId || crypto.randomUUID();
    deployRun.historyId = id;
    const metadataTypes = deployRun.spec.types.map((entry) => ({ type: entry.type, members: [...entry.members] }));
    const saved = {
      ...record,
      id,
      label: (deployHistoryLabel?.value || "").trim().slice(0, 120) || (deployRun.spec.operation === "delete" ? "Delete metadata" : "Deployment"),
      createdAt: record.createdAt || deployRun.startedAt,
      source: deployRun.spec.source,
      target: deployRun.spec.target,
      operation: deployRun.spec.operation || "deploy",
      types: metadataTypes,
      components: metadataTypes.flatMap((entry) => entry.members.map((member) => `${entry.type}:${member}`)),
      checksum: await checksumDeployZip(packageZip),
      packageZip,
      backupZip,
      packageBytes: packageZip.length * 2,
      backupBytes: backupZip ? backupZip.length * 2 : 0,
      pinned: Boolean(record.pinned),
      sourceOrgId: deployRun.orgs?.sourceId || record.sourceOrgId || "",
      targetOrgId: deployRun.orgs?.targetId || record.targetOrgId || "",
      spec: deployRun.spec,
      startedAt: deployRun.startedAt,
      validationId: deployRun.validation?.id || "",
      deploymentId: deployRun.deployment?.id || "",
      status: deployRun.deployment?.status || deployRun.validation?.status || deployRun.status,
      report: {
        validation: deployRun.validation,
        deployment: deployRun.deployment,
        error: deployRun.error,
        verification: deployRun.verification
      }
    };
    return persistDeployHistory(saved, id);
  }

  async function executeDeployRequest(quick = false, direct = false) {
    if (deployBusy || hasPendingDeployOperation()) return;
    let spec;
    try {
      spec = getDeployRequestSpec();
      if (quick && !canQuickDeploy()) throw new Error("Validate this scope against the selected target before Quick Deploy.");
    } catch (error) {
      setStatus(deployExecuteStatus, error.message);
      return;
    }
    const reuseValidatedPackage = spec.operation === "delete" && direct && hasMatchingDeployValidation();
    const checkOnly = !quick && !direct;
    if (spec.operation === "delete" && !checkOnly && !confirm(`Permanently delete ${spec.types.reduce((sum, entry) => sum + entry.members.length, 0)} metadata member(s) from ${spec.target}? A target backup will be downloaded/cached first.`)) return;
    if (!quick && !reuseValidatedPackage) deployRun = { spec, signature: JSON.stringify(spec), startedAt: new Date().toISOString(), status: "Preparing", validation: null, deployment: null, verification: { status: "Not run", files: [] }, log: [], error: "", package: null, backup: null };
    deployRun.spec = spec;
    deployRun.signature = JSON.stringify(spec);
    deployBusy = true;
    updateDeployStepActions();
    try {
      const targetInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: spec.target });
      if (!targetInfo.orgId) throw new Error("Confirm an authenticated target org before deployment.");
      let sourceOrgId = deployReplay?.record?.sourceOrgId || "";
      if (spec.operation !== "delete") {
        if (!sourceOrgId) {
          const sourceInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: spec.source });
          sourceOrgId = sourceInfo.orgId;
        }
        if (!sourceOrgId || sourceOrgId === targetInfo.orgId) throw new Error("Confirm authenticated, distinct source and target orgs before deployment.");
      }
      deployRun.orgs = { sourceId: sourceOrgId, targetId: targetInfo.orgId };
      if (spec.testLevel === "NoTestRun" && targetInfo.isSandbox !== true) throw new Error("No Tests is allowed only for a Sandbox target.");
      // SECURITY_NOTE: Keep Production deployments atomic before any metadata is retrieved or submitted.
      if (!spec.options.rollbackOnError && targetInfo.isSandbox !== true) throw new Error("Roll back on error is required for Production targets.");
      if (!quick && !reuseValidatedPackage) {
        if (deployCreateBackup?.checked || spec.operation === "delete") {
          setDeployProgress("Backing up selected metadata from the target org...");
          deployRun.backup = await retrieveDeployPackage(spec, spec.target, { allowExpectedMissing: true });
          deployRun.backup.missing.forEach((entry) => deployRun.log.push({ at: new Date().toISOString(), message: `Target backup: ${entry.type} ${entry.name} is not present in the target; recorded as missing.` }));
          if (deployRun.backup.warnings?.length) throw new Error("Target backup returned warnings that were not verified as expected missing components.");
          downloadFile("target-metadata-backup.zip", new Blob([deployZipBytes(deployRun.backup.encoded)], { type: "application/zip" }), "application/zip");
          setStatus(deployResultsStatus, "Target metadata backup downloaded. It contains metadata only; it is not a complete rollback.", false);
        }
        if (deployReplay && spec.operation === "deploy") {
          deployRun.package = { encoded: deployReplay.encoded, zip: deployReplay.zip, id: "history" };
        } else if (spec.operation === "delete") {
          setDeployProgress("Preparing target destructive changes...");
          deployRun.package = await createDeployPayload(spec);
        } else {
          setDeployProgress("Retrieving selected metadata from the source org...");
          deployRun.package = await retrieveDeployPackage(spec, spec.source);
        }
      }
      const kind = checkOnly ? "validation" : "deployment";
      setDeployProgress(checkOnly ? "Submitting target validation..." : "Submitting target deployment...");
      let response;
      deployRun.submissionUncertain = true;
      if (quick) {
        response = deploySoapResult(await metadataSoapRequest(spec.target, "deployRecentValidation", `<met:validationId>${escapeMetadataXml(deployRun.validation.id)}</met:validationId>`));
      } else {
        const tests = spec.tests.map((name) => `<met:runTests>${escapeMetadataXml(name)}</met:runTests>`).join("");
        const level = spec.testLevel ? `<met:testLevel>${spec.testLevel}</met:testLevel>` : "";
        response = deploySoapResult(await metadataSoapRequest(spec.target, "deploy", `<met:ZipFile>${deployRun.package.encoded}</met:ZipFile><met:DeployOptions><met:allowMissingFiles>${spec.options.allowMissingFiles}</met:allowMissingFiles><met:autoUpdatePackage>${spec.options.autoUpdatePackage}</met:autoUpdatePackage><met:checkOnly>${checkOnly}</met:checkOnly><met:ignoreWarnings>${spec.options.ignoreWarnings}</met:ignoreWarnings><met:purgeOnDelete>false</met:purgeOnDelete><met:rollbackOnError>${spec.options.rollbackOnError}</met:rollbackOnError>${tests}<met:singlePackage>true</met:singlePackage>${level}</met:DeployOptions>`));
      }
      const id = deploySoapText(response, "id") || response.textContent.trim();
      if (!/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(id)) throw new Error("Salesforce did not return a valid deployment ID.");
      deployRun.submissionUncertain = false;
      deployRun[kind] = { id, done: false, success: false, status: "Submitted" };
      const result = await pollDeployJob(spec.target, id, kind);
      if (!result.success || result.status !== "Succeeded") deployRun.error = result.error || `${checkOnly ? "Validation" : "Deployment"} ${result.status || "failed"}. Review component and test failures below.`;
      else deployRun.error = "";
    } catch (error) {
      if (/INVALID_ID_FIELD: Source validate did not run tests in the org/.test(String(error.message))) {
        deployRun.submissionUncertain = false;
        deployRun.error = "Salesforce rejected Quick Deploy because the validation ran no tests. Click Deploy again to submit the validated package as a regular deployment.";
        deployRun.quickDeployRejected = true;
      } else {
        deployRun.error = String(error.message || "The Metadata API operation failed.").slice(0, 2000);
      }
      if (deployRun.submissionUncertain) deployRun.error += " Submission outcome unknown. Check Deployment Status in the target org before submitting again.";
      deployRun.status = "Operation not completed";
    } finally {
      deployBusy = false;
      if (deployRun?.package) {
        try { await saveDeployHistoryRecord(); } catch { /* The visible history status reports storage pressure. */ }
      }
      setStatus(deployExecuteStatus, deployRun.error || deployRun.status, Boolean(deployRun.error));
      renderDeployReport();
      updateDeployStepActions();
    }
  }

  function updateDeployExecutionActions() {
    if (!deployRunButton) return;
    const pending = hasPendingDeployOperation();
    deployRunButton.disabled = deployBusy || pending || !getDeploySelectionCount() || Boolean(deployRun?.deployment?.success);
    deployQuickButton.disabled = deployRunButton.disabled;
    deployRunButton.textContent = "Validate";
    deployQuickButton.textContent = "Deploy";
    if (getDeployOperation() === "delete") {
      deployQuickButton.title = hasMatchingDeployValidation() ? "Confirm and deploy the validated destructive changes" : "Back up target metadata and deploy destructive changes directly";
    } else {
      deployQuickButton.title = canQuickDeploy() ? "Deploy using the successful validation" : "Deploy selected metadata directly";
    }
    deployTestNames.hidden = !deployTestLevels.some((control) => control.checked && control.value === "RunSpecifiedTests");
    [...deployTestLevels, deployTestNames, ...Object.values(deployOptionControls), deployOperationControls, deploySelectMetadata, deployUsePackageXml, deployChangeTargetOrgButton, deployTargetEnvironment, deployPackageFile, deployDestructiveFile, deployHistoryZipFile, document.getElementById("deployPackageChoose")].flat().filter(Boolean).forEach((control) => { control.disabled = deployBusy || pending; });
    deployUsePackageXml.disabled = deployBusy || pending;
    const noTestControl = deployTestLevels.find((control) => control.value === "NoTestRun");
    if (noTestControl) noTestControl.disabled = deployBusy || pending || deployTargetIsSandbox === false;
    const rollbackControl = deployOptionControls.rollbackOnError;
    if (rollbackControl && deployTargetIsSandbox === false) {
      rollbackControl.checked = true;
      rollbackControl.disabled = true;
    }
    if (deployBusy) deploySelectTargetOrgButton.disabled = true;
    document.getElementById("deployVerifyButton").disabled = deployBusy || !hasSuccessfulDeployment() || !deployRun.package;
    document.getElementById("deploySkipVerify").disabled = deployBusy || !hasSuccessfulDeployment();
    document.getElementById("deployRefreshReport").disabled = deployBusy || !(deployRun?.validation?.id || deployRun?.deployment?.id);
    document.getElementById("deployResultsDownload").disabled = deployBusy || !deployRun;
    document.getElementById("deployDownloadManifest").disabled = deployBusy || !getDeploySelectionCount();
    document.getElementById("deployDownloadPackage").disabled = deployBusy || !deployRun?.package?.encoded;
    document.getElementById("deployDownloadBackup").disabled = deployBusy || !deployRun?.backup?.encoded;
    renderDeployReport();
  }

  function setDeployOutputTab(tab) {
    if (!["Messages", "Report"].includes(tab)) return;
    for (const name of ["Messages", "Report"]) {
      const selected = tab === name;
      const button = document.getElementById(`deploy${name}Tab`);
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
      document.getElementById(`deployExecute${name}`).hidden = !selected;
    }
  }

  for (const name of ["Messages", "Report"]) {
    const button = document.getElementById(`deploy${name}Tab`);
    button.addEventListener("click", () => setDeployOutputTab(name));
    button.addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === "Home" ? "Messages" : event.key === "End" ? "Report" : name === "Messages" ? "Report" : "Messages";
      setDeployOutputTab(next);
      document.getElementById(`deploy${next}Tab`).focus();
    });
  }

  function deployProgressCount(value) {
    const number = Number(value);
    return Number.isSafeInteger(number) && number >= 0 ? number : 0;
  }

  function getDeployComponentProgress(result) {
    const succeeded = deployProgressCount(result?.componentsDeployed);
    const failed = deployProgressCount(result?.componentErrors);
    const processed = succeeded + failed;
    const total = Math.max(deployProgressCount(result?.componentsTotal), processed);
    return { succeeded, failed, processed, total, percentage: total ? Math.floor(processed / total * 100) : 0 };
  }

  function getDeployTestProgress(result) {
    const failed = deployProgressCount(result?.testErrors);
    return getDeployComponentProgress({ componentsDeployed: Math.max(0, deployProgressCount(result?.testsCompleted) - failed), componentErrors: failed, componentsTotal: result?.testsTotal });
  }

  function getDeploySummaryRows() {
    if (!deployRun) return [];
    const rows = [["Source", deployRun.spec.source], ["Target", deployRun.spec.target], ["API Version", deployRun.spec.version], ["Status", deployRun.status]];
    const statusErrors = [["Validation", deployRun.validation], ["Deployment", deployRun.deployment]].flatMap(([kind, result]) => result && !result.error ? [`${kind} ${result.status || "failed"}. Review component and test failures below.`, `${kind.toLowerCase()} ${result.status}`] : []);
    if (deployRun.error && !statusErrors.includes(deployRun.error)) rows.push(["Error", deployRun.error]);
    if (deployRun.validation && deployRun.deployment) rows.push(["Validation Result", deployRun.validation.status]);
    if (deployRun.backup) {
      rows.push(["Target Metadata Backup", deployRun.backup.id || "Generated"]);
      rows.push(["Backup Components Missing in Target", String(deployRun.backup.missing?.length || 0)]);
      (deployRun.backup.missing || []).forEach((entry) => rows.push(["Backup Missing Component", `${entry.type}:${entry.name}`]));
    }
    for (const [kind, result] of [["Validation", deployRun.validation], ["Deployment", deployRun.deployment]]) {
      if (!result) continue;
      rows.push([`${kind} ID`, result.id], [`${kind} Components`, `${result.componentsDeployed || "0"} / ${result.componentsTotal || "0"} succeeded; ${result.componentErrors || "0"} failed`], [`${kind} Tests`, `${result.testsCompleted || "0"} / ${result.testsTotal || "0"} completed; ${result.testErrors || "0"} failed`]);
    }
    if (deployRun.verification.status !== "Not run") rows.push(["Verification", deployRun.verification.status]);
    if (deployRun.verification.error) rows.push(["Verification Error", deployRun.verification.error]);
    return rows.map((row) => row.map((value) => String(value ?? "")));
  }

  function getDeployResultRows() {
    if (!deployRun) return [];
    const rows = [];
    for (const [kind, result] of [["Validation", deployRun.validation], ["Deployment", deployRun.deployment]]) {
      if (!result) continue;
      const add = (type, name, status, message = "", line = "", column = "") => rows.push([kind, type, name, status, message, line, column].map((value) => String(value ?? "")));
      (result.failures || []).forEach((entry) => add(entry.type, entry.component, entry.problemType || "Error", entry.problem, entry.line, entry.column));
      (result.testFailures || []).forEach((entry) => add("Apex Test", [entry.name, entry.method].filter(Boolean).join("."), "Failed", [entry.message, entry.stackTrace].filter(Boolean).join("\n")));
      (result.coverageWarnings || []).forEach((entry) => add("Code Coverage", entry.name || "Overall", "Warning", entry.message));
      (result.successes || []).forEach((entry) => add(entry.type, entry.component, entry.status.charAt(0).toUpperCase() + entry.status.slice(1) + (entry.problem ? ` (${entry.problemType || "Warning"})` : ""), entry.problem, entry.line, entry.column));
      (result.testSuccesses || []).forEach((entry) => add("Apex Test", [entry.name, entry.method].filter(Boolean).join("."), "Passed", entry.time ? `${entry.time} ms` : ""));
      (result.coverage || []).forEach((entry) => {
        const total = deployProgressCount(entry.locations);
        const covered = Math.max(0, total - deployProgressCount(entry.uncovered));
        add(`Code Coverage${entry.type ? ` (${entry.type})` : ""}`, entry.name, total ? `${Math.floor(covered / total * 100)}%` : "No lines", `${covered} of ${total} lines covered`);
      });
    }
    return rows;
  }

  function protectDeploySpreadsheetValue(value) {
    // SECURITY_NOTE: Spreadsheet formula-like values must remain literal text, even inside quoted CSV cells.
    return /^[\s\uFEFF]*[=+\-@]|^[\t\r\n]/.test(value) ? `'${value}` : value;
  }

  function createDeployReportTable(label, columns, rows, emptyText) {
    const scroller = document.createElement("div");
    scroller.className = "deploy-report-table-scroll";
    scroller.tabIndex = 0;
    scroller.setAttribute("role", "region");
    scroller.setAttribute("aria-label", `${label} scroll area`);
    const table = document.createElement("table");
    table.className = "configuration-table deploy-report-table";
    table.setAttribute("aria-label", label);
    const head = document.createElement("thead");
    const headings = document.createElement("tr");
    columns.forEach((title) => {
      const cell = document.createElement("th");
      cell.setAttribute("scope", "col");
      cell.textContent = title;
      headings.appendChild(cell);
    });
    head.appendChild(headings);
    const body = document.createElement("tbody");
    if (!rows.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = columns.length;
      cell.textContent = emptyText;
      row.appendChild(cell);
      body.appendChild(row);
    }
    rows.forEach((values) => {
      const row = document.createElement("tr");
      values.forEach((value) => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
      body.appendChild(row);
    });
    table.append(head, body);
    scroller.appendChild(table);
    return scroller;
  }

  function renderDeployReport() {
    setStatus(deployExecuteStatus, deployRun ? deployRun.error || deployRun.status : "Ready", Boolean(deployRun?.error));
    const result = deployRun?.deployment || deployRun?.validation;
    const progress = getDeployComponentProgress(result);
    document.getElementById("deployTotalCount").textContent = String(progress.total);
    document.getElementById("deployProgressCount").textContent = `${progress.percentage}%`;
    document.getElementById("deploySucceededCount").textContent = String(progress.succeeded);
    document.getElementById("deployFailedCount").textContent = String(progress.failed);
    document.getElementById("deploySuccessBar").style.width = `${progress.total ? progress.succeeded / progress.total * 100 : 0}%`;
    document.getElementById("deployFailureBar").style.width = `${progress.total ? progress.failed / progress.total * 100 : 0}%`;
    const componentProgress = document.getElementById("deployComponentProgress");
    componentProgress.setAttribute("aria-valuenow", String(progress.percentage));
    componentProgress.setAttribute("aria-valuetext", progress.total ? `${progress.processed} of ${progress.total} components processed; ${progress.succeeded} succeeded, ${progress.failed} failed` : "No component counts reported yet");
    const tests = getDeployTestProgress(result);
    document.getElementById("deployTestProgressSection").hidden = !tests.total;
    document.getElementById("deployTestProgressText").textContent = `${tests.processed} / ${tests.total} (${tests.percentage}%)`;
    document.getElementById("deployTestSuccessBar").style.width = `${tests.total ? tests.succeeded / tests.total * 100 : 0}%`;
    document.getElementById("deployTestFailureBar").style.width = `${tests.total ? tests.failed / tests.total * 100 : 0}%`;
    const testProgress = document.getElementById("deployTestProgress");
    testProgress.setAttribute("aria-valuenow", String(tests.percentage));
    testProgress.setAttribute("aria-valuetext", `${tests.processed} of ${tests.total} tests completed; ${tests.failed} failed`);
    const messages = document.getElementById("deployExecuteMessages");
    messages.replaceChildren();
    const addMessage = (text) => {
      const entry = document.createElement("p");
      entry.className = "deploy-output-message";
      entry.textContent = text;
      messages.appendChild(entry);
    };
    if (!deployRun) addMessage("No messages yet.");
    else {
      deployRun.log.forEach((entry) => addMessage(`${entry.at}  ${entry.message}`));
      if (deployRun.error) addMessage(deployRun.error);
      for (const job of [deployRun.validation, deployRun.deployment].filter(Boolean)) {
        (job.failures || []).forEach((entry) => addMessage(`${entry.component}: ${entry.problem}`));
        (job.testFailures || []).forEach((entry) => addMessage(`${entry.name}.${entry.method}: ${entry.message}`));
        (job.coverageWarnings || []).forEach((entry) => addMessage(`${entry.name}: ${entry.message}`));
      }
    }
    const summaryRows = getDeploySummaryRows();
    const resultRows = getDeployResultRows();
    for (const id of ["deployExecuteReport", "deployResultsReport"]) {
      const container = document.getElementById(id);
      if (!container) continue;
      container.replaceChildren();
      if (!deployRun) continue;
      const summary = document.createElement("dl");
      summary.className = "deploy-report-summary";
      summaryRows.forEach(([label, value]) => {
        const item = document.createElement("div");
        const term = document.createElement("dt");
        term.textContent = label;
        const detail = document.createElement("dd");
        detail.textContent = value;
        item.append(term, detail);
        summary.appendChild(item);
      });
      const tools = document.createElement("div");
      tools.className = "deploy-report-tools";
      const heading = document.createElement("h4");
      heading.textContent = `Salesforce Report (${resultRows.length})`;
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.textContent = "Copy";
      copyButton.disabled = deployBusy || !resultRows.length;
      copyButton.addEventListener("click", copyDeployResultReport);
      const saveButton = document.createElement("button");
      saveButton.type = "button";
      saveButton.textContent = "Save";
      saveButton.disabled = deployBusy || !resultRows.length;
      saveButton.addEventListener("click", downloadDeployCsvReport);
      tools.append(heading, copyButton, saveButton);
      const table = createDeployReportTable("Salesforce deployment report", deployReportColumns, resultRows, "Salesforce has not returned component or test details yet.");
      container.append(summary, tools, table);
      if (id === "deployResultsReport" && deployRun.verification.files?.length) {
        const verificationHeading = document.createElement("h4");
        verificationHeading.className = "deploy-report-subheading";
        verificationHeading.textContent = "Metadata Read-Back";
        container.append(verificationHeading, createDeployReportTable("Metadata read-back verification", ["File", "Status"], deployRun.verification.files.map((entry) => [entry.file, entry.status]), ""));
      }
    }
  }

  async function hashDeployZip(zip) {
    const files = new Map();
    let total = 0;
    for (const entry of Object.values(zip.files).filter((entry) => !entry.dir)) {
      const name = entry.name.replace(/^unpackaged\//, "");
      if (name === "package.xml") continue;
      const data = await entry.async("uint8array");
      total += data.byteLength;
      if (data.byteLength > 10 * 1024 * 1024 || total > 64 * 1024 * 1024) throw new Error("The metadata is too large for browser read-back verification.");
      const hash = await crypto.subtle.digest("SHA-256", data);
      files.set(name, Array.from(new Uint8Array(hash), (value) => value.toString(16).padStart(2, "0")).join(""));
    }
    return files;
  }

  async function verifyDeployMetadata() {
    if (deployBusy || !hasSuccessfulDeployment() || !deployRun.package) return;
    deployBusy = true;
    deployRun.verification = { status: "Retrieving target metadata", files: [] };
    updateDeployStepActions();
    setStatus(deployResultsStatus, "Reading deployed metadata back from the target org...", false);
    try {
      const target = await retrieveDeployPackage(deployRun.spec, deployRun.spec.target);
      const [sourceHashes, targetHashes] = await Promise.all([hashDeployZip(deployRun.package.zip), hashDeployZip(target.zip)]);
      if (!sourceHashes.size) throw new Error("The retrieved source package contains no metadata files to verify.");
      const names = Array.from(new Set([...sourceHashes.keys(), ...targetHashes.keys()])).sort();
      const files = names.map((file) => ({ file, status: !targetHashes.has(file) ? "Missing in target" : !sourceHashes.has(file) ? "Additional in target" : sourceHashes.get(file) === targetHashes.get(file) ? "Match" : "Different content" }));
      deployRun.verification = { status: files.every((entry) => entry.status === "Match") ? "Exact metadata match" : "Differences found", at: new Date().toISOString(), files };
      setStatus(deployResultsStatus, deployRun.verification.status, deployRun.verification.status !== "Exact metadata match");
    } catch (error) {
      deployRun.verification = { status: "Verification not completed", error: String(error.message || "Metadata read-back failed.").slice(0, 2000), files: [] };
      setStatus(deployResultsStatus, deployRun.verification.error);
    } finally {
      deployBusy = false;
      renderDeployReport();
      updateDeployStepActions();
      if (deployRun?.package && deployRun.historyId) {
        try { await saveDeployHistoryRecord(); } catch { /* Cache errors are shown in deployment history. */ }
      }
    }
  }

  async function refreshDeployReport() {
    if (deployBusy || !deployRun) return;
    deployBusy = true;
    updateDeployStepActions();
    try {
      for (const kind of ["validation", "deployment"]) {
        const previous = deployRun[kind];
        if (!previous?.id) continue;
        const result = parseDeployJobResult(deploySoapResult(await metadataSoapRequest(deployRun.spec.target, "checkDeployStatus", `<met:asyncProcessId>${escapeMetadataXml(previous.id)}</met:asyncProcessId><met:includeDetails>true</met:includeDetails>`)));
        result.id = result.id || previous.id;
        deployRun[kind] = result;
        deployRun.error = result.done && !result.success ? result.error || `${kind} ${result.status}` : "";
        deployRun.status = `${kind}: ${result.status || "In Progress"}`;
      }
      setStatus(deployResultsStatus, deployRun.error || deployRun.status, Boolean(deployRun.error));
    } catch (error) {
      setStatus(deployResultsStatus, String(error.message || "Unable to retrieve the report.").slice(0, 2000));
    } finally {
      deployBusy = false;
      renderDeployReport();
      updateDeployStepActions();
      if (deployRun?.package && deployRun.historyId) {
        try { await saveDeployHistoryRecord(); } catch { /* Cache errors are shown in deployment history. */ }
      }
    }
  }

  function getDeployExportRows() {
    const rows = [["Report Summary"], ...getDeploySummaryRows(), [], ["Salesforce Report"], deployReportColumns, ...getDeployResultRows()];
    if (deployRun.verification.files?.length) rows.push([], ["Metadata Read-Back"], ["File", "Status"], ...deployRun.verification.files.map((entry) => [entry.file, entry.status]));
    return rows.map((row) => row.map((value) => protectDeploySpreadsheetValue(String(value ?? ""))));
  }

  function downloadDeployCsvReport() {
    if (!deployRun || deployBusy) return;
    const worksheet = XLSX.utils.aoa_to_sheet(getDeployExportRows());
    const csv = XLSX.utils.sheet_to_csv(worksheet, { forceQuotes: true, FS: ",", RS: "\r\n" });
    downloadFile("deployment-report.csv", csv, "text/csv;charset=utf-8");
  }

  async function copyDeployResultReport(event) {
    if (!deployRun || deployBusy) return;
    const button = event?.currentTarget;
    const text = getDeployExportRows().map((row) => row.map((value) => value.replace(/[\t\r\n]+/g, " ")).join("\t")).join("\n");
    let label = "Copied";
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      label = "Copy failed";
    }
    if (!button) return;
    button.textContent = label;
    setTimeout(() => { button.textContent = "Copy"; }, 1500);
  }

  function downloadDeployReport() {
    if (!deployRun) return;
    const report = { source: deployRun.spec.source, target: deployRun.spec.target, operation: deployRun.spec.operation || "deploy", apiVersion: deployRun.spec.version, scope: deployRun.spec.types, testLevel: deployRun.spec.testLevel, tests: deployRun.spec.tests, options: deployRun.spec.options, startedAt: deployRun.startedAt, status: deployRun.status, error: deployRun.error, submissionUncertain: Boolean(deployRun.submissionUncertain), backup: deployRun.backup ? { id: deployRun.backup.id, missing: deployRun.backup.missing || [], warnings: deployRun.backup.warnings || [] } : null, validation: deployRun.validation, deployment: deployRun.deployment, verification: deployRun.verification, activity: deployRun.log };
    downloadFile("deployment-report.json", JSON.stringify(report, null, 2), "application/json");
  }
  // scope "object" types are filtered by the objects chosen in step 2; "org" types are not.
  // supported: false means the browser exporter cannot query this type yet (requires Metadata API/SF CLI).
  const predefinedExportTypes = [
    { type: "CustomField", label: "Fields", category: "schema-ui", scope: "object", supported: true },
    { type: "RecordType", label: "Record Types", category: "schema-ui", scope: "object", supported: true },
    { type: "ValidationRule", label: "Validation Rules", category: "schema-ui", scope: "object", supported: true },
    { type: "Layout", label: "Layouts", category: "schema-ui", scope: "object", supported: true },
    { type: "ListView", label: "List Views", category: "schema-ui", scope: "object", supported: true },
    { type: "CompactLayout", label: "Compact Layouts", category: "schema-ui", scope: "object", supported: true },
    { type: "FieldSet", label: "Field Sets", category: "schema-ui", scope: "object", supported: true },
    { type: "WebLink", label: "Buttons, Links, and Actions", category: "schema-ui", scope: "object", supported: true },
    { type: "ObjectAccess", label: "Object Access", category: "security", scope: "object", supported: true },
    { type: "FieldAccess", label: "Field Access", category: "security", scope: "object", supported: true },
    { type: "Objects", label: "Object List", category: "schema-ui", scope: "org", supported: true },
    { type: "PermissionSet", label: "Permission Sets", category: "security", scope: "org", supported: true },
    { type: "Profile", label: "Profiles", category: "security", scope: "org", supported: true },
    { type: "Queue", label: "Queues", category: "security", scope: "org", supported: true },
    { type: "ApexClass", label: "Apex Classes", category: "code", scope: "org", supported: true },
    { type: "ApexTrigger", label: "Apex Triggers", category: "code", scope: "org", supported: true },
    { type: "CustomLabel", label: "Custom Labels", category: "code", scope: "org", supported: true },
    { type: "LWC", label: "LWC", category: "code", scope: "org", supported: true },
    { type: "Flow", label: "Flows", category: "automation", scope: "org", supported: true },
    { type: "CustomTab", label: "Custom Tabs", category: "schema-ui", scope: "org", supported: true },
    { type: "CustomApplication", label: "Applications", category: "schema-ui", scope: "org", supported: true },
    { type: "GlobalValueSet", label: "Global Value Sets", category: "schema-ui", scope: "org", supported: true },
    { type: "ReportFolder", label: "Report Folders", category: "schema-ui", scope: "org", supported: true },
    { type: "Report", label: "Reports", category: "schema-ui", scope: "org", supported: true },
    { type: "RecordType_OrgWide", label: "All Record Types", category: "schema-ui", scope: "org", supported: true }
  ];

  function setStatus(element, message, isError = true) {
    element.textContent = message || "";
    element.style.color = isError ? "#c00" : "inherit";
    if (element === importStatus && message) {
      importIssues.hidden = false;
    }
  }

  function escapeXml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function valueOf(row, aliases) {
    const entries = Object.entries(row || {});
    for (const alias of aliases) {
      const match = entries.find(([key]) => key.trim().toLowerCase() === alias.toLowerCase());
      if (match && String(match[1] ?? "").trim()) return String(match[1]).trim();
    }
    for (const alias of aliases) {
      const match = entries.find(([key]) => key.trim().toLowerCase().includes(alias.toLowerCase()));
      if (match && String(match[1] ?? "").trim()) return String(match[1]).trim();
    }
    return "";
  }

  function truthy(value) {
    return /^(x|true|yes|1)$/i.test(String(value || "").trim());
  }

  function suffixApiName(value) {
    const name = String(value || "").trim();
    return name.endsWith("__c") ? name : `${name}__c`;
  }

  function generatedApiName(label) {
    const name = String(label || "Field").replace(/[^A-Za-z0-9\s]/g, "").trim().replace(/\s+/g, "_");
    return `${name.replace(/^[0-9]/, "X$&")}__c`;
  }

  function typeParts(value) {
    const match = String(value || "").trim().match(/^(.+?)\s*\(([^)]*)\)$/);
    return match ? { base: match[1].trim(), parameter: match[2].trim() } : { base: String(value || "").trim(), parameter: "" };
  }

  function typeKey(value) {
    const parts = typeParts(value);
    if (parts.base.toLowerCase() === "text" && parts.parameter.toLowerCase() === "encrypted") return "encryptedtext";
    return parts.base.toLowerCase().replace(/[\s_\/-]+/g, "");
  }

  function rowsFromSheet(workbook, namePattern) {
    const name = workbook.SheetNames.find((sheet) => namePattern.test(String(sheet).trim()));
    return name ? XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, defval: "" }) : [];
  }

  function headerIndex(rows, required) {
    return rows.findIndex((row) => {
      const values = row.map((cell) => String(cell || "").trim().toLowerCase());
      return required.every((name) => values.some((value) => value.includes(name)));
    });
  }

  function columns(row) {
    return row.map((cell) => String(cell || "").trim());
  }

  function parseTabularSheet(workbook, pattern, requiredHeaders, type, objectApiName, mapper) {
    const rows = rowsFromSheet(workbook, pattern);
    const headerRow = headerIndex(rows, requiredHeaders);
    if (headerRow < 0) return [];
    const headers = columns(rows[headerRow]);
    const indexOf = (regex) => headers.findIndex((header) => regex.test(header));
    return rows.slice(headerRow + 1).map((row, offset) => {
      const raw = mapper(row, indexOf, objectApiName, offset + headerRow + 2);
      return raw ? { ...raw, rowNumber: raw.rowNumber || offset + headerRow + 2 } : null;
    })
      .filter(Boolean)
      .map((raw) => ({
        section: type,
        apiName: raw.fullApiName || raw.apiName || raw.uniqueName,
        label: raw.label || raw.name || raw.uniqueName || raw.apiName,
        details: raw.details || "",
        raw: { ...raw, rowNumber: raw.rowNumber || undefined }
      }));
  }

  function parseAdditionalWorkbookTabs(workbook, objectApiName) {
    const items = [];

    const permissionRows = rowsFromSheet(workbook, /^permission\s*sets?$/i);
    if (permissionRows.length >= 2) {
      const labels = columns(permissionRows[0]);
      const apiNames = columns(permissionRows[1]);
      const descriptions = columns(permissionRows[2] || []);
      for (let column = 0; column < Math.max(labels.length, apiNames.length); column += 1) {
        const label = labels[column] || "";
        const apiName = apiNames[column] || "";
        if (!label && !apiName) continue;
        items.push({
          type: "PermissionSet",
          apiName: apiName || generatedApiName(label).replace(/__c$/i, ""),
          label: label || apiName,
          details: "Permission Set",
          raw: {
            apiName: apiName || generatedApiName(label).replace(/__c$/i, ""),
            label: label || apiName,
            description: descriptions[column] || ""
          }
        });
      }
    }

    items.push(...parseTabularSheet(workbook, /^picklists?$/i, ["field", "value"], "PicklistValue", objectApiName, (row, indexOf) => {
      const field = String(row[indexOf(/field api name|picklist name/i)] || "").trim();
      const value = String(row[indexOf(/^value$|picklist value/i)] || "").trim();
      return field && value ? { apiName: `${field}.${value}`, label: value, details: `Field: ${field}`, field, value } : null;
    }));

    items.push(...parseTabularSheet(workbook, /picklists?\s*by\s*record\s*types?/i, ["record type", "picklist", "value"], "PicklistRecordType", objectApiName, (row, indexOf) => {
      const recordType = String(row[indexOf(/record type/i)] || "").trim();
      const field = String(row[indexOf(/picklist field api name/i)] || "").trim();
      const value = String(row[indexOf(/picklist value/i)] || "").trim();
      return recordType && field && value ? { apiName: `${recordType}.${field}.${value}`, label: value, details: `${recordType} / ${field}`, recordType, field, value, enabled: truthy(row[indexOf(/enabled|selected/i)]), defaultValue: truthy(row[indexOf(/default/i)]) } : null;
    }));

    items.push(...parseTabularSheet(workbook, /^email\s*alerts?$/i, ["unique name", "description"], "WorkflowAlert", objectApiName, (row, indexOf) => {
      const uniqueName = String(row[indexOf(/unique name/i)] || "").trim();
      const description = String(row[indexOf(/description/i)] || "").trim();
      return uniqueName || description ? { uniqueName: uniqueName || generatedApiName(description).replace(/__c$/i, ""), apiName: uniqueName || description, label: description || uniqueName, details: `Recipients: ${String(row[indexOf(/recipients?/i)] || "").trim()}`, description, fromEmailAddress: String(row[indexOf(/from email address/i)] || "").trim(), recipients: String(row[indexOf(/recipients?/i)] || "").trim(), emailTemplate: String(row[indexOf(/email template/i)] || "").trim() } : null;
    }));

    items.push(...parseTabularSheet(workbook, /^email\s*templates?$/i, ["template", "folder"], "EmailTemplate", objectApiName, (row, indexOf) => {
      const name = String(row[indexOf(/email template name/i)] || "").trim();
      const uniqueName = String(row[indexOf(/template unique name/i)] || "").trim();
      return name || uniqueName ? { apiName: uniqueName || name, label: name || uniqueName, details: `Folder: ${String(row[indexOf(/^folder$/i)] || "").trim()}`, name, uniqueName, folder: String(row[indexOf(/^folder$/i)] || "").trim(), subject: String(row[indexOf(/email subject/i)] || "").trim(), body: String(row[indexOf(/email body/i)] || "").trim(), description: String(row[indexOf(/^description$/i)] || "").trim(), availableForUse: truthy(row[indexOf(/available for use/i)]) } : null;
    }));

    items.push(...parseTabularSheet(workbook, /email\s*template\s*folders?/i, ["label", "unique name"], "EmailFolder", objectApiName, (row, indexOf) => {
      const label = String(row[indexOf(/label/i)] || "").trim();
      const uniqueName = String(row[indexOf(/unique name/i)] || "").trim();
      return label || uniqueName ? { apiName: uniqueName || label, label: label || uniqueName, details: "Email Template Folder", publicFolderAccess: String(row[indexOf(/public folder access/i)] || "").trim() } : null;
    }));

    return items;
  }

  function validateImportedItems(items) {
    const errors = [];
    const names = new Set();
    const fieldNames = new Set();
    items.forEach((item) => {
      const raw = item.raw || {};
      const addError = (message) => errors.push(message);
      if (!item.apiName) addError(`${item.type}: API name is required.`);
      if (["CustomObject", "CustomField", "RecordType", "ValidationRule"].includes(item.type) && item.apiName && names.has(item.apiName.toLowerCase())) {
        addError(`${item.type}: duplicate API name ${item.apiName}.`);
      }
      if (item.apiName) names.add(item.apiName.toLowerCase());
      if (item.type === "CustomField" && !raw.objectApiName) addError(`${item.apiName}: target object is required.`);
      if (item.type === "CustomField" && !raw.label) addError(`${item.apiName}: field label is required.`);
      if (item.type === "CustomField" && raw.apiName) {
        const fieldKey = `${raw.objectApiName}.${raw.apiName}`.toLowerCase();
        if (fieldNames.has(fieldKey)) addError(`${item.apiName}: duplicate field API name.`);
        fieldNames.add(fieldKey);
      }
      if (item.type === "CustomField" && raw.fieldType && !["text", "encryptedtext", "email", "phone", "url", "date", "datetime", "time", "textarea", "longtextarea", "richtextarea", "number", "currency", "percent", "checkbox", "picklist", "multipicklist", "lookup", "lookuprelationship", "externallookup", "masterdetail", "masterdetailrelationship", "formula", "autonumber", "geolocation", "location"].includes(typeKey(raw.fieldType))) {
        addError(`${item.apiName}: unsupported field type ${raw.fieldType}.`);
      }
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "formula" && (!raw.returnType || !raw.formula)) addError(`${item.apiName}: formula fields require Return Type and Formula.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "formula" && ["number", "currency", "percent"].includes(typeKey(raw.returnType)) && (!/^\d+$/.test(raw.precision) || !/^\d+$/.test(raw.scale))) addError(`${item.apiName}: formula fields returning ${raw.returnType} require numeric Precision and Scale.`);
      if (item.type === "CustomField" && ["lookup", "lookuprelationship", "externallookup", "masterdetail", "masterdetailrelationship"].includes(raw.fieldTypeKey) && !raw.referenceTo) addError(`${item.apiName}: relationship fields require a target object.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "autonumber" && (!raw.displayFormat || !/^\d+$/.test(raw.startingNumber))) addError(`${item.apiName}: AutoNumber fields require Display Format and numeric Starting Number.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "autonumber" && raw.displayFormat && !/\{0+\}/.test(raw.displayFormat.replace(/^\{(.+)\}$/, "$1"))) addError(`${item.apiName}: AutoNumber Display Format must include a zero placeholder, such as A-0000 or A-{0000}.`);
      if (item.type === "CustomField" && ["text", "encryptedtext"].includes(typeKey(raw.fieldType)) && !/^\d+$/.test(raw.length)) addError(`${item.apiName}: ${typeKey(raw.fieldType) === "encryptedtext" ? "Text (Encrypted)" : "Text"} fields require numeric Length.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "encryptedtext" && !raw.maskType) addError(`${item.apiName}: Text (Encrypted) fields require Mask Type.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "encryptedtext" && raw.maskType && !["all", "maskallcharacters", "creditcard", "creditcardnumber", "ssn", "socialsecuritynumber", "lastfour", "lastfourcharactersclear", "sin", "socialinsurancenumber", "nin", "nationalinsurancenumber"].includes(typeKey(raw.maskType))) addError(`${item.apiName}: Text (Encrypted) Mask Type must be Mask All Characters, Credit Card Number, Social Security Number, Last Four Characters Clear, Social Insurance Number, or National Insurance Number.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "encryptedtext" && !raw.maskChar) addError(`${item.apiName}: Text (Encrypted) fields require Mask Character.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "encryptedtext" && raw.maskChar && !["asterisk", "*", "X"].includes(raw.maskChar)) addError(`${item.apiName}: Text (Encrypted) Mask Character must be * or X.`);
      if (item.type === "CustomField" && ["number", "currency", "percent"].includes(typeKey(raw.fieldType)) && (!/^\d+$/.test(raw.precision) || !/^\d+$/.test(raw.scale))) addError(`${item.apiName}: ${raw.fieldType} fields require numeric Precision and Scale.`);
      if (item.type === "CustomField" && ["number", "currency", "percent"].includes(typeKey(raw.fieldType)) && /^\d+$/.test(raw.precision) && /^\d+$/.test(raw.scale) && Number(raw.scale) > Number(raw.precision)) addError(`${item.apiName}: Scale cannot be greater than Precision.`);
      if (item.type === "CustomField" && typeKey(raw.fieldType) === "externallookup" && !/^\d+$/.test(raw.length)) addError(`${item.apiName}: External Lookup fields require numeric Length.`);
      if (item.type === "CustomField" && ["geolocation", "location"].includes(typeKey(raw.fieldType)) && !/^\d+$/.test(raw.decimalPlaces)) addError(`${item.apiName}: Geolocation fields require numeric Decimal Places.`);
      if (item.type === "CustomField" && ["longtextarea", "richtextarea"].includes(typeKey(raw.fieldType)) && (!/^\d+$/.test(raw.length) || !/^\d+$/.test(raw.visibleLines))) addError(`${item.apiName}: ${raw.fieldType} fields require numeric Length and Visible Lines.`);
      if (item.type === "CustomField" && ["longtextarea", "richtextarea"].includes(typeKey(raw.fieldType)) && /^\d+$/.test(raw.length) && Number(raw.length) < 256) addError(`${item.apiName}: ${raw.fieldType} fields require Length of at least 256.`);
      if (item.type === "WorkflowAlert" && !raw.recipients) addError(`${item.apiName}: recipients are required.`);
      if (item.type === "EmailTemplate" && !raw.name && !raw.uniqueName) addError(`${item.apiName}: template name is required.`);
      if (item.type === "ValidationRule" && (!raw.apiName || !raw.errorConditionFormula || !raw.errorMessage)) addError(`${item.apiName || "Validation Rule"}: name, formula, and error message are required.`);
    });
    return errors;
  }

  function parseWorkbook(workbook) {
    const objectRows = rowsFromSheet(workbook, /^object$/i);
    const object = {};
    objectRows.forEach((row) => {
      const key = String(row[0] || "").trim().toLowerCase();
      const value = String(row[1] || "").trim();
      if (key === "label") object.label = value;
      if (key === "plural label") object.pluralLabel = value;
      if (key === "api name") object.apiName = value;
      if (key === "description") object.description = value;
    });
    object.apiName = suffixApiName(object.apiName || generatedApiName(object.label));
    object.label = object.label || object.apiName.replace(/__c$/, "");
    object.pluralLabel = object.pluralLabel || `${object.label}s`;

    const picklistRows = rowsFromSheet(workbook, /^picklists?$/i);
    const picklists = new Map();
    if (picklistRows.length > 1) {
      const headers = columns(picklistRows[0]);
      const fieldIndex = headers.findIndex((header) => /field api name|picklist name/i.test(header));
      const valueIndex = headers.findIndex((header) => /^value$|picklist value/i.test(header));
      if (fieldIndex >= 0 && valueIndex >= 0) {
        picklistRows.slice(1).forEach((row) => {
          const field = String(row[fieldIndex] || "").trim();
          const value = String(row[valueIndex] || "").trim();
          if (!field || !value) return;
          const values = picklists.get(field.toLowerCase()) || [];
          if (!values.includes(value)) values.push(value);
          picklists.set(field.toLowerCase(), values);
        });
      }
    }

    const items = [{
      type: "CustomObject",
      section: "Object",
      apiName: object.apiName,
      label: object.label,
      details: `Plural Label: ${object.pluralLabel}`,
      raw: object
    }];

    const fieldRows = rowsFromSheet(workbook, /^(fields|form)$/i);
    const fieldHeader = headerIndex(fieldRows, ["field label", "api name"]);
    if (fieldHeader >= 0) {
      const headers = columns(fieldRows[fieldHeader]);
      const indexOf = (pattern) => headers.findIndex((header) => pattern.test(header));
      const labelIndex = indexOf(/field label|^label$/i);
      const apiIndex = indexOf(/^api name/i);
      const fieldTypeIndex = indexOf(/field type|^type$/i);
      const refIndex = indexOf(/reference to api name|reference to/i);
      const requiredIndex = indexOf(/required/i);
      const uniqueIndex = indexOf(/unique/i);
      const externalIndex = indexOf(/external id/i);
      const defaultIndex = indexOf(/default value/i);
      const lengthIndex = indexOf(/^length/i);
      const precisionIndex = indexOf(/^precision/i);
      const scaleIndex = indexOf(/decimal places|^scale/i);
      const formulaIndex = indexOf(/^formula/i);
      const returnTypeIndex = indexOf(/return type/i);
      const displayFormatIndex = indexOf(/display format|auto.?number format|^format/i);
      const startingNumberIndex = indexOf(/starting number|starting value/i);
      const maskTypeIndex = indexOf(/mask type/i);
      const decimalPlacesIndex = indexOf(/decimal places/i);
      const visibleLinesIndex = indexOf(/visible lines/i);
      const helpIndex = indexOf(/help text/i);
      const descriptionIndex = indexOf(/^description/i);
      const maskCharIndex = indexOf(/mask character|^mask char$/i);
      fieldRows.slice(fieldHeader + 1).forEach((row, fieldOffset) => {
        const label = String(row[labelIndex] || row[0] || "").trim();
        let apiName = String(row[apiIndex] || row[1] || "").trim();
        if (!label && !apiName) return;
        apiName = suffixApiName(apiName || generatedApiName(label));
        const suppliedFieldType = String(row[fieldTypeIndex] || "Text").trim();
        const relationshipType = suppliedFieldType.match(/^(lookup|lookuprelationship|externallookup|master[ -]?detail(?:relationship)?)\s*\(([^()]+)\)$/i);
        const fieldType = relationshipType ? relationshipType[1] : suppliedFieldType;
        const fieldTypeKey = typeKey(fieldType);
        const values = picklists.get(apiName.toLowerCase()) || picklists.get(apiName.replace(/__c$/i, "").toLowerCase()) || [];
        const raw = {
          rowNumber: fieldHeader + fieldOffset + 2,
          objectApiName: object.apiName,
          apiName,
          fullApiName: `${object.apiName}.${apiName}`,
          label: label || apiName.replace(/__c$/, ""),
          fieldType,
          fieldTypeKey,
          referenceTo: String(row[refIndex] || relationshipType?.[2] || "").trim(),
          required: truthy(row[requiredIndex]),
          unique: truthy(row[uniqueIndex]),
          externalId: truthy(row[externalIndex]),
          defaultValue: String(row[defaultIndex] || "").trim(),
          length: String(row[lengthIndex] || "").trim(),
          maskType: String(row[maskTypeIndex] || "").trim(),
          maskChar: String(row[maskCharIndex] || "").trim(),
          precision: String(row[precisionIndex] || row[lengthIndex] || "").trim(),
          scale: String(row[scaleIndex] ?? "").trim(),
          formula: String(row[formulaIndex] || "").trim(),
          returnType: String(row[returnTypeIndex] || "").trim(),
          displayFormat: String(row[displayFormatIndex] || "").trim(),
          startingNumber: String(row[startingNumberIndex] || "").trim(),
          decimalPlaces: String(row[decimalPlacesIndex] || "").trim(),
          visibleLines: String(row[visibleLinesIndex] || "").trim(),
          inlineHelpText: String(row[helpIndex] || "").trim(),
          description: String(row[descriptionIndex] || "").trim(),
          picklistValues: values
        };
        items.push({ type: "CustomField", section: "Fields", apiName: raw.fullApiName, label: raw.label, details: `${raw.fieldType}${values.length ? `; ${values.length} picklist value(s)` : ""}`, raw });
      });
    }

    const recordRows = rowsFromSheet(workbook, /^record\s*types?$/i);
    const recordHeader = headerIndex(recordRows, ["label", "name"]);
    if (recordHeader >= 0) {
      const headers = columns(recordRows[recordHeader]);
      const indexOf = (pattern) => headers.findIndex((header) => pattern.test(header));
      recordRows.slice(recordHeader + 1).forEach((row) => {
        const label = String(row[indexOf(/label/i)] || "").trim();
        const name = String(row[indexOf(/name/i)] || "").trim();
        if (!label && !name) return;
        const raw = { rowNumber: recordHeader + recordRows.slice(recordHeader + 1).indexOf(row) + 2, objectApiName: object.apiName, apiName: name || generatedApiName(label).replace(/__c$/, ""), label: label || name, description: String(row[indexOf(/description/i)] || "").trim(), active: truthy(row[indexOf(/active/i)]) };
        items.push({ type: "RecordType", section: "Record Types", apiName: `${object.apiName}.${raw.apiName}`, label: raw.label, details: raw.active ? "Active" : "Inactive", raw: { ...raw, fullApiName: `${object.apiName}.${raw.apiName}` } });
      });
    }

    const validationRows = rowsFromSheet(workbook, /^validation\s*rules?$/i);
    const validationHeader = headerIndex(validationRows, ["name", "formula"]);
    if (validationHeader >= 0) {
      const headers = columns(validationRows[validationHeader]);
      const indexOf = (pattern) => headers.findIndex((header) => pattern.test(header));
      const nameIndex = indexOf(/unique name|^name$/i);
      const descriptionIndex = indexOf(/description/i);
      const activeIndex = indexOf(/active/i);
      const formulaIndex = indexOf(/error condition formula|formula/i);
      const messageIndex = indexOf(/error message|message/i);
      const locationIndex = indexOf(/error location|error display field|location/i);

      validationRows.slice(validationHeader + 1).forEach((row) => {
        const name = String(row[nameIndex] || "").trim();
        const formula = String(row[formulaIndex] || "").trim();
        if (!name && !formula) return;
        const raw = {
          rowNumber: validationHeader + validationRows.slice(validationHeader + 1).indexOf(row) + 2,
          objectApiName: object.apiName,
          apiName: name,
          fullApiName: `${object.apiName}.${name}`,
          label: name,
          description: String(row[descriptionIndex] || "").trim(),
          active: activeIndex >= 0 ? truthy(row[activeIndex]) : true,
          errorConditionFormula: formula,
          errorMessage: String(row[messageIndex] || "Validation error.").trim(),
          errorDisplayField: String(row[locationIndex] || "").trim()
        };
        items.push({
          type: "ValidationRule",
          section: "Validation Rules",
          apiName: raw.fullApiName,
          label: raw.label,
          details: raw.errorMessage,
          raw
        });
      });
    }

    items.push(...parseAdditionalWorkbookTabs(workbook, object.apiName));
    return items;
  }

  function parseCsv(text) {
    const rows = [];
    let cell = "", row = [], quoted = false;
    for (let i = 0; i < text.length; i += 1) {
      const ch = text[i];
      if (ch === '"' && quoted && text[i + 1] === '"') { cell += '"'; i += 1; }
      else if (ch === '"') quoted = !quoted;
      else if (ch === "," && !quoted) { row.push(cell); cell = ""; }
      else if ((ch === "\n" || ch === "\r") && !quoted) { if (ch === "\r" && text[i + 1] === "\n") i += 1; row.push(cell); if (row.some((v) => v.trim())) rows.push(row); row = []; cell = ""; }
      else cell += ch;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    const headers = (rows.shift() || []).map((value) => value.trim());
    return rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, (values[index] || "").trim()])));
  }

  function parseExcelXml(text) {
    const xml = new DOMParser().parseFromString(text, "application/xml");
    if (xml.querySelector("parsererror")) throw new Error("Invalid Excel XML file.");
    const rows = Array.from(xml.getElementsByTagName("Row")).map((row) =>
      Array.from(row.getElementsByTagName("Data")).map((cell) => cell.textContent || "")
    );
    const headers = (rows.shift() || []).map((header) => header.trim());
    return rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, (values[index] || "").trim()])));
  }

  function parseFlatRows(rows) {
    return rows.map((row) => {
      const normalized = Object.fromEntries(Object.entries(row).map(([key, value]) => [key.trim(), String(value ?? "").trim()]));
      const type = valueOf(normalized, ["type"]) || (valueOf(normalized, ["targetObject"]) ? "field" : "object");
      const apiName = valueOf(normalized, ["apiName", "fullName", "name"]);
      const label = valueOf(normalized, ["label", "field label"]);
      if (!apiName && !label) return null;
      if (/object/i.test(type)) {
        const name = suffixApiName(apiName || generatedApiName(label));
        return { type: "CustomObject", apiName: name, label: label || name.replace(/__c$/, ""), details: "Custom Object", raw: { apiName: name, label: label || name.replace(/__c$/, ""), pluralLabel: valueOf(normalized, ["pluralLabel"]) || `${label}s`, description: valueOf(normalized, ["description"]) } };
      }
      const objectName = valueOf(normalized, ["targetObject"]) || "";
      const name = suffixApiName(apiName || generatedApiName(label));
      return { type: "CustomField", apiName: `${objectName}.${name}`, label: label || name, details: `Target: ${objectName}`, raw: { objectApiName: objectName, apiName: name, fullApiName: `${objectName}.${name}`, label: label || name, fieldType: valueOf(normalized, ["fieldType"]) || "Text", fieldTypeKey: typeKey(valueOf(normalized, ["fieldType"]) || "Text"), required: truthy(valueOf(normalized, ["required"])), length: valueOf(normalized, ["length"]), precision: valueOf(normalized, ["precision"]), scale: valueOf(normalized, ["scale"]), picklistValues: valueOf(normalized, ["picklistValues"]).split(/[|\n]/).map((v) => v.trim()).filter(Boolean) } };
    }).filter(Boolean);
  }

  function renderImportTabs(items) {
    if (!importTabs) return;
    importTabs.textContent = "";
    const sections = ["All", ...new Set(items.map((item) => item.section || item.type))];
    sections.forEach((section) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "config-import-tab";
      tab.classList.toggle("active", section === activeImportSection);
      tab.textContent = `${section} (${section === "All" ? items.length : items.filter((item) => (item.section || item.type) === section).length})`;
      tab.addEventListener("click", () => {
        activeImportSection = section;
        renderImportTabs(importedItems);
        renderPreview(importedItems);
      });
      importTabs.appendChild(tab);
    });
    importTabs.hidden = sections.length <= 1;
  }

  function renderPreview(items) {
    importPreview.textContent = "";
    const visibleItems = activeImportSection === "All"
      ? items
      : items.filter((item) => (item.section || item.type) === activeImportSection);
    if (!visibleItems.length) return;
    const table = document.createElement("table");
    table.className = "configuration-table";
    const header = document.createElement("tr");
    ["Type", "API Name", "Label / Name", "Details"].forEach((text) => { const th = document.createElement("th"); th.textContent = text; header.appendChild(th); });
    const thead = document.createElement("thead"); thead.appendChild(header); table.appendChild(thead);
    const tbody = document.createElement("tbody");
    visibleItems.forEach((item) => {
      const tr = document.createElement("tr");
      [item.type, item.apiName, item.label, item.details].forEach((text) => { const td = document.createElement("td"); td.textContent = text || ""; tr.appendChild(td); });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody); importPreview.appendChild(table);
  }

  function encryptedMaskChar(value) {
    return String(value || "").trim() === "*" ? "asterisk" : String(value || "").trim();
  }

  function encryptedMaskType(value) {
    const key = typeKey(value);
    return {
      maskallcharacters: "all",
      creditcard: "creditCard",
      creditcardnumber: "creditCard",
      socialsecuritynumber: "ssn",
      lastfourcharactersclear: "lastFour",
      socialinsurancenumber: "sin",
      nationalinsurancenumber: "nin"
    }[key] || key;
  }

  function fieldMetadata(raw) {
    const key = raw.fieldTypeKey || typeKey(raw.fieldType);
    const metadata = { label: raw.label, type: "Text", required: !!raw.required };
    if (raw.description) metadata.description = raw.description;
    if (raw.inlineHelpText) metadata.inlineHelpText = raw.inlineHelpText;
    if (["text", "encryptedtext"].includes(key)) { metadata.type = key === "encryptedtext" ? "EncryptedText" : "Text"; metadata.length = Number(raw.length); if (key === "encryptedtext") { metadata.maskType = encryptedMaskType(raw.maskType); metadata.maskChar = encryptedMaskChar(raw.maskChar); } }
    else if (["number", "currency", "percent"].includes(key)) { metadata.type = key[0].toUpperCase() + key.slice(1); metadata.precision = Number(raw.precision); metadata.scale = Number(raw.scale); }
    else if (key === "checkbox") { metadata.type = "Checkbox"; metadata.defaultValue = truthy(raw.defaultValue) ? "true" : "false"; }
    else if (["date", "datetime", "phone", "email", "url", "textarea"].includes(key)) metadata.type = key === "datetime" ? "DateTime" : key === "textarea" ? "TextArea" : key[0].toUpperCase() + key.slice(1);
    else if (["picklist", "multipicklist"].includes(key)) { metadata.type = key === "multipicklist" ? "MultiselectPicklist" : "Picklist"; metadata.valueSet = { restricted: true, valueSetDefinition: { value: (raw.picklistValues || []).map((value) => ({ fullName: value, label: value, default: false })) } }; }
    else if (key.includes("masterdetail") || key.includes("lookup")) { metadata.type = key.includes("master") ? "MasterDetail" : key.includes("external") ? "ExternalLookup" : "Lookup"; metadata.referenceTo = raw.referenceTo; metadata.relationshipName = `${raw.objectApiName.replace(/__c$/i, "")}_${raw.apiName.replace(/__c$/i, "")}`; }
    else if (key === "formula") { metadata.type = raw.returnType || "Text"; metadata.formula = raw.formula; }
    return metadata;
  }

  async function createItem(hostname, item, existingId) {
    let path, body;
    if (item.type === "CustomObject") { path = `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/CustomObject/`; body = { FullName: item.raw.apiName, Metadata: { label: item.raw.label, pluralLabel: item.raw.pluralLabel, ...(item.raw.description ? { description: item.raw.description } : {}), nameField: { type: "Text", label: "Name" }, deploymentStatus: "Deployed", sharingModel: "ReadWrite" } }; }
    else if (item.type === "CustomField") { path = `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/CustomField/`; body = { FullName: item.raw.fullApiName, Metadata: fieldMetadata(item.raw) }; }
    else if (item.type === "RecordType") { path = `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/RecordType/`; body = { FullName: item.raw.fullApiName, Metadata: { label: item.raw.label, active: !!item.raw.active, ...(item.raw.description ? { description: item.raw.description } : {}) } }; }
    else if (item.type === "ValidationRule") { path = `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/ValidationRule/`; body = { FullName: item.raw.fullApiName, Metadata: { active: !!item.raw.active, description: item.raw.description || "", errorConditionFormula: item.raw.errorConditionFormula, errorMessage: item.raw.errorMessage || "Validation error.", ...(item.raw.errorDisplayField ? { errorDisplayField: item.raw.errorDisplayField } : {}) } }; }
    else throw new Error(`Unsupported component type: ${item.type}`);
    return SFPanel.sendMessage({ type: "restRequest", feature: "import_configuration", hostname, method: existingId ? "PATCH" : "POST", path: existingId ? `${path}${encodeURIComponent(existingId)}` : path, body });
  }

  function xmlEscape(value) {
    return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
  }

  function metadataFieldXml(raw) {
    const key = raw.fieldTypeKey || typeKey(raw.fieldType);
    const requiredInteger = (value, name) => {
      if (!/^\d+$/.test(String(value || "").trim())) throw new Error(`${raw.apiName}: ${name} must be a numeric value.`);
      return String(value).trim();
    };
    const lines = [`    <fields>`, `      <fullName>${xmlEscape(raw.apiName)}</fullName>`, `      <label>${xmlEscape(raw.label || raw.apiName)}</label>`];
    if (["text", "encryptedtext"].includes(key)) { lines.push(`      <length>${requiredInteger(raw.length, "Length")}</length>`); if (key === "encryptedtext") lines.push(`      <maskType>${xmlEscape(encryptedMaskType(raw.maskType))}</maskType>`, `      <maskChar>${xmlEscape(encryptedMaskChar(raw.maskChar))}</maskChar>`); lines.push(`      <type>${key === "encryptedtext" ? "EncryptedText" : "Text"}</type>`); }
    else if (key === "autonumber") lines.push(`      <displayFormat>${xmlEscape(raw.displayFormat)}</displayFormat>`, `      <startingNumber>${requiredInteger(raw.startingNumber, "Starting Number")}</startingNumber>`, "      <type>AutoNumber</type>");
    else if (["number", "currency", "percent"].includes(key)) {
      lines.push(`      <precision>${requiredInteger(raw.precision, "Precision")}</precision>`, `      <scale>${requiredInteger(raw.scale, "Scale")}</scale>`, `      <type>${key[0].toUpperCase() + key.slice(1)}</type>`);
    }
    else if (key === "checkbox") lines.push(`      <defaultValue>${truthy(raw.defaultValue) ? "true" : "false"}</defaultValue>`, "      <type>Checkbox</type>");
    else if (["date", "datetime", "time", "email", "phone", "url", "textarea", "longtextarea", "richtextarea"].includes(key)) {
      const metadataType = { datetime: "DateTime", textarea: "TextArea", longtextarea: "LongTextArea", richtextarea: "Html" }[key] || key[0].toUpperCase() + key.slice(1);
      if (["longtextarea", "richtextarea"].includes(key)) lines.push(`      <length>${requiredInteger(raw.length, "Length")}</length>`, `      <visibleLines>${requiredInteger(raw.visibleLines, "Visible Lines")}</visibleLines>`);
      lines.push(`      <type>${metadataType}</type>`);
    } else if (["lookup", "lookuprelationship", "externallookup", "masterdetail", "masterdetailrelationship"].includes(key)) {
      lines.push(`      <referenceTo>${xmlEscape(raw.referenceTo)}</referenceTo>`, `      <relationshipName>${xmlEscape(`${raw.objectApiName.replace(/__c$/i, "")}_${raw.apiName.replace(/__c$/i, "")}`)}</relationshipName>`);
      if (key.includes("external")) lines.push(`      <length>${requiredInteger(raw.length, "Length")}</length>`);
      lines.push(`      <type>${key.includes("master") ? "MasterDetail" : key.includes("external") ? "ExternalLookup" : "Lookup"}</type>`);
    } else if (["picklist", "multipicklist"].includes(key)) {
      lines.push(`      <type>${key === "multipicklist" ? "MultiselectPicklist" : "Picklist"}</type>`, "      <valueSet>", "        <restricted>true</restricted>", "        <valueSetDefinition>");
      for (const value of raw.picklistValues || []) lines.push("          <value>", "            <default>false</default>", `            <fullName>${xmlEscape(value)}</fullName>`, `            <label>${xmlEscape(value)}</label>`, "          </value>");
      lines.push("        </valueSetDefinition>", "      </valueSet>");
    } else if (key === "formula") {
      const returnType = { "date/time": "DateTime", datetime: "DateTime" }[typeKey(raw.returnType)] || raw.returnType || "Text";
      if (["Number", "Currency", "Percent"].includes(returnType)) lines.push(`      <precision>${requiredInteger(raw.precision, "Precision")}</precision>`, `      <scale>${requiredInteger(raw.scale, "Scale")}</scale>`);
      lines.push(`      <formula>${xmlEscape(raw.formula)}</formula>`, `      <type>${xmlEscape(returnType)}</type>`);
    } else if (["geolocation", "location"].includes(key)) {
      lines.push(`      <displayLocationInDecimal>true</displayLocationInDecimal>`, `      <scale>${requiredInteger(raw.decimalPlaces, "Decimal Places")}</scale>`, `      <type>Location</type>`);
    } else lines.push("      <type>Text</type>");
    lines.push("    </fields>");
    return lines.join("\n");
  }

  function buildMetadataFiles(items) {
    const object = items.find((item) => item.type === "CustomObject");
    if (!object) throw new Error("Object tab is required before metadata can be deployed.");
    const fields = items.filter((item) => item.type === "CustomField");
    const recordTypes = items.filter((item) => item.type === "RecordType");
    const rules = items.filter((item) => item.type === "ValidationRule");
    const hasMasterDetail = fields.some((item) => (item.raw.fieldTypeKey || typeKey(item.raw.fieldType)).includes("masterdetail"));
    const objectXml = ["<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "<CustomObject xmlns=\"http://soap.sforce.com/2006/04/metadata\">", `  <fullName>${xmlEscape(object.raw.apiName)}</fullName>`, `  <label>${xmlEscape(object.raw.label)}</label>`, "  <nameField>", "    <label>Name</label>", "    <type>Text</type>", "  </nameField>", `  <pluralLabel>${xmlEscape(object.raw.pluralLabel)}</pluralLabel>`, "  <deploymentStatus>Deployed</deploymentStatus>", `  <sharingModel>${hasMasterDetail ? "ControlledByParent" : "ReadWrite"}</sharingModel>`, ...fields.map((item) => metadataFieldXml(item.raw)), ...recordTypes.map((item) => `  <recordTypes>\n    <fullName>${xmlEscape(item.raw.apiName)}</fullName>\n    <label>${xmlEscape(item.raw.label)}</label>\n    <active>${item.raw.active ? "true" : "false"}</active>\n  </recordTypes>`), ...rules.map((item) => `  <validationRules>\n    <fullName>${xmlEscape(item.raw.apiName)}</fullName>\n    <active>${item.raw.active ? "true" : "false"}</active>\n    <errorConditionFormula>${xmlEscape(item.raw.errorConditionFormula)}</errorConditionFormula>\n    <errorMessage>${xmlEscape(item.raw.errorMessage)}</errorMessage>\n  </validationRules>`), "</CustomObject>"].join("\n");
    const version = String(SFPanel.API_VERSION || "v65.0").replace(/^v/, "");
    return { [`objects/${object.raw.apiName}.object`]: objectXml, "package.xml": `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata">\n  <types>\n    <members>${xmlEscape(object.raw.apiName)}</members>\n    <name>CustomObject</name>\n  </types>\n  <version>${version}</version>\n</Package>` };
  }

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (const byte of bytes) { crc ^= byte; for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0); }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function zipStore(files) {
    const encoder = new TextEncoder(); const chunks = []; const central = []; let offset = 0;
    const u16 = (value) => [value & 255, (value >>> 8) & 255]; const u32 = (value) => [value & 255, (value >>> 8) & 255, (value >>> 16) & 255, (value >>> 24) & 255];
    for (const [name, text] of Object.entries(files)) { const nameBytes = encoder.encode(name); const data = encoder.encode(text); const crc = crc32(data); const local = [80, 75, 3, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), 0, 0, ...nameBytes, ...data]; chunks.push(new Uint8Array(local)); central.push({ nameBytes, crc, size: data.length, offset }); offset += local.length; }
    const centralStart = offset;
    for (const entry of central) chunks.push(new Uint8Array([80, 75, 1, 2, 20, 0, 20, 0, 0, 0, 0, 0, 0, 0, ...u32(entry.crc), ...u32(entry.size), ...u32(entry.size), ...u16(entry.nameBytes.length), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...u32(entry.offset), ...entry.nameBytes]));
    const centralSize = offset - centralStart; chunks.push(new Uint8Array([80, 75, 5, 6, 0, 0, 0, 0, ...u16(central.length), ...u16(central.length), ...u32(centralSize), ...u32(centralStart), 0, 0]));
    return new Blob(chunks, { type: "application/zip" });
  }

  async function blobBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    return btoa(binary);
  }

  function metadataEnvelope(action, payload) {
    return `<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:met="http://soap.sforce.com/2006/04/metadata"><env:Header/><env:Body><met:${action}>${payload}</met:${action}></env:Body></env:Envelope>`;
  }

  function xmlTag(xml, tag) { return String(xml || "").match(new RegExp(`<[^>]*${tag}[^>]*>([\\s\\S]*?)</[^>]*${tag}>`, "i"))?.[1] || ""; }

  async function deployMetadata(hostname, items, checkOnly = false) {
    if (!checkOnly) setDeployStep("deploy");
    const files = buildMetadataFiles(items);
    if (importLog) importLog.textContent += `Preparing Salesforce ${checkOnly ? "validation" : "deployment"} for ${Object.keys(files).length} package file(s).\n`;
    const encodedZip = await blobBase64(zipStore(files));
    console.info("[SF Tool] Starting Metadata API deployment", { itemCount: items.length, fileCount: Object.keys(files).length });
    const start = await SFPanel.sendMessage({ type: "metadataDeployRequest", feature: "import_configuration", hostname, zipBase64: encodedZip, checkOnly });
    const id = String(start.data?.id || start.data?.deployResult?.id || "").trim();
    if (!id) throw new Error(`Metadata deployment did not return a deployment ID: ${String(start.data || "").slice(0, 500)}`);
    if (importLog) importLog.textContent += `Salesforce ${checkOnly ? "validation" : "deployment"} ${id} started.\n`;
    for (let attempt = 0; attempt < 120; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      const status = await SFPanel.sendMessage({ type: "metadataStatusRequest", feature: "import_configuration", hostname, id });
      const result = status.data?.deployResult || status.data?.result || status.data || {};
      const state = String(result.status || "").trim();
      const done = /succeeded|failed|canceled|succeededpartial/i.test(state);
      if (importLog) importLog.textContent = `Salesforce ${checkOnly ? "validation" : "deployment"} ${id}: ${state || "In Progress"}\n`;
      if (done) {
        if (!/^succeeded$/i.test(state)) {
          const failures = result.details?.componentFailures || [];
          const failureList = (Array.isArray(failures) ? failures : [failures]).map((failure) => `${failure.fullName || failure.fileName || "Component"}: ${failure.problem || failure.message || "Unknown failure"}`).join("\n");
          throw new Error(`Salesforce metadata validation/deployment ${state || "failed"}: ${failureList || result.errorMessage || "See deployment details."}`);
        }
        if (!checkOnly) setDeployStep("verify");
        return result;
      }
    }
    throw new Error(`Salesforce ${checkOnly ? "validation" : "deployment"} ${id} did not finish within the allowed time.`);
  }

  function soqlLiteral(value) { return String(value || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'"); }

  async function findExistingItem(hostname, item) {
    let query;
    let useToolingApi = true;
    if (item.type === "CustomObject") {
      query = `SELECT Id FROM CustomObject WHERE DeveloperName = '${soqlLiteral(item.raw.apiName.replace(/__c$/i, ""))}'`;
    } else if (item.type === "CustomField") {
      query = `SELECT Id FROM CustomField WHERE TableEnumOrId = '${soqlLiteral(item.raw.objectApiName)}' AND DeveloperName = '${soqlLiteral(item.raw.apiName.replace(/__c$/i, ""))}'`;
    } else if (item.type === "RecordType") {
      // The Tooling API's RecordType object has no DeveloperName field; the standard REST RecordType object does.
      useToolingApi = false;
      query = `SELECT Id FROM RecordType WHERE SobjectType = '${soqlLiteral(item.raw.objectApiName)}' AND DeveloperName = '${soqlLiteral(item.raw.apiName.replace(/__c$/i, ""))}'`;
    } else if (item.type === "ValidationRule") {
      query = `SELECT Id FROM ValidationRule WHERE TableEnumOrId = '${soqlLiteral(item.raw.objectApiName)}' AND ValidationName = '${soqlLiteral(item.raw.apiName.replace(/__c$/i, ""))}'`;
    } else {
      return null;
    }
    try {
      const path = useToolingApi
        ? `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(query)}`
        : `/services/data/${SFPanel.API_VERSION}/query/?q=${encodeURIComponent(query)}`;
      const result = await SFPanel.sendMessage({ type: "restRequest", feature: "import_configuration", hostname, method: "GET", path });
      return result.data?.records?.[0] || null;
    } catch (error) {
      if (/Salesforce API error 404/.test(error.message || "")) return null;
      throw error;
    }
  }

  async function handleImport() {
    const file = importFileInput.files[0];
    if (!file) return;
    try {
      importSource = null;
      clearImportState();
      if (importFileName) importFileName.value = file.name;
      setStatus(importStatus, "Reading configuration file…", false);
      const lower = file.name.toLowerCase();
      if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) {
        const buffer = await file.arrayBuffer();
        importSource = { name: file.name, kind: "workbook", data: buffer };
        importedItems = parseWorkbook(XLSX.read(new Uint8Array(buffer), { type: "array" }));
      } else if (lower.endsWith(".json")) {
        const text = await file.text();
        importSource = { name: file.name, kind: "json", data: text };
        const parsed = JSON.parse(text);
        importedItems = parseFlatRows(Array.isArray(parsed) ? parsed : [...(parsed.objects || []), ...(parsed.fields || [])]);
      } else if (lower.endsWith(".csv")) {
        const text = await file.text();
        importSource = { name: file.name, kind: "csv", data: text };
        importedItems = parseFlatRows(parseCsv(text));
      } else if (lower.endsWith(".xml")) {
        const text = await file.text();
        importSource = { name: file.name, kind: "xml", data: text };
        importedItems = parseFlatRows(parseExcelXml(text));
      }
      else throw new Error("Choose an .xlsx, .xls, .json, .csv, or Excel XML configuration file.");
      activeImportSection = "All";
      validationErrors = [];
      renderImportTabs(importedItems); renderPreview(importedItems);
      importRefreshButton.disabled = false;
      importValidateButton.disabled = importedItems.length === 0;
      importCreateButton.disabled = true;
      setDeployStep("retrieve");
      setStatus(importStatus, "", false);
    } catch (error) {
      clearImportState();
      if (importFileName) importFileName.value = file.name;
      setStatus(importStatus, error.message || "Could not parse the configuration file.");
    }
  }

  async function refreshImportFile() {
    if (!importFileInput) return;
    setStatus(importStatus, "Select the saved configuration file to reload its current contents.", false);
    importFileInput.value = "";
    importFileInput.click();
  }

  function clearImportState() { importedItems = []; validationErrors = []; activeImportSection = "All"; importPreview.textContent = ""; importTabs.hidden = true; importIssues.replaceChildren(importStatus, importLog); importIssues.hidden = true; importResizeHandle.hidden = true; importCreateButton.disabled = true; importRefreshButton.disabled = true; importValidateButton.disabled = true; if (importLog) { importLog.textContent = ""; importLog.hidden = true; } if (importFileName) importFileName.value = "No file selected"; }

  async function validateRelationshipTargets(items, hostname = getImportTargetHostname()) {
    if (!hostname) return ["Workbook validation tab: Open a Salesforce tab to validate relationship targets against the org."];
    const workbookObjects = new Set(items.filter((item) => item.type === "CustomObject").map((item) => item.apiName.toLowerCase()));
    const relationshipFields = items.filter((item) => item.type === "CustomField" && ["lookup", "lookuprelationship", "externallookup", "masterdetail", "masterdetailrelationship"].includes(item.raw?.fieldTypeKey));
    if (!relationshipFields.length) return [];
    const result = await SFPanel.sendMessage({ type: "getObjects", feature: "import_configuration", hostname });
    const orgObjects = new Set((result.objects || []).map((item) => String(item.name || "").toLowerCase()));
    return relationshipFields
      .filter((item) => item.raw.referenceTo && !workbookObjects.has(item.raw.referenceTo.toLowerCase()) && !orgObjects.has(item.raw.referenceTo.toLowerCase()))
      .map((item) => `${item.section || "Fields"} tab: ${item.apiName}: relationship target ${item.raw.referenceTo} was not found in the workbook or target org.`);
  }

  function friendlyValidationMessage(message) {
    const text = String(message || "");
    if (/does not resolve to a valid sObject type|Entity .* not found|referenceTo/i.test(text)) {
      return "A relationship field points to an object that Salesforce cannot find. In the Fields tab, correct Reference To API Name or add the referenced object to the Object tab/package.";
    }
    if (/sharingModel.*ReadWrite|Cannot set sharingModel/i.test(text)) {
      return "The object has a Master-Detail field. Check the Fields tab relationship setup; Salesforce requires controlled sharing for this object.";
    }
    if (/invalid value|invalid type|error parsing file/i.test(text)) {
      return `Salesforce could not use one of the values in the workbook. Check the Fields tab values and field type formatting. Details: ${text}`;
    }
    return text.replace(/^Salesforce metadata validation\/deployment\s+Failed:\s*/i, "");
  }

  async function validateImport() {
    const hostname = getImportTargetHostname();
    importValidateButton.disabled = true;
    importCreateButton.disabled = true;
    setDeployStep("validate");
    importIssues.hidden = false;
    if (importLog) { importLog.hidden = false; importLog.textContent = ""; }
    setStatus(importStatus, "Validating workbook and Salesforce metadata rules...", false);
    validationErrors = validateImportedItems(importedItems);
    try {
      validationErrors.push(...await validateRelationshipTargets(importedItems, hostname));
    } catch (error) {
      validationErrors.push(`Fields tab: Could not validate relationship targets against the org: ${error.message || "Salesforce request failed."}`);
    }
    const deployableItems = importedItems.filter((item) => ["CustomObject", "CustomField", "RecordType", "ValidationRule"].includes(item.type));
    if (validationErrors.length === 0 && deployableItems.length > 0) {
      try {
        await deployMetadata(hostname, deployableItems, true);
      } catch (error) {
        String(error.message || error).split(/\r?\n/).filter(Boolean).forEach((message) => validationErrors.push(`Salesforce check: ${friendlyValidationMessage(message)}`));
      }
    }
    importValidateButton.disabled = false;
    importIssues.replaceChildren(importStatus, importLog);
    if (validationErrors.length) {
      const table = document.createElement("table");
      table.className = "configuration-table config-issues-table";
      const header = document.createElement("tr");
      ["Tab", "Row #", "Message"].forEach((label) => {
        const th = document.createElement("th");
        th.textContent = label;
        header.appendChild(th);
      });
      const thead = document.createElement("thead");
      thead.appendChild(header);
      table.appendChild(thead);
      const tbody = document.createElement("tbody");
      validationErrors.forEach((message) => {
        const source = importedItems
          .filter((item) => message.includes(item.apiName) || message.includes(item.label))
          .sort((left, right) => (right.apiName || "").length - (left.apiName || "").length)[0];
        const row = document.createElement("tr");
        [source?.section || source?.type || "Workbook", source?.raw?.rowNumber || "-", message].forEach((value) => {
          const td = document.createElement("td");
          td.textContent = value;
          row.appendChild(td);
        });
        tbody.appendChild(row);
      });
      table.appendChild(tbody);
      importIssues.appendChild(table);
    } else {
      setStatus(importStatus, "Validation passed. Salesforce accepted the package in check-only mode.", false);
    }
    importIssues.hidden = false;
    importResizeHandle.hidden = false;
    importCreateButton.disabled = importedItems.length === 0 || validationErrors.length > 0;
    updateDeployStepActions();
    const skippedCount = importedItems.filter((item) => !["CustomObject", "CustomField", "RecordType", "ValidationRule"].includes(item.type)).length;
    setStatus(importStatus, validationErrors.length ? `${validationErrors.length} validation issue(s) found.` : `Validation passed. Salesforce accepted the package in check-only mode.${skippedCount ? ` ${skippedCount} desktop-only component(s) will be skipped.` : ""}`, validationErrors.length > 0);
  }

  async function createImportedMetadata() {
    const hostname = getImportTargetHostname();
    if (validationErrors.length > 0) return setStatus(importStatus, "Fix validation issues before creating metadata.");
    const selected = importedItems.filter((item) => ["CustomObject", "CustomField", "RecordType", "ValidationRule"].includes(item.type));
    if (!hostname) return setStatus(importStatus, "No Salesforce tab detected.");
    if (!selected.length) return setStatus(importStatus, "No deployable metadata components were found. Permission Sets and picklist assignments are not supported by this browser deployment yet.");
    importCreateButton.disabled = true;
    if (importLog) { importLog.hidden = false; importLog.textContent = ""; }
    try {
      await deployMetadata(hostname, selected);
      const skipped = importedItems.length - selected.length;
      setStatus(importStatus, `Metadata deployment completed for ${selected.length} component(s).${skipped ? ` ${skipped} read-only component(s) were skipped.` : ""}`, false);
    } catch (error) {
      const errorMessage = error?.message || String(error);
      const detail = /INVALID_SESSION_ID|Illegal Session|session expired or is invalid/i.test(errorMessage)
        ? "Salesforce authentication expired or is invalid. Sign in to Salesforce again in the selected Salesforce tab, then retry Import."
        : /Unknown request type/i.test(errorMessage)
        ? `${errorMessage} The active extension service worker does not support Metadata API requests. Reload the extension from the folder containing this updated background.js file.`
        : errorMessage;
      console.error("[SF Tool] Metadata import failed", { message: errorMessage, requestType: "metadataRequest" });
      setStatus(importStatus, detail);
      if (importLog) importLog.textContent += `Deployment failed: ${detail}\n`;
    } finally {
      importCreateButton.disabled = false;
      if (validationErrors.length === 0) setDeployStep("report");
    }
  }

  function downloadFile(name, content, type) { const url = URL.createObjectURL(content instanceof Blob ? content : new Blob([content], { type })); const link = document.createElement("a"); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }

  // Shared by the Excel export and the Step 3 tabbed preview so both show identical columns per type.
  const exportSheetDefinitions = [
    { type: "field", name: "Fields", columns: (row) => ({ "Object API Name": row.targetObject, "Field Label": row.label, "API Name": row.apiName, "Field Type": row.fieldType, Length: row.length, Precision: row.precision, Scale: row.scale, Required: row.required ? "Yes" : "No", Unique: row.unique ? "Yes" : "No", "External Id": row.externalId ? "Yes" : "No", "Default Value": row.defaultValue, "Picklist Values": Array.isArray(row.picklistValues) ? row.picklistValues.join("; ") : (row.picklistValues || "") }) },
    { type: "recordType", name: "Record Types", columns: (row) => ({ "Object API Name": row.targetObject, Label: row.label, "API Name": row.apiName, Active: row.active ? "Yes" : "No", "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "validationRule", name: "Validation Rules", columns: (row) => ({ "Object API Name": row.targetObject, "API Name": row.apiName, Active: row.active ? "Yes" : "No", Description: row.description || "", "Error Location": row.errorDisplayField || "", "Error Message": row.errorMessage, "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "listView", name: "List Views", columns: (row) => ({ "Object API Name": row.targetObject, Label: row.label, "Developer Name": row.apiName, Namespace: row.namespace || "", "SOQL Compatible": row.soqlCompatible ? "Yes" : "No" }) },
    { type: "compactLayout", name: "Compact Layouts", columns: (row) => ({ "Object API Name": row.targetObject, Label: row.label, "Developer Name": row.apiName, Namespace: row.namespace || "", "Managed State": row.manageableState || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "objectAccess", name: "Object Access", columns: (row) => ({ "Object API Name": row.targetObject, "Access Type": row.accessType, "Profile / Permission Set": row.label, Read: row.read ? "Yes" : "No", Create: row.create ? "Yes" : "No", Edit: row.edit ? "Yes" : "No", Delete: row.delete ? "Yes" : "No", "View All": row.viewAll ? "Yes" : "No", "Modify All": row.modifyAll ? "Yes" : "No" }) },
    { type: "fieldAccess", name: "Field Access", columns: (row) => ({ "Object API Name": row.targetObject, "Field API Name": row.fieldName, "Access Type": row.accessType, "Profile / Permission Set": row.label, Read: row.read ? "Yes" : "No", Edit: row.edit ? "Yes" : "No" }) },
    { type: "objectList", name: "Object List", columns: (row) => ({ Label: row.label, "API Name": row.apiName }) },
    { type: "lwc", name: "LWC", columns: (row) => ({ "Developer Name": row.apiName, Label: row.label, "API Version": row.apiVersion, Namespace: row.namespace || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "flow", name: "Flows", columns: (row) => ({ Label: row.label, "Process Type": row.processType || "", Status: row.status || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "recordTypeOrgWide", name: "All Record Types", columns: (row) => ({ "Object API Name": row.targetObject, Label: row.label, Active: row.active ? "Yes" : "No", Description: row.description || "", "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "layout", name: "Layouts", columns: (row) => ({ "Object API Name": row.targetObject, Name: row.apiName, Type: row.layoutType, Namespace: row.namespace || "", "Managed State": row.manageableState || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "webLink", name: "Buttons Links Actions", columns: (row) => ({ "Object API Name": row.targetObject, Label: row.label, Name: row.apiName, "Link Type": row.linkType || "", "Open Type": row.openType || "", Url: row.url || "", "Display Type": row.displayType || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "fieldSet", name: "Field Sets", columns: (row) => ({ "Object API Name": row.targetObject, "API Name": row.apiName, Label: row.label, Namespace: row.namespace || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "customTab", name: "Custom Tabs", columns: (row) => ({ "API Name": row.apiName, Label: row.label, Type: row.tabType, Namespace: row.namespace || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "customApplication", name: "Applications", columns: (row) => ({ "API Name": row.apiName, Label: row.label, "UI Type": row.uiType || "", "Nav Type": row.navType || "", Namespace: row.namespace || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "globalValueSet", name: "Global Value Sets", columns: (row) => ({ "API Name": row.apiName, Label: row.label, Namespace: row.namespace || "", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "permissionSet", name: "PermissionSets", columns: (row) => ({ Label: row.label, "API Name": row.apiName, Description: row.description || "", "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "profile", name: "Profiles", columns: (row) => ({ Name: row.label, "User License": row.userLicense || "", Description: row.description || "", "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "permissionSetObjectAccess", name: "Object Permissions", columns: (row) => ({ "Permission Set": row.label, "Object API Name": row.targetObject, Read: row.read ? "Yes" : "No", Create: row.create ? "Yes" : "No", Edit: row.edit ? "Yes" : "No", Delete: row.delete ? "Yes" : "No", "View All": row.viewAll ? "Yes" : "No", "Modify All": row.modifyAll ? "Yes" : "No" }) },
    { type: "permissionSetFieldAccess", name: "Field Permissions", columns: (row) => ({ "Permission Set": row.label, "Object API Name": row.targetObject, "Field API Name": row.fieldName, Read: row.read ? "Yes" : "No", Edit: row.edit ? "Yes" : "No" }) },
    { type: "profileObjectAccess", name: "Object Permissions", columns: (row) => ({ Profile: row.label, "Object API Name": row.targetObject, Read: row.read ? "Yes" : "No", Create: row.create ? "Yes" : "No", Edit: row.edit ? "Yes" : "No", Delete: row.delete ? "Yes" : "No", "View All": row.viewAll ? "Yes" : "No", "Modify All": row.modifyAll ? "Yes" : "No" }) },
    { type: "profileFieldAccess", name: "Field Permissions", columns: (row) => ({ Profile: row.label, "Object API Name": row.targetObject, "Field API Name": row.fieldName, Read: row.read ? "Yes" : "No", Edit: row.edit ? "Yes" : "No" }) },
    { type: "queue", name: "Queues", columns: (row) => ({ Label: row.label, "API Name": row.apiName, "Include Bosses": row.doesIncludeBosses ? "Yes" : "No", Description: row.description || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "apexClass", name: "Apex Classes", columns: (row, includeExportDetails = false) => ({ Name: row.label, "API Version": row.apiVersion, Status: row.status, Namespace: row.namespace || "", ...(includeExportDetails ? { Body: row.body || "" } : {}), "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "apexTrigger", name: "Apex Triggers", columns: (row, includeExportDetails = false) => ({ Name: row.label, "Object API Name": row.targetObject, Status: row.status, "API Version": row.apiVersion, Namespace: row.namespace || "", ...(includeExportDetails ? { Body: row.body || "" } : {}), "Created By": row.createdBy || "", "Created Date": row.createdDate || "", "Last Modified By": row.lastModifiedBy || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "customLabel", name: "Custom Labels", columns: (row) => ({ Name: row.label, Category: row.category || "", Language: row.language || "", Protected: row.protected ? "Yes" : "No", Value: row.value || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "reportFolder", name: "Report Folders", columns: (row) => ({ Name: row.label, "Developer Name": row.apiName, "Access Type": row.accessType || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) },
    { type: "report", name: "Reports", columns: (row) => ({ Name: row.label, Folder: row.targetObject || "", Description: row.description || "", Format: row.format || "", "Created Date": row.createdDate || "", "Last Modified Date": row.lastModifiedDate || "" }) }
  ];

  // Excel rejects any cell longer than 32,767 characters (UTF-16 units).
  const EXCEL_CELL_LIMIT = 32767;

  function splitExcelText(text) {
    const parts = [];
    let start = 0;
    while (start < text.length) {
      let end = Math.min(start + EXCEL_CELL_LIMIT, text.length);
      // Don't cut a surrogate pair (e.g. an emoji) in half.
      if (end < text.length && /[\uD800-\uDBFF]/.test(text[end - 1])) end -= 1;
      parts.push(text.slice(start, end));
      start = end;
    }
    return parts;
  }

  // Replaces each column that has an over-limit value with "<Column> (part 1)", "(part 2)", ...
  // columns; joining a row's parts in order gives back the full text.
  function splitOversizedColumns(headers, mappedRows, sheetName, splitReport) {
    const outHeaders = [];
    const outRows = mappedRows.map(() => ({}));
    headers.forEach((header) => {
      const pieces = mappedRows.map((row) => (typeof row[header] === "string" && row[header].length > EXCEL_CELL_LIMIT ? splitExcelText(row[header]) : null));
      const partCount = Math.max(0, ...pieces.map((parts) => (parts ? parts.length : 0)));
      if (!partCount) {
        outHeaders.push(header);
        mappedRows.forEach((row, index) => { outRows[index][header] = row[header]; });
        return;
      }
      const partHeaders = Array.from({ length: partCount }, (_, index) => `${header} (part ${index + 1})`);
      outHeaders.push(...partHeaders);
      mappedRows.forEach((row, index) => {
        const parts = pieces[index] || [row[header] ?? ""];
        partHeaders.forEach((partHeader, partIndex) => { outRows[index][partHeader] = parts[partIndex] ?? ""; });
        if (pieces[index] && splitReport) splitReport.push(`${sheetName}: ${row.Name || row["API Name"] || row.Label || `row ${index + 2}`} (${header}, ${pieces[index].length} parts)`);
      });
    });
    return { headers: outHeaders, rows: outRows };
  }

  function createWorkbook(rows, includedTypes, splitReport) {
    if (typeof XLSX === "undefined") throw new Error("Excel export library is unavailable. Reload the extension.");
    const workbook = XLSX.utils.book_new();
    exportSheetDefinitions.forEach(({ type, name, columns }) => {
      if (includedTypes && !includedTypes.includes(type)) return;
      const sheetRows = rows.filter((row) => row.type === type);
      const split = splitOversizedColumns(Object.keys(columns({}, true)), sheetRows.map((row) => columns(row, true)), name, splitReport);
      const { headers } = split;
      const mappedRows = split.rows;
      const worksheet = mappedRows.length ? XLSX.utils.json_to_sheet(mappedRows, { header: headers }) : XLSX.utils.aoa_to_sheet([headers]);
      worksheet["!cols"] = headers.map((header) => {
        const longestValue = Math.max(header.length, ...mappedRows.map((row) => String(row[header] ?? "").length));
        return { wch: Math.min(Math.max(longestValue, header === "Picklist Values" ? 20 : 10), header === "Picklist Values" ? 60 : 40) };
      });
      const picklistColumnIndex = headers.indexOf("Picklist Values");
      if (picklistColumnIndex >= 0 && worksheet["!ref"]) {
        const range = XLSX.utils.decode_range(worksheet["!ref"]);
        for (let rowIndex = range.s.r; rowIndex <= range.e.r; rowIndex += 1) {
          const cell = worksheet[XLSX.utils.encode_cell({ r: rowIndex, c: picklistColumnIndex })];
          if (cell) cell.s = { ...(cell.s || {}), alignment: { ...(cell.s?.alignment || {}), wrapText: true, vertical: "top" } };
        }
      }
      XLSX.utils.book_append_sheet(workbook, worksheet, name);
    });
    if (workbook.SheetNames.length === 0) throw new Error("No metadata types to export.");
    return XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  }

  const objectScopedExportRowTypes = new Set(["field", "recordType", "validationRule", "layout", "listView", "compactLayout", "fieldSet", "webLink", "objectAccess", "fieldAccess"]);
  const orgWideExportBundles = new Map([
    ["profile", "Profiles"], ["profileObjectAccess", "Profiles"], ["profileFieldAccess", "Profiles"],
    ["permissionSet", "PermissionSets"], ["permissionSetObjectAccess", "PermissionSets"], ["permissionSetFieldAccess", "PermissionSets"]
  ]);

  function safeFilePart(value, fallback) {
    return String(value || fallback).replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_+|_+$/g, "") || fallback;
  }

  function exportTimestamp(date = new Date()) {
    const pad = (value) => String(value).padStart(2, "0");
    return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
  }

  function rowsByType(rows, includedTypes) {
    return exportSheetDefinitions.reduce((result, definition) => {
      if (includedTypes && !includedTypes.includes(definition.type)) return result;
      const typeRows = rows.filter((row) => row.type === definition.type);
      result[definition.name] = typeRows;
      return result;
    }, {});
  }

  const exportSelectionRowTypes = {
    CustomField: ["field"],
    RecordType: ["recordType"],
    ValidationRule: ["validationRule"],
    ListView: ["listView"],
    CompactLayout: ["compactLayout"],
    ObjectAccess: ["objectAccess"],
    FieldAccess: ["fieldAccess"],
    Layout: ["layout"],
    WebLink: ["webLink"],
    FieldSet: ["fieldSet"],
    Objects: ["objectList"],
    LWC: ["lwc"],
    Flow: ["flow"],
    RecordType_OrgWide: ["recordTypeOrgWide"],
    CustomTab: ["customTab"],
    CustomApplication: ["customApplication"],
    GlobalValueSet: ["globalValueSet"],
    PermissionSet: ["permissionSet", "permissionSetObjectAccess", "permissionSetFieldAccess"],
    Profile: ["profile", "profileObjectAccess", "profileFieldAccess"],
    Queue: ["queue"],
    ApexClass: ["apexClass"],
    ApexTrigger: ["apexTrigger"],
    CustomLabel: ["customLabel"],
    ReportFolder: ["reportFolder"],
    Report: ["report"]
  };

  function selectedExportRowTypes(scope) {
    return getSelectedExportTypes()
      .filter((selection) => selection.scope === scope)
      .flatMap((selection) => exportSelectionRowTypes[selection.type] || []);
  }

  function splitExportRows(rows) {
    const objects = new Map();
    const orgWide = new Map();
    rows.forEach((row) => {
      if (!objectScopedExportRowTypes.has(row.type)) {
        const definition = exportSheetDefinitions.find((item) => item.type === row.type);
        const bundleName = orgWideExportBundles.get(row.type) || definition?.name || row.type;
        if (!orgWide.has(bundleName)) orgWide.set(bundleName, []);
        orgWide.get(bundleName).push(row);
        return;
      }
      const objectName = row.targetObject || row.apiName;
      if (!objects.has(objectName)) objects.set(objectName, []);
      objects.get(objectName).push(row);
    });
    return { objects, orgWide };
  }

  function setExportButtonsDisabled(disabled) {
    if (exportExcelButton) exportExcelButton.disabled = disabled;
    if (exportJsonButton) exportJsonButton.disabled = disabled;
  }

  function setExportProgress(message) {
    exportStatus.textContent = "";
    exportStatus.style.color = "inherit";
    const spinner = document.createElement("span");
    spinner.className = "export-loading-spinner status-inline-spinner";
    spinner.setAttribute("aria-hidden", "true");
    exportStatus.append(spinner, document.createTextNode(message));
  }

  function setExportLoading(isLoading) {
    if (exportLoading) exportLoading.hidden = !isLoading;
  }

  function isObjectScopedExportType(type) {
    return objectScopedExportRowTypes.has(type);
  }

  function syncExportResultScope() {
    const hasObjectSelection = selectedExportRowTypes("object").length > 0;
    const hasOrgSelection = selectedExportRowTypes("org").length > 0;
    if (exportResultObjectScope) exportResultObjectScope.disabled = !hasObjectSelection;
    if (exportResultOrgScope) exportResultOrgScope.disabled = !hasOrgSelection;
    if (!hasObjectSelection && hasOrgSelection) activeExportResultScope = "org";
    if (!hasOrgSelection && hasObjectSelection) activeExportResultScope = "object";
    if (exportResultObjectScope) exportResultObjectScope.checked = activeExportResultScope === "object";
    if (exportResultOrgScope) exportResultOrgScope.checked = activeExportResultScope === "org";
  }

  async function hydrateDeferredExportDetails(hostname, rows) {
    const exportRows = rows.map((row) => ({ ...row }));
    const deferredTypes = [
      { rowType: "apexClass", objectType: "ApexClass", label: "Apex class source" },
      { rowType: "apexTrigger", objectType: "ApexTrigger", label: "Apex trigger source" }
    ];
    for (const deferredType of deferredTypes) {
      if (!exportRows.some((row) => row.type === deferredType.rowType)) continue;
      setExportProgress(`Retrieving ${deferredType.label} for the export package...`);
      const records = await toolingQuery(hostname, `SELECT Name, Body FROM ${deferredType.objectType}`);
      const bodyByName = new Map(records.map((record) => [record.Name, record.Body || ""]));
      exportRows.forEach((row) => {
        if (row.type === deferredType.rowType) row.body = bodyByName.get(row.apiName) || "";
      });
    }
    return exportRows;
  }

  async function exportConfigurationPackage(format) {
    if (!getSelectedExportTypes().length) return;
    if (typeof JSZip === "undefined") return setStatus(exportStatus, "ZIP export library is unavailable. Reload the extension.");
    setExportButtonsDisabled(true);
    setExportProgress(`Creating ${format === "xlsx" ? "Excel" : "JSON"} package...`);
    const splitReport = [];
    try {
      const hostname = SFPanel.getHostname();
      const orgInfo = await SFPanel.sendMessage({ type: "getOrgInfo", hostname });
      const username = safeFilePart(orgInfo.username, "salesforce_user");
      const formatLabel = format === "xlsx" ? "Excel" : "JSON";
      const zip = new JSZip();
      const packageRows = await hydrateDeferredExportDetails(hostname, exportedRows);
      setExportProgress(`Building ${formatLabel} package...`);
      const objectTypes = selectedExportRowTypes("object");
      const orgTypes = selectedExportRowTypes("org");
      Array.from(selectedExportObjects).sort().forEach((objectName) => {
        const rows = packageRows.filter((row) => row.targetObject === objectName && objectTypes.includes(row.type));
        const safeObjectName = safeFilePart(objectName, "Object");
        if (format === "xlsx") zip.file(`objects/${safeObjectName}.xlsx`, createWorkbook(rows, objectTypes, splitReport));
        else zip.file(`objects/${safeObjectName}.json`, JSON.stringify(rowsByType(rows, objectTypes), null, 2));
      });
      const orgBundles = new Map();
      orgTypes.forEach((type) => {
        const definition = exportSheetDefinitions.find((item) => item.type === type);
        const bundleName = orgWideExportBundles.get(type) || definition?.name || type;
        if (!orgBundles.has(bundleName)) orgBundles.set(bundleName, []);
        orgBundles.get(bundleName).push(type);
      });
      orgBundles.forEach((bundleTypes, bundleName) => {
        const rows = packageRows.filter((row) => bundleTypes.includes(row.type));
        const safeBundleName = safeFilePart(bundleName, "OrgWide");
        if (format === "xlsx") zip.file(`org-wide/${safeBundleName}.xlsx`, createWorkbook(rows, bundleTypes, splitReport));
        else zip.file(`org-wide/${safeBundleName}.json`, JSON.stringify(rowsByType(rows, bundleTypes), null, 2));
      });
      const content = await zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 6 } });
      downloadFile(`${username}_Configuration_${exportTimestamp()}_${formatLabel}.zip`, content, "application/zip");
      const splitNote = splitReport.length
        ? ` ${splitReport.length} value(s) were longer than Excel's 32,767-character cell limit and were split across numbered columns (e.g. "Body (part 1)", "Body (part 2)"); join the parts in order to get the full text: ${splitReport.slice(0, 10).join("; ")}${splitReport.length > 10 ? `; and ${splitReport.length - 10} more` : ""}.`
        : "";
      setStatus(exportStatus, `${formatLabel} package created.${splitNote}`, false);
    } catch (error) {
      setStatus(exportStatus, error.message || "Export failed.");
    } finally {
      setExportButtonsDisabled(false);
    }
  }

  function renderExportResultTabs() {
    if (!exportResultTabs) return;
    exportResultTabs.textContent = "";
    const presentTypes = exportSheetDefinitions.filter((def) => selectedExportRowTypes(activeExportResultScope).includes(def.type));
    if (!presentTypes.some((def) => def.type === activeExportResultTab)) {
      activeExportResultTab = presentTypes[0]?.type || "";
      activeExportResultObject = "";
      activeExportAccessType = "";
    }
    presentTypes.forEach((def) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "config-import-tab";
      tab.classList.toggle("active", def.type === activeExportResultTab);
      const count = exportedRows.filter((row) => row.type === def.type).length;
      tab.textContent = `${def.name} (${count})`;
      tab.addEventListener("click", () => {
        activeExportResultTab = def.type;
        activeExportResultObject = "";
        activeExportAccessType = "";
        renderExportResultTabs();
        renderExportResultObjectTabs();
        renderExportAccessTabs();
        renderExportResultPreview();
      });
      exportResultTabs.appendChild(tab);
    });
    exportResultTabs.hidden = presentTypes.length <= 1;
  }

  // Groups the active type's rows by object so large multi-object result sets stay navigable.
  function renderExportResultObjectTabs() {
    if (!exportResultObjectTabs || !exportResultObjectSelect) return;
    exportResultObjectSelect.textContent = "";
    const rowsForType = exportedRows.filter((row) => row.type === activeExportResultTab);
    const objectNames = isObjectScopedExportType(activeExportResultTab)
      ? Array.from(selectedExportObjects).sort((a, b) => a.localeCompare(b))
      : Array.from(new Set(rowsForType.map((row) => row.targetObject).filter(Boolean))).sort((a, b) => a.localeCompare(b));
    if (objectNames.length <= 1) {
      activeExportResultObject = "";
      exportResultObjectTabs.hidden = true;
      return;
    }
    if (!objectNames.includes(activeExportResultObject)) activeExportResultObject = objectNames[0];
    objectNames.forEach((objectName) => {
      const option = document.createElement("option");
      option.value = objectName;
      const count = rowsForType.filter((row) => row.targetObject === objectName).length;
      option.textContent = `${objectName} (${count})`;
      option.selected = objectName === activeExportResultObject;
      exportResultObjectSelect.appendChild(option);
    });
    exportResultObjectTabs.hidden = false;
  }

  function renderExportAccessTabs() {
    if (!exportAccessTabs) return;
    exportAccessTabs.textContent = "";
    if (!["objectAccess", "fieldAccess"].includes(activeExportResultTab)) {
      exportAccessTabs.hidden = true;
      return;
    }
    let rows = exportedRows.filter((row) => row.type === activeExportResultTab);
    if (activeExportResultObject) rows = rows.filter((row) => row.targetObject === activeExportResultObject);
    const filters = [
      { type: "Profile", label: "Profiles" },
      { type: "Permission Set", label: "Permission Sets" }
    ].filter((filter) => rows.some((row) => row.accessType === filter.type));
    if (!filters.some((filter) => filter.type === activeExportAccessType)) activeExportAccessType = filters[0]?.type || "";
    filters.forEach((filter) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "config-import-tab";
      tab.classList.toggle("active", filter.type === activeExportAccessType);
      const count = rows.filter((row) => row.accessType === filter.type).length;
      tab.textContent = `${filter.label} (${count})`;
      tab.addEventListener("click", () => {
        activeExportAccessType = filter.type;
        renderExportAccessTabs();
        renderExportResultPreview();
      });
      exportAccessTabs.appendChild(tab);
    });
    exportAccessTabs.hidden = filters.length <= 1;
  }

  function renderExportResultPreview() {
    if (!exportResultContent) return;
    exportResultContent.textContent = "";
    const def = exportSheetDefinitions.find((item) => item.type === activeExportResultTab);
    let rows = exportedRows.filter((row) => row.type === activeExportResultTab);
    if (activeExportResultObject) rows = rows.filter((row) => row.targetObject === activeExportResultObject);
    if (["objectAccess", "fieldAccess"].includes(activeExportResultTab) && activeExportAccessType) rows = rows.filter((row) => row.accessType === activeExportAccessType);
    if (!def) return;
    const table = document.createElement("table");
    table.className = "configuration-table";
    const thead = document.createElement("thead");
    const tbody = document.createElement("tbody");
    const mappedRows = rows.map((row) => def.columns(row, false));
    const headers = Object.keys(mappedRows[0] || def.columns({}, false));
    const header = document.createElement("tr");
    headers.forEach((text) => { const th = document.createElement("th"); th.textContent = text; header.appendChild(th); });
    thead.appendChild(header);
    mappedRows.forEach((mapped) => {
      const tr = document.createElement("tr");
      headers.forEach((key) => { const td = document.createElement("td"); td.textContent = mapped[key] ?? ""; if (key === "Picklist Values") td.className = "configuration-picklist-values"; tr.appendChild(td); });
      tbody.appendChild(tr);
    });
    table.append(thead, tbody);
    exportResultContent.appendChild(table);
  }


  function renderExportCatalog() {
    const groups = [
      { container: exportObjectTypesEl, scope: "object" },
      { container: exportOrgTypesEl, scope: "org" }
    ];
    groups.forEach(({ container, scope }) => {
      if (!container) return;
      container.textContent = "";
      predefinedExportTypes.filter((entry) => entry.scope === scope).forEach((entry) => {
        const row = document.createElement("label");
        row.className = "config-export-type";
        row.dataset.category = entry.category;
        row.hidden = activeExportCategory !== "all" && entry.category !== activeExportCategory;
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = entry.type;
        checkbox.dataset.scope = scope;
        checkbox.checked = entry.type === "CustomField";
        checkbox.disabled = !entry.supported;
        row.title = entry.supported ? "" : "Requires the Salesforce CLI desktop app; not yet supported in the browser.";
        const text = document.createElement("span");
        text.textContent = entry.supported ? entry.label : `${entry.label} (desktop app only)`;
        row.append(checkbox, text);
        container.appendChild(row);
      });
    });
    syncExportSelectAllState();
  }

  function applyExportCategoryFilter(category) {
    activeExportCategory = category;
    document.querySelectorAll(".export-filter-btn").forEach((btn) => btn.classList.toggle("active", btn.dataset.category === category));
    document.querySelectorAll(".config-export-type").forEach((row) => {
      row.hidden = category !== "all" && row.dataset.category !== category;
    });
  }

  function syncExportSelectAllState() {
    const syncGroup = (container, selectAllCheckbox) => {
      if (!container || !selectAllCheckbox) return;
      const supportedItems = Array.from(container.querySelectorAll("input:not(:disabled)"));
      selectAllCheckbox.checked = supportedItems.length > 0 && supportedItems.every((input) => input.checked);
    };
    syncGroup(exportObjectTypesEl, exportSelectAllObjectScope);
    syncGroup(exportOrgTypesEl, exportSelectAllOrgWide);
    if (exportStep1Next) exportStep1Next.disabled = getSelectedExportTypes().length === 0;
  }

  function getSelectedExportTypes() {
    return Array.from(document.querySelectorAll("#configExportObjectTypes input:checked, #configExportOrgTypes input:checked")).map((input) => ({ type: input.value, scope: input.dataset.scope }));
  }

  function hasObjectScopedSelection() {
    return getSelectedExportTypes().some((entry) => entry.scope === "object");
  }

  function goToExportStep(step) {
    currentExportStep = step;
    document.querySelectorAll(".export-step").forEach((el) => el.classList.toggle("active", Number(el.dataset.step) === step));
    exportStep1.hidden = step !== 1;
    exportStep2.hidden = step !== 2;
    exportStep3.hidden = step !== 3;
    if (step === 3) loadExportRows();
  }

  async function loadExportObjectsIfNeeded(hostnameOverride) {
    if (exportObjectsLoaded) return;
    const hostname = hostnameOverride || SFPanel.getHostname();
    if (!hostname) throw new Error("No Salesforce tab detected.");
    const result = await SFPanel.sendMessage({ type: "getObjects", feature: "export_configuration", hostname });
    availableExportObjects = (result.objects || []).filter((object) => object.queryable).sort((a, b) => a.label.localeCompare(b.label));
    exportObjectsLoaded = true;
  }

  function renderExportObjectList() {
    if (!exportObjectList) return;
    exportObjectList.textContent = "";
    const term = (exportObjectSearch?.value || "").trim().toLowerCase();
    const showStandard = Boolean(exportShowStandardObjects?.checked);
    const visible = availableExportObjects
      .filter((object) => object.custom || showStandard)
      .filter((object) => !term || object.label.toLowerCase().includes(term) || object.name.toLowerCase().includes(term));
    visible.forEach((object) => {
      const label = document.createElement("label");
      label.className = "checkbox-row";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.dataset.object = object.name;
      cb.checked = selectedExportObjects.has(object.name);
      cb.addEventListener("change", () => {
        if (cb.checked) selectedExportObjects.add(object.name); else selectedExportObjects.delete(object.name);
        syncExportSelectAllObjectsState();
      });
      const text = document.createElement("span");
      text.className = "checkbox-row-label";
      text.textContent = `${object.label} (${object.name})`;
      label.append(cb, text);
      exportObjectList.appendChild(label);
    });
    syncExportSelectAllObjectsState();
  }

  function syncExportSelectAllObjectsState() {
    const inputs = Array.from(exportObjectList?.querySelectorAll("input") || []);
    if (exportSelectAllObjects) exportSelectAllObjects.checked = inputs.length > 0 && inputs.every((input) => input.checked);
    if (exportStep2Next) exportStep2Next.disabled = selectedExportObjects.size === 0;
  }

  async function goToExportStep2() {
    const selectedTypes = getSelectedExportTypes();
    if (!selectedTypes.length) return setStatus(exportStatus, "Select at least one metadata type.");
    if (!hasObjectScopedSelection()) { goToExportStep(3); return; }
    try {
      setStatus(exportStatus, "Loading custom objects...", false);
      await loadExportObjectsIfNeeded();
      renderExportObjectList();
      setStatus(exportStatus, "", false);
      goToExportStep(2);
    } catch (error) { setStatus(exportStatus, error.message); }
  }

  function soqlLiteralList(values) { return values.map((value) => `'${String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`).join(", "); }

  async function queryAllPages(hostname, path) {
    const records = [];
    let nextPath = path;
    while (nextPath) {
      const result = await SFPanel.sendMessage({ type: "restRequest", feature: "export_configuration", hostname, method: "GET", path: nextPath });
      const data = result.data || {};
      records.push(...(data.records || []));
      nextPath = data.done ? null : data.nextRecordsUrl || null;
    }
    return records;
  }

  async function toolingQuery(hostname, soql) {
    return queryAllPages(hostname, `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(soql)}`);
  }

  async function restQuery(hostname, soql) {
    return queryAllPages(hostname, `/services/data/${SFPanel.API_VERSION}/query/?q=${encodeURIComponent(soql)}`);
  }

  const entityDefinitionIdCache = new Map();
  async function getEntityDefinitionId(hostname, objectApiName) {
    const cacheKey = `${hostname}:${objectApiName}`;
    if (entityDefinitionIdCache.has(cacheKey)) return entityDefinitionIdCache.get(cacheKey);
    const records = await toolingQuery(hostname, `SELECT DurableId FROM EntityDefinition WHERE QualifiedApiName = '${objectApiName}'`);
    const durableId = records[0]?.DurableId || null;
    entityDefinitionIdCache.set(cacheKey, durableId);
    return durableId;
  }

  async function loadExportRows(hostnameOverride, selectedTypesOverride, objectNamesOverride, throwOnError = false) {
    const hostname = hostnameOverride || SFPanel.getHostname();
    if (!hostname) return setStatus(exportStatus, "No Salesforce tab detected.");
    const selectedTypes = selectedTypesOverride || getSelectedExportTypes().map((entry) => entry.type);
    if (!selectedTypes.length) return setStatus(exportStatus, "Select at least one metadata type.");
    const objectNames = objectNamesOverride || Array.from(selectedExportObjects);
    const includesObjectScopedType = selectedTypes.some((type) => predefinedExportTypes.some((entry) => entry.type === type && entry.scope === "object"));
    if (includesObjectScopedType && !objectNames.length) return setStatus(exportStatus, "Select at least one object in step 2.");
    setExportButtonsDisabled(true);
    setExportLoading(true);
    try {
      exportedRows = [];
      const objectScopedTypes = ["CustomField", "RecordType", "ValidationRule", "ListView", "CompactLayout", "ObjectAccess", "FieldAccess", "Layout", "WebLink", "FieldSet"];
      if (objectScopedTypes.some((type) => selectedTypes.includes(type))) {
        for (const objectName of objectNames) {
          if (selectedTypes.includes("CustomField")) {
            const result = await SFPanel.sendMessage({ type: "restRequest", feature: "export_configuration", hostname, method: "GET", path: `/services/data/${SFPanel.API_VERSION}/sobjects/${objectName}/describe/` });
            (result.data?.fields || []).forEach((field) => exportedRows.push({
              type: "field",
              apiName: field.name,
              label: field.label,
              targetObject: objectName,
              fieldType: field.type,
              length: field.length ?? "",
              precision: field.precision ?? "",
              scale: field.scale ?? "",
              required: field.nillable === false,
              unique: !!field.unique,
              externalId: !!field.externalId,
              defaultValue: field.defaultValue ?? "",
              picklistValues: Array.isArray(field.picklistValues) ? field.picklistValues.map((pv) => pv.value).filter(Boolean) : []
            }));
          }
          if (selectedTypes.includes("RecordType")) {
            const records = await restQuery(hostname, `SELECT DeveloperName, Name, IsActive, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM RecordType WHERE SobjectType = '${objectName}'`);
            records.forEach((record) => exportedRows.push({ type: "recordType", apiName: record.DeveloperName, label: record.Name, targetObject: objectName, active: record.IsActive, createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
          }
          if (selectedTypes.includes("ValidationRule")) {
            const records = await toolingQuery(hostname, `SELECT ValidationName, Active, Description, ErrorDisplayField, ErrorMessage, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM ValidationRule WHERE EntityDefinition.QualifiedApiName = '${objectName}'`);
            records.forEach((record) => exportedRows.push({ type: "validationRule", apiName: record.ValidationName, targetObject: objectName, active: record.Active, description: record.Description, errorDisplayField: record.ErrorDisplayField, errorMessage: record.ErrorMessage, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
          }
          if (selectedTypes.includes("ListView")) {
            const records = await restQuery(hostname, `SELECT DeveloperName, Name, NamespacePrefix, IsSoqlCompatible FROM ListView WHERE SobjectType = '${objectName}'`);
            records.forEach((record) => exportedRows.push({ type: "listView", apiName: record.DeveloperName, label: record.Name, targetObject: objectName, namespace: record.NamespacePrefix, soqlCompatible: record.IsSoqlCompatible }));
          }
          if (selectedTypes.includes("CompactLayout")) {
            const records = await toolingQuery(hostname, `SELECT DeveloperName, MasterLabel, NamespacePrefix, ManageableState, CreatedDate, LastModifiedDate FROM CompactLayout WHERE SobjectType = '${objectName}'`);
            records.forEach((record) => exportedRows.push({ type: "compactLayout", apiName: record.DeveloperName, label: record.MasterLabel || record.DeveloperName, targetObject: objectName, namespace: record.NamespacePrefix, manageableState: record.ManageableState, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
          }
          if (selectedTypes.includes("ObjectAccess")) {
            const records = await restQuery(hostname, `SELECT Parent.Name, Parent.Label, Parent.IsOwnedByProfile, Parent.Profile.Name, PermissionsRead, PermissionsCreate, PermissionsEdit, PermissionsDelete, PermissionsViewAllRecords, PermissionsModifyAllRecords FROM ObjectPermissions WHERE SobjectType = '${objectName}'`);
            records.forEach((record) => exportedRows.push({
              type: "objectAccess",
              apiName: objectName,
              accessType: record.Parent?.IsOwnedByProfile ? "Profile" : "Permission Set",
              label: record.Parent?.IsOwnedByProfile ? record.Parent?.Profile?.Name || record.Parent?.Label || "" : record.Parent?.Label || record.Parent?.Name || "",
              targetObject: objectName,
              read: record.PermissionsRead,
              create: record.PermissionsCreate,
              edit: record.PermissionsEdit,
              delete: record.PermissionsDelete,
              viewAll: record.PermissionsViewAllRecords,
              modifyAll: record.PermissionsModifyAllRecords
            }));
          }
          if (selectedTypes.includes("FieldAccess")) {
            const records = await restQuery(hostname, `SELECT Field, PermissionsRead, PermissionsEdit, Parent.Name, Parent.Label, Parent.IsOwnedByProfile, Parent.Profile.Name FROM FieldPermissions WHERE SobjectType = '${objectName}'`);
            records.forEach((record) => exportedRows.push({
              type: "fieldAccess",
              apiName: record.Field,
              fieldName: record.Field,
              accessType: record.Parent?.IsOwnedByProfile ? "Profile" : "Permission Set",
              label: record.Parent?.IsOwnedByProfile ? record.Parent?.Profile?.Name || record.Parent?.Label || "" : record.Parent?.Label || record.Parent?.Name || "",
              targetObject: objectName,
              read: record.PermissionsRead,
              edit: record.PermissionsEdit
            }));
          }
          if (selectedTypes.includes("Layout")) {
            const entityDefinitionId = await getEntityDefinitionId(hostname, objectName);
            if (entityDefinitionId) {
              const records = await toolingQuery(hostname, `SELECT Name, LayoutType, NamespacePrefix, ManageableState, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM Layout WHERE EntityDefinitionId = '${entityDefinitionId}'`);
              records.forEach((record) => exportedRows.push({ type: "layout", apiName: record.Name, label: record.Name, targetObject: objectName, layoutType: record.LayoutType, namespace: record.NamespacePrefix, manageableState: record.ManageableState, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
            }
          }
          if (selectedTypes.includes("WebLink")) {
            const records = await toolingQuery(hostname, `SELECT Name, MasterLabel, Description, LinkType, OpenType, Url, DisplayType, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM WebLink WHERE EntityDefinition.QualifiedApiName = '${objectName}'`);
            records.forEach((record) => exportedRows.push({ type: "webLink", apiName: record.Name, label: record.MasterLabel || record.Name, targetObject: objectName, description: record.Description, linkType: record.LinkType, openType: record.OpenType, url: record.Url, displayType: record.DisplayType, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
          }
          if (selectedTypes.includes("FieldSet")) {
            const entityDefinitionId = await getEntityDefinitionId(hostname, objectName);
            if (entityDefinitionId) {
              const records = await toolingQuery(hostname, `SELECT DeveloperName, MasterLabel, Description, NamespacePrefix, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM FieldSet WHERE EntityDefinitionId = '${entityDefinitionId}'`);
              records.forEach((record) => exportedRows.push({ type: "fieldSet", apiName: record.DeveloperName, label: record.MasterLabel || record.DeveloperName, targetObject: objectName, description: record.Description, namespace: record.NamespacePrefix, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
            }
          }
        }
      }
      if (selectedTypes.includes("Objects")) {
        const result = await SFPanel.sendMessage({ type: "getObjects", feature: "export_configuration", hostname });
        (result.objects || []).filter((object) => object.queryable).forEach((object) => exportedRows.push({ type: "objectList", apiName: object.name, label: object.label }));
      }
      if (selectedTypes.includes("LWC")) {
        const records = await toolingQuery(hostname, "SELECT DeveloperName, MasterLabel, ApiVersion, Description, NamespacePrefix, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM LightningComponentBundle");
        records.forEach((record) => exportedRows.push({ type: "lwc", apiName: record.DeveloperName, label: record.MasterLabel || record.DeveloperName, apiVersion: record.ApiVersion, description: record.Description, namespace: record.NamespacePrefix, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("Flow")) {
        const records = await toolingQuery(hostname, "SELECT MasterLabel, ProcessType, Status, Description, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM Flow");
        records.forEach((record) => exportedRows.push({ type: "flow", apiName: record.MasterLabel, label: record.MasterLabel, description: record.Description, processType: record.ProcessType, status: record.Status, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("RecordType_OrgWide")) {
        const records = await restQuery(hostname, "SELECT SobjectType, Name, IsActive, Description, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM RecordType");
        records.forEach((record) => exportedRows.push({ type: "recordTypeOrgWide", apiName: record.Name, label: record.Name, targetObject: record.SobjectType, active: record.IsActive, description: record.Description, createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("CustomTab")) {
        const records = await toolingQuery(hostname, "SELECT DeveloperName, MasterLabel, Type, Description, NamespacePrefix, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM CustomTab");
        records.forEach((record) => exportedRows.push({ type: "customTab", apiName: record.DeveloperName, label: record.MasterLabel || record.DeveloperName, tabType: record.Type, description: record.Description, namespace: record.NamespacePrefix, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("CustomApplication")) {
        const records = await toolingQuery(hostname, "SELECT DeveloperName, Label, Description, NamespacePrefix, UiType, NavType, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM CustomApplication");
        records.forEach((record) => exportedRows.push({ type: "customApplication", apiName: record.DeveloperName, label: record.Label || record.DeveloperName, description: record.Description, namespace: record.NamespacePrefix, uiType: record.UiType, navType: record.NavType, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("GlobalValueSet")) {
        const records = await toolingQuery(hostname, "SELECT DeveloperName, MasterLabel, Description, NamespacePrefix, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM GlobalValueSet");
        records.forEach((record) => exportedRows.push({ type: "globalValueSet", apiName: record.DeveloperName, label: record.MasterLabel || record.DeveloperName, description: record.Description, namespace: record.NamespacePrefix, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("PermissionSet")) {
        const records = await restQuery(hostname, "SELECT Name, Label, Description, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM PermissionSet WHERE IsOwnedByProfile = false");
        records.forEach((record) => exportedRows.push({ type: "permissionSet", apiName: record.Name, label: record.Label, description: record.Description, createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("Profile")) {
        const records = await restQuery(hostname, "SELECT Name, Description, UserLicense.Name, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM Profile");
        records.forEach((record) => exportedRows.push({ type: "profile", apiName: record.Name, label: record.Name, description: record.Description, userLicense: record.UserLicense?.Name || "", createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("PermissionSet") || selectedTypes.includes("Profile")) {
        const [objectPermissions, fieldPermissions] = await Promise.all([
          restQuery(hostname, "SELECT Parent.Name, Parent.Label, Parent.IsOwnedByProfile, Parent.Profile.Name, SobjectType, PermissionsRead, PermissionsCreate, PermissionsEdit, PermissionsDelete, PermissionsViewAllRecords, PermissionsModifyAllRecords FROM ObjectPermissions"),
          restQuery(hostname, "SELECT Parent.Name, Parent.Label, Parent.IsOwnedByProfile, Parent.Profile.Name, Field, SobjectType, PermissionsRead, PermissionsEdit FROM FieldPermissions")
        ]);
        const addPermissionRows = (records, isFieldPermission) => records.forEach((record) => {
          const isProfile = record.Parent?.IsOwnedByProfile;
          const label = isProfile ? record.Parent?.Profile?.Name || record.Parent?.Label || "" : record.Parent?.Label || record.Parent?.Name || "";
          if (!label) return;
          const base = {
            label,
            targetObject: record.SobjectType || String(record.Field || "").split(".")[0],
            read: record.PermissionsRead,
            edit: record.PermissionsEdit
          };
          if (isFieldPermission) base.fieldName = record.Field || "";
          else Object.assign(base, {
            create: record.PermissionsCreate,
            delete: record.PermissionsDelete,
            viewAll: record.PermissionsViewAllRecords,
            modifyAll: record.PermissionsModifyAllRecords
          });
          if (isProfile && selectedTypes.includes("Profile")) exportedRows.push({ type: isFieldPermission ? "profileFieldAccess" : "profileObjectAccess", ...base });
          if (!isProfile && selectedTypes.includes("PermissionSet")) exportedRows.push({ type: isFieldPermission ? "permissionSetFieldAccess" : "permissionSetObjectAccess", ...base });
        });
        addPermissionRows(objectPermissions, false);
        addPermissionRows(fieldPermissions, true);
      }
      if (selectedTypes.includes("Queue")) {
        const records = await restQuery(hostname, "SELECT DeveloperName, Name, Description, DoesIncludeBosses, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM Group WHERE Type = 'Queue'");
        records.forEach((record) => exportedRows.push({ type: "queue", apiName: record.DeveloperName, label: record.Name, description: record.Description, doesIncludeBosses: record.DoesIncludeBosses, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("ApexClass")) {
        const records = await toolingQuery(hostname, "SELECT Name, ApiVersion, Status, NamespacePrefix, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM ApexClass");
        records.forEach((record) => exportedRows.push({ type: "apexClass", apiName: record.Name, label: record.Name, apiVersion: record.ApiVersion, status: record.Status, namespace: record.NamespacePrefix, createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("ApexTrigger")) {
        const records = await toolingQuery(hostname, "SELECT Name, TableEnumOrId, Status, ApiVersion, NamespacePrefix, CreatedBy.Name, CreatedDate, LastModifiedBy.Name, LastModifiedDate FROM ApexTrigger");
        records.forEach((record) => exportedRows.push({ type: "apexTrigger", apiName: record.Name, label: record.Name, targetObject: record.TableEnumOrId, status: record.Status, apiVersion: record.ApiVersion, namespace: record.NamespacePrefix, createdBy: record.CreatedBy?.Name || "", createdDate: record.CreatedDate || "", lastModifiedBy: record.LastModifiedBy?.Name || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("CustomLabel")) {
        const records = await toolingQuery(hostname, "SELECT Name, MasterLabel, Value, IsProtected, Category, Language, NamespacePrefix, ManageableState, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM CustomLabel");
        records.forEach((record) => exportedRows.push({ type: "customLabel", apiName: record.Name, label: record.MasterLabel || record.Name, category: record.Category, value: record.Value, language: record.Language, protected: record.IsProtected, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("ReportFolder")) {
        const records = await restQuery(hostname, "SELECT DeveloperName, Name, AccessType, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM Folder WHERE Type = 'Report'");
        records.forEach((record) => exportedRows.push({ type: "reportFolder", apiName: record.DeveloperName, label: record.Name, accessType: record.AccessType, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      if (selectedTypes.includes("Report")) {
        const records = await restQuery(hostname, "SELECT DeveloperName, Name, FolderName, Description, Format, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById FROM Report");
        records.forEach((record) => exportedRows.push({ type: "report", apiName: record.DeveloperName, label: record.Name, targetObject: record.FolderName, description: record.Description, format: record.Format, createdDate: record.CreatedDate || "", lastModifiedDate: record.LastModifiedDate || "" }));
      }
      setExportButtonsDisabled(exportedRows.length === 0);
      activeExportResultScope = selectedExportRowTypes("object").length ? "object" : "org";
      syncExportResultScope();
      activeExportResultTab = exportSheetDefinitions.find((def) => selectedExportRowTypes(activeExportResultScope).includes(def.type))?.type || "";
      activeExportResultObject = "";
      activeExportAccessType = "";
      renderExportResultTabs();
      renderExportResultObjectTabs();
      renderExportAccessTabs();
      renderExportResultPreview();
      setStatus(exportStatus, "", false);
    } catch (error) {
      setStatus(exportStatus, error.message);
      if (throwOnError) throw error;
    } finally { setExportLoading(false); setExportButtonsDisabled(getSelectedExportTypes().length === 0); }
    return exportedRows;
  }

  async function getSalesforceTabHosts(httpsOnly = false) {
    const tabs = await chrome.tabs.query({});
    return [...new Set(tabs.map((tab) => { try { const url = new URL(tab.url || ""); const host = url.hostname; return (!httpsOnly || url.protocol === "https:") && SALESFORCE_HOST_PATTERN.test(host) && !/^(login|test)\.salesforce\.com$/i.test(host) ? normalizeOrgHostname(host) : null; } catch { return null; } }).filter(Boolean))].sort();
  }

  async function loadCompareOrgChoices(resetSource = false, preferredTarget = "", discoveryOnly = false) {
    if (!compareSourceOrg || !compareTargetOrg) return;
    const generation = ++compareOrgChoiceGeneration;
    if (resetSource) {
      compareObjectSelection.hidden = true;
      compareMemberCache.clear();
      compareMemberLoad = null;
      selectedCompareMembers.clear();
      selectedCompareTypes.clear();
      availableCompareTypes = [];
      activeCompareScopeType = "";
    }
    const activeHostname = SFPanel.getHostname() || "";
    const source = normalizeOrgHostname(resetSource ? activeHostname : sourceOrgHost || activeHostname);
    sourceOrgHost = source;
    if (targetOrgHost === sourceOrgHost) targetOrgHost = "";
    compareSourceOrg.value = source;
    compareSourceOrg.title = source;
    let sourceError = "";
    if (source) {
      try {
        const info = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: source });
        if (generation !== compareOrgChoiceGeneration) return;
        sourceOrgId = info.orgId || "";
        compareSourceOrg.value = info.username || source;
      } catch (error) {
        if (generation !== compareOrgChoiceGeneration) return;
        sourceOrgId = "";
        sourceError = `Unable to verify source org ${source}: ${error.message}`;
      }
    } else {
      sourceOrgId = "";
      compareSourceOrg.value = "";
    }
    if (!source || sourceError) {
      targetOrgHost = ""; compareTargetOrg.value = ""; compareTargetOrg.title = "";
      updateCompareTargetSetup();
      setCompareStatus(sourceError || "Open a signed-in Salesforce tab to use it as the source.");
      return;
    }
    const hosts = (await getSalesforceTabHosts(true)).filter((host) => host !== source);
    if (generation !== compareOrgChoiceGeneration) return;
    let targetHost = preferredTarget || targetOrgHost;
    if (targetLoginTabId) {
      try {
        const targetTab = await chrome.tabs.get(targetLoginTabId);
        if (generation !== compareOrgChoiceGeneration) return;
        const targetUrl = new URL(targetTab.url || "");
        const targetUrlHost = normalizeOrgHostname(targetUrl.hostname);
        if (targetUrl.protocol === "https:" && hosts.includes(targetUrlHost)) targetHost = targetUrlHost;
      } catch {
        if (generation !== compareOrgChoiceGeneration) return;
        targetLoginTabId = null;
      }
    }
    const candidates = [...new Set([targetHost, ...hosts].filter(host => hosts.includes(host)))];
    const failures = [];
    let connectedTarget = "", targetInfo = null;
    for (const host of candidates) {
      try {
        const info = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: host });
        if (generation !== compareOrgChoiceGeneration) return;
        if (sourceOrgId && info.orgId && sourceOrgId === info.orgId) continue;
        connectedTarget = host; targetInfo = info; break;
      } catch (error) {
        if (generation !== compareOrgChoiceGeneration) return;
        failures.push(`${host}: ${error.message}`);
      }
    }
    const changedTarget = targetOrgHost !== connectedTarget;
    targetOrgHost = connectedTarget;
    compareTargetOrg.value = targetInfo ? targetInfo.username || connectedTarget : "";
    compareTargetOrg.title = connectedTarget;
    if (changedTarget || resetSource) {
      compareMemberCache.clear(); compareMemberLoad = null;
      selectedCompareMembers.clear(); selectedCompareTypes.clear();
      availableCompareTypes = []; activeCompareScopeType = "";
    }
    // Publish the connection before metadata retrieval, which can fail independently.
    updateCompareTargetSetup();
    if (!connectedTarget) {
      setCompareStatus(failures.length
        ? `No accessible target org could be verified. ${failures.join("; ")}`
        : "Source is the current org. Open and log in to a different Salesforce org as the target.");
      return;
    }
    if (targetLoginTabId && connectedTarget === targetHost) targetLoginTabId = null;
    if (!discoveryOnly && compareMode === "metadata" && !availableCompareTypes.length) await loadCompareTypeCatalog();
    if (generation !== compareOrgChoiceGeneration) return;
    updateCompareTargetSetup();
    setCompareStatus("", false);
  }

  async function openTargetLogin() {
    const environment = compareTargetEnvironment?.value === "sandbox" ? "sandbox" : "production";
    const loginUrl = environment === "sandbox" ? "https://test.salesforce.com/" : "https://login.salesforce.com/";
    try {
      // Keep the source fixed before activating the target login tab.
      if (!sourceOrgHost) sourceOrgHost = normalizeOrgHostname(SFPanel.getHostname() || "");
      const loginTab = await chrome.tabs.create({
        url: loginUrl,
        active: true
      });
      if (!loginTab?.id) throw new Error("The browser did not provide the new login tab.");
      targetLoginTabId = loginTab.id;
      setCompareStatus(`Log in to the target ${environment} org in the new tab. The target label will update automatically after login.`, false);
    } catch (error) {
      targetLoginTabId = null;
      setCompareStatus(`Unable to open the target login tab: ${error.message || String(error)}`);
    }
  }

  async function updateTargetAfterLogin(tabId, changeInfo, tab) {
    if (deployLoginTabId && tabId === deployLoginTabId && changeInfo.status === "complete") {
      if (deployBusy) return;
      const generation = ++deployLoginGeneration;
      deployTargetHostname = "";
      deployTargetOrg.textContent = "Waiting for target login";
      deployTargetOrg.removeAttribute("title");
      updateDeployStepActions();
      try {
        const url = new URL(tab.url || "");
        const rawHost = url.hostname;
        if (url.protocol !== "https:" || !SALESFORCE_HOST_PATTERN.test(rawHost) || /^(login|test)\.salesforce\.com$/i.test(rawHost)) return;
        const host = normalizeOrgHostname(rawHost);
        if (host === deploySourceHostname) {
          setStatus(deployTargetStatus, "Select a target org different from the source org.");
          return;
        }
        const info = await SFPanel.sendMessage({ type: "getOrgInfo", hostname: host });
        if (tabId !== deployLoginTabId || generation !== deployLoginGeneration) return;
        if (typeof info.isSandbox !== "boolean" || info.isSandbox !== (deployTargetEnvironment.value === "sandbox")) {
          setStatus(deployTargetStatus, "The logged-in org does not match the selected target org type.");
          return;
        }
        selectDeployTarget(host, info);
        deployLoginTabId = null;
      } catch {
        if (generation === deployLoginGeneration) setStatus(deployTargetStatus, "Target login is not ready. Complete Salesforce login to continue.");
      }
      return;
    }
    if (changeInfo.status !== "complete") return;
    if (tabId !== targetLoginTabId && !["compareOrgs", "compareObjects"].includes(SFPanel.getActiveTab())) return;
    try {
      const url = new URL(tab.url || "");
      const rawHost = url.hostname;
      if (url.protocol !== "https:") return;
      if (!SALESFORCE_HOST_PATTERN.test(rawHost) || /^(login|test)\.salesforce\.com$/i.test(rawHost)) return;
      const host = normalizeOrgHostname(rawHost);
      if (host === sourceOrgHost) return;
      await loadCompareOrgChoices(false, host);
    } catch (error) {
      setCompareStatus(`Unable to refresh comparison orgs: ${error.message}`);
      console.debug("[SF Tool] Target login is not ready yet", { message: error.message || String(error) });
    }
  }

  function getCompareType(type) {
    return availableCompareTypes.find((entry) => entry.type === type);
  }

  function escapeMetadataXml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function metadataTypeLabel(xmlName) {
    return String(xmlName || "").replace(/([a-z0-9])([A-Z])/g, "$1 $2");
  }

  function metadataMemberLabel(apiName) {
    return String(apiName || "")
      .replace(/__c$/i, "")
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/_+/g, " ")
      .trim();
  }

  async function getOrgComparableTypes(hostname, feature = "compare_metadata") {
    const types = new Map();
    const apiVersion = String(SFPanel.API_VERSION || "v65.0").replace(/^v/i, "");
    const body = `<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:met="http://soap.sforce.com/2006/04/metadata"><env:Header/><env:Body><met:describeMetadata><met:asOfVersion>${escapeMetadataXml(apiVersion)}</met:asOfVersion></met:describeMetadata></env:Body></env:Envelope>`;
    const result = await SFPanel.sendMessage({ type: "metadataRequest", feature, hostname, action: "describeMetadata", body });
    const document = new DOMParser().parseFromString(result.data || "", "text/xml");
    if (document.querySelector("parsererror")) throw new Error("Salesforce returned an invalid Metadata API response.");
    Array.from(document.getElementsByTagName("*")).forEach((element) => {
      if (element.localName !== "metadataObjects") return;
      const xmlName = Array.from(element.children).find((child) => child.localName === "xmlName")?.textContent?.trim();
      if (xmlName) types.set(xmlName, { name: xmlName, label: metadataTypeLabel(xmlName) });
    });
    return types;
  }

  async function loadCompareTypeCatalog() {
    if (!sourceOrgHost || !targetOrgHost) return;
    compareObjectSelection.hidden = true;
    setCompareStatus("Loading metadata types from both orgs...", false);
    const [sourceTypes, targetTypes] = await Promise.all([getOrgComparableTypes(sourceOrgHost), getOrgComparableTypes(targetOrgHost)]);
    const loaderTypes = {
      CustomField: "CustomField", RecordType: "RecordType", ValidationRule: "ValidationRule", Layout: "Layout", ListView: "ListView", CompactLayout: "CompactLayout", FieldSet: "FieldSet", WebLink: "WebLink",
      PermissionSet: "PermissionSet", Profile: "Profile", ApexClass: "ApexClass", ApexTrigger: "ApexTrigger", CustomLabel: "CustomLabel", LightningComponentBundle: "LWC", Flow: "Flow", CustomTab: "CustomTab", CustomApplication: "CustomApplication", GlobalValueSet: "GlobalValueSet", Report: "Report"
    };
    const loaderDefinitions = new Map(predefinedExportTypes.map((entry) => [entry.type, entry]));
    const liveTypes = new Map([...sourceTypes, ...targetTypes]);
    availableCompareTypes = Array.from(liveTypes.values())
      .map((entry) => {
        const loaderType = loaderTypes[entry.name];
        const loaderDefinition = loaderDefinitions.get(loaderType);
        return {
          type: entry.name,
          label: entry.label,
          scope: loaderDefinition?.scope || "org",
          loaderType,
          supported: true
        };
      });
    selectedCompareTypes.forEach((type) => {
      if (!availableCompareTypes.some((entry) => entry.type === type)) selectedCompareTypes.delete(type);
    });
    compareObjectSelection.hidden = false;
    renderCompareScopeTypes();
    renderCompareSelectedItems();
    setCompareStatus("", false);
  }

  function getCompareMemberKey(row) {
    return `${row.targetObject || ""}|${row.apiName}`;
  }

  function getCompareSelectedMembers(type) {
    if (!selectedCompareMembers.has(type)) selectedCompareMembers.set(type, new Map());
    return selectedCompareMembers.get(type);
  }

  function renderCompareScopeTypes() {
    if (!compareScopeTypeList) return;
    compareScopeTypeList.textContent = "";
    const commonOnly = Boolean(compareCommonTypesToggle?.checked);
    const types = availableCompareTypes
      .filter((entry) => !commonOnly || commonCompareTypes.has(entry.type.toLowerCase()))
      .sort((left, right) => left.label.localeCompare(right.label));
    if (compareTypesTitle) compareTypesTitle.textContent = `Types (${types.length})`;
    if (!selectedCompareTypes.has(activeCompareScopeType)) activeCompareScopeType = "";
    types.forEach((type) => {
      const item = document.createElement("li");
      item.className = "pkg-list-item";
      item.classList.toggle("active", type.type === activeCompareScopeType);
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = selectedCompareTypes.has(type.type);
      checkbox.disabled = !type.supported;
      if (!type.supported) item.title = "Comparison is not available for this Salesforce type yet.";
      checkbox.addEventListener("click", (event) => event.stopPropagation());
      checkbox.addEventListener("change", async () => {
        if (checkbox.checked) {
          selectedCompareTypes.add(type.type);
          activeCompareScopeType = type.type;
          await loadCompareMembers(type.type);
        } else {
          selectedCompareTypes.delete(type.type);
          selectedCompareMembers.delete(type.type);
          if (activeCompareScopeType === type.type) activeCompareScopeType = "";
        }
        renderCompareScopeTypes();
        renderCompareMemberList();
        renderCompareSelectedItems();
      });
      const label = document.createElement("span");
      label.className = "pkg-item-label";
      label.textContent = type.label;
      const count = document.createElement("span");
      count.className = "pkg-item-badge";
      count.textContent = selectedCompareTypes.has(type.type) ? `${getCompareSelectedMembers(type.type).size}` : "";
      item.append(checkbox, label, count);
      item.addEventListener("click", async () => {
        if (!type.supported) return;
        if (!selectedCompareTypes.has(type.type)) selectedCompareTypes.add(type.type);
        activeCompareScopeType = type.type;
        renderCompareScopeTypes();
        await loadCompareMembers(type.type);
      });
      compareScopeTypeList.appendChild(item);
    });
    if (compareSelectAllTypes) {
      const selectableTypes = types.filter((type) => type.supported);
      const selectedVisible = selectableTypes.filter((type) => selectedCompareTypes.has(type.type)).length;
      compareSelectAllTypes.checked = selectableTypes.length > 0 && selectedVisible === selectableTypes.length;
      compareSelectAllTypes.indeterminate = selectedVisible > 0 && selectedVisible < types.length;
    }
  }

  async function loadCompareMembers(type) {
    const entry = getCompareType(type);
    if (!entry || !entry.supported) return;
    const source = sourceOrgHost;
    const target = targetOrgHost;
    const request = { type, loading: !compareMemberCache.has(type), error: "" };
    compareMemberLoad = request;
    if (compareMembersTitle) compareMembersTitle.textContent = entry.label;
    renderCompareMemberList();
    try {
      if (!source || !target) throw new Error("Log in to a target org before selecting comparison members.");
      if (!compareMemberCache.has(type)) {
        const [sourceMembers, targetMembers] = await Promise.all([listMetadataMembers(source, type), listMetadataMembers(target, type)]);
        if (compareMemberLoad !== request || sourceOrgHost !== source || targetOrgHost !== target || activeCompareScopeType !== type) return;
        const members = new Map();
        [...sourceMembers, ...targetMembers].forEach((member) => members.set(member.key, member));
        compareMemberCache.set(type, Array.from(members.values()).sort((left, right) => left.label.localeCompare(right.label)));
      }
    } catch (error) {
      if (compareMemberLoad === request && sourceOrgHost === source && targetOrgHost === target) request.error = error.message || "Could not load comparison members.";
    } finally {
      if (compareMemberLoad === request) {
        request.loading = false;
        renderCompareMemberList();
      }
    }
  }

  function renderCompareMemberList() {
    if (!compareMemberList || !compareMembersEmpty) return;
    const type = activeCompareScopeType;
    const members = compareMemberCache.get(type) || [];
    const term = (compareMemberSearch?.value || "").trim().toLowerCase();
    const visible = members.filter((member) => !term || member.label.toLowerCase().includes(term) || member.key.toLowerCase().includes(term));
    compareMemberList.textContent = "";
    compareMembersEmpty.hidden = Boolean(type);
    compareMemberList.hidden = !type;
    const load = compareMemberLoad?.type === type ? compareMemberLoad : null;
    compareMemberList.setAttribute("aria-busy", String(Boolean(load?.loading)));
    if (type && (load?.loading || load?.error)) {
      if (compareMembersCount) compareMembersCount.textContent = load.loading ? "Loading..." : "0 available";
      if (compareSelectAllMembers) {
        compareSelectAllMembers.disabled = true;
        compareSelectAllMembers.checked = false;
        compareSelectAllMembers.indeterminate = false;
      }
      const row = document.createElement("li");
      row.className = "compare-member-status";
      row.setAttribute("role", load.loading ? "status" : "alert");
      if (load.loading) {
        const spinner = document.createElement("span");
        spinner.className = "export-loading-spinner";
        spinner.setAttribute("aria-hidden", "true");
        row.appendChild(spinner);
      }
      const message = document.createElement("span");
      message.textContent = load.loading ? "Loading members..." : load.error;
      row.appendChild(message);
      compareMemberList.appendChild(row);
      return;
    }
    if (compareMembersCount) compareMembersCount.textContent = type ? `${members.length} available` : "Select a type";
    const selected = getCompareSelectedMembers(type);
    visible.forEach((member) => {
      const item = document.createElement("li");
      item.className = "pkg-list-item";
      item.classList.toggle("active", selected.has(member.key));
      item.tabIndex = 0;
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = selected.has(member.key);
      checkbox.addEventListener("click", (event) => event.stopPropagation());
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) selected.set(member.key, member); else selected.delete(member.key);
        renderCompareMemberList();
        renderCompareScopeTypes();
        renderCompareSelectedItems();
      });
      const label = document.createElement("span");
      label.className = "pkg-item-label compare-member-label";
      const labelText = document.createElement("span");
      labelText.className = "compare-member-label-text";
      labelText.textContent = member.label;
      const apiName = document.createElement("span");
      apiName.className = "compare-member-api-name";
      apiName.textContent = member.apiName || member.key;
      label.append(labelText, apiName);
      item.append(checkbox, label);
      const toggleSelection = () => {
        if (selected.has(member.key)) selected.delete(member.key); else selected.set(member.key, member);
        renderCompareMemberList();
        renderCompareScopeTypes();
        renderCompareSelectedItems();
      };
      item.addEventListener("click", toggleSelection);
      item.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          toggleSelection();
        }
      });
      compareMemberList.appendChild(item);
    });
    if (compareSelectAllMembers) {
      compareSelectAllMembers.disabled = !type;
      const selectedVisible = visible.filter((member) => selected.has(member.key)).length;
      compareSelectAllMembers.checked = visible.length > 0 && selectedVisible === visible.length;
      compareSelectAllMembers.indeterminate = selectedVisible > 0 && selectedVisible < visible.length;
    }
  }

  function renderCompareSelectedItems() {
    if (!compareSelectedList) return;
    compareSelectedList.textContent = "";
    let total = 0;
    Array.from(selectedCompareTypes).sort((left, right) => getCompareType(left).label.localeCompare(getCompareType(right).label)).forEach((type) => {
      const entry = getCompareType(type);
      const members = Array.from(getCompareSelectedMembers(type).values());
      total += members.length;
      if (!members.length) return;
      const group = document.createElement("details");
      group.open = true;
      const heading = document.createElement("summary");
      heading.textContent = `${entry.label} (${members.length})`;
      const list = document.createElement("ul");
      members.sort((left, right) => left.label.localeCompare(right.label)).forEach((member) => {
        const item = document.createElement("li");
        item.className = "pkg-list-item";
        const label = document.createElement("span");
        label.className = "pkg-item-label";
        label.textContent = member.label;
        item.appendChild(label);
        list.appendChild(item);
      });
      group.append(heading, list);
      compareSelectedList.appendChild(group);
    });
    if (!total) compareSelectedList.textContent = "Select members from a metadata type.";
    if (compareSelectedCount) compareSelectedCount.textContent = `${total} selected`;
    if (compareOrgsLoad) compareOrgsLoad.disabled = total === 0;
  }

  async function compareOrganizations() {
    const sourceOrg = sourceOrgHost || SFPanel.getHostname();
    const targetOrg = targetOrgHost;
    if (!sourceOrg || !targetOrg || sourceOrg === targetOrg) return setCompareStatus("Open the source Salesforce org and log in to a different target org.");
    if (comparisonInProgress) return;
    comparisonInProgress = true;
    const selectedTypes = Array.from(selectedCompareTypes).filter((type) => getCompareSelectedMembers(type).size > 0);
    if (!selectedTypes.length) return setCompareStatus("Select at least one metadata type.");
    lastComparisonResults = null;
    activeCompareResultFilter = "All";
    activeCompareResultPath = "";
    activeCompareDetailView = "source";
    compareResults.textContent = "";
    if (compareResultsFilters) compareResultsFilters.textContent = "";
    renderComparisonDetails(null);
    if (typeof JSZip === "undefined") return setCompareStatus("ZIP support is unavailable. Reload the extension.");
    if (compareOrgsLoad) compareOrgsLoad.disabled = true;
    lastComparisonContext = {
      sourceHost: sourceOrg,
      targetHost: targetOrg,
      sourceLabel: compareSourceOrg?.value || sourceOrg,
      targetLabel: compareTargetOrg?.value || targetOrg
    };
    showCompareResultsPage();
    try {
      const packageTypes = selectedTypes.map((type) => ({
        type,
        members: Array.from(getCompareSelectedMembers(type).keys())
      }));
      setCompareStatus("Retrieving selected metadata XML from the source org...", false);
      const sourceFiles = await retrieveMetadataXml(sourceOrg, packageTypes);
      setCompareStatus("Retrieving selected metadata XML from the target org...", false);
      const targetFiles = await retrieveMetadataXml(targetOrg, packageTypes);
      setCompareStatus("Comparing retrieved XML files...", false);
      const results = compareMetadataXml(sourceFiles, targetFiles);
      setCompareStatus("Formatting comparison results...", false);
      lastComparisonResults = results;
      activeCompareResultFilter = "All";
      activeCompareResultPath = "";
      renderComparisonResults(results);
      setCompareStatus("", false);
    } catch (error) { setCompareStatus(error.message || "Could not compare Salesforce orgs."); } finally {
      comparisonInProgress = false;
      compareStatus?.classList.remove("compare-status-busy");
    }
  }

  function soapText(document, name) {
    return Array.from(document.getElementsByTagName("*")).find((element) => element.localName === name)?.textContent?.trim() || "";
  }

  async function metadataSoapRequest(hostname, action, payload, feature = "deploy_metadata") {
    const body = `<?xml version="1.0" encoding="UTF-8"?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:met="http://soap.sforce.com/2006/04/metadata"><env:Header/><env:Body><met:${action}>${payload}</met:${action}></env:Body></env:Envelope>`;
    const result = await SFPanel.sendMessage({ type: "metadataRequest", feature, hostname, action, body });
    const document = new DOMParser().parseFromString(result.data || "", "text/xml");
    const fault = soapText(document, "faultstring");
    if (fault) throw new Error(`Salesforce Metadata API error: ${fault}`);
    if (document.querySelector("parsererror")) throw new Error("Salesforce returned an invalid Metadata API response.");
    return document;
  }

  async function listMetadataMembers(hostname, type, folder = "", feature = "compare_metadata") {
    const document = await metadataSoapRequest(hostname, "listMetadata", `<met:queries><met:type>${escapeMetadataXml(type)}</met:type>${folder ? `<met:folder>${escapeMetadataXml(folder)}</met:folder>` : ""}</met:queries><met:asOfVersion>${escapeMetadataXml(String(SFPanel.API_VERSION).replace(/^v/i, ""))}</met:asOfVersion>`, feature);
    return Array.from(document.getElementsByTagName("*")).filter((element) => element.localName === "result").map((element) => {
      const fullName = Array.from(element.children).find((child) => child.localName === "fullName")?.textContent?.trim();
      return fullName ? { key: fullName, label: metadataMemberLabel(fullName), apiName: fullName } : null;
    }).filter(Boolean);
  }

  async function retrieveMetadataXml(hostname, packageTypes) {
    const version = escapeMetadataXml(String(SFPanel.API_VERSION).replace(/^v/i, ""));
    const typeXml = packageTypes.map(({ type, members }) => `<met:types>${members.map((member) => `<met:members>${escapeMetadataXml(member)}</met:members>`).join("")}<met:name>${escapeMetadataXml(type)}</met:name></met:types>`).join("");
    const request = `<met:request><met:apiVersion>${version}</met:apiVersion><met:singlePackage>true</met:singlePackage><met:unpackaged>${typeXml}<met:version>${version}</met:version></met:unpackaged></met:request>`;
    const started = await metadataSoapRequest(hostname, "retrieve", request, "compare_metadata");
    const id = soapText(started, "id");
    if (!id) throw new Error("Salesforce did not return a metadata retrieve ID.");
    for (let attempt = 0; attempt < 120; attempt += 1) {
      const status = await metadataSoapRequest(hostname, "checkRetrieveStatus", `<met:asyncProcessId>${escapeMetadataXml(id)}</met:asyncProcessId><met:includeZip>true</met:includeZip>`, "compare_metadata");
      if (soapText(status, "done") === "true") {
        const zipFile = soapText(status, "zipFile");
        if (!zipFile) throw new Error(soapText(status, "errorMessage") || "Salesforce completed retrieval without an archive.");
        const zip = await JSZip.loadAsync(zipFile, { base64: true });
        const files = new Map();
        await Promise.all(Object.values(zip.files).filter((file) => !file.dir && file.name !== "package.xml").map(async (file) => {
          const content = await file.async("string");
          if (/^\s*(?:<\?xml\b|<[^>]+>)/i.test(content) || /\.(?:cls|trigger)$/i.test(file.name)) {
            files.set(file.name.replace(/^unpackaged\//, ""), content);
          }
        }));
        return files;
      }
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    throw new Error("Salesforce metadata retrieval timed out.");
  }

  function normalizeXmlForComparison(xml) {
    const document = new DOMParser().parseFromString(xml, "application/xml");
    if (document.querySelector("parsererror")) return xml;
    const walker = document.createTreeWalker(document, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) node.nodeValue = node.nodeValue.replace(/\s+/g, " ").trim();
    return new XMLSerializer().serializeToString(document);
  }

  function compareMetadataXml(sourceFiles, targetFiles) {
    const paths = new Set([...sourceFiles.keys(), ...targetFiles.keys()]);
    const apexItems = new Map();
    const results = [];
    Array.from(paths).sort().forEach((path) => {
      const source = sourceFiles.get(path);
      const target = targetFiles.get(path);
      const type = metadataTypeForPath(path);
      const apexMatch = path.match(/^(classes|triggers)\/(.+)\.(cls|trigger)(-meta\.xml)?$/i);
      if (apexMatch) {
        const itemName = apexMatch[2];
        const key = `${type}:${itemName}`;
        const item = apexItems.get(key) || {
          id: key,
          name: itemName,
          type,
          apexItem: true,
          sourceCode: undefined,
          targetCode: undefined,
          sourceXml: undefined,
          targetXml: undefined
        };
        if (apexMatch[4]) {
          item.sourceXml = source;
          item.targetXml = target;
        } else {
          item.sourceCode = source;
          item.targetCode = target;
        }
        apexItems.set(key, item);
        return;
      }
      if (source === undefined) {
        results.push({ id: path, status: "Target Only", type, name: metadataItemName(path), path, sourceXml: "", targetXml: target });
      } else if (target === undefined) {
        results.push({ id: path, status: "Source Only", type, name: metadataItemName(path), path, sourceXml: source, targetXml: "" });
      } else {
        results.push({
          id: path,
        status: normalizeXmlForComparison(source) === normalizeXmlForComparison(target) ? "Identical" : "Different",
        type,
          name: metadataItemName(path),
          path,
        sourceXml: source,
        targetXml: target
        });
      }
    });
    apexItems.forEach((item) => {
      const sourcePresent = item.sourceCode !== undefined || item.sourceXml !== undefined;
      const targetPresent = item.targetCode !== undefined || item.targetXml !== undefined;
      item.status = !sourcePresent ? "Target Only" : !targetPresent ? "Source Only" :
        item.sourceCode === item.targetCode && normalizeXmlForComparison(item.sourceXml || "") === normalizeXmlForComparison(item.targetXml || "") ? "Identical" : "Different";
      results.push(item);
    });
    return results.sort((left, right) => left.type.localeCompare(right.type) || left.name.localeCompare(right.name));
  }

  function metadataItemName(path) {
    const fileName = String(path || "").split("/").pop() || "";
    return fileName.replace(/-meta\.xml$/i, "").replace(/\.[^.]+$/i, "");
  }

  function metadataTypeForPath(path) {
    const folder = String(path || "").split("/")[0].toLowerCase();
    const types = {
      classes: "ApexClass", components: "AuraDefinitionBundle", dashboards: "Dashboard", documents: "Document",
      email: "EmailTemplate", flows: "Flow", labels: "CustomLabel", layouts: "Layout", lwc: "LightningComponentBundle",
      objects: "CustomObject", pages: "ApexPage", permissionsets: "PermissionSet", profiles: "Profile",
      reports: "Report", resources: "StaticResource", tabs: "CustomTab", triggers: "ApexTrigger"
    };
    return types[folder] || folder || "Metadata";
  }

  function formatXmlForDiff(xml) {
    const rawXml = String(xml || "").trim();
    if (!rawXml) return [];
    const lines = rawXml.replace(/>\s*</g, ">\n<").split(/\r?\n/);
    let depth = 0;
    return lines.map((line) => {
      const trimmed = line.trim();
      const closesElement = /^<\//.test(trimmed);
      if (closesElement) depth = Math.max(0, depth - 1);
      const formatted = `${"  ".repeat(depth)}${trimmed}`;
      const opensElement = /^<[^/!?][^>]*[^/]>/i.test(trimmed) && !/<\/[^>]+>/.test(trimmed);
      if (opensElement && !closesElement) depth += 1;
      return formatted;
    });
  }

  function formatMetadataForDiff(path, content) {
    if (/\.(?:cls|trigger)$/i.test(path)) return String(content || "").split(/\r?\n/);
    return formatXmlForDiff(content);
  }

  function metadataLanguageForPath(path) {
    return /\.(?:cls|trigger)$/i.test(path) ? "apex" : "xml";
  }

  function alignXmlDiffLines(sourceLines, targetLines) {
    const sourceCount = sourceLines.length;
    const targetCount = targetLines.length;
    const lcs = Array.from({ length: sourceCount + 1 }, () => new Int32Array(targetCount + 1));
    for (let sourceIndex = sourceCount - 1; sourceIndex >= 0; sourceIndex -= 1) {
      for (let targetIndex = targetCount - 1; targetIndex >= 0; targetIndex -= 1) {
        lcs[sourceIndex][targetIndex] = sourceLines[sourceIndex] === targetLines[targetIndex]
          ? lcs[sourceIndex + 1][targetIndex + 1] + 1
          : Math.max(lcs[sourceIndex + 1][targetIndex], lcs[sourceIndex][targetIndex + 1]);
      }
    }
    const alignedLines = [];
    let sourceIndex = 0;
    let targetIndex = 0;
    while (sourceIndex < sourceCount || targetIndex < targetCount) {
      if (sourceIndex < sourceCount && targetIndex < targetCount && sourceLines[sourceIndex] === targetLines[targetIndex]) {
        alignedLines.push({ source: sourceLines[sourceIndex], target: targetLines[targetIndex], sourceLineNumber: sourceIndex + 1, targetLineNumber: targetIndex + 1 });
        sourceIndex += 1;
        targetIndex += 1;
      } else if (sourceIndex < sourceCount && (targetIndex === targetCount || lcs[sourceIndex + 1][targetIndex] >= lcs[sourceIndex][targetIndex + 1])) {
        alignedLines.push({ source: sourceLines[sourceIndex], target: "", sourceLineNumber: sourceIndex + 1, removed: true });
        sourceIndex += 1;
      } else {
        alignedLines.push({ source: "", target: targetLines[targetIndex], targetLineNumber: targetIndex + 1, inserted: true });
        targetIndex += 1;
      }
    }
    return alignedLines;
  }

  function renderStaticXmlDiff(parent, sourceLines, targetLines) {
    const alignedLines = alignXmlDiffLines(sourceLines, targetLines);
    const split = document.createElement("div");
    split.className = "compare-xml-split";
    const codeViews = [];
    [
      { title: "Source Org", content: "source", change: "removed" },
      { title: "Target Org", content: "target", change: "inserted" }
    ].forEach((side) => {
      const pane = document.createElement("div");
      pane.className = "compare-xml-pane";
      const title = document.createElement("div");
      title.className = "compare-xml-pane-title";
      title.textContent = side.title;
      const code = document.createElement("pre");
      const overview = document.createElement("div");
      overview.className = "compare-xml-overview";
      alignedLines.forEach((line, index) => {
        const row = document.createElement("span");
        row.className = "compare-xml-line";
        row.classList.toggle(side.change, Boolean(line[side.change]));
        const lineNumber = document.createElement("span");
        lineNumber.className = "compare-xml-line-number";
        lineNumber.textContent = line[`${side.content}LineNumber`] || "";
        const text = document.createElement("span");
        text.className = "compare-xml-line-content";
        text.textContent = line[side.content] || " ";
        row.append(lineNumber, text);
        code.appendChild(row);
        if (line[side.change]) {
          const marker = document.createElement("span");
          marker.className = `compare-xml-overview-marker ${side.change}`;
          marker.style.top = `${((index + 0.5) / alignedLines.length) * 100}%`;
          overview.appendChild(marker);
        }
      });
      pane.append(title, code, overview);
      split.appendChild(pane);
      codeViews.push(code);
    });
    let syncingScroll = false;
    codeViews.forEach((code, index) => {
      code.addEventListener("scroll", () => {
        if (syncingScroll) return;
        syncingScroll = true;
        codeViews.forEach((otherCode, otherIndex) => {
          if (otherIndex !== index) {
            otherCode.scrollTop = code.scrollTop;
            otherCode.scrollLeft = code.scrollLeft;
          }
        });
        syncingScroll = false;
      });
    });
    parent.appendChild(split);
  }

  function renderComparisonDetails(row, rows = []) {
    if (!compareResultDetails) return;
    activeCompareMergeViews.forEach((view) => view.destroy());
    activeCompareMergeViews = [];
    compareResultDetails.textContent = "";
    if (!row) {
      compareResultDetails.textContent = "Select a comparison result to inspect its metadata.";
      return;
    }
    const detailRows = row.apexItem
      ? [
        { view: "source", label: "Apex Source", language: "apex", source: row.sourceCode, target: row.targetCode },
        { view: "metadata", label: "Metadata XML", language: "xml", source: row.sourceXml, target: row.targetXml }
      ]
      : [{ view: "metadata", label: "Metadata XML", language: "xml", source: row.sourceXml, target: row.targetXml }];
    const selectedDetailRow = detailRows.find((detailRow) => detailRow.view === activeCompareDetailView) || detailRows[0];
    const heading = document.createElement("div");
    heading.className = "compare-detail-heading";
    heading.textContent = `${row.type} - ${row.name}`;
    const tabs = document.createElement("div");
    tabs.className = "compare-detail-tabs";
    detailRows.forEach((detailRow) => {
      const tab = document.createElement("button");
      tab.type = "button";
      tab.className = "config-import-tab";
      tab.classList.toggle("active", detailRow.view === activeCompareDetailView);
      tab.textContent = detailRow.label;
      tab.addEventListener("click", () => {
        activeCompareDetailView = detailRow.view;
        renderComparisonDetails(row, rows);
      });
      tabs.appendChild(tab);
    });
    const sourceLines = selectedDetailRow.language === "apex" ? String(selectedDetailRow.source || "").split(/\r?\n/) : formatXmlForDiff(selectedDetailRow.source || "");
    const targetLines = selectedDetailRow.language === "apex" ? String(selectedDetailRow.target || "").split(/\r?\n/) : formatXmlForDiff(selectedDetailRow.target || "");
    const mergeHost = document.createElement("div");
    mergeHost.className = "compare-xml-merge";
    compareResultDetails.append(heading);
    if (detailRows.length > 1) compareResultDetails.appendChild(tabs);
    if (!row.apexItem && selectedDetailRow.language === "xml") {
      renderStaticXmlDiff(compareResultDetails, sourceLines, targetLines);
      return;
    }
    compareResultDetails.appendChild(mergeHost);
    activeCompareMergeViews.push(window.SFMonaco.renderMetadataDiff(
      mergeHost,
      sourceLines.length ? sourceLines.join("\n") : `${selectedDetailRow.label} is not present in the source org.`,
      targetLines.length ? targetLines.join("\n") : `${selectedDetailRow.label} is not present in the target org.`,
      selectedDetailRow.language
    ));
  }

  function renderComparisonResults(rows) {
    compareResults.textContent = "";
    const filters = ["All", "Identical", "Different", "Source Only", "Target Only"];
    if (compareResultsFilters) {
      compareResultsFilters.textContent = "";
      filters.forEach((filter) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "config-import-tab";
        button.classList.toggle("active", filter === activeCompareResultFilter);
        const count = filter === "All" ? rows.length : rows.filter((row) => row.status === filter).length;
        button.textContent = `${filter === "Identical" ? "Same" : filter} (${count})`;
        button.addEventListener("click", () => {
          activeCompareResultFilter = filter;
          renderComparisonResults(rows);
        });
        compareResultsFilters.appendChild(button);
      });
    }
    if (!rows.length) {
      compareResults.textContent = "No metadata files were retrieved.";
      return;
    }
    const visibleRows = activeCompareResultFilter === "All" ? rows : rows.filter((row) => row.status === activeCompareResultFilter);
    if (!visibleRows.length) {
      compareResults.textContent = `No ${activeCompareResultFilter === "Identical" ? "same" : activeCompareResultFilter.toLowerCase()} files.`;
      renderComparisonDetails(null);
      return;
    }
    const table = document.createElement("table");
    table.className = "configuration-table";
    const head = document.createElement("tr");
    ["Type", "Name", "Status"].forEach((label) => {
      const th = document.createElement("th");
      th.textContent = label;
      head.appendChild(th);
    });
    const thead = document.createElement("thead");
    thead.appendChild(head);
    table.appendChild(thead);
    const body = document.createElement("tbody");
    visibleRows.forEach((entry) => {
      const tr = document.createElement("tr");
      tr.classList.toggle("active", entry.id === activeCompareResultPath);
      tr.tabIndex = 0;
      tr.addEventListener("click", () => {
        activeCompareResultPath = entry.id;
        activeCompareDetailView = entry.apexItem ? "source" : "metadata";
        renderComparisonResults(rows);
      });
      tr.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          activeCompareResultPath = entry.id;
          activeCompareDetailView = entry.apexItem ? "source" : "metadata";
          renderComparisonResults(rows);
        }
      });
      [entry.type, `${metadataMemberLabel(entry.name)} (${entry.name})`, entry.status === "Identical" ? "Same" : entry.status].forEach((value) => {
        const td = document.createElement("td");
        td.textContent = String(value ?? "");
        tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    table.appendChild(body);
    compareResults.appendChild(table);
    renderComparisonDetails(rows.find((row) => row.id === activeCompareResultPath) || null, rows);
  }

  if (importChooseButton) importChooseButton.addEventListener("click", () => {
    if (!importFileInput) return;
    importFileInput.value = "";
    importFileInput.click();
  });
  if (importDownloadTemplateButton) importDownloadTemplateButton.addEventListener("click", async () => {
    const response = await fetch(chrome.runtime.getURL("templates/ConfigurationWorkbook_template.xlsx"));
    if (!response.ok) throw new Error("Could not load the configuration template.");
    const url = URL.createObjectURL(await response.blob());
    const download = document.createElement("a");
    download.href = url;
    download.download = "ConfigurationWorkbook_template.xlsx";
    download.click();
    URL.revokeObjectURL(url);
  });
  if (importFileInput) importFileInput.addEventListener("change", handleImport);
  if (importRefreshButton) importRefreshButton.addEventListener("click", refreshImportFile);
  if (importValidateButton) importValidateButton.addEventListener("click", validateImport);
  if (importCreateButton) importCreateButton.addEventListener("click", createImportedMetadata);
  if (deploySelectTargetOrgButton) deploySelectTargetOrgButton.addEventListener("click", openDeployTargetLogin);
  deployOperationControls.forEach((control) => control.addEventListener("change", () => {
    if (deployBusy) return;
    const operation = getDeployOperation();
    if (getDeployOperation() === "delete") {
      deployOptionalBackupChoice = deployCreateBackup.checked;
      deployCreateBackup.checked = true;
      deploySelectMetadata.checked = true;
      deployUsePackageXml.checked = false;
    } else deployCreateBackup.checked = deployOptionalBackupChoice;
    resetDeployScope();
    deployDestructiveFile.value = "";
    if (operation === "deploy" && deployTargetHostname === deploySourceHostname) {
      deployTargetHostname = "";
      deployTargetIsSandbox = undefined;
      deployTargetOrg.textContent = "Select a target org to continue";
      deployTargetOrg.removeAttribute("title");
      deployOpenTargetOrg.value = "";
    }
    deployTargetInitialized = false;
    loadDeployTargetChoices(!deployTargetHostname);
    if (currentDeployStep === "scope") initializeDeployScope();
    updateDeployStepActions();
  }));
  deployDestructiveFile?.addEventListener("change", loadDeployDestructiveFile);
  deployHistorySearch?.addEventListener("input", renderDeployHistory);
  deployHistoryZipFile?.addEventListener("change", acceptDeployReplayZip);
  deployHistoryZipFile?.addEventListener("click", () => { deployHistoryZipFile.value = ""; });
  document.getElementById("deployDownloadPackage")?.addEventListener("click", () => {
    if (deployRun?.package?.encoded) downloadFile("deployment-package.zip", new Blob([deployZipBytes(deployRun.package.encoded)], { type: "application/zip" }), "application/zip");
  });
  document.getElementById("deployDownloadBackup")?.addEventListener("click", () => {
    if (deployRun?.backup?.encoded) downloadFile("target-metadata-backup.zip", new Blob([deployZipBytes(deployRun.backup.encoded)], { type: "application/zip" }), "application/zip");
  });
  [deploySelectMetadata, deployUsePackageXml].filter(Boolean).forEach((radio) => radio.addEventListener("change", () => {
    if (deployBusy) return;
    resetDeployScope();
    updateDeployStepActions();
    if (currentDeployStep === "scope") initializeDeployScope();
  }));
  deployCreateBackup?.addEventListener("change", () => {
    if (getDeployOperation() === "deploy") deployOptionalBackupChoice = deployCreateBackup.checked;
    updateDeployStepActions();
  });
  document.getElementById("deployPackageChoose")?.addEventListener("click", () => { deployPackageFile.value = ""; deployPackageFile.click(); });
  deployPackageFile?.addEventListener("change", loadDeployPackageFile);
  deployTypeSearch?.addEventListener("input", renderDeployScope);
  deployMemberSearch?.addEventListener("input", renderDeployScopeMembers);
  deploySelectAllMembers?.addEventListener("change", () => {
    deployRun = null;
    deployReplay = null;
    const members = getDeploySelectedMembers(deployActiveType);
    getDeployVisibleMembers().filter((member) => getDeployOperation() === "delete" || member.inSource !== false).forEach((member) => { if (deploySelectAllMembers.checked) members.add(member.apiName); else members.delete(member.apiName); });
    renderDeployScope();
  });
  if (deployChangeTargetOrgButton) deployChangeTargetOrgButton.addEventListener("click", changeDeployTarget);
  if (deployOpenTargetOrg) deployOpenTargetOrg.addEventListener("change", selectOpenDeployTarget);
  if (deployTargetEnvironment) deployTargetEnvironment.addEventListener("change", () => {
    deployLoginGeneration++;
    deployTargetHostname = "";
    deployTargetIsSandbox = undefined;
    resetDeployScope();
    deployLoginTabId = null;
    deployOpenTargetOrg.value = "";
    deployTargetOrg.textContent = "Select a target org to continue";
    deployTargetOrg.removeAttribute("title");
    deploySelectTargetOrgButton.disabled = !["production", "sandbox"].includes(deployTargetEnvironment.value);
    setStatus(deployTargetStatus, "", false);
    updateDeployStepActions();
  });
  if (deployStepBackButton) deployStepBackButton.addEventListener("click", () => {
    if (deployStepBackButton.disabled) return;
    const stepIndex = deployStepOrder.indexOf(currentDeployStep);
    if (stepIndex > 0 && !deployBusy) setDeployStep(deployStepOrder[stepIndex - 1]);
  });
  if (deployStepNextButton) deployStepNextButton.addEventListener("click", () => {
    if (deployStepNextButton.disabled) return;
    if (currentDeployStep === "target") setDeployStep("scope");
    else if (currentDeployStep === "scope") setDeployStep("execute");
    else if (currentDeployStep === "execute") setDeployStep("results");
  });
  deployRunButton?.addEventListener("click", () => executeDeployRequest());
  deployQuickButton?.addEventListener("click", () => executeDeployRequest(canQuickDeploy(), true));
  [...deployTestLevels, deployTestNames, ...Object.values(deployOptionControls)].filter(Boolean).forEach((control) => control.addEventListener("change", updateDeployStepActions));
  document.getElementById("deployVerifyButton")?.addEventListener("click", verifyDeployMetadata);
  document.getElementById("deploySkipVerify")?.addEventListener("click", () => {
    if (deployBusy || !hasSuccessfulDeployment()) return;
    deployRun.verification = { status: "Skipped", files: [] };
    renderDeployReport();
  });
  document.getElementById("deployRefreshReport")?.addEventListener("click", refreshDeployReport);
  document.getElementById("deployResultsDownload")?.addEventListener("click", downloadDeployReport);
  document.getElementById("deployDownloadManifest")?.addEventListener("click", () => {
    try { const spec = getDeployRequestSpec(); downloadFile("package.xml", `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata">\n${deployManifestBody(spec, "", true)}\n</Package>\n`, "application/xml"); }
    catch (error) { setStatus(deployExecuteStatus, error.message); }
  });
  if (exportExcelButton) exportExcelButton.addEventListener("click", () => exportConfigurationPackage("xlsx"));
  if (exportJsonButton) exportJsonButton.addEventListener("click", () => exportConfigurationPackage("json"));
  [exportResultObjectScope, exportResultOrgScope].filter(Boolean).forEach((radio) => radio.addEventListener("change", () => {
    if (!radio.checked) return;
    activeExportResultScope = radio.value;
    activeExportResultTab = "";
    activeExportResultObject = "";
    activeExportAccessType = "";
    renderExportResultTabs();
    renderExportResultObjectTabs();
    renderExportAccessTabs();
    renderExportResultPreview();
  }));
  if (exportResultObjectSelect) exportResultObjectSelect.addEventListener("change", () => {
    activeExportResultObject = exportResultObjectSelect.value;
    renderExportAccessTabs();
    renderExportResultPreview();
  });
  renderExportCatalog();
  goToExportStep(1);
  document.querySelectorAll(".export-filter-btn").forEach((btn) => btn.addEventListener("click", () => applyExportCategoryFilter(btn.dataset.category)));
  if (exportObjectTypesEl) exportObjectTypesEl.addEventListener("change", syncExportSelectAllState);
  if (exportOrgTypesEl) exportOrgTypesEl.addEventListener("change", syncExportSelectAllState);
  if (exportSelectAllObjectScope) exportSelectAllObjectScope.addEventListener("change", () => { Array.from(exportObjectTypesEl.querySelectorAll("input:not(:disabled)")).forEach((input) => { input.checked = exportSelectAllObjectScope.checked; }); syncExportSelectAllState(); });
  if (exportSelectAllOrgWide) exportSelectAllOrgWide.addEventListener("change", () => { Array.from(exportOrgTypesEl.querySelectorAll("input:not(:disabled)")).forEach((input) => { input.checked = exportSelectAllOrgWide.checked; }); syncExportSelectAllState(); });
  if (exportStep1Next) exportStep1Next.addEventListener("click", goToExportStep2);
  if (exportStep2Back) exportStep2Back.addEventListener("click", () => goToExportStep(1));
  if (exportStep2Next) exportStep2Next.addEventListener("click", () => { if (!selectedExportObjects.size) return setStatus(exportStatus, "Select at least one object."); setStatus(exportStatus, "", false); goToExportStep(3); });
  if (exportStep3Back) exportStep3Back.addEventListener("click", () => goToExportStep(hasObjectScopedSelection() ? 2 : 1));
  if (exportObjectSearch) exportObjectSearch.addEventListener("input", renderExportObjectList);
  if (exportShowStandardObjects) exportShowStandardObjects.addEventListener("change", renderExportObjectList);
  if (exportSelectAllObjects) exportSelectAllObjects.addEventListener("change", () => {
    const inputs = Array.from(exportObjectList?.querySelectorAll("input") || []);
    inputs.forEach((input) => { input.checked = exportSelectAllObjects.checked; if (exportSelectAllObjects.checked) selectedExportObjects.add(input.dataset.object); else selectedExportObjects.delete(input.dataset.object); });
    syncExportSelectAllObjectsState();
  });
  if (compareTargetLogin) compareTargetLogin.addEventListener("click", openTargetLogin);
  document.addEventListener("compareobjectconfiguration", event => {
    SFPanel.showTab("compareObjects");
    if (SFPanel.getActiveTab() !== "compareObjects") return;
    setCompareMode("objects", event.detail?.objectName);
  });
  if (compareCommonTypesToggle) compareCommonTypesToggle.addEventListener("change", renderCompareScopeTypes);
  if (compareSelectAllTypes) compareSelectAllTypes.addEventListener("change", async () => {
    const types = availableCompareTypes.filter((entry) => entry.supported && (!compareCommonTypesToggle?.checked || commonCompareTypes.has(entry.type.toLowerCase())));
    if (compareSelectAllTypes.checked) {
      types.forEach((entry) => selectedCompareTypes.add(entry.type));
      if (!activeCompareScopeType && types.length) {
        activeCompareScopeType = types[0].type;
        await loadCompareMembers(activeCompareScopeType);
      }
    } else {
      types.forEach((entry) => {
        selectedCompareTypes.delete(entry.type);
        selectedCompareMembers.delete(entry.type);
      });
      if (!selectedCompareTypes.has(activeCompareScopeType)) activeCompareScopeType = "";
    }
    renderCompareScopeTypes();
    renderCompareMemberList();
    renderCompareSelectedItems();
  });
  if (compareMemberSearch) compareMemberSearch.addEventListener("input", renderCompareMemberList);
  if (compareSelectAllMembers) compareSelectAllMembers.addEventListener("change", () => {
    const type = activeCompareScopeType;
    if (!type) return;
    const selected = getCompareSelectedMembers(type);
    const term = (compareMemberSearch?.value || "").trim().toLowerCase();
    const visible = (compareMemberCache.get(type) || []).filter((member) => !term || member.label.toLowerCase().includes(term) || member.key.toLowerCase().includes(term));
    visible.forEach((member) => {
      if (compareSelectAllMembers.checked) selected.set(member.key, member); else selected.delete(member.key);
    });
    renderCompareMemberList();
    renderCompareScopeTypes();
    renderCompareSelectedItems();
  });
  if (compareOrgsLoad) compareOrgsLoad.addEventListener("click", compareOrganizations);
  if (compareResultsBack) compareResultsBack.addEventListener("click", returnToCompareSelection);
  if (compareSplitDirection) compareSplitDirection.addEventListener("click", () => {
    compareResultsVertical = !compareResultsVertical;
    updateCompareSplitDirection();
  });
  (function initCompareResultsResize() {
    const split = document.querySelector(".compare-results-split");
    if (!split || !compareResultsResizeHandle) return;
    const resize = (clientX, clientY) => {
      const panes = split.querySelectorAll(".compare-result-pane");
      if (panes.length < 2) return;
      const rect = split.getBoundingClientRect();
      const vertical = compareResultsVertical;
      const totalSize = vertical ? rect.height : rect.width;
      const pointerSize = vertical ? clientY - rect.top : clientX - rect.left;
      const minimum = vertical ? 120 : 220;
      const handleSize = 5;
      const firstSize = Math.min(totalSize - minimum - handleSize, Math.max(minimum, pointerSize));
      panes[0].style.flex = `0 0 ${firstSize}px`;
      panes[1].style.flex = "1 1 0";
    };
    let resizing = false;
    compareResultsResizeHandle.addEventListener("pointerdown", (event) => {
      resizing = true;
      compareResultsResizeHandle.setPointerCapture(event.pointerId);
      document.body.style.userSelect = "none";
      resize(event.clientX, event.clientY);
    });
    compareResultsResizeHandle.addEventListener("pointermove", (event) => {
      if (resizing) resize(event.clientX, event.clientY);
    });
    const stopResize = () => {
      resizing = false;
      document.body.style.userSelect = "";
    };
    compareResultsResizeHandle.addEventListener("pointerup", stopResize);
    compareResultsResizeHandle.addEventListener("pointercancel", stopResize);
    compareResultsResizeHandle.addEventListener("keydown", (event) => {
      const decrease = compareResultsVertical ? event.key === "ArrowUp" : event.key === "ArrowLeft";
      const increase = compareResultsVertical ? event.key === "ArrowDown" : event.key === "ArrowRight";
      if (!decrease && !increase) return;
      event.preventDefault();
      const panes = split.querySelectorAll(".compare-result-pane");
      const current = compareResultsVertical ? panes[0].getBoundingClientRect().height : panes[0].getBoundingClientRect().width;
      const next = current + (increase ? 20 : -20);
      const rect = split.getBoundingClientRect();
      resize(compareResultsVertical ? rect.left : rect.left + next, compareResultsVertical ? rect.top + next : rect.top);
    });
  })();

  function initDeployPaneResize(selector, minimumWidth = 80) {
    const split = document.querySelector(selector);
    if (!split) return;
    const panes = Array.from(split.querySelectorAll(".pkg-pane"));
    const resizePair = (index, widths, delta) => {
      const pairWidth = widths[index] + widths[index + 1];
      const nextWidths = widths.slice();
      nextWidths[index] = Math.max(minimumWidth, Math.min(pairWidth - minimumWidth, widths[index] + delta));
      nextWidths[index + 1] = pairWidth - nextWidths[index];
      split.style.gridTemplateColumns = nextWidths.map(width => `minmax(${minimumWidth}px, ${width}fr)`).join(" 5px ");
    };
    Array.from(split.querySelectorAll(".pkg-resize-handle")).forEach((handle, index) => {
      let drag = null;
      const finishDrag = (event) => {
        if (!drag || event.pointerId !== drag.pointerId) return;
        document.body.style.cursor = drag.cursor;
        document.body.style.userSelect = drag.userSelect;
        drag = null;
      };
      handle.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || drag) return;
        event.preventDefault();
        drag = {
          pointerId: event.pointerId,
          startX: event.clientX,
          widths: panes.map(pane => pane.getBoundingClientRect().width),
          cursor: document.body.style.cursor,
          userSelect: document.body.style.userSelect
        };
        handle.setPointerCapture(event.pointerId);
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
      });
      handle.addEventListener("pointermove", (event) => {
        if (drag && event.pointerId === drag.pointerId) resizePair(index, drag.widths, event.clientX - drag.startX);
      });
      handle.addEventListener("pointerup", finishDrag);
      handle.addEventListener("pointercancel", finishDrag);
      handle.addEventListener("lostpointercapture", finishDrag);
      handle.addEventListener("keydown", (event) => {
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
        event.preventDefault();
        const delta = (event.key === "ArrowRight" ? 1 : -1) * (event.shiftKey ? 40 : 10);
        resizePair(index, panes.map(pane => pane.getBoundingClientRect().width), delta);
      });
    });
  }

  initDeployPaneResize(".deploy-metadata-selection");
  initDeployPaneResize(".deploy-execute-split", 160);

  (function initCompareResize() {
    const split = document.querySelector(".compare-scope-split");
    if (!split) return;
    const minSideWidth = 140;
    const minCenterWidth = 180;
    const handleWidth = 5;
    let leftWidth = 180;
    let rightWidth = 220;
    let gridInitialized = false;
    const initializeGridWidths = () => {
      if (gridInitialized) return;
      const panes = split.querySelectorAll(".pkg-pane");
      leftWidth = panes[0]?.getBoundingClientRect().width || leftWidth;
      rightWidth = panes[2]?.getBoundingClientRect().width || rightWidth;
      gridInitialized = true;
    };
    const maximumLeftWidth = () => Math.max(minSideWidth, split.getBoundingClientRect().width - rightWidth - (handleWidth * 2) - minCenterWidth);
    const maximumSideWidth = () => Math.max(minSideWidth, split.getBoundingClientRect().width - leftWidth - (handleWidth * 2) - minCenterWidth);
    const applyGrid = () => {
      rightWidth = Math.min(maximumSideWidth(), Math.max(minSideWidth, rightWidth));
      split.style.gridTemplateColumns = `${leftWidth}px ${handleWidth}px minmax(${minCenterWidth}px, 1fr) ${handleWidth}px ${rightWidth}px`;
    };
    const bindResize = (handle, updateWidth) => {
      if (!handle) return;
      let dragging = false;
      let startX = 0;
      let startWidth = 0;
      handle.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        initializeGridWidths();
        dragging = true;
        startX = event.clientX;
        startWidth = updateWidth();
        handle.setPointerCapture?.(event.pointerId);
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
      });
      document.addEventListener("pointermove", (event) => {
        if (!dragging) return;
        updateWidth(startWidth, event.clientX - startX);
        applyGrid();
      });
      document.addEventListener("pointerup", () => {
        if (!dragging) return;
        dragging = false;
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
      });
    };
    bindResize(compareResizeHandle1, (startWidth, delta) => {
      if (startWidth === undefined) return leftWidth;
      leftWidth = Math.min(maximumLeftWidth(), Math.max(minSideWidth, startWidth + delta));
      return leftWidth;
    });
    bindResize(compareResizeHandle2, (startWidth, delta) => {
      if (startWidth === undefined) return rightWidth;
      rightWidth = Math.min(maximumSideWidth(), Math.max(minSideWidth, startWidth - delta));
      return rightWidth;
    });
  })();
  chrome.tabs.onUpdated.addListener(updateTargetAfterLogin);

  if (importResizeHandle) {
    let resizing = false;
    let startY = 0;
    let startIssuesHeight = 0;
    importResizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      resizing = true;
      startY = event.clientY;
      startIssuesHeight = importIssues.getBoundingClientRect().height;
      importResizeHandle.setPointerCapture?.(event.pointerId);
      document.body.style.cursor = "ns-resize";
      document.body.style.userSelect = "none";
    });
    importResizeHandle.addEventListener("pointermove", (event) => {
      if (!resizing) return;
      const workspaceHeight = importIssues.parentElement.getBoundingClientRect().height;
      const nextHeight = Math.min(workspaceHeight - 60, Math.max(32, startIssuesHeight - (event.clientY - startY)));
      importIssues.parentElement.style.gridTemplateRows = `minmax(60px, 1fr) 5px ${nextHeight}px`;
    });
    importResizeHandle.addEventListener("pointerup", () => {
      resizing = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    });
    importResizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowUp" ? 10 : event.key === "ArrowDown" ? -10 : 0;
      if (!step) return;
      event.preventDefault();
      const workspaceHeight = importIssues.parentElement.getBoundingClientRect().height;
      const currentHeight = importIssues.getBoundingClientRect().height;
      const nextHeight = Math.min(workspaceHeight - 60, Math.max(32, currentHeight - step));
      importIssues.parentElement.style.gridTemplateRows = `minmax(60px, 1fr) 5px ${nextHeight}px`;
    });
  }
  SFPanel.registerTab("import", { onShow() {} });
  SFPanel.registerTab("deploy", { onShow() { refreshDeploySourceOrg(); refreshDeployHistory(); setDeployStep(currentDeployStep); } });
  SFPanel.registerTab("export", { onShow() {} });
  SFPanel.registerTab("compareOrgs", {
    onStartup() {
      loadCompareOrgChoices(false, "", true).catch(error => setCompareStatus(error.message));
    },
    onShow() {
      setCompareMode("metadata");
      if (!compareResultsPage.hidden && lastComparisonResults) {
        restoreComparisonContext();
        renderComparisonResults(lastComparisonResults);
        return;
      }
      loadCompareOrgChoices().catch(error => setCompareStatus(error.message));
    },
    onHostnameChange() {
      // Activating a target tab must not replace the comparison's source.
      if (SFPanel.getActiveTab() === "compareOrgs") {
        loadCompareOrgChoices().catch(error => setCompareStatus(error.message));
      }
    }
  });
  SFPanel.registerTab("compareObjects", {
    onShow() {
      setCompareMode("objects");
      loadCompareOrgChoices().catch(error => setCompareStatus(error.message));
    },
    onHostnameChange() {
      if (SFPanel.getActiveTab() === "compareObjects") {
        loadCompareOrgChoices().catch(error => setCompareStatus(error.message));
      }
    }
  });
})(SFPanel.forTools("deploy", "import", "export", "compareOrgs", "compareObjects"));
