// js/rest.js — "REST Explorer" tab: send arbitrary REST/Tooling API calls
// using the current tab's Salesforce session, via the background's generic
// restRequest proxy (path must start with /services/, enforced there too).

((SFPanel) => {
  const methodSelect = document.getElementById("restMethod");
  const versionSelect = document.getElementById("restVersion");
  const pathInput = document.getElementById("restPath");
  const historyToggle = document.getElementById("restHistoryToggle");
  const historyMenu = document.getElementById("restHistoryMenu");
  const upButton = document.getElementById("restUp");
  const breadcrumbsEl = document.getElementById("restBreadcrumbs");
  const queryToggle = document.getElementById("restQueryToggle");
  const queryToggleLabel = queryToggle.closest("label");
  const queryInput = document.getElementById("restQuery");
  const bodyTextarea = document.getElementById("restBody");
  const sendButton = document.getElementById("restSend");
  const historySelect = document.getElementById("restHistory");
  const statusEl = document.getElementById("restStatus");
  const responseEl = document.getElementById("restResponse");
  const treeResponseEl = document.getElementById("restTreeResponse");
  const treeControlsEl = document.getElementById("restTreeControls");
  const expandAllBtn = document.getElementById("restExpandAll");
  const collapseAllBtn = document.getElementById("restCollapseAll");
  const viewBtns = document.querySelectorAll(".rest-view-btn");

  let currentViewMode = "json"; // "json" | "tree"
  let lastResponseData = null;

  const HISTORY_STORAGE_KEY = "restRequestHistory";
  const MAX_HISTORY_ITEMS = 25;

  let initialized = false;

  function extractQueryParam(path) {
    const queryIndex = path.indexOf("?");
    if (queryIndex === -1) return "";
    return new URLSearchParams(path.slice(queryIndex)).get("q") || "";
  }

  function isQueryPath(path) {
    return /\/(query|queryAll)\/?(\?|$)/i.test(path);
  }

  // GET/DELETE never take a body.
  function updateFieldVisibility() {
    const method = methodSelect.value;
    bodyTextarea.hidden = method === "GET" || method === "DELETE";

    // SOQL queries only apply to GET requests.
    queryToggleLabel.hidden = method !== "GET";
    if (method !== "GET" && queryToggle.checked) {
      queryToggle.checked = false;
      queryInput.hidden = true;
    }
  }

  methodSelect.addEventListener("change", updateFieldVisibility);

  let loadedVersionHostname = null;

  function syncVersionFromPath(path) {
    if (!path || !versionSelect) return;
    const match = path.match(/\/services\/data\/(v\d+\.\d+)\/?/i);
    if (match && match[1]) {
      const ver = match[1];
      let exists = Array.from(versionSelect.options).some((opt) => opt.value === ver);
      if (!exists) {
        const opt = document.createElement("option");
        opt.value = ver;
        opt.textContent = ver;
        versionSelect.appendChild(opt);
      }
      versionSelect.value = ver;
    }
  }

  async function loadVersions(hostname) {
    if (!hostname || loadedVersionHostname === hostname) return;
    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: "/services/data/"
      });
      if (Array.isArray(result.data) && result.data.length > 0) {
        const versions = result.data
          .map((item) => ({
            version: item.version ? `v${item.version}` : "",
            label: item.label || "",
            num: Number(item.version) || 0
          }))
          .filter((v) => v.version && v.num > 0)
          .sort((a, b) => b.num - a.num);

        if (versions.length > 0) {
          versionSelect.textContent = "";
          versions.forEach((v) => {
            const opt = document.createElement("option");
            opt.value = v.version;
            opt.textContent = v.version;
            if (v.label) opt.title = v.label;
            versionSelect.appendChild(opt);
          });

          loadedVersionHostname = hostname;
          const latestVersion = versions[0].version;
          versionSelect.value = latestVersion;

          let currentPath = pathInput.value.trim();
          if (!currentPath || /\/services\/data\/v\d+\.\d+\//i.test(currentPath)) {
            if (/\/services\/data\/v\d+\.\d+\//i.test(currentPath)) {
              currentPath = currentPath.replace(/\/services\/data\/v\d+\.\d+\//i, `/services/data/${latestVersion}/`);
            } else {
              currentPath = `/services/data/${latestVersion}/sobjects/`;
            }
            pathInput.value = currentPath;
            updateBreadcrumbs();
          } else {
            syncVersionFromPath(currentPath);
          }
        }
      }
    } catch {
      // Keep default options if fetch fails
    }
  }

  if (versionSelect) {
    versionSelect.addEventListener("change", () => {
      const selectedVersion = versionSelect.value;
      if (!selectedVersion) return;

      let currentPath = pathInput.value.trim();
      if (/\/services\/data\/v\d+\.\d+\//i.test(currentPath)) {
        currentPath = currentPath.replace(/\/services\/data\/v\d+\.\d+\//i, `/services/data/${selectedVersion}/`);
      } else if (currentPath === "/services/data/" || currentPath === "/services/data") {
        currentPath = `/services/data/${selectedVersion}/`;
      } else if (currentPath.startsWith("/services/data/")) {
        currentPath = currentPath.replace(/^\/services\/data\/[^\/]*/, `/services/data/${selectedVersion}`);
      } else {
        currentPath = `/services/data/${selectedVersion}/sobjects/`;
      }
      pathInput.value = currentPath;
      updateBreadcrumbs();
    });
  }

  // The checkbox is the single source of truth for showing the SOQL box;
  // the final "?q=..." path is only ever built fresh at send time (below),
  // instead of trying to keep the path and query text in sync on every keystroke.
  queryToggle.addEventListener("change", () => {
    queryInput.hidden = !queryToggle.checked;
    if (!queryToggle.checked) return;

    const currentPath = pathInput.value.trim();
    if (isQueryPath(currentPath)) {
      const existing = extractQueryParam(currentPath);
      if (existing) queryInput.value = existing;
    } else {
      const currentVer = versionSelect.value || SFPanel.API_VERSION;
      pathInput.value = `/services/data/${currentVer}/query/`;
    }
    methodSelect.value = "GET";
    updateFieldVisibility();
    updateBreadcrumbs();
    queryInput.focus();
  });

  function updateBreadcrumbs() {
    breadcrumbsEl.textContent = "";
    let rawPath = pathInput.value.trim().split("?")[0];
    if (!rawPath.startsWith("/")) rawPath = "/" + rawPath;
    syncVersionFromPath(rawPath);

    const parts = rawPath.split("/").filter(Boolean);
    if (parts.length === 0) {
      upButton.disabled = true;
      breadcrumbsEl.hidden = true;
      return;
    }

    upButton.disabled = parts.length <= 1;
    breadcrumbsEl.hidden = false;

    let cumulativePath = "";
    parts.forEach((part, index) => {
      cumulativePath += "/" + part;
      const targetPath = cumulativePath + "/";

      if (index > 0) {
        const sep = document.createElement("span");
        sep.className = "breadcrumb-sep";
        sep.textContent = "/";
        breadcrumbsEl.appendChild(sep);
      }

      const item = document.createElement("button");
      item.type = "button";
      item.className = "breadcrumb-item";
      if (index === parts.length - 1) {
        item.classList.add("active");
      }
      item.textContent = part;
      item.title = `Go to ${targetPath}`;
      item.addEventListener("click", () => {
        if (index === parts.length - 1) return;
        navigateToPath(targetPath);
      });
      breadcrumbsEl.appendChild(item);
    });
  }

  function navigateToPath(targetPath) {
    methodSelect.value = "GET";
    pathInput.value = targetPath;
    bodyTextarea.value = "";
    updateFieldVisibility();

    queryToggle.checked = isQueryPath(targetPath);
    queryInput.hidden = !queryToggle.checked;
    if (queryToggle.checked) {
      const existing = extractQueryParam(targetPath);
      if (existing) queryInput.value = existing;
    }

    updateBreadcrumbs();
    send();
  }

  upButton.addEventListener("click", () => {
    let rawPath = pathInput.value.trim().split("?")[0];
    if (!rawPath.startsWith("/")) rawPath = "/" + rawPath;
    const parts = rawPath.split("/").filter(Boolean);
    if (parts.length <= 1) return;

    parts.pop();
    const parentPath = "/" + parts.join("/") + "/";
    navigateToPath(parentPath);
  });

  pathInput.addEventListener("input", updateBreadcrumbs);

  function getHistoryList() {
    try {
      return JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY)) || [];
    } catch {
      return [];
    }
  }

  function saveHistoryList(list) {
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(list));
    } catch {
      // ignore
    }
  }

  function restoreHistoryItem(item) {
    if (!item) return;
    methodSelect.value = item.method || "GET";
    pathInput.value = item.path || `/services/data/${SFPanel.API_VERSION}/sobjects/`;
    bodyTextarea.value = item.body || "";

    queryToggle.checked = !!item.isQuery;
    queryInput.hidden = !queryToggle.checked;
    queryInput.value = item.query || "";

    updateFieldVisibility();
    updateBreadcrumbs();
    if (historyMenu) historyMenu.hidden = true;
  }

  function renderHistoryMenu() {
    if (!historyMenu) return;
    historyMenu.textContent = "";
    const list = getHistoryList();

    if (list.length === 0) {
      const emptyEl = document.createElement("div");
      emptyEl.className = "rest-history-empty";
      emptyEl.textContent = "No recent requests";
      historyMenu.appendChild(emptyEl);
      return;
    }

    list.forEach((item) => {
      const itemEl = document.createElement("div");
      itemEl.className = "rest-history-item";

      const methodEl = document.createElement("span");
      methodEl.className = "rest-history-item-method";
      methodEl.textContent = item.isQuery ? "GET [SOQL]" : item.method;

      const sepEl = document.createElement("span");
      sepEl.className = "rest-history-item-sep";
      sepEl.textContent = "–";

      const pathEl = document.createElement("span");
      pathEl.className = "rest-history-item-path";
      if (item.isQuery) {
        const querySnippet = (item.query || "").replace(/\s+/g, " ").trim();
        pathEl.textContent = querySnippet;
      } else {
        pathEl.textContent = item.path;
      }

      itemEl.appendChild(methodEl);
      itemEl.appendChild(sepEl);
      itemEl.appendChild(pathEl);

      itemEl.addEventListener("click", () => restoreHistoryItem(item));
      historyMenu.appendChild(itemEl);
    });

    const clearEl = document.createElement("div");
    clearEl.className = "rest-history-clear";
    clearEl.textContent = "🗑 Clear History";
    clearEl.addEventListener("click", (e) => {
      e.stopPropagation();
      saveHistoryList([]);
      renderHistoryMenu();
    });
    historyMenu.appendChild(clearEl);
  }

  function recordRequestInHistory(method, basePath, isQuery, queryText, rawBodyText) {
    let list = getHistoryList();

    list = list.filter((item) => {
      if (item.isQuery !== isQuery) return true;
      if (isQuery) {
        return item.query !== queryText || item.path !== basePath;
      }
      return item.method !== method || item.path !== basePath || (item.body || "") !== (rawBodyText || "");
    });

    list.unshift({
      method,
      path: basePath,
      isQuery: !!isQuery,
      query: queryText || "",
      body: rawBodyText || "",
      timestamp: Date.now()
    });

    if (list.length > MAX_HISTORY_ITEMS) {
      list = list.slice(0, MAX_HISTORY_ITEMS);
    }

    saveHistoryList(list);
    renderHistoryMenu();
  }

  if (historyToggle) {
    historyToggle.addEventListener("click", (e) => {
      e.stopPropagation();
      const willShow = historyMenu.hidden;
      if (willShow) {
        renderHistoryMenu();
      }
      historyMenu.hidden = !willShow;
    });
  }

  document.addEventListener("click", (e) => {
    if (historyMenu && !historyMenu.hidden && !e.target.closest(".rest-url-combo")) {
      historyMenu.hidden = true;
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && historyMenu && !historyMenu.hidden) {
      historyMenu.hidden = true;
    }
  });

  function setStatus(message, isError = true) {
    statusEl.textContent = message || "";
    statusEl.style.color = isError ? "#c00" : "inherit";
  }

  function setViewMode(mode) {
    currentViewMode = mode;
    viewBtns.forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.view === mode);
    });
    responseEl.hidden = mode !== "json";
    if (treeResponseEl) treeResponseEl.hidden = mode !== "tree";
  }

  function setTreeCollapseAll(container, collapse) {
    if (!container) return;
    container.querySelectorAll(".json-tree-node").forEach((node) => {
      const isRoot = node.classList.contains("json-tree-root");
      const children = node.querySelector(":scope > .json-tree-children");
      const toggle = node.querySelector(":scope > .json-tree-row > .json-tree-toggle");
      if (children && toggle) {
        const shouldHide = collapse ? !isRoot : false;
        children.hidden = shouldHide;
        toggle.textContent = shouldHide ? "▶" : "▼";
      }
    });
  }

  function setRawJsonCollapseAll(container, collapse) {
    if (!container) return;
    container.querySelectorAll(".json-raw-node").forEach((node) => {
      const isRoot = node.classList.contains("json-raw-root");
      const children = node.querySelector(":scope > .json-raw-children");
      const footer = node.querySelector(":scope > .json-raw-node-footer");
      const headerRow = node.querySelector(":scope > .json-raw-line.collapsible");
      if (headerRow && children) {
        const toggle = headerRow.querySelector(".json-tree-toggle");
        const summary = headerRow.querySelector(".json-syntax-summary");
        const shouldHide = collapse ? !isRoot : false;
        children.hidden = shouldHide;
        if (footer) footer.hidden = shouldHide;
        if (summary) summary.hidden = !shouldHide;
        if (toggle) toggle.textContent = shouldHide ? "▶" : "▼";
      }
    });
  }

  if (expandAllBtn) {
    expandAllBtn.addEventListener("click", () => {
      if (currentViewMode === "tree") setTreeCollapseAll(treeResponseEl, false);
      else setRawJsonCollapseAll(responseEl, false);
    });
  }
  if (collapseAllBtn) {
    collapseAllBtn.addEventListener("click", () => {
      if (currentViewMode === "tree") setTreeCollapseAll(treeResponseEl, true);
      else setRawJsonCollapseAll(responseEl, true);
    });
  }

  viewBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      setViewMode(btn.dataset.view);
    });
  });

  function getObjectLabel(obj) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
    if (typeof obj.name === "string" && obj.name) return obj.name;
    if (typeof obj.Name === "string" && obj.Name) return obj.Name;
    if (typeof obj.label === "string" && obj.label) return obj.label;
    if (typeof obj.Label === "string" && obj.Label) return obj.Label;
    if (typeof obj.developerName === "string" && obj.developerName) return obj.developerName;
    if (typeof obj.DeveloperName === "string" && obj.DeveloperName) return obj.DeveloperName;
    if (typeof obj.fullName === "string" && obj.fullName) return obj.fullName;
    if (typeof obj.childSObject === "string" && obj.childSObject) return obj.childSObject;
    if (typeof obj.relationshipName === "string" && obj.relationshipName) return obj.relationshipName;
    if (typeof obj.attributes === "object" && obj.attributes && typeof obj.attributes.type === "string") {
      if (typeof obj.Id === "string" && obj.Id) return `${obj.attributes.type} (${obj.Id})`;
    }
    if (typeof obj.Id === "string" && obj.Id) return obj.Id;
    if (typeof obj.id === "string" && obj.id) return obj.id;
    return null;
  }

  function formatNodeKey(key) {
    if (key === null || key === undefined) return key;
    if (typeof key === "number") return String(key + 1);
    if (typeof key === "string" && /^\d+$/.test(key)) return String(Number(key) + 1);
    return key;
  }

  function renderJsonTree(data, parentContainer) {
    parentContainer.textContent = "";

    function buildNode(key, value, isRoot = false) {
      const container = document.createElement("div");
      container.className = isRoot ? "json-tree-node json-tree-root" : "json-tree-node";

      const row = document.createElement("div");
      row.className = "json-tree-row";

      const isObject = value !== null && typeof value === "object";
      const isArray = Array.isArray(value);

      if (isObject) {
        row.classList.add("collapsible");
        const keys = Object.keys(value);
        const shouldCollapse = !isRoot; // collapse non-root object/array nodes by default
        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.textContent = shouldCollapse ? "▶" : "▼";

        const childrenContainer = document.createElement("div");
        childrenContainer.className = "json-tree-children";
        if (shouldCollapse) {
          childrenContainer.hidden = true;
        }

        const toggleHandler = (e) => {
          e.stopPropagation();
          const isCollapsed = childrenContainer.hidden;
          childrenContainer.hidden = !isCollapsed;
          toggle.textContent = isCollapsed ? "▼" : "▶";
        };

        row.addEventListener("click", toggleHandler);

        row.appendChild(toggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-tree-key";

          const formattedKey = isRoot ? key : formatNodeKey(key);
          let displayKey = formattedKey;
          const objLabel = getObjectLabel(value);
          if (objLabel && objLabel !== formattedKey) {
            displayKey = `${formattedKey} (${objLabel})`;
          }

          keyEl.textContent = `${displayKey} (${keys.length})`;
          row.appendChild(keyEl);
        }

        container.appendChild(row);

        keys.forEach((childKey) => {
          childrenContainer.appendChild(buildNode(childKey, value[childKey]));
        });

        container.appendChild(childrenContainer);
      } else {
        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.style.visibility = "hidden";
        row.appendChild(toggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-tree-key";
          keyEl.textContent = isRoot ? key : formatNodeKey(key);
          const colonEl = document.createElement("span");
          colonEl.className = "json-tree-colon";
          colonEl.textContent = ": ";
          row.appendChild(keyEl);
          row.appendChild(colonEl);
        }

        const valEl = document.createElement("span");
        const valType = value === null ? "null" : typeof value;
        valEl.className = `json-tree-value ${valType}`;
        valEl.textContent = value === null ? "null" : JSON.stringify(value);
        row.appendChild(valEl);

        container.appendChild(row);
      }

      return container;
    }

    parentContainer.appendChild(buildNode(null, data, true));
  }

  function renderPlainTextWithLinks(rawText, containerEl, followLink) {
    containerEl.textContent = "";
    const urlPattern = /(https?:\/\/[^\s"'<>]+|\/services\/[^\s"'<>]+)/g;
    let lastIndex = 0;
    let match;
    while ((match = urlPattern.exec(rawText))) {
      if (match.index > lastIndex) {
        containerEl.appendChild(document.createTextNode(rawText.slice(lastIndex, match.index)));
      }
      const matchedText = match[0];
      const link = document.createElement("span");
      link.className = "rest-response-link";
      link.textContent = matchedText;
      link.setAttribute("role", "link");
      link.tabIndex = 0;
      link.title = "Load this path and send the request";
      if (followLink) {
        link.addEventListener("click", (e) => {
          e.stopPropagation();
          followLink(matchedText);
        });
        link.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.stopPropagation();
            e.preventDefault();
            followLink(matchedText);
          }
        });
      }
      containerEl.appendChild(link);
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < rawText.length) {
      containerEl.appendChild(document.createTextNode(rawText.slice(lastIndex)));
    }
  }

  function renderStringValue(textContainer, strValue, followLink) {
    const urlPattern = /(https?:\/\/[^\s"'<>]+|\/services\/[^\s"'<>]+)/g;
    let lastIndex = 0;
    let match;
    const formatted = JSON.stringify(strValue);
    while ((match = urlPattern.exec(formatted))) {
      if (match.index > lastIndex) {
        textContainer.appendChild(document.createTextNode(formatted.slice(lastIndex, match.index)));
      }
      const matchedText = match[0];
      const cleanUrl = matchedText.replace(/"$/, "");
      const link = document.createElement("span");
      link.className = "rest-response-link";
      link.textContent = cleanUrl;
      link.setAttribute("role", "link");
      link.tabIndex = 0;
      link.title = "Load this path and send the request";
      if (followLink) {
        link.addEventListener("click", (e) => {
          e.stopPropagation();
          followLink(cleanUrl);
        });
        link.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.stopPropagation();
            e.preventDefault();
            followLink(cleanUrl);
          }
        });
      }
      textContainer.appendChild(link);
      lastIndex = match.index + cleanUrl.length;
    }
    if (lastIndex < formatted.length) {
      textContainer.appendChild(document.createTextNode(formatted.slice(lastIndex)));
    }
  }

  function renderCollapsibleJson(data, parentContainer, followLink) {
    parentContainer.textContent = "";

    function buildNode(key, value, isLast, isRoot = false) {
      const container = document.createElement("div");
      container.className = isRoot ? "json-raw-node json-raw-root" : "json-raw-node";

      const isObject = value !== null && typeof value === "object";

      if (isObject) {
        const isArray = Array.isArray(value);
        const keys = Object.keys(value);
        const openBracket = isArray ? "[" : "{";
        const closeBracket = isArray ? "]" : "}";
        const trailingComma = isLast ? "" : ",";
        const shouldCollapse = isRoot;

        const headerRow = document.createElement("div");
        headerRow.className = "json-raw-line collapsible";

        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.textContent = shouldCollapse ? "▶" : "▼";
        headerRow.appendChild(toggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-syntax-key";
          keyEl.textContent = JSON.stringify(key) + ": ";
          headerRow.appendChild(keyEl);
        }

        const openSpan = document.createElement("span");
        openSpan.className = "json-syntax-bracket";
        openSpan.textContent = openBracket;
        headerRow.appendChild(openSpan);

        const summarySpan = document.createElement("span");
        summarySpan.className = "json-syntax-summary";
        summarySpan.textContent = ` ... ${closeBracket}${trailingComma}`;
        summarySpan.hidden = !shouldCollapse;
        headerRow.appendChild(summarySpan);

        if (keys.length === 0) {
          toggle.style.visibility = "hidden";
          headerRow.classList.remove("collapsible");
          summarySpan.textContent = `${closeBracket}${trailingComma}`;
          summarySpan.hidden = false;
          container.appendChild(headerRow);
          return container;
        }

        const childrenContainer = document.createElement("div");
        childrenContainer.className = "json-raw-children";
        if (shouldCollapse) {
          childrenContainer.hidden = true;
        }

        const footerRow = document.createElement("div");
        footerRow.className = "json-raw-line json-raw-node-footer";
        if (shouldCollapse) {
          footerRow.hidden = true;
        }
        const dummyToggle = document.createElement("span");
        dummyToggle.className = "json-tree-toggle";
        dummyToggle.style.visibility = "hidden";
        footerRow.appendChild(dummyToggle);

        const closeSpan = document.createElement("span");
        closeSpan.className = "json-syntax-bracket";
        closeSpan.textContent = closeBracket + trailingComma;
        footerRow.appendChild(closeSpan);

        headerRow.addEventListener("click", (e) => {
          e.stopPropagation();
          const isCollapsed = childrenContainer.hidden;
          childrenContainer.hidden = !isCollapsed;
          footerRow.hidden = !isCollapsed;
          summarySpan.hidden = !isCollapsed;
          toggle.textContent = isCollapsed ? "▼" : "▶";
        });

        container.appendChild(headerRow);

        keys.forEach((childKey, idx) => {
          const childIsLast = idx === keys.length - 1;
          const childVal = isArray ? value[childKey] : value[childKey];
          const childKeyName = isArray ? null : childKey;
          childrenContainer.appendChild(buildNode(childKeyName, childVal, childIsLast, false));
        });

        container.appendChild(childrenContainer);
        container.appendChild(footerRow);
      } else {
        const line = document.createElement("div");
        line.className = "json-raw-line";

        const dummyToggle = document.createElement("span");
        dummyToggle.className = "json-tree-toggle";
        dummyToggle.style.visibility = "hidden";
        line.appendChild(dummyToggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-syntax-key";
          keyEl.textContent = JSON.stringify(key) + ": ";
          line.appendChild(keyEl);
        }

        const valSpan = document.createElement("span");
        const valType = value === null ? "null" : typeof value;
        valSpan.className = `json-syntax-value ${valType}`;

        if (typeof value === "string") {
          renderStringValue(valSpan, value, followLink);
        } else {
          valSpan.textContent = value === null ? "null" : JSON.stringify(value);
        }
        line.appendChild(valSpan);

        if (!isLast) {
          const commaSpan = document.createElement("span");
          commaSpan.className = "json-syntax-comma";
          commaSpan.textContent = ",";
          line.appendChild(commaSpan);
        }

        container.appendChild(line);
      }

      return container;
    }

    parentContainer.appendChild(buildNode(null, data, true, true));
  }

  function displayResponseData(data) {
    lastResponseData = data;
    const rawText = typeof data === "string" ? data : JSON.stringify(data, null, 2);
    renderResponse(rawText, data);

    if (treeResponseEl) {
      if (typeof data === "object" && data !== null) {
        renderJsonTree(data, treeResponseEl);
      } else {
        try {
          const parsed = JSON.parse(data);
          renderJsonTree(parsed, treeResponseEl);
        } catch {
          treeResponseEl.textContent = rawText;
        }
      }
    }
  }

  // Renders response text with any /services/ path or absolute Salesforce URL
  // turned into a clickable element that loads and re-sends that request.
  function renderResponse(rawText, dataObj = null) {
    responseEl.textContent = "";
    let dataToRender = dataObj || lastResponseData;
    if (!dataToRender && typeof rawText === "string") {
      try {
        dataToRender = JSON.parse(rawText);
      } catch {
        dataToRender = null;
      }
    }

    if (dataToRender !== null && typeof dataToRender === "object") {
      renderCollapsibleJson(dataToRender, responseEl, followResponseLink);
    } else {
      renderPlainTextWithLinks(rawText, responseEl, followResponseLink);
    }
  }

  function followResponseLink(rawUrl) {
    let path = rawUrl;
    if (/^https?:\/\//i.test(rawUrl)) {
      try {
        const url = new URL(rawUrl);
        path = `${url.pathname}${url.search}`;
      } catch {
        return;
      }
    }
    if (!path.startsWith("/services/")) {
      setStatus("Only /services/ paths can be opened here.");
      return;
    }
    methodSelect.value = "GET";
    pathInput.value = path;
    bodyTextarea.value = "";
    updateFieldVisibility();
    updateBreadcrumbs();

    queryToggle.checked = isQueryPath(path);
    queryInput.hidden = !queryToggle.checked;
    if (queryToggle.checked) {
      const existing = extractQueryParam(path);
      if (existing) queryInput.value = existing;
    }

    // Salesforce sobject listings include templated URLs like ".../{ID}" —
    // not a real value, so load it for editing instead of sending as-is.
    const placeholder = path.match(/\{[^}]+\}/);
    if (placeholder) {
      setStatus(`Replace the placeholder ${placeholder[0]} with a real value before sending.`);
      return;
    }

    send();
  }

  async function send() {
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    const method = methodSelect.value;
    let path = pathInput.value.trim();
    if (!path) {
      setStatus("Enter a path, e.g. /services/data/v65.0/sobjects/Account/describe/");
      return;
    }
    if (!path.startsWith("/")) path = `/${path}`;
    pathInput.value = path;
    updateBreadcrumbs();

    if (queryToggle.checked) {
      const soql = queryInput.value.trim();
      if (!soql) {
        setStatus("Enter a SOQL query.");
        return;
      }
      let base = path.split("?")[0];
      if (!base.endsWith("/")) base += "/";
      pathInput.value = base;
      path = `${base}?q=${encodeURIComponent(soql)}`;
      updateBreadcrumbs();
    }

    let body;
    const rawBody = bodyTextarea.value.trim();
    if (rawBody && method !== "GET" && method !== "DELETE") {
      try {
        body = JSON.parse(rawBody);
      } catch {
        setStatus("Request body must be valid JSON.");
        return;
      }
    }

    setStatus("Sending…", false);
    responseEl.textContent = "";
    sendButton.disabled = true;

    recordRequestInHistory(
      method,
      queryToggle.checked ? path.split("?")[0] : path,
      queryToggle.checked,
      queryInput.value.trim(),
      rawBody
    );

    try {
      const result = await SFPanel.sendMessage({ type: "restRequest", hostname, method, path, body });
      setStatus(`${method} ${path} → ${result.status}`, false);
      displayResponseData(result.data);
    } catch (err) {
      setStatus(err.message);
      responseEl.textContent = "";
      if (treeResponseEl) treeResponseEl.textContent = "";
    } finally {
      sendButton.disabled = false;
    }
  }

  sendButton.addEventListener("click", send);
  updateFieldVisibility();
  renderHistoryMenu();

  SFPanel.registerTab("rest", {
    onShow(hostname) {
      if (!initialized) {
        initialized = true;
        if (hostname) pathInput.value = `/services/data/${SFPanel.API_VERSION}/sobjects/`;
        updateFieldVisibility();
        updateBreadcrumbs();
        renderHistoryMenu();
      }
      if (hostname) {
        loadVersions(hostname);
      }
    },
    onHostnameChange(hostname) {
      if (hostname) {
        loadedVersionHostname = null;
        loadVersions(hostname);
      }
    }
  });
})(SFPanel.forTools("rest"));
