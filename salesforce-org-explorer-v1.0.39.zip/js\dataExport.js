// Visual, read-only record export. No Tooling API or record modifications.
const DataExportCore = (() => {
  const numericTypes = new Set(["int", "double", "currency", "percent", "long"]);
  const textTypes = new Set(["string", "textarea", "email", "url", "phone", "id", "reference", "picklist", "combobox"]);
  const unsupportedTypes = new Set(["base64", "address", "location", "anyType", "complexvalue"]);
  function identifier(name) {
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name || "")) throw new Error(`Invalid API name: ${name}`);
    return name;
  }
  function exportable(field) {
    return field.deprecatedAndHidden !== true && !unsupportedTypes.has(field.type);
  }
  function operators(field) {
    if (!field || field.filterable !== true) return [];
    if (field.type === "boolean") return ["eq", "ne", "empty", "notEmpty"];
    if (numericTypes.has(field.type) || ["date", "datetime", "time"].includes(field.type)) return ["eq", "ne", "gt", "ge", "lt", "le", "empty", "notEmpty"];
    if (textTypes.has(field.type)) return ["eq", "ne", ...(["string", "textarea", "email", "url", "phone", "combobox"].includes(field.type) ? ["contains", "starts"] : []), "empty", "notEmpty"];
    return [];
  }
  function quoted(value) {
    return `'${String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t")}'`;
  }
  function literal(field, value) {
    if (value === "" || value == null) throw new Error(`Enter a value for ${field.label || field.name}, or use "is empty".`);
    const text = String(value);
    if (numericTypes.has(field.type)) {
      if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text) || !Number.isFinite(Number(text))) throw new Error(`Enter a valid number for ${field.name}.`);
      return text;
    }
    if (field.type === "boolean") {
      if (!["true", "false"].includes(text)) throw new Error(`Choose true or false for ${field.name}.`);
      return text;
    }
    if (field.type === "date") {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || !Number.isFinite(Date.parse(text)) || new Date(text).toISOString().slice(0, 10) !== text) throw new Error(`Enter a valid date for ${field.name}.`);
      return text;
    }
    if (field.type === "datetime") {
      if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?Z?$/.test(text)) throw new Error(`Enter a valid UTC date/time for ${field.name}.`);
      const utc = text.endsWith("Z") ? text : `${text}Z`;
      if (!Number.isFinite(Date.parse(utc)) || new Date(utc).toISOString().slice(0, 10) !== text.slice(0, 10)) throw new Error(`Enter a valid UTC date/time for ${field.name}.`);
      return new Date(utc).toISOString();
    }
    if (field.type === "time") {
      if (!/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,3})?)?$/.test(text)) throw new Error(`Enter a valid time for ${field.name}.`);
      const seconds = text.length === 5 ? `${text}:00` : text;
      return `${seconds.includes(".") ? seconds : `${seconds}.000`}Z`;
    }
    return quoted(text);
  }
  function query(config, mode = "export") {
    const byName = new Map(config.fields.filter(exportable).map(field => [field.name, field]));
    const fields = config.fields.filter(field => config.selected.has(field.name) && byName.has(field.name)).map(field => identifier(field.name));
    if (!fields.length) throw new Error(`Choose at least one field for ${config.name}.`);
    if (!["all", "any"].includes(config.match)) throw new Error("Choose how filter conditions should be matched.");
    const conditions = config.filters.map(filter => {
      const field = byName.get(filter.field);
      if (!field || !operators(field).includes(filter.operator)) throw new Error(`Choose a valid filter field and operator for ${config.name}.`);
      const name = identifier(field.name);
      if (filter.operator === "empty") return `${name} = null`;
      if (filter.operator === "notEmpty") return `${name} != null`;
      if (["contains", "starts"].includes(filter.operator)) {
        if (!filter.value) throw new Error(`Enter a value for ${name}.`);
        const value = String(filter.value).replace(/\\/g, "\\\\").replace(/%/g, "\\%").replace(/_/g, "\\_");
        return `${name} LIKE ${quoted(`${filter.operator === "contains" ? "%" : ""}${value}%`)}`;
      }
      const symbols = { eq: "=", ne: "!=", gt: ">", ge: ">=", lt: "<", le: "<=" };
      return `${name} ${symbols[filter.operator]} ${literal(field, filter.value)}`;
    });
    return `SELECT ${mode === "count" ? "COUNT()" : fields.join(", ")} FROM ${identifier(config.name)}${conditions.length ? ` WHERE (${conditions.join(config.match === "any" ? " OR " : " AND ")})` : ""}${mode === "preview" ? " LIMIT 20" : ""}`;
  }
  function csv(fields, records) {
    function cell(value) {
      let text = value == null ? "" : typeof value === "object" ? JSON.stringify(value) : String(value);
      // CSV is opened in spreadsheets: keep text from becoming a formula.
      if (typeof value === "string" && /^\s*[=+@\-\t\r]/.test(value)) text = `'${text}`;
      return `"${text.replace(/"/g, '""')}"`;
    }
    return "\uFEFF" + [fields.map(cell).join(","), ...records.map(record => fields.map(name => cell(record[name])).join(","))].join("\r\n");
  }
  async function fetchRecords(send, hostname, soql, progress = () => {}, check = () => {}) {
    let path = `/services/data/${send.apiVersion || "v65.0"}/query/?q=${encodeURIComponent(soql)}`;
    const records = [];
    const visited = new Set();
    let expectedTotal = null;
    while (path) {
      check();
      if (visited.has(path)) throw new Error("Salesforce repeated a result page. Export stopped to avoid duplicate records.");
      visited.add(path);
      const response = await send({ type: "restRequest", hostname, method: "GET", path });
      check();
      const data = response.data;
      if (!data || !Array.isArray(data.records) || typeof data.done !== "boolean") throw new Error("Salesforce returned an invalid query result. No file was downloaded.");
      if (Number.isInteger(data.totalSize) && data.totalSize >= 0) {
        if (expectedTotal !== null && expectedTotal !== data.totalSize) throw new Error("Salesforce changed the result count during pagination. Retry the export.");
        expectedTotal = data.totalSize;
      }
      records.push(...data.records);
      progress(records.length, data.totalSize);
      if (data.done) {
        if (expectedTotal !== null && records.length !== expectedTotal) throw new Error(`Salesforce reported ${expectedTotal} records, but returned ${records.length}. No file was downloaded.`);
        break;
      }
      if (typeof data.nextRecordsUrl !== "string" || !/^\/services\/data\/v\d+\.\d+\/query\/[A-Za-z0-9_-]+(?:\?[^#]*)?$/.test(data.nextRecordsUrl)) throw new Error("Salesforce didn't return a valid next page. No file was downloaded.");
      path = data.nextRecordsUrl;
    }
    return records;
  }
  return { exportable, operators, query, csv, fetchRecords };
})();

if (typeof module !== "undefined" && module.exports) module.exports = DataExportCore;

if (typeof document !== "undefined" && typeof SFPanel !== "undefined") ((SFPanel) => {
  const panel = document.getElementById("dataExportPanel");
  if (!panel) return;
  const core = DataExportCore;
  const state = { hostname: null, objects: [], configs: new Map(), active: "", busy: false, generation: 0 };
  const send = message => SFPanel.sendMessage(message);
  send.apiVersion = SFPanel.API_VERSION;
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.assign(node, props);
    children.forEach(child => node.appendChild(child));
    return node;
  }
  function button(text, action) {
    const node = el("button", { type: "button", textContent: text });
    node.addEventListener("click", action);
    return node;
  }
  function option(value, text) { return el("option", { value, textContent: text }); }
  const search = el("input", { type: "search", placeholder: "Find objects by label or API name", ariaLabel: "Find objects" });
  const refresh = button("Refresh objects", () => loadObjects());
  const objectList = el("div", { className: "data-export-object-list" });
  const objectCount = el("span", { className: "data-export-object-count" });
  const active = el("select", { ariaLabel: "Configure selected object" });
  const settings = el("fieldset", { className: "data-export-settings" });
  const status = el("div", { className: "status", role: "status", ariaLive: "polite" });
  const preview = el("div", { className: "data-export-preview" });
  const queryText = el("pre", { className: "data-export-query" });
  const previewButton = button("Preview (20 records)", () => run("preview"));
  const countButton = button("Count records", () => run("count"));
  const exportButton = button("Export selected objects", () => run("export"));
  const cancelButton = button("Cancel", () => {
    state.generation += 1;
    state.busy = false;
    setStatus("Cancelled. No export file was downloaded.");
    render();
  });
  const queryDetails = el("details", {}, [el("summary", { textContent: "Generated SOQL (optional)" }), queryText]);
  const divider = el("div", { className: "data-export-divider", tabIndex: 0, title: "Drag left or right to resize the object list and options" });
  for (const [name, value] of Object.entries({ role: "separator", "aria-orientation": "vertical", "aria-label": "Resize object list and options", "aria-valuemin": "20", "aria-valuemax": "65", "aria-valuenow": "33" })) divider.setAttribute(name, value);
  const workspace = el("div", { className: "data-export-workspace" }, [
    el("div", { className: "data-export-objects" }, [el("div", { className: "data-export-object-heading" }, [el("strong", { textContent: "1. Select objects" }), objectCount]), objectList]),
    divider,
    el("div", { className: "data-export-options" }, [el("label", { textContent: "2. Configure each selected object", className: "data-export-heading" }, [active]), settings])
  ]);
  let leftPercent = 33;
  let drag = null;
  function resizeColumns(percent) {
    leftPercent = Math.max(20, Math.min(65, percent));
    workspace.style.setProperty("--data-export-left", `${leftPercent}%`);
    divider.setAttribute("aria-valuenow", String(Math.round(leftPercent)));
  }
  divider.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    event.preventDefault();
    drag = { pointerId: event.pointerId, x: event.clientX, width: workspace.getBoundingClientRect().width, percent: leftPercent };
    divider.setPointerCapture(event.pointerId);
  });
  divider.addEventListener("pointermove", event => {
    if (drag && event.pointerId === drag.pointerId && drag.width > 0) resizeColumns(drag.percent + (event.clientX - drag.x) / drag.width * 100);
  });
  function stopResize(event) {
    if (drag && event.pointerId === drag.pointerId) drag = null;
  }
  divider.addEventListener("pointerup", stopResize);
  divider.addEventListener("pointercancel", stopResize);
  divider.addEventListener("lostpointercapture", stopResize);
  divider.addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    resizeColumns(event.key === "Home" ? 20 : event.key === "End" ? 65 : leftPercent + (event.key === "ArrowLeft" ? -3 : 3));
  });
  panel.append(
    el("p", { className: "tab-help", textContent: "Export records without writing SOQL. Select objects, choose fields and optional filters for each, then preview or download. No filters means all accessible, non-deleted records. This is not a full org backup." }),
    el("div", { className: "data-export-toolbar" }, [search, refresh]),
    workspace,
    el("div", { className: "data-export-toolbar" }, [previewButton, countButton, exportButton, cancelButton]),
    status, preview, queryDetails
  );
  function setStatus(message, loading = false, error = false) {
    status.textContent = "";
    status.style.color = error ? "#c00" : "inherit";
    status.setAttribute("aria-busy", String(loading));
    if (loading) status.appendChild(el("span", { className: "export-loading-spinner status-inline-spinner", ariaHidden: "true" }));
    status.appendChild(el("span", { textContent: message }));
  }
  function clearResults() {
    preview.textContent = "";
    setStatus("");
    updateQuery();
  }
  function updateQuery() {
    const config = state.configs.get(state.active);
    try { queryText.textContent = config && !config.error && config.fields ? core.query(config) : ""; }
    catch (error) { queryText.textContent = error.message; }
  }
  function renderObjects() {
    objectList.textContent = "";
    objectCount.textContent = `${state.objects.length.toLocaleString()} objects`;
    const term = search.value.trim().toLowerCase();
    const shown = state.objects.filter(object => `${object.label} ${object.name}`.toLowerCase().includes(term));
    shown.forEach(object => {
      const checkbox = el("input", { type: "checkbox", checked: state.configs.has(object.name), disabled: state.busy });
      checkbox.addEventListener("change", () => selectObject(object, checkbox.checked));
      objectList.appendChild(el("label", {}, [checkbox, el("span", { textContent: `${object.label} (${object.name})` })]));
    });
    if (!shown.length) objectList.appendChild(el("p", { textContent: state.objects.length ? "No matching objects." : "No objects loaded." }));
  }
  function render() {
    renderObjects();
    active.textContent = "";
    state.configs.forEach(config => active.appendChild(option(config.name, `${config.label} (${config.name})`)));
    if (!state.configs.has(state.active)) state.active = state.configs.keys().next().value || "";
    active.value = state.active;
    active.disabled = state.busy || !state.configs.size;
    settings.disabled = state.busy;
    refresh.disabled = state.busy;
    const ready = state.configs.size > 0 && [...state.configs.values()].every(config => config.fields && !config.error);
    exportButton.disabled = state.busy || !ready;
    const current = state.configs.get(state.active);
    const pendingFields = [...state.configs.values()].some(config => !config.fields && !config.error);
    previewButton.disabled = countButton.disabled = state.busy || pendingFields || !current?.fields || Boolean(current?.error);
    cancelButton.hidden = !state.busy;
    renderSettings();
    updateQuery();
  }
  async function selectObject(object, checked) {
    clearResults();
    if (!checked) {
      state.configs.delete(object.name);
      render();
      return;
    }
    const config = { name: object.name, label: object.label, fields: null, selected: new Set(), filters: [], match: "all", allFields: true };
    state.configs.set(object.name, config);
    state.active = object.name;
    render();
    await loadFields(config);
  }
  async function loadFields(config) {
    const generation = state.generation;
    const host = state.hostname;
    setStatus(`Loading fields for ${config.name}...`, true);
    try {
      const response = await send({ type: "restRequest", hostname: host, method: "GET", path: `/services/data/${SFPanel.API_VERSION}/sobjects/${config.name}/describe/` });
      if (generation !== state.generation || state.configs.get(config.name) !== config) return;
      if (!Array.isArray(response.data?.fields)) throw new Error("Salesforce returned no field definitions.");
      config.fields = response.data.fields.filter(core.exportable);
      config.selected = new Set(config.fields.map(field => field.name));
      config.error = "";
      setStatus("");
    } catch (error) {
      if (generation !== state.generation || state.configs.get(config.name) !== config) return;
      config.error = error.message;
      setStatus(`Couldn't load ${config.name}: ${error.message}`, false, true);
    }
    render();
  }
  const operatorLabels = { eq: "equals", ne: "does not equal", gt: "greater than / after", ge: "at least / on or after", lt: "less than / before", le: "at most / on or before", contains: "contains", starts: "starts with", empty: "is empty", notEmpty: "is not empty" };
  function renderSettings() {
    settings.textContent = "";
    const config = state.configs.get(state.active);
    if (!config) { settings.appendChild(el("p", { textContent: "Select an object to get started." })); return; }
    if (config.error) {
      settings.append(el("p", { textContent: config.error }), button("Retry fields", () => loadFields(config)));
      return;
    }
    if (!config.fields) { settings.appendChild(el("p", { textContent: "Loading fields..." })); return; }
    function section(key, label) {
      const details = el("details", { className: "data-export-section", open: config[key] !== false }, [el("summary", { textContent: label })]);
      details.addEventListener("toggle", () => { config[key] = details.open; });
      settings.appendChild(details);
      return details;
    }
    const fieldSection = section("fieldsOpen", "Fields");
    const mode = el("fieldset", { className: "data-export-field-mode" }, [el("legend", { textContent: "Fields to export" })]);
    for (const [value, label] of [["all", "All"], ["choose", "Select"]]) {
      const radio = el("input", { type: "radio", name: "data-export-field-mode", value, checked: config.allFields === (value === "all"), ariaLabel: `Fields to export: ${label}` });
      radio.addEventListener("change", () => {
        if (!radio.checked) return;
        config.allFields = value === "all";
        if (config.allFields) config.selected = new Set(config.fields.map(field => field.name));
        clearResults(); render();
      });
      mode.appendChild(el("label", {}, [radio, el("span", { textContent: label })]));
    }
    fieldSection.append(mode, el("p", { className: "tab-help", textContent: "Record ID is always selected when available. Binary and compound address/location fields are excluded; their individual components can be exported." }));
    if (!config.allFields) {
      const list = el("div", { className: "data-export-field-list" });
      const fieldSearch = el("input", { type: "search", placeholder: "Find fields", ariaLabel: "Find fields" });
      const fill = () => {
        list.textContent = "";
        config.fields.filter(field => `${field.label} ${field.name}`.toLowerCase().includes(fieldSearch.value.toLowerCase())).forEach(field => {
          const check = el("input", { type: "checkbox", checked: config.selected.has(field.name), disabled: field.name === "Id" });
          check.addEventListener("change", () => {
            if (check.checked) config.selected.add(field.name); else config.selected.delete(field.name);
            clearResults();
          });
          list.appendChild(el("label", {}, [check, el("span", { textContent: `${field.label} (${field.name})` })]));
        });
      };
      fill();
      fieldSearch.addEventListener("input", fill);
      fieldSection.append(fieldSearch, button("Select All", () => { config.selected = new Set(config.fields.map(field => field.name)); clearResults(); render(); }),
        button("Deselect All", () => { config.selected = new Set(config.fields.some(field => field.name === "Id") ? ["Id"] : []); clearResults(); render(); }), list);
    }
    const match = el("select", { ariaLabel: "Match conditions" }, [option("all", "All conditions (AND)"), option("any", "Any condition (OR)")]);
    match.value = config.match;
    match.addEventListener("change", () => { config.match = match.value; clearResults(); });
    const filterSection = section("filtersOpen", "Optional filters");
    filterSection.appendChild(match);
    config.filters.forEach((filter, index) => {
      const fields = config.fields.filter(field => core.operators(field).length);
      const fieldSelect = el("select", { ariaLabel: `Filter ${index + 1} field` }, fields.map(field => option(field.name, `${field.label} (${field.name})`)));
      fieldSelect.value = filter.field;
      const field = fields.find(item => item.name === filter.field);
      const ops = el("select", { ariaLabel: `Filter ${index + 1} operator` }, core.operators(field).map(op => option(op, operatorLabels[op])));
      ops.value = filter.operator;
      fieldSelect.addEventListener("change", () => {
        filter.field = fieldSelect.value; filter.operator = "eq";
        filter.value = fields.find(item => item.name === filter.field)?.type === "boolean" ? "true" : "";
        clearResults(); renderSettings();
      });
      ops.addEventListener("change", () => { filter.operator = ops.value; clearResults(); renderSettings(); });
      const row = el("div", { className: "data-export-filter" }, [fieldSelect, ops]);
      if (!["empty", "notEmpty"].includes(filter.operator)) {
        let input;
        if (field?.type === "boolean") input = el("select", {}, [option("true", "True"), option("false", "False")]);
        else if (field?.type === "picklist") input = el("select", {}, [option("", "Choose a value"), ...(field.picklistValues || []).filter(item => item.active !== false).map(item => option(item.value, item.label || item.value))]);
        else input = el("input", { type: field?.type === "date" ? "date" : field?.type === "datetime" ? "datetime-local" : field?.type === "time" ? "time" : "text", placeholder: field?.type === "datetime" ? "UTC date/time" : "Value" });
        input.setAttribute("aria-label", `Filter ${index + 1} value${field?.type === "datetime" ? " (UTC)" : ""}`);
        input.value = filter.value;
        input.addEventListener("input", () => { filter.value = input.value; clearResults(); });
        input.addEventListener("change", () => { filter.value = input.value; clearResults(); });
        row.appendChild(input);
        if (field?.type === "datetime") row.appendChild(el("span", { textContent: "UTC" }));
      }
      row.appendChild(button("Remove", () => { config.filters.splice(index, 1); clearResults(); renderSettings(); }));
      filterSection.appendChild(row);
    });
    filterSection.appendChild(button("Add filter", () => {
      const field = config.fields.find(item => core.operators(item).length);
      if (!field) { setStatus("This object has no supported filterable fields.", false, true); return; }
      config.filters.push({ field: field.name, operator: "eq", value: field.type === "boolean" ? "true" : "" });
      clearResults(); renderSettings();
    }));
    if (!config.filters.length) filterSection.appendChild(el("p", { textContent: "No filters: all accessible records will be exported." }));
  }
  async function loadObjects() {
    const generation = ++state.generation;
    state.hostname = SFPanel.getHostname();
    state.objects = []; state.configs.clear(); state.active = ""; state.busy = true;
    preview.textContent = ""; render();
    if (!state.hostname) {
      state.busy = false; render(); setStatus("Connect to a Salesforce org to export records.", false, true); return;
    }
    setStatus("Loading queryable objects...", true);
    try {
      const result = await send({ type: "getObjects", hostname: state.hostname });
      if (generation !== state.generation) return;
      if (!Array.isArray(result.objects)) throw new Error("Salesforce returned no object catalog.");
      state.objects = result.objects.filter(object => object.queryable).sort((a, b) => a.label.localeCompare(b.label));
      setStatus("");
    } catch (error) {
      if (generation === state.generation) setStatus(`Couldn't load objects: ${error.message}`, false, true);
    } finally {
      if (generation === state.generation) { state.busy = false; render(); }
    }
  }
  function showPreview(config, records) {
    preview.textContent = "";
    const fields = config.fields.filter(field => config.selected.has(field.name)).map(field => field.name);
    const body = el("tbody");
    records.forEach(record => body.appendChild(el("tr", {}, fields.map(name => el("td", { className: name === "Id" ? "data-export-id" : "", textContent: record[name] == null ? "" : typeof record[name] === "object" ? JSON.stringify(record[name]) : String(record[name]) })))));
    preview.appendChild(el("table", { className: "configuration-table" }, [el("thead", {}, [el("tr", {}, fields.map(name => el("th", { className: name === "Id" ? "data-export-id" : "", textContent: name })))]), body]));
  }
  function download(name, content) {
    const url = URL.createObjectURL(content);
    const link = el("a", { href: url, download: name });
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function run(mode) {
    if (state.busy || [...state.configs.values()].some(config => !config.fields && !config.error)) return;
    const configs = mode === "export" ? [...state.configs.values()] : [state.configs.get(state.active)].filter(Boolean);
    if (!configs.length) return;
    let queries;
    try { queries = configs.map(config => ({ config, soql: core.query(config, mode) })); }
    catch (error) { setStatus(error.message, false, true); return; }
    if (mode === "export" && !confirm(`Export records from ${configs.length} object(s) in ${state.hostname}?\n\n${configs.map(config => `${config.name}: ${config.filters.length ? `${config.filters.length} filter(s)` : "ALL accessible records (no filters)"}`).join("\n")}\n\nAll result pages will be downloaded. Large exports use browser memory; narrow the filters if necessary. Text that could be interpreted as a spreadsheet formula is prefixed with an apostrophe in CSV. No Salesforce records are changed.`)) return;
    const generation = ++state.generation;
    const hostname = state.hostname;
    let currentObject = "";
    const check = () => {
      if (generation !== state.generation || hostname !== SFPanel.getHostname()) throw new Error("The export was cancelled or the connected org changed.");
    };
    state.busy = true; preview.textContent = ""; render();
    try {
      if (mode === "export" && configs.length > 1 && typeof JSZip === "undefined") throw new Error("ZIP library unavailable. Reload the extension.");
      const zip = mode === "export" && configs.length > 1 ? new JSZip() : null;
      let singleCsv = "";
      const counts = [];
      for (const { config, soql } of queries) {
        currentObject = config.name;
        check();
        setStatus(`${mode === "count" ? "Counting" : "Retrieving"} ${config.name}...`, true);
        if (mode === "count") {
          const result = await send({ type: "restRequest", hostname, method: "GET", path: `/services/data/${SFPanel.API_VERSION}/query/?q=${encodeURIComponent(soql)}` });
          check();
          if (!Number.isInteger(result.data?.totalSize)) throw new Error("Salesforce returned no record count.");
          setStatus(`${config.name}: ${result.data.totalSize.toLocaleString()} matching records.`);
          return;
        }
        const records = await core.fetchRecords(send, hostname, soql, (count, total) => setStatus(`${config.name}: retrieved ${count.toLocaleString()}${Number.isInteger(total) ? ` of ${total.toLocaleString()}` : ""} records...`, true), check);
        counts.push(`${config.name}: ${records.length.toLocaleString()}`);
        if (mode === "preview") {
          showPreview(config, records);
          setStatus(`${config.name}: showing ${records.length} sample record(s), maximum 20. Use Count records for the full matching count.`);
          return;
        }
        const fields = config.fields.filter(field => config.selected.has(field.name)).map(field => field.name);
        const csv = core.csv(fields, records);
        if (zip) zip.file(`${config.name}.csv`, csv); else singleCsv = csv;
      }
      check();
      setStatus("Preparing download...", true);
      const content = zip ? await zip.generateAsync({ type: "blob", compression: "DEFLATE" }) : new Blob([singleCsv], { type: "text/csv;charset=utf-8" });
      check();
      const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
      download(`${hostname}_${configs.length === 1 ? configs[0].name : "records"}_${timestamp}.${zip ? "zip" : "csv"}`, content);
      setStatus(`Export complete. ${counts.join("; ")} record(s). All result pages included. CSV formula-like text is prefixed with an apostrophe.`);
    } catch (error) {
      if (generation === state.generation) setStatus(`${currentObject ? `${currentObject}: ` : ""}${error.message} No export file was downloaded.`, false, true);
    } finally {
      if (generation === state.generation) { state.busy = false; render(); }
    }
  }
  search.addEventListener("input", renderObjects);
  active.addEventListener("change", () => { state.active = active.value; clearResults(); render(); });
  panel.addEventListener("tabpanelshow", () => { if (!state.hostname && !state.busy) loadObjects(); });
  SFPanel.registerTab("dataTransfer", {
    onShow() {
      if (typeof DataImportPanel !== "undefined") DataImportPanel?.onShow();
      if (!panel.hidden && !state.hostname && !state.busy) loadObjects();
    },
    onHostnameChange() {
      if (typeof DataImportPanel !== "undefined") DataImportPanel?.onHostnameChange();
      state.generation += 1;
      state.hostname = null; state.objects = []; state.configs.clear(); state.active = ""; state.busy = false;
      preview.textContent = ""; render();
      setStatus("Org changed. Select objects again before exporting.");
      if (SFPanel.getActiveTab() === "dataTransfer" && !panel.hidden) loadObjects();
    }
  });
  render();
})(SFPanel.forTools("dataTransfer"));
