// js/permissions.js - read-only Profile and Permission Set explorer.
// SECURITY_NOTE: Salesforce values are rendered with textContent only.

((SFPanel) => {
  const searchInput = document.getElementById("permissionsSearch");
  const refreshButton = document.getElementById("permissionsRefresh");
  const statusEl = document.getElementById("permissionsStatus");
  const listEl = document.getElementById("permissionsList");
  const emptyEl = document.getElementById("permissionsEmpty");
  const detailEl = document.getElementById("permissionsDetail");
  const detailTitle = document.getElementById("permissionsDetailTitle");
  const detailStatus = document.getElementById("permissionsDetailStatus");
  const detailContent = document.getElementById("permissionsDetailContent");
  const detailTabs = Array.from(document.querySelectorAll("[data-permissions-view]"));
  const typeTabs = Array.from(document.querySelectorAll("[data-permissions-type]"));
  const resizeHandle = document.getElementById("permissionsResizeHandle");
  const split = document.querySelector(".permissions-split");
  const fieldControls = document.getElementById("permissionsFieldControls");
  const fieldObject = document.getElementById("permissionsFieldObject");
  let catalogHostname = null;
  let detailRevision = 0;
  let listRevision = 0;

  let records = [];
  let selectedRecord = null;
  let loadedHostname = null;
  let activeView = "objects";
  let activeType = "profile";
  let userFieldNames = null;
  let userReferenceFields = null;

  function setStatus(message, isError = true) {
    statusEl.textContent = message || "";
    statusEl.style.color = isError && message ? "#c00" : "";
  }

  function setDetailStatus(message, isError = true) {
    detailStatus.textContent = message || "";
    detailStatus.style.color = isError && message ? "#c00" : "";
  }

  async function query(query, hostname = SFPanel.getHostname(), tooling = false) {
    let path = `/services/data/${SFPanel.API_VERSION}/${tooling ? "tooling/" : ""}query/?q=${encodeURIComponent(query)}`;
    const seen = new Set(), records = [];
    let totalSize;
    while (path) {
      if (seen.has(path)) throw new Error("Salesforce repeated a query page.");
      seen.add(path);
      const { data } = await SFPanel.sendMessage({ type: "restRequest", hostname, method: "GET", path });
      if (!Array.isArray(data?.records) || typeof data.done !== "boolean") throw new Error("Incomplete Salesforce query response.");
      if (Number.isInteger(data.totalSize)) {
        if (totalSize !== undefined && totalSize !== data.totalSize) throw new Error("Salesforce query size changed between pages.");
        totalSize = data.totalSize;
      }
      records.push(...data.records);
      if (data.done) {
        if (totalSize !== undefined && records.length !== totalSize) throw new Error("Incomplete Salesforce query results.");
        return records;
      }
      // SECURITY_NOTE: Only Salesforce query cursors may be followed; never arbitrary URLs.
      if (typeof data.nextRecordsUrl !== "string" ||
        !/^\/services\/data\/v\d+\.\d+\/(?:tooling\/)?query\/[A-Za-z0-9_-]+(?:\?[^#]*)?$/.test(data.nextRecordsUrl)) {
        throw new Error("Invalid Salesforce query next page.");
      }
      path = data.nextRecordsUrl;
    }
  }

  async function loadFieldDetail(hostname, current, parentId) {
    if (catalogHostname !== hostname) {
      const { data } = await SFPanel.sendMessage({
        type: "restRequest", hostname, method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/sobjects/`
      });
      if (!current()) return;
      if (!Array.isArray(data?.sobjects)) throw new Error("Invalid Salesforce object catalog.");
      fieldObject.textContent = "";
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Choose an object";
      fieldObject.appendChild(placeholder);
      data.sobjects.filter(item => /^[A-Za-z_][A-Za-z0-9_]*$/.test(item.name) &&
        !/__missing label__/i.test(item.label || ""))
        .sort((a, b) => String(a.label || a.name).localeCompare(String(b.label || b.name)))
        .forEach(item => {
          const option = document.createElement("option");
          option.value = item.name;
          option.textContent = `${item.label || item.name} (${item.name})`;
          fieldObject.appendChild(option);
        });
      fieldObject.value = "";
      catalogHostname = hostname;
    }
    if (!current()) return;
    const name = fieldObject.value;
    if (!name) {
      setDetailStatus("Choose an object to load its fields.", false);
      return;
    }
    // SECURITY_NOTE: Validate identifiers before interpolating the object-scoped SOQL.
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || !/^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/.test(parentId)) {
      throw new Error("Invalid Salesforce object or permission set identifier.");
    }
    const [description, permissions, definitions, objectPermissions] = await Promise.all([
      SFPanel.sendMessage({ type: "restRequest", hostname, method: "GET",
        path: `/services/data/${SFPanel.API_VERSION}/sobjects/${name}/describe` }),
      query(`SELECT SobjectType, Field, PermissionsRead, PermissionsEdit FROM FieldPermissions WHERE ParentId = '${parentId}' AND SobjectType = '${name}' ORDER BY Field`, hostname),
      query(`SELECT QualifiedApiName, IsPermissionable FROM EntityParticle WHERE EntityDefinition.QualifiedApiName = '${name}'`, hostname, true),
      query(`SELECT PermissionsRead, PermissionsEdit FROM ObjectPermissions WHERE ParentId = '${parentId}' AND SobjectType = '${name}'`, hostname)
    ]);
    if (!current()) return;
    if (!Array.isArray(description.data?.fields)) throw new Error("Invalid Salesforce field inventory.");
    const byName = new Map(permissions.map(row => [row.Field, row]));
    const fieldDefinitions = new Map(definitions.map(field => [field.QualifiedApiName, field]));
    const objectGrant = objectPermissions[0];
    if (objectPermissions.length > 1 || objectGrant &&
      (typeof objectGrant.PermissionsRead !== "boolean" || typeof objectGrant.PermissionsEdit !== "boolean")) {
      throw new Error("Invalid object permission values. No system-field permissions were inferred.");
    }
    const excludedSetupFields = new Set([
      "Id", "CreatedDate", "LastModifiedDate", "SystemModstamp", "IsDeleted",
      "LastActivityDate", "LastViewedDate", "LastReferencedDate"
    ]);
    const readOnlySystemFields = new Set(["CreatedById", "LastModifiedById"]);
    function resolvePermission(field) {
      const explicit = byName.get(`${name}.${field.name}`);
      if (explicit) {
        if (typeof explicit.PermissionsRead !== "boolean" || typeof explicit.PermissionsEdit !== "boolean") {
          throw new Error(`Invalid field permission values for ${field.name}.`);
        }
        return { read: explicit.PermissionsRead, edit: explicit.PermissionsEdit, source: "Explicit field grant" };
      }
      const permissionable = fieldDefinitions.get(field.name)?.IsPermissionable;
      if (typeof permissionable !== "boolean") {
        throw new Error(`Cannot determine whether ${field.name} supports field-level security. No permission values were inferred.`);
      }
      if (permissionable) return { read: false, edit: false, source: "No field grant (FLS-controlled)" };
      // SECURITY_NOTE: Never use the connected user's createable/updateable flags as the selected owner's grants.
      const editableSystemField = field.name === "OwnerId" || field.name === "RecordTypeId" ||
        (field.nameField === true && field.autoNumber !== true);
      const knownReadOnly = readOnlySystemFields.has(field.name) || field.calculated === true || field.autoNumber === true;
      return {
        read: objectGrant?.PermissionsRead === true,
        edit: editableSystemField ? objectGrant?.PermissionsEdit === true : knownReadOnly ? false : null,
        source: editableSystemField || knownReadOnly
          ? "Object-derived; not independently FLS-controlled"
          : "Object-derived read; system-field edit rule unavailable"
      };
    }
    const rows = description.data.fields.filter(field => !excludedSetupFields.has(field.name)).map(field => ({
      name: field.name, label: field.label || field.name, ...resolvePermission(field)
    }));
    const known = new Set(rows.map(row => row.name));
    for (const permission of permissions) {
      const field = permission.Field.slice(name.length + 1);
      if (!known.has(field) && !excludedSetupFields.has(field)) rows.push({
        name: field, label: "Not in connected-user field inventory",
        read: permission.PermissionsRead, edit: permission.PermissionsEdit, source: "Explicit field grant"
      });
    }
    rows.sort((a, b) => a.label.localeCompare(b.label) || a.name.localeCompare(b.name));
    const displayedRows = rows.filter(row => row.edit !== null);
    renderTable(displayedRows, [
      { label: "Field Name", value: row => row.label },
      { label: "Field API Name", value: row => row.name },
      { label: "Read", value: row => row.read, checkbox: true },
      { label: "Edit", value: row => row.edit, checkbox: true }
    ]);
    const count = document.createElement("span");
    count.className = "permissions-field-count";
    count.setAttribute("role", "status");
    count.textContent = `${displayedRows.length} fields loaded for ${name}; ${permissions.length} explicit permission records.`;
    const actions = detailContent.querySelector(".permissions-table-actions");
    if (actions) actions.appendChild(count);
    else detailContent.appendChild(count);
    setDetailStatus("", false);
  }

  async function getUserFieldNames() {
    if (userFieldNames) return userFieldNames;
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/sobjects/User/describe`
    });
    const describedFields = result.data.fields || [];
    userFieldNames = describedFields
      .filter((field) => field.filterable && field.name !== "Id")
      .map((field) => field.name);
    userReferenceFields = describedFields
      .filter((field) => userFieldNames.includes(field.name) && field.relationshipName && field.name.endsWith("Id"))
      .map((field) => ({ fieldName: field.name, relationshipName: field.relationshipName }));
    if (!userFieldNames.length) {
      userFieldNames = ["Name", "Username", "Alias", "Email", "IsActive", "UserType", "TimeZoneSidKey", "LocaleSidKey", "LanguageLocaleKey", "LastLoginDate", "CreatedDate", "LastModifiedDate", "ProfileId", "UserRoleId"];
      userReferenceFields = [
        { fieldName: "ProfileId", relationshipName: "Profile" },
        { fieldName: "UserRoleId", relationshipName: "UserRole" }
      ];
    }
    return userFieldNames;
  }

  function getSetupRecordUrl(record) {
    const setupHostname = SFPanel.getHostname().replace(".my.salesforce.com", ".my.salesforce-setup.com");
    const setupPage = record.listType === "profile"
      ? "EnhancedProfiles"
      : record.listType === "permissionSet"
        ? "PermSets"
        : "ManageUsers";
    return `https://${setupHostname}/lightning/setup/${setupPage}/page?address=%2F${encodeURIComponent(record.setupRecordId || record.Id)}`;
  }

  function renderList() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    const filtered = records
      .filter((record) => record.listType === activeType && (!searchTerm || record.displayName.toLowerCase().includes(searchTerm)))
      .sort((left, right) => left.displayName.localeCompare(right.displayName));
    listEl.textContent = "";
    if (!filtered.length) {
      const row = document.createElement("li");
      row.className = "object-row";
      row.textContent = `No ${activeType === "permissionSet" ? "permission sets" : `${activeType}s`} found.`;
      listEl.appendChild(row);
      return;
    }
    const fragment = document.createDocumentFragment();
    filtered.forEach((record) => {
      const item = document.createElement("li");
      item.className = "object-row";
      const main = document.createElement("div");
      main.className = "object-row-main";
      main.classList.toggle("active", selectedRecord?.Id === record.Id);
      const label = document.createElement("span");
      label.className = "object-label";
      label.textContent = record.displayName;
      main.appendChild(label);
      const idLink = document.createElement("a");
      idLink.className = "object-name soql-id-link";
      idLink.href = getSetupRecordUrl(record);
      idLink.target = "_blank";
      idLink.rel = "noopener noreferrer";
      idLink.title = `Open ${record.displayName} in Salesforce`;
      idLink.textContent = record.setupRecordId || record.Id;
      idLink.addEventListener("click", (event) => event.stopPropagation());
      main.appendChild(idLink);
      main.addEventListener("click", () => selectRecord(record));
      item.appendChild(main);
      fragment.appendChild(item);
    });
    listEl.appendChild(fragment);
  }

  function renderTypeTabCounts() {
    const counts = records.reduce((result, record) => {
      result[record.listType] = (result[record.listType] || 0) + 1;
      return result;
    }, {});
    typeTabs.forEach((tab) => {
      const type = tab.dataset.permissionsType;
      const label = type === "permissionSet" ? "Permission Set" : type[0].toUpperCase() + type.slice(1);
      tab.textContent = `${label} (${counts[type] || 0})`;
    });
  }

  function renderTable(rows, columns) {
    detailContent.textContent = "";
    if (!rows.length) {
      detailContent.textContent = "No permissions found.";
      return;
    }
    const getValue = (row, column) => column.checkbox
      ? column.value(row) === null ? "Unavailable" : column.value(row) ? "TRUE" : "FALSE"
      : String(column.value(row) ?? "");
    const tableText = [
      columns.map((column) => column.label),
      ...rows.map((row) => columns.map((column) => getValue(row, column)))
    ];
    const actions = document.createElement("div");
    actions.className = "permissions-table-actions";
    const copyButton = document.createElement("button");
    copyButton.type = "button";
    copyButton.textContent = "Copy";
    copyButton.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(tableText.map((row) => row.join("\t")).join("\n"));
        setDetailStatus("Copied table.", false);
      } catch {
        setDetailStatus("Unable to copy table.");
      }
    });
    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.textContent = "Save";
    saveButton.addEventListener("click", () => {
      const quoteCsv = (value) => `"${String(value).replace(/"/g, '""')}"`;
      const csv = tableText.map((row) => row.map(quoteCsv).join(",")).join("\r\n");
      const link = document.createElement("a");
      link.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
      link.download = `${selectedRecord?.displayName || "salesforce"}-${activeView}.csv`.replace(/[^a-z0-9._-]+/gi, "-");
      link.click();
      URL.revokeObjectURL(link.href);
    });
    actions.append(copyButton, saveButton);
    const table = document.createElement("table");
    table.className = "configuration-table";
    const headerRow = document.createElement("tr");
    columns.forEach((column) => {
      const cell = document.createElement("th");
      cell.textContent = column.label;
      headerRow.appendChild(cell);
    });
    const thead = document.createElement("thead");
    thead.appendChild(headerRow);
    const tbody = document.createElement("tbody");
    rows.forEach((row) => {
      const tr = document.createElement("tr");
      columns.forEach((column) => {
        const cell = document.createElement("td");
        if (column.checkbox && column.value(row) !== null) {
          const checkbox = document.createElement("input");
          checkbox.type = "checkbox";
          checkbox.checked = Boolean(column.value(row));
          checkbox.disabled = true;
          checkbox.setAttribute("aria-label", column.label);
          cell.appendChild(checkbox);
        } else if (column.link && column.link(row)) {
          const link = document.createElement("a");
          link.className = "soql-id-link";
          link.href = column.link(row);
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          link.textContent = getValue(row, column);
          cell.appendChild(link);
        } else {
          cell.textContent = getValue(row, column);
        }
        tr.appendChild(cell);
      });
      tbody.appendChild(tr);
    });
    table.append(thead, tbody);
    detailContent.append(actions, table);
  }

  async function loadDetail() {
    const revision = ++detailRevision;
    if (!selectedRecord) return;
    const hostname = SFPanel.getHostname();
    const current = () => revision === detailRevision && hostname === SFPanel.getHostname();
    const renderCurrentTable = (rows, columns) => { if (current()) renderTable(rows, columns); };
    fieldControls.hidden = activeView !== "fields" || selectedRecord.listType === "user";
    setDetailStatus("Loading...", false);
    detailContent.textContent = "";
    try {
      if (activeView === "fields" && selectedRecord.listType !== "user") {
        await loadFieldDetail(hostname, current, selectedRecord.Id);
        return;
      }
      if (selectedRecord.listType === "user") {
        const fields = await getUserFieldNames();
        const relationshipFields = userReferenceFields
          .map((field) => `${field.relationshipName}.Name`)
          .filter((field, index, values) => values.indexOf(field) === index);
        const user = (await query(`SELECT Id, ${[...fields, ...relationshipFields].join(", ")} FROM User WHERE Id = '${selectedRecord.Id}' LIMIT 1`))[0];
        if (!user) throw new Error("User was not found.");
        const referenceNames = new Map(userReferenceFields.map((field) => [field.fieldName, user[field.relationshipName]?.Name]));
        const values = [{ field: "Id", value: user.Id, isId: true }, ...Object.entries(user)
          .filter(([field, value]) => field !== "attributes" && value !== null && value !== "")
          .filter(([field]) => field !== "Id")
          .filter(([field]) => !userReferenceFields.some((reference) => reference.relationshipName === field))
          .map(([field, value]) => ({
            field: referenceNames.get(field) ? field.slice(0, -2) : field,
            value: referenceNames.get(field) || (typeof value === "object" ? JSON.stringify(value) : String(value))
          }))];
        renderCurrentTable(values, [
          { label: "Field", value: (row) => row.field },
          {
            label: "Value",
            value: (row) => row.value,
            link: (row) => row.isId ? getSetupRecordUrl({ Id: row.value, listType: "user" }) : ""
          }
        ]);
        if (current()) setDetailStatus("", false);
        return;
      }
      if (activeView === "objects") {
        const rows = await query(`SELECT SobjectType, PermissionsRead, PermissionsCreate, PermissionsEdit, PermissionsDelete, PermissionsViewAllRecords, PermissionsModifyAllRecords FROM ObjectPermissions WHERE ParentId = '${selectedRecord.Id}' ORDER BY SobjectType`);
        rows.sort((left, right) => String(left.SobjectType || "").localeCompare(String(right.SobjectType || "")));
        renderCurrentTable(rows, [
          { label: "Object", value: (row) => row.SobjectType || "" },
          { label: "Read", value: (row) => row.PermissionsRead, checkbox: true },
          { label: "Create", value: (row) => row.PermissionsCreate, checkbox: true },
          { label: "Edit", value: (row) => row.PermissionsEdit, checkbox: true },
          { label: "Delete", value: (row) => row.PermissionsDelete, checkbox: true },
          { label: "View All", value: (row) => row.PermissionsViewAllRecords, checkbox: true },
          { label: "Modify All", value: (row) => row.PermissionsModifyAllRecords, checkbox: true }
        ]);
      } else {
        const permissionSet = await query(`SELECT PermissionsApiEnabled, PermissionsViewAllData, PermissionsModifyAllData, PermissionsManageUsers, PermissionsCustomizeApplication, PermissionsAuthorApex, PermissionsModifyMetadata FROM PermissionSet WHERE Id = '${selectedRecord.Id}' LIMIT 1`);
        const row = permissionSet[0];
        if (!row) throw new Error("Permission set was not found.");
        renderCurrentTable([row], [
          { label: "API Enabled", value: (item) => item.PermissionsApiEnabled, checkbox: true },
          { label: "View All Data", value: (item) => item.PermissionsViewAllData, checkbox: true },
          { label: "Modify All Data", value: (item) => item.PermissionsModifyAllData, checkbox: true },
          { label: "Manage Users", value: (item) => item.PermissionsManageUsers, checkbox: true },
          { label: "Customize Application", value: (item) => item.PermissionsCustomizeApplication, checkbox: true },
          { label: "Author Apex", value: (item) => item.PermissionsAuthorApex, checkbox: true },
          { label: "Modify Metadata", value: (item) => item.PermissionsModifyMetadata, checkbox: true }
        ]);
      }
      if (current()) setDetailStatus("", false);
    } catch (error) {
      if (current()) setDetailStatus(error.message || "Unable to load permissions.");
    }
  }

  function selectRecord(record) {
    selectedRecord = record;
    detailTitle.textContent = record.displayName;
    emptyEl.hidden = true;
    detailEl.hidden = false;
    renderList();
    detailTabs.forEach((tab) => { tab.hidden = record.listType === "user"; });
    loadDetail();
  }

  function formatDate(value) {
    return value ? new Date(value).toLocaleString() : "";
  }

  async function loadPermissions() {
    const revision = ++listRevision;
    ++detailRevision;
    catalogHostname = null;
    fieldObject.value = "";
    selectedRecord = null;
    detailContent.textContent = "";
    detailEl.hidden = true;
    emptyEl.hidden = false;
    const hostname = SFPanel.getHostname();
    if (!hostname) return setStatus("No Salesforce tab detected.");
    refreshButton.disabled = true;
    setStatus("Loading profiles and permission sets...", false);
    try {
      const permissionSets = await query("SELECT Id, Name, Label, IsOwnedByProfile, Profile.Id, Profile.Name FROM PermissionSet ORDER BY Label");
      if (revision !== listRevision || hostname !== SFPanel.getHostname()) return;
      const users = await query("SELECT Id, Name, Username, Profile.Name FROM User ORDER BY Name", hostname);
      if (revision !== listRevision || hostname !== SFPanel.getHostname()) return;
      records = permissionSets.map((record) => ({
        ...record,
        listType: record.IsOwnedByProfile ? "profile" : "permissionSet",
        setupRecordId: record.IsOwnedByProfile ? record.Profile?.Id || record.Id : record.Id,
        displayName: record.IsOwnedByProfile ? record.Profile?.Name || record.Label || record.Name : record.Label || record.Name
      })).concat(users.map((record) => ({ ...record, listType: "user", displayName: record.Name || record.Username })));
      loadedHostname = hostname;
      searchInput.disabled = false;
      renderTypeTabCounts();
      renderList();
      setStatus("", false);
    } catch (error) {
      if (revision !== listRevision || hostname !== SFPanel.getHostname()) return;
      records = [];
      renderTypeTabCounts();
      renderList();
      setStatus(error.message || "Unable to load permissions.");
    } finally {
      if (revision === listRevision) refreshButton.disabled = false;
    }
  }

  searchInput.addEventListener("input", renderList);
  fieldObject.addEventListener("change", loadDetail);
  refreshButton.addEventListener("click", loadPermissions);
  typeTabs.forEach((tab) => tab.addEventListener("click", () => {
    activeType = tab.dataset.permissionsType;
    ++detailRevision;
    selectedRecord = null;
    detailEl.hidden = true;
    emptyEl.hidden = false;
    typeTabs.forEach((button) => button.classList.toggle("active", button === tab));
    detailTabs.forEach((button) => { button.hidden = false; });
    renderList();
  }));
  detailTabs.forEach((tab) => tab.addEventListener("click", () => {
    activeView = tab.dataset.permissionsView;
    detailTabs.forEach((button) => button.classList.toggle("active", button === tab));
    loadDetail();
  }));

  (function initPermissionsResize() {
    const MIN_LIST_WIDTH = 180;
    const MIN_DETAIL_WIDTH = 300;
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function setWidth(width) {
      const maxWidth = Math.max(MIN_LIST_WIDTH, split.getBoundingClientRect().width - MIN_DETAIL_WIDTH - 5);
      const clamped = Math.min(maxWidth, Math.max(MIN_LIST_WIDTH, width));
      split.style.gridTemplateColumns = `${Math.round(clamped)}px 5px minmax(${MIN_DETAIL_WIDTH}px, 1fr)`;
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    resizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      dragStartX = event.clientX;
      dragStartWidth = listEl.getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    });
    document.addEventListener("pointermove", (event) => {
      if (isDragging) setWidth(dragStartWidth + event.clientX - dragStartX);
    });
    document.addEventListener("pointerup", endDrag);
    resizeHandle.addEventListener("keydown", (event) => {
      const step = event.key === "ArrowLeft" ? -20 : event.key === "ArrowRight" ? 20 : 0;
      if (!step) return;
      event.preventDefault();
      setWidth(listEl.getBoundingClientRect().width + step);
    });
  })();

  SFPanel.registerTab("permissionsExplorer", {
    onShow() {
      if (loadedHostname !== SFPanel.getHostname()) loadPermissions();
    },
    onHostnameChange() {
      ++detailRevision;
      ++listRevision;
      catalogHostname = null;
      fieldObject.textContent = "";
      loadedHostname = null;
      userFieldNames = null;
      userReferenceFields = null;
      records = [];
      renderTypeTabCounts();
      selectedRecord = null;
      searchInput.disabled = true;
      listEl.textContent = "";
      detailEl.hidden = true;
      emptyEl.hidden = false;
      if (SFPanel.getActiveTab() === "permissionsExplorer") loadPermissions();
    }
  });
})(SFPanel.forTools("permissionsExplorer"));