// Shared read-only configuration surfaces for Object Explorer and cross-org comparison.
// SECURITY_NOTE: Requests are GET-only; API names are allow-listed and SOQL literals escaped.
const ObjectConfigCore = (() => {
  const categories = [
    ["fields", "Fields"], ["recordTypes", "Record Types"], ["validation", "Validation Rules"],
    ["layouts", "Layouts"], ["listViews", "List Views"], ["compactLayouts", "Compact Layouts"],
    ["fieldSets", "Field Sets"], ["webLinks", "Buttons, Links, and Actions"],
    ["objectAccess", "Object Access"], ["fieldAccess", "Field Access"]
  ];
  const identities = {
    fields: ["API Name"], recordTypes: ["NamespacePrefix", "DeveloperName"], validation: ["ValidationName"],
    layouts: ["NamespacePrefix", "Name"], listViews: ["NamespacePrefix", "DeveloperName"],
    compactLayouts: ["NamespacePrefix", "DeveloperName"], fieldSets: ["NamespacePrefix", "DeveloperName"],
    webLinks: ["Name"], objectAccess: ["Access Type", "Owner API Name"],
    fieldAccess: ["Field", "Access Type", "Owner API Name"]
  };
  const ignored = new Set(["attributes", "Id", "CreatedDate", "LastModifiedDate"]);
  function identifier(name) {
    if (typeof name !== "string" || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) throw new Error("Invalid Salesforce API name.");
    return name;
  }
  function literal(value) { return `'${String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`; }
  async function load(send, hostname, version, name, category, check = () => {}) {
    identifier(name);
    if (!/^v\d+\.\d+$/.test(version) || (!identities[category] && category !== "fieldInventory")) throw new Error("Invalid object configuration request.");
    if (name === "Activity" && category !== "fields") throw new Error("Activity is shared by Task and Event. Select Task or Event for this view.");
    const base = `/services/data/${version}`;
    async function get(path) {
      check();
      const response = await send({ type: "restRequest", hostname, method: "GET", path });
      check();
      if (!response || !response.data || typeof response.data !== "object") throw new Error("Salesforce returned invalid configuration data.");
      return response.data;
    }
    async function query(soql, tooling = false) {
      let path = `${base}/${tooling ? "tooling/" : ""}query/?q=${encodeURIComponent(soql)}`;
      const rows = [], visited = new Set();
      let expected = null;
      while (path) {
        if (visited.has(path)) throw new Error("Salesforce repeated a configuration result page.");
        visited.add(path);
        const data = await get(path);
        if (!Array.isArray(data.records) || typeof data.done !== "boolean") throw new Error("Salesforce returned an incomplete configuration query.");
        if (Number.isInteger(data.totalSize)) {
          if (expected !== null && expected !== data.totalSize) throw new Error("Configuration result count changed during retrieval.");
          expected = data.totalSize;
        }
        rows.push(...data.records);
        if (data.done) {
          if (expected !== null && expected !== rows.length) throw new Error("Salesforce returned a truncated configuration result.");
          break;
        }
        if (typeof data.nextRecordsUrl !== "string" || !/^\/services\/data\/v\d+\.\d+\/(?:tooling\/)?query\/[A-Za-z0-9_-]+(?:\?[^#]*)?$/.test(data.nextRecordsUrl)) throw new Error("Salesforce returned an invalid configuration next page.");
        path = data.nextRecordsUrl;
      }
      return rows;
    }
    if (category === "fieldInventory") {
      const rows = await query(`SELECT QualifiedApiName FROM FieldDefinition WHERE EntityDefinition.QualifiedApiName = ${literal(name)}`, true);
      if (!rows.length || rows.some(row => typeof row.QualifiedApiName !== "string" || !row.QualifiedApiName)) throw new Error("Field-definition inventory is unavailable or incomplete; field absence cannot be verified.");
      return { rows, checkboxColumns: [] };
    }
    if (category === "fields") {
      const names = name === "Activity" ? ["Task", "Event"] : [name];
      const descriptions = await Promise.all(names.map(object => get(`${base}/sobjects/${object}/describe/`)));
      if (descriptions.some(data => !Array.isArray(data.fields))) throw new Error("Salesforce returned no field description.");
      if (descriptions.some((data, index) => data.name && data.name !== names[index])) throw new Error("Salesforce returned the description of a different object.");
      const fields = descriptions[0].fields.filter(field => descriptions.every(data => data.fields.some(other => other.name === field.name && other.type === field.type)));
      return { rows: fields.sort((a, b) => a.name.localeCompare(b.name)).map(field => ({
        "Field Label": field.label || "", "API Name": field.name, "Field Type": field.type,
        Length: field.length ?? "", Precision: field.precision ?? "", Scale: field.scale ?? "",
        Required: field.nillable === false && field.defaultedOnCreate !== true ? "Yes" : "No",
        Unique: field.unique ? "Yes" : "No", "External Id": field.externalId ? "Yes" : "No",
        "Default Value": field.defaultValue ?? "", "Reference To": (field.referenceTo || []).join("; "),
        "Picklist Values": (field.picklistValues || []).map(value => value.value).filter(Boolean).join("; ")
      })), checkboxColumns: [] };
    }
    const object = literal(name);
    let entity;
    if (category === "layouts" || category === "fieldSets") {
      const records = await query(`SELECT DurableId FROM EntityDefinition WHERE QualifiedApiName = ${object}`, true);
      if (records.length !== 1 || !records[0].DurableId) throw new Error(`EntityDefinition for ${name} is unavailable; configuration cannot be compared.`);
      entity = literal(records[0].DurableId);
    }
    const queries = {
      recordTypes: [`SELECT DeveloperName, NamespacePrefix, Name, IsActive, Description, CreatedDate, LastModifiedDate FROM RecordType WHERE SobjectType = ${object} ORDER BY Name`, false],
      validation: [`SELECT Id, ValidationName, Active, ErrorMessage FROM ValidationRule WHERE EntityDefinition.QualifiedApiName = ${object}`, true],
      layouts: [`SELECT Name, LayoutType, NamespacePrefix, ManageableState, CreatedDate, LastModifiedDate FROM Layout WHERE EntityDefinitionId = ${entity} ORDER BY Name`, true],
      listViews: [`SELECT DeveloperName, Name, NamespacePrefix, IsSoqlCompatible FROM ListView WHERE SobjectType = ${object} ORDER BY Name`, false],
      compactLayouts: [`SELECT DeveloperName, MasterLabel, NamespacePrefix, ManageableState, CreatedDate, LastModifiedDate FROM CompactLayout WHERE SobjectType = ${object} ORDER BY MasterLabel`, true],
      fieldSets: [`SELECT DeveloperName, MasterLabel, Description, NamespacePrefix, CreatedDate, LastModifiedDate FROM FieldSet WHERE EntityDefinitionId = ${entity} ORDER BY MasterLabel`, true],
      webLinks: [`SELECT Name, MasterLabel, Description, LinkType, OpenType, Url, DisplayType, CreatedDate, LastModifiedDate FROM WebLink WHERE EntityDefinition.QualifiedApiName = ${object} ORDER BY MasterLabel`, true]
    };
    if (category === "objectAccess" || category === "fieldAccess") {
      const fieldAccess = category === "fieldAccess";
      const columns = fieldAccess ? ["Read", "Edit"] : ["Read", "Create", "Edit", "Delete", "View All", "Modify All"];
      const apiColumns = fieldAccess ? ["PermissionsRead", "PermissionsEdit"] : ["PermissionsRead", "PermissionsCreate", "PermissionsEdit", "PermissionsDelete", "PermissionsViewAllRecords", "PermissionsModifyAllRecords"];
      const records = await query(`SELECT ${fieldAccess ? "Field, " : ""}${apiColumns.join(", ")}, Parent.Name, Parent.Label, Parent.NamespacePrefix, Parent.IsOwnedByProfile, Parent.Profile.Name FROM ${fieldAccess ? "FieldPermissions" : "ObjectPermissions"} WHERE SObjectType = ${object}${fieldAccess ? " ORDER BY Field" : ""}`);
      return { checkboxColumns: columns, rows: records.map(record => {
        const parent = record.Parent;
        const owner = parent?.IsOwnedByProfile ? parent.Profile?.Name : parent?.Name;
        if (!owner) throw new Error("Salesforce returned permissions without a stable profile/permission-set identity.");
        return {
          ...(fieldAccess ? { Field: record.Field } : {}),
          "Access Type": parent.IsOwnedByProfile ? "Profile" : "Permission Set",
          "Profile / Permission Set": parent.IsOwnedByProfile ? owner : parent.Label || owner,
          "Owner API Name": !parent.IsOwnedByProfile && parent.NamespacePrefix ? `${parent.NamespacePrefix}__${owner}` : owner,
          ...Object.fromEntries(columns.map((column, index) => [column, record[apiColumns[index]]]))
        };
      }) };
    }
    const [soql, tooling] = queries[category];
    const rows = await query(soql, tooling);
    if (category === "validation") {
      // Fetch one rule at a time: Tooling metadata requires individual record reads.
      for (const rule of rows) {
        const detail = await get(`${base}/tooling/sobjects/ValidationRule/${encodeURIComponent(rule.Id)}`);
        if (!detail.Metadata || typeof detail.Metadata !== "object") throw new Error(`Validation rule metadata unavailable: ${rule.ValidationName}.`);
        rule.ErrorConditionFormula = detail.Metadata.errorConditionFormula || "";
        rule.ErrorDisplayField = detail.Metadata.errorDisplayField || "";
      }
    }
    return { rows, checkboxColumns: [] };
  }
  function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
    return value ?? null;
  }
  function compare(category, source, target) {
    const keys = identities[category];
    if (!keys) throw new Error("Unknown configuration category.");
    function index(rows) {
      const map = new Map();
      for (const row of rows) {
        if (keys.some(key => key !== "NamespacePrefix" && (typeof row[key] !== "string" || !row[key]))) throw new Error("Configuration row is missing its comparison identity.");
        const key = JSON.stringify(keys.map(name => row[name] || ""));
        if (map.has(key)) throw new Error(`Duplicate comparison identity: ${key}.`);
        map.set(key, Object.fromEntries(Object.entries(row).filter(([name]) => !ignored.has(name))));
      }
      return map;
    }
    const left = index(source), right = index(target);
    return [...new Set([...left.keys(), ...right.keys()])].sort().map(key => {
      const a = left.get(key), b = right.get(key);
      const properties = [...new Set([...Object.keys(a || {}), ...Object.keys(b || {})])].sort();
      const differences = properties.filter(property => JSON.stringify(canonical(a?.[property])) !== JSON.stringify(canonical(b?.[property])))
        .map(property => ({ property, source: a?.[property] ?? null, target: b?.[property] ?? null }));
      return { key: JSON.parse(key).filter(Boolean).join(" / "), status: !a ? "Target only" : !b ? "Source only" : differences.length ? "Different" : "Same", source: a || null, target: b || null, differences };
    });
  }
  function verifyFieldPresence(rows, sourceInventory, targetInventory) {
    const inventories = [sourceInventory, targetInventory].map(records => new Set(records.map(row => row.QualifiedApiName)));
    return rows.map(row => {
      if (!["Source only", "Target only"].includes(row.status)) return row;
      const name = (row.source || row.target)["API Name"];
      const missingSide = row.source ? 1 : 0;
      if (inventories[missingSide].has(name)) return { ...row, status: "Unable to compare", reason: `Field ${name} exists in ${missingSide ? "target" : "source"} FieldDefinition but is not returned by REST Describe. Check field-level access and feature availability for that user.` };
      if (!inventories[1 - missingSide].has(name)) return { ...row, status: "Unable to compare", reason: `Field ${name} is not consistently represented in Describe and FieldDefinition; absence cannot be verified.` };
      return { ...row, reason: "Returned by Describe in one org and absent from the other org's accessible FieldDefinition inventory. Review permissions and enabled features before treating this as a schema difference." };
    });
  }
  return { categories, load, compare, verifyFieldPresence };
})();
if (typeof module !== "undefined" && module.exports) module.exports = ObjectConfigCore;
