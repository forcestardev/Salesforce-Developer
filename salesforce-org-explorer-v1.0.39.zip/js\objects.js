// js/objects.js — "Objects" tab: lists all sObjects for the current org and
// shows fields on demand. Registers itself with the shared SFPanel shell.

((SFPanel) => {
  const searchInput = document.getElementById("search");
  const refreshButton = document.getElementById("refresh");
  const statusEl = document.getElementById("objectsStatus");
  const summaryEl = document.getElementById("summary");
  const listEl = document.getElementById("objectList");
  const resizeHandle = document.getElementById("objectsResizeHandle");
  const objectRowTemplate = document.getElementById("objectRowTemplate");
  const fieldRowTemplate = document.getElementById("fieldRowTemplate");
  const objectDetail = document.getElementById("objectDetail");
  const objectDetailEmpty = document.getElementById("objectDetailEmpty");
  const objectDetailTitle = document.getElementById("objectDetailTitle");
  const objectDetailStatus = document.getElementById("objectDetailStatus");
  const objectDetailContent = document.getElementById("objectDetailContent");

  let allObjects = [];
  const fieldsCache = new Map();
  let loaded = false;
  let selectedObjectName = null;
  let detailGeneration = 0;
  const detailTabButtons = Array.from(objectDetail.querySelectorAll("[data-detail-tab]"));

  detailTabButtons.forEach((button) => {
    button.dataset.detailLabel = button.textContent.trim();
  });

  function setStatus(message) {
    statusEl.textContent = message || "";
  }

  function setSummary(text) {
    summaryEl.textContent = text || "";
  }

  async function getActiveTabContext(tabOverride) {
    if (tabOverride) return { url: tabOverride.url || "", title: tabOverride.title || "" };
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ? { url: tab.url || "", title: tab.title || "" } : null;
  }

  function findObjectFromActiveTab(context) {
    if (!context) return null;
    let url;
    try {
      url = new URL(context.url);
    } catch {
      url = null;
    }

    const path = url ? url.pathname : "";
    const apiMatch = path.match(/^\/lightning\/(?:r|o)\/([A-Za-z0-9_]+)/);
    const objectManagerMatch = path.match(/^\/lightning\/setup\/ObjectManager\/([A-Za-z0-9_]+)/);
    const keyPrefixMatch = path.match(/^\/([A-Za-z0-9]{3})\/o$/);
    const isActivityPage = /^\/lightning\/page\/activity\/?$/i.test(path);
    const candidates = [apiMatch?.[1], objectManagerMatch?.[1], isActivityPage ? "Activity" : null];
    const keyPrefix = keyPrefixMatch?.[1];

    let match = allObjects.find((object) =>
      candidates.some((candidate) => candidate && object.name.toLowerCase() === candidate.toLowerCase())
    );
    if (!match && keyPrefix) match = allObjects.find((object) => object.keyPrefix === keyPrefix);
    if (!match && context.title) {
      const title = context.title.toLowerCase();
      match = allObjects.find((object) =>
        title.includes(object.label.toLowerCase()) || title.includes(object.name.toLowerCase())
      );
    }
    return match || null;
  }

  function renderObjectList(objects) {
    listEl.textContent = "";
    const fragment = document.createDocumentFragment();

    for (const obj of objects) {
      const node = objectRowTemplate.content.firstElementChild.cloneNode(true);
      node.querySelector(".object-label").textContent = obj.label;
      node.querySelector(".object-name").textContent = obj.name;

      const badge = node.querySelector(".object-badge");
      if (obj.custom) badge.classList.add("show");

      const mainRow = node.querySelector(".object-row-main");
      mainRow.classList.toggle("active", obj.name === selectedObjectName);
      mainRow.addEventListener("click", () => openObjectDetail(obj));

      fragment.appendChild(node);
    }

    listEl.appendChild(fragment);
    setSummary(`${objects.length} object${objects.length === 1 ? "" : "s"}`);
  }

  function setDetailStatus(message, isError = true) {
    objectDetailStatus.textContent = message || "";
    objectDetailStatus.style.color = isError ? "#c00" : "inherit";
  }

  function resetDetailTabCounts() {
    detailTabButtons.forEach((button) => {
      button.textContent = button.dataset.detailLabel;
    });
  }

  function setActiveDetailTabCount(count) {
    const activeTab = detailTabButtons.find((button) => button.classList.contains("active"));
    if (activeTab) activeTab.textContent = `${activeTab.dataset.detailLabel} (${count})`;
  }

  function renderDetailTable(rows, checkboxColumns = []) {
    objectDetailContent.textContent = "";
    setActiveDetailTabCount(rows.length);
    if (!rows.length) {
      objectDetailContent.textContent = "No data returned.";
      return;
    }
    const columns = [...new Set(rows.flatMap((row) => Object.keys(row).filter((key) => key !== "attributes")))].slice(0, 12);
    let sortedRows = [...rows];
    let sortColumn = "";
    let sortDirection = "ascending";
    const table = document.createElement("table");
    table.className = "configuration-table";
    const head = document.createElement("tr");
    const body = document.createElement("tbody");

    function compareValues(left, right) {
      const leftNumber = Number(left);
      const rightNumber = Number(right);
      if (String(left).trim() !== "" && String(right).trim() !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) return leftNumber - rightNumber;
      return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
    }

    function renderRows() {
      body.textContent = "";
      sortedRows.forEach((row) => {
        const line = document.createElement("tr");
        columns.forEach((column) => {
          const cell = document.createElement("td");
          const value = row[column];
          if (checkboxColumns.includes(column)) {
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.checked = Boolean(value);
            checkbox.setAttribute("aria-label", `${column} permission`);
            cell.appendChild(checkbox);
          } else if (column === "Picklist Values" && value) {
            const values = String(value).split(";").map((item) => item.trim()).filter(Boolean);
            const preview = document.createElement("span");
            preview.className = "picklist-values-preview";
            preview.textContent = values.join("; ");
            const copyButton = document.createElement("button");
            copyButton.type = "button";
            copyButton.className = "picklist-values-copy";
            copyButton.textContent = "Copy";
            copyButton.setAttribute("aria-label", "Copy picklist values");
            copyButton.addEventListener("click", async () => {
              try {
                await navigator.clipboard.writeText(values.join("\n"));
                setDetailStatus(`${values.length} picklist value${values.length === 1 ? "" : "s"} copied.`, false);
              } catch {
                setDetailStatus("Unable to copy picklist values.");
              }
            });
            cell.append(preview, copyButton);
          } else {
            cell.textContent = value && typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
          }
          line.appendChild(cell);
        });
        body.appendChild(line);
      });
    }

    columns.forEach((column) => {
      const cell = document.createElement("th");
      const button = document.createElement("button");
      button.type = "button";
      button.className = "detail-sort-button";
      button.textContent = column;
      button.setAttribute("aria-label", `Sort by ${column}`);
      button.addEventListener("click", () => {
        sortDirection = sortColumn === column && sortDirection === "ascending" ? "descending" : "ascending";
        sortColumn = column;
        sortedRows = [...sortedRows].sort((left, right) => compareValues(left[column], right[column]) * (sortDirection === "ascending" ? 1 : -1));
        columns.forEach((headerColumn, index) => {
          const headerButton = head.cells[index].querySelector("button");
          headerButton.dataset.sortDirection = headerColumn === sortColumn ? sortDirection : "";
          headerButton.setAttribute("aria-label", `${headerColumn === sortColumn ? `${sortDirection === "ascending" ? "Ascending" : "Descending"}. ` : ""}Sort by ${headerColumn}`);
        });
        renderRows();
      });
      cell.appendChild(button);
      head.appendChild(cell);
    });
    const thead = document.createElement("thead");
    thead.appendChild(head);
    table.appendChild(thead);
    renderRows();
    table.appendChild(body);
    objectDetailContent.appendChild(table);
  }

  function renderRecordTable(records) {
    renderDetailTable(records.map((record) => {
      const flat = {};
      Object.entries(record).forEach(([key, value]) => {
        if (key !== "attributes") flat[key] = value;
      });
      return flat;
    }));
  }

  async function querySalesforce(query, tooling = false) {
    const hostname = SFPanel.getHostname();
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname,
      method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/${tooling ? "tooling/" : ""}query/?q=${encodeURIComponent(query)}`
    });
    return result.data.records || [];
  }

  async function loadObjectDetail(detailTab) {
    if (!selectedObjectName) return;
    const generation = ++detailGeneration;
    const hostname = SFPanel.getHostname(), objectName = selectedObjectName;
    setDetailStatus("Loading…", false);
    objectDetailContent.textContent = "";
    try {
      if (detailTab === "records") {
        const { fields } = await SFPanel.sendMessage({
          type: "getObjectFields",
          hostname: SFPanel.getHostname(),
          objectName: selectedObjectName
        });
        const queryFields = fields
          .map((field) => field.name)
          .filter((fieldName) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(fieldName))
          .slice(0, 25);
        if (!queryFields.length) throw new Error("This object has no readable fields.");
        const records = await querySalesforce(`SELECT ${queryFields.join(", ")} FROM ${selectedObjectName} LIMIT 50`);
        renderRecordTable(records);
      } else {
        const check = () => {
          if (generation !== detailGeneration || hostname !== SFPanel.getHostname() || objectName !== selectedObjectName) throw new Error("Object view changed.");
        };
        const result = await ObjectConfigCore.load(message => SFPanel.sendMessage(message), hostname, SFPanel.API_VERSION, objectName, detailTab, check);
        check();
        renderDetailTable(result.rows, result.checkboxColumns);
      }
      setDetailStatus("", false);
    } catch (err) {
      if (generation !== detailGeneration || hostname !== SFPanel.getHostname() || objectName !== selectedObjectName) return;
      const message = err.message || "Unable to load this view.";
      if (detailTab === "validation" && /400|404/.test(message)) {
        setDetailStatus("Validation rules are not available through this org's Tooling API.");
      } else {
        setDetailStatus(message);
      }
    }
  }

  document.getElementById("objectCompareConfiguration").addEventListener("click", () => {
    if (!selectedObjectName) return;
    document.dispatchEvent(new CustomEvent("compareobjectconfiguration", { detail: { objectName: selectedObjectName } }));
  });

  function openObjectDetail(object) {
    selectedObjectName = object.name;
    objectDetailTitle.textContent = `${object.label} (${object.name})`;
    objectDetail.hidden = false;
    objectDetailEmpty.hidden = true;
    applyFilter();
    resetDetailTabCounts();
    detailTabButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.detailTab === "fields");
    });
    loadObjectDetail("fields");
  }

  detailTabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      detailTabButtons.forEach((tab) => tab.classList.remove("active"));
      button.classList.add("active");
      loadObjectDetail(button.dataset.detailTab);
    });
  });

  async function toggleFields(objectName, container) {
    const isHidden = container.hasAttribute("hidden");
    if (!isHidden) {
      container.setAttribute("hidden", "");
      return;
    }

    container.removeAttribute("hidden");

    if (fieldsCache.has(objectName)) {
      renderFields(container, fieldsCache.get(objectName));
      return;
    }

    container.textContent = "Loading fields…";
    try {
      const { fields } = await SFPanel.sendMessage({
        type: "getObjectFields",
        hostname: SFPanel.getHostname(),
        objectName
      });
      fieldsCache.set(objectName, fields);
      renderFields(container, fields);
    } catch (err) {
      container.textContent = "";
      const errEl = document.createElement("div");
      errEl.className = "field-row";
      errEl.textContent = `Failed to load fields: ${err.message}`;
      container.appendChild(errEl);
    }
  }

  function renderFields(container, fields) {
    container.textContent = "";
    const fragment = document.createDocumentFragment();

    for (const field of fields) {
      const node = fieldRowTemplate.content.firstElementChild.cloneNode(true);
      node.querySelector(".field-label").textContent = field.label;
      node.querySelector(".field-name").textContent = field.name;
      node.querySelector(".field-type").textContent = field.type;
      node.querySelector(".field-required").textContent = field.required ? "*" : "";
      fragment.appendChild(node);
    }

    container.appendChild(fragment);
  }

  function applyFilter() {
    const term = searchInput.value.trim().toLowerCase();
    const filtered = term
      ? allObjects.filter(
          (o) => o.label.toLowerCase().includes(term) || o.name.toLowerCase().includes(term)
        )
      : allObjects;
    renderObjectList(filtered);
  }

  async function syncActiveObject(tabOverride) {
    const context = await getActiveTabContext(tabOverride);
    const activeObject = findObjectFromActiveTab(context);
    if (activeObject && activeObject.name !== selectedObjectName) openObjectDetail(activeObject);
    if (!activeObject) {
      clearSelectedObject();
      let page = "Active tab URL unavailable";
      try {
        const url = new URL(context?.url);
        page = `${url.hostname}${url.pathname}`;
      } catch {}
      setStatus(`Auto-select: no match. Page: ${page}. Catalog: ${allObjects.length} objects.`);
    } else {
      setStatus("");
    }
  }

  function clearSelectedObject() {
    if (!selectedObjectName) return;
    selectedObjectName = null;
    detailGeneration++;
    objectDetail.hidden = true;
    objectDetailEmpty.hidden = false;
    applyFilter();
  }

  function syncActiveObjectIfVisible() {
    if (loaded && SFPanel.getActiveTab() === "objects") syncActiveObject();
  }

  async function loadObjects(tabOverride) {
    const hostname = SFPanel.getHostname();
    setStatus("");
    searchInput.disabled = true;
    refreshButton.disabled = true;
    setSummary("Loading objects…");
    listEl.textContent = "";
    fieldsCache.clear();

    try {
      if (!hostname) {
        throw new Error("Couldn't detect the active tab's URL.");
      }

      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      if (!objects.some((object) => object.name === "Activity") &&
          ["Task", "Event"].every((name) => objects.some((object) => object.name === name))) {
        objects.push({ name: "Activity", label: "Activity", custom: false, queryable: false, keyPrefix: "" });
      }
      allObjects = objects.sort((a, b) => a.label.localeCompare(b.label));
      searchInput.disabled = false;
      refreshButton.disabled = false;
      loaded = true;
      applyFilter();
      await syncActiveObject(tabOverride);
    } catch (err) {
      setStatus(err.message);
      setSummary("");
    }
  }

  searchInput.addEventListener("input", applyFilter);
  refreshButton.addEventListener("click", () => loadObjects());

  (function initResize() {
    const MIN_LIST_WIDTH = 160;
    const MIN_DETAIL_WIDTH = 240;
    const HANDLE_WIDTH = 5;
    const splitEl = listEl.parentElement;
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function maxWidth() {
      return Math.max(MIN_LIST_WIDTH, splitEl.getBoundingClientRect().width - HANDLE_WIDTH - MIN_DETAIL_WIDTH);
    }

    function setWidth(width) {
      const clamped = Math.min(maxWidth(), Math.max(MIN_LIST_WIDTH, width));
      splitEl.style.gridTemplateColumns = `${clamped}px ${HANDLE_WIDTH}px minmax(0, 1fr)`;
    }

    function beginDrag(clientX) {
      dragStartX = clientX;
      dragStartWidth = listEl.getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    resizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
      resizeHandle.setPointerCapture?.(event.pointerId);
    });
    resizeHandle.addEventListener("pointermove", (event) => {
      if (!isDragging) return;
      setWidth(dragStartWidth + event.clientX - dragStartX);
    });
    resizeHandle.addEventListener("pointerup", endDrag);
    resizeHandle.addEventListener("pointercancel", endDrag);
    resizeHandle.addEventListener("keydown", (event) => {
      const movement = event.key === "ArrowLeft" ? -20 : event.key === "ArrowRight" ? 20 : 0;
      if (!movement) return;
      event.preventDefault();
      setWidth(listEl.getBoundingClientRect().width + movement);
    });
  })();

  SFPanel.registerTab("objects", {
    onStartup(_hostname, tabContext) {
      if (!loaded) return loadObjects(tabContext);
    },
    onShow(_hostname, tabContext) {
      if (!loaded) return loadObjects(tabContext);
    },
    onHostnameChange() {
      loaded = false;
      if (SFPanel.getActiveTab() === "objects") return loadObjects();
    }
  });
})(SFPanel.forTools("objects"));
