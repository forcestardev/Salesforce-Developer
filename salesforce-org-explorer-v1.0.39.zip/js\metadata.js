// js/metadata.js — "Create Metadata" tab: create a Custom Object or Custom
// Field via the Tooling API (POST /services/data/vXX.X/tooling/sobjects/...),
// routed through the same generic restRequest proxy as the REST Explorer tab.

((SFPanel) => {
  const subtabButtons = document.querySelectorAll(".subtab-btn");
  const createObjectForm = document.getElementById("createObjectForm");
  const createFieldForm = document.getElementById("createFieldForm");
  const statusEl = document.getElementById("metaStatus");
  const responseEl = document.getElementById("metaResponse");

  const fieldModeControls = document.getElementById("fieldModeControls");
  const singleFieldDefinition = document.getElementById("singleFieldDefinition");
  const fieldTargetObject = document.getElementById("fldObjectName");
  const fieldRelationshipTarget = singleFieldDefinition.querySelector(".field-reference-to");
  const fieldRows = document.getElementById("fieldRows");
  const addFieldRowButton = document.getElementById("addFieldRow");
  const fieldCsvFile = document.getElementById("fieldCsvFile");
  const fieldCsvChooseButton = document.getElementById("fieldCsvChoose");
  const fieldCsvTemplateButton = document.getElementById("fieldCsvTemplate");
  const fieldSaveButton = document.getElementById("fieldSaveButton");
  const fieldSecurityList = document.getElementById("fieldSecurityList");
  const fieldLayoutList = document.getElementById("fieldLayoutList");
  let fieldSecurityOptions = [];
  let fieldLayoutOptions = [];
  let fieldSettingsObjectName = "";
  let fieldSettingsLoadTimer;
  let fieldSaveInProgress = false;
  let loadedFieldObjectHostname = "";
  let lastToolingError = "";

  function setStatus(message, isError = true, isSuccess = false) {
    if (!statusEl) return;
    statusEl.textContent = message || "";
    statusEl.style.color = isSuccess ? "#107c10" : isError ? "#c00" : "inherit";
    statusEl.hidden = !message;
  }

  function displayErrorMessage(error) {
    const message = error?.message || "Unable to complete the request.";
    const jsonStart = message.indexOf("[");
    if (jsonStart < 0) return message;
    try {
      const details = JSON.parse(message.slice(jsonStart));
      if (Array.isArray(details) && details[0]?.message) return details[0].message;
    } catch {
      // Keep the original message when the API response is not valid JSON.
    }
    return message;
  }

  function clearFieldSettings() {
    fieldSecurityOptions = [];
    fieldLayoutOptions = [];
    fieldSettingsObjectName = "";
    if (fieldSecurityList) fieldSecurityList.textContent = "Select a target object to load profiles.";
    if (fieldLayoutList) fieldLayoutList.textContent = "Select a target object to load page layouts.";
  }

  function addCheckbox(parent, label, value, checked = false, className = "") {
    const option = document.createElement("label");
    option.className = className;
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = value;
    checkbox.checked = checked;
    option.append(checkbox, document.createTextNode(` ${label}`));
    parent.appendChild(option);
    return checkbox;
  }

  async function toolingQuery(hostname, query) {
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname,
      method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/query/?q=${encodeURIComponent(query)}`
    });
    return result.data?.records || [];
  }

  async function loadFieldSettings() {
    const objectName = fieldTargetObject.value.trim();
    const hostname = SFPanel.getHostname();
    if (!objectName || !hostname || fieldSettingsObjectName === objectName) return;
    if (!/^[A-Za-z][A-Za-z0-9_]*(__c)?$/.test(objectName)) return;
    fieldSecurityList.textContent = "Loading profiles...";
    fieldLayoutList.textContent = "Loading page layouts...";
    try {
      const escapedObjectName = objectName.replace(/'/g, "\\'");
      const developerName = objectName.replace(/__c$/i, "").replace(/'/g, "\\'");
      const customObjectRows = objectName.endsWith("__c")
        ? await toolingQuery(hostname, `SELECT Id FROM CustomObject WHERE DeveloperName = '${developerName}'`)
        : [];
      const layoutOwnerIds = [escapedObjectName, ...customObjectRows.map((object) => object.Id).filter(Boolean)];
      const layoutOwnerFilter = layoutOwnerIds.map((id) => `'${String(id).replace(/'/g, "\\'")}'`).join(", ");
      const [permissionSets, layouts] = await Promise.all([
        toolingQuery(hostname, "SELECT Id, Name, Profile.Name FROM PermissionSet WHERE IsOwnedByProfile = true ORDER BY Profile.Name"),
        toolingQuery(hostname, `SELECT Id, Name, TableEnumOrId FROM Layout WHERE TableEnumOrId IN (${layoutOwnerFilter}) ORDER BY Name`)
      ]);
      fieldSettingsObjectName = objectName;
      fieldSecurityOptions = permissionSets.map((permissionSet) => ({ id: permissionSet.Id, name: permissionSet.Profile?.Name || permissionSet.Name })).filter((option) => option.name);
      fieldLayoutOptions = await Promise.all(layouts.map(async (layout) => {
        const result = await SFPanel.sendMessage({ type: "restRequest", hostname, method: "GET", path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/Layout/${encodeURIComponent(layout.Id)}` });
        return { id: layout.Id, name: layout.Name, metadata: result.data?.Metadata };
      }));
      fieldLayoutOptions = fieldLayoutOptions.filter((option) => option.id && option.metadata);
      fieldSecurityList.textContent = "";
      fieldLayoutList.textContent = "";
      if (!fieldSecurityOptions.length) fieldSecurityList.textContent = "No profile permission sets are available.";
      if (fieldSecurityOptions.length) {
        const header = document.createElement("div");
        header.className = "field-security-header";
        ["Profile", "Visible", "Read-Only"].forEach((text) => {
          const cell = document.createElement("span");
          cell.textContent = text;
          header.appendChild(cell);
        });
        fieldSecurityList.appendChild(header);
      }
      fieldSecurityOptions.forEach((profile) => {
        const row = document.createElement("div");
        row.className = "field-security-option";
        const name = document.createElement("span");
        name.textContent = profile.name;
        const visible = document.createElement("input");
        visible.type = "checkbox";
        visible.className = "field-security-visible";
        visible.dataset.permissionSetId = profile.id;
        visible.setAttribute("aria-label", `${profile.name}: Visible`);
        const readOnly = document.createElement("input");
        readOnly.type = "checkbox";
        readOnly.className = "field-security-read-only";
        readOnly.dataset.permissionSetId = profile.id;
        readOnly.setAttribute("aria-label", `${profile.name}: Read-Only`);
        readOnly.addEventListener("change", () => { if (readOnly.checked) visible.checked = true; });
        visible.addEventListener("change", () => { if (!visible.checked) readOnly.checked = false; });
        row.append(name, visible, readOnly);
        fieldSecurityList.appendChild(row);
      });
      if (!fieldLayoutOptions.length) fieldLayoutList.textContent = "No page layouts are available for this object.";
      fieldLayoutOptions.forEach((layout) => {
        const checkbox = addCheckbox(fieldLayoutList, layout.name, layout.id, false, "field-layout-option");
        checkbox.dataset.layoutId = layout.id;
      });
    } catch (error) {
      fieldSecurityList.textContent = "Could not load profiles.";
      fieldLayoutList.textContent = "Could not load page layouts.";
      setStatus(displayErrorMessage(error));
    }
  }

  function selectedFieldSecurity() {
    return Array.from(fieldSecurityList?.querySelectorAll(".field-security-visible") || []).filter((input) => input.checked).map((visible) => ({
      permissionSetId: visible.dataset.permissionSetId,
      editable: !fieldSecurityList.querySelector(`.field-security-read-only[data-permission-set-id="${CSS.escape(visible.dataset.permissionSetId)}"]`)?.checked
    }));
  }

  function selectedFieldLayouts() {
    const selectedIds = new Set(Array.from(fieldLayoutList?.querySelectorAll(".field-layout-option:checked") || []).map((input) => input.dataset.layoutId));
    return fieldLayoutOptions.filter((layout) => selectedIds.has(layout.id));
  }

  async function getActiveTabContext() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ? { url: tab.url || "", title: tab.title || "" } : null;
  }

  function findObjectFromActiveTab(context, objects) {
    if (!context) return null;
    let url;
    try {
      url = new URL(context.url);
    } catch {
      url = null;
    }
    const path = url ? url.pathname : "";
    const apiMatch = path.match(/^\/lightning\/(?:r|o)\/([A-Za-z0-9_]+)/);
    const objectManagerMatch = path.match(/^\/lightning\/setup\/ObjectManager\/([A-Za-z0-9_]+)/);
    const keyPrefixMatch = path.match(/^\/([A-Za-z0-9]{3})\/o$/);
    const candidates = [apiMatch?.[1], objectManagerMatch?.[1]];
    const keyPrefix = keyPrefixMatch?.[1];
    let match = objects.find((object) => candidates.some((candidate) => candidate && object.name.toLowerCase() === candidate.toLowerCase()));
    if (!match && keyPrefix) match = objects.find((object) => object.keyPrefix === keyPrefix);
    if (!match && context.title) {
      const title = context.title.toLowerCase();
      match = objects.find((object) => title.includes(object.label.toLowerCase()) || title.includes(object.name.toLowerCase()));
    }
    return match || null;
  }

  function ensureSuffix(name, suffix) {
    return name.endsWith(suffix) ? name : `${name}${suffix}`;
  }

  function apiNameFromLabel(label) {
    return label
      .trim()
      .replace(/[^A-Za-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .replace(/^[^A-Za-z]+/, "")
      .slice(0, 40);
  }

  function connectLabelToApiName(labelInput, apiInput) {
    let automatic = !apiInput.value.trim();
    labelInput.addEventListener("input", () => {
      if (automatic) apiInput.value = apiNameFromLabel(labelInput.value);
    });
    apiInput.addEventListener("input", () => {
      automatic = !apiInput.value.trim();
    });
  }

  connectLabelToApiName(
    document.getElementById("objLabel"),
    document.getElementById("objApiName")
  );

  function showSubtab(name) {
    subtabButtons.forEach((btn) => {
      const selected = btn.dataset.subtab === name;
      btn.classList.toggle("active", selected);
      btn.setAttribute("aria-selected", String(selected));
    });
    createObjectForm.hidden = name !== "object";
    createFieldForm.hidden = name !== "field";
    setStatus("");
    responseEl.textContent = "";
  }

  subtabButtons.forEach((btn) => {
    btn.addEventListener("click", () => showSubtab(btn.dataset.subtab));
  });
  showSubtab("field");


  function updateFieldTypeRows(row) {
    const type = row.querySelector(".field-type").value;
    const setVisible = (selector, visible) => {
      const element = row.querySelector(selector);
      if (element) element.hidden = !visible;
    };
    const isSingle = row === singleFieldDefinition;
    const textTypes = ["Text", "TextArea", "LongTextArea", "Html", "EncryptedText"];
    const numberTypes = ["Number", "Currency", "Percent"];
    setVisible(".field-length-row", textTypes.includes(type));
    setVisible(".field-visible-lines-row", ["LongTextArea", "Html", "MultiselectPicklist"].includes(type));
    setVisible(".field-precision-row", numberTypes.includes(type));
    setVisible(".field-scale-row", numberTypes.includes(type));
    setVisible(".field-picklist-row", ["Picklist", "MultiselectPicklist"].includes(type));
    setVisible(".field-auto-number-format-row", type === "AutoNumber");
    setVisible(".field-starting-number-row", type === "AutoNumber");
    setVisible(".field-relationship-target-row", ["Lookup", "ExternalLookup", "MasterDetail"].includes(type));
    setVisible(".field-relationship-name-row", ["Lookup", "ExternalLookup", "MasterDetail"].includes(type));
    setVisible(".field-formula-return-type-row", type === "Formula");
    setVisible(".field-formula-row", type === "Formula");
    setVisible(".field-rollup-object-row", type === "Summary");
    setVisible(".field-rollup-field-row", type === "Summary");
    setVisible(".field-rollup-operation-row", type === "Summary");
    setVisible(".field-visible-lines-row", ["LongTextArea", "Html"].includes(type));
    if (isSingle) {
      const hasTypeSettings = textTypes.includes(type) || numberTypes.includes(type) || ["Picklist", "MultiselectPicklist", "AutoNumber", "Lookup", "ExternalLookup", "MasterDetail", "Formula", "Summary"].includes(type);
      const label = row.querySelector(".field-label-input").value.trim();
      const apiName = row.querySelector(".field-api-name").value.trim();
      const fieldTypeComplete = Boolean(type && label && apiName);
      row.querySelector(".single-field-type-settings").hidden = !hasTypeSettings;
      row.querySelector(".single-field-options-section").hidden = !fieldTypeComplete;
      row.querySelector(".single-field-access-section").hidden = !fieldTypeComplete;
      row.querySelector(".single-field-layout-section").hidden = !fieldTypeComplete;
    }
  }

  function escapeHtml(value) {
    return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function invalidateFieldValidation() {
    fieldRows.querySelectorAll(".field-create-status").forEach((status) => { status.textContent = ""; });
    updateFieldSaveButtonState();
  }

  function addFieldRow(values = {}) {
    const row = document.createElement("div");
    row.className = "field-row-card";
    row.innerHTML = `
      <label><input class="field-label-input" aria-label="Field Label" placeholder="Label" maxlength="255" value="${escapeHtml(values.label)}" /></label>
      <label><input class="field-api-name" aria-label="API Name" placeholder="My_Field" maxlength="255" value="${escapeHtml(values.apiName)}" /></label>
      <label><select class="field-type" aria-label="Type">
          <option value="Text">Text</option>
          <option value="TextArea">Text Area</option>
          <option value="Number">Number</option>
          <option value="Checkbox">Checkbox</option>
          <option value="Date">Date</option>
          <option value="DateTime">Date/Time</option>
          <option value="Email">Email</option>
          <option value="AutoNumber">Auto Number</option>
          <option value="Currency">Currency</option>
          <option value="Percent">Percent</option>
          <option value="Phone">Phone</option>
          <option value="Picklist">Picklist</option>
          <option value="MultiselectPicklist">Picklist (Multi-Select)</option>
          <option value="LongTextArea">Text Area (Long)</option>
          <option value="Html">Text Area (Rich)</option>
          <option value="EncryptedText">Text (Encrypted)</option>
          <option value="Time">Time</option>
          <option value="Url">URL</option>
          <option value="Location">Geolocation</option>
        </select></label>
      <label class="field-length-row"><input class="field-length" aria-label="Length" type="text" inputmode="numeric" value="${escapeHtml(values.length || "")}" /></label>
      <label class="field-visible-lines-row" hidden><input class="field-visible-lines" aria-label="Visible Lines" type="text" inputmode="numeric" value="${escapeHtml(values.config?.visibleLines || "3")}" /></label>
      <label class="field-precision-row" hidden><input class="field-precision" aria-label="Precision" type="text" inputmode="numeric" value="${escapeHtml(values.precision || "18")}" /></label>
      <label class="field-scale-row" hidden><input class="field-scale" aria-label="Scale" type="number" value="${escapeHtml(values.scale || "0")}" /></label>
      <label class="field-picklist-row" hidden><textarea class="field-picklist-values" aria-label="Picklist Values" rows="2" placeholder="Values, one per line">${escapeHtml(values.picklistValues)}</textarea></label>
      <label class="field-auto-number-format-row" hidden><input class="field-auto-number-format" aria-label="Display Format" placeholder="INV-{0000}" value="${escapeHtml(values.config?.displayFormat)}" /></label>
      <label class="field-starting-number-row" hidden><input class="field-starting-number" aria-label="Starting Number" type="number" min="0" value="${escapeHtml(values.config?.startingNumber || "1")}" /></label>
      <label class="checkbox-label"><input class="field-required" aria-label="Required" type="checkbox" ${values.required ? "checked" : ""} /></label>
      <span class="field-create-status" aria-live="polite"></span>
      <button type="button" class="remove-field-row" title="Remove field" aria-label="Remove field"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7 H20 M10 11 V17 M14 11 V17 M9 7 L10 4 H14 L15 7 M6 7 L7 20 H17 L18 7"></path></svg></button>`;
    row.querySelector(".field-type").value = values.type || "Text";
    if (values.config) row.dataset.csvConfig = JSON.stringify(values.config);
    row.querySelector(".field-type").addEventListener("change", () => updateFieldTypeRows(row));
    connectLabelToApiName(row.querySelector(".field-label-input"), row.querySelector(".field-api-name"));
    row.querySelector(".remove-field-row").addEventListener("click", () => {
      if (fieldRows.children.length > 1) { row.remove(); invalidateFieldValidation(); }
    });
    row.querySelectorAll("input, select, textarea").forEach((input) => input.addEventListener("input", invalidateFieldValidation));
    row.querySelector(".field-type").addEventListener("change", invalidateFieldValidation);
    fieldRows.appendChild(row);
    updateFieldTypeRows(row);
  }

  function getActiveFieldRows() {
    if (singleFieldDefinition && !singleFieldDefinition.hidden) return [singleFieldDefinition];
    return Array.from(fieldRows.querySelectorAll(".field-row-card:not([hidden])"));
  }

  function updateFieldCreationMode() {
    const mode = fieldModeControls?.querySelector('input[name="fieldCreationMode"]:checked')?.value || "bulk";
    const bulk = mode === "bulk";
    createFieldForm.dataset.fieldCreationMode = mode;
    singleFieldDefinition.hidden = bulk;
    document.querySelector(".field-table-wrapper").hidden = !bulk;
    fieldRows.querySelectorAll(".field-row-card").forEach((row, index) => { row.hidden = !bulk && index > 0; });
    document.querySelector(".field-csv-controls").hidden = !bulk;
    addFieldRowButton.hidden = !bulk;
    invalidateFieldValidation();
  }

  addFieldRowButton.addEventListener("click", () => { addFieldRow(); invalidateFieldValidation(); });
  for (let index = 0; index < 10; index += 1) addFieldRow();
  fieldModeControls?.addEventListener("change", updateFieldCreationMode);
  connectLabelToApiName(singleFieldDefinition.querySelector(".field-label-input"), singleFieldDefinition.querySelector(".field-api-name"));
  singleFieldDefinition.querySelector(".field-type").addEventListener("change", () => {
    updateFieldTypeRows(singleFieldDefinition);
  });
  singleFieldDefinition.querySelectorAll("input, select, textarea").forEach((input) => input.addEventListener("input", () => {
    invalidateFieldValidation();
    updateFieldTypeRows(singleFieldDefinition);
  }));
  singleFieldDefinition.querySelector(".field-type").addEventListener("change", invalidateFieldValidation);
  updateFieldTypeRows(singleFieldDefinition);
  updateFieldCreationMode();

  function parseCsv(text) {
    const rows = [];
    let row = [];
    let value = "";
    let quoted = false;
    for (let index = 0; index < text.length; index += 1) {
      const character = text[index];
      if (character === '"' && quoted && text[index + 1] === '"') { value += '"'; index += 1; }
      else if (character === '"') quoted = !quoted;
      else if (character === "," && !quoted) { row.push(value); value = ""; }
      else if ((character === "\n" || character === "\r") && !quoted) { if (character === "\r" && text[index + 1] === "\n") index += 1; row.push(value); if (row.some((cell) => cell.trim())) rows.push(row); row = []; value = ""; }
      else value += character;
    }
    row.push(value);
    if (row.some((cell) => cell.trim())) rows.push(row);
    return rows;
  }

  function csvColumnIndex(headers, expression) {
    return headers.findIndex((header) => expression.test(header));
  }

  function fieldRowData(row) {
    const fieldApiName = ensureSuffix(row.querySelector(".field-api-name").value.trim(), "__c");
    const type = row.querySelector(".field-type").value;
    const picklistValues = row.querySelector(".field-picklist-values").value.split("\n").map((value) => value.trim()).filter(Boolean);
    let csvConfig = {};
    try { csvConfig = JSON.parse(row.dataset.csvConfig || "{}"); } catch { csvConfig = {}; }
    const metadata = { label: row.querySelector(".field-label-input").value.trim(), type, required: row.querySelector(".field-required").checked };
    const valueOf = (selector, configName) => row.querySelector(selector)?.value.trim() || csvConfig[configName] || "";
    if (["Text", "LongTextArea", "Html", "EncryptedText"].includes(type)) metadata.length = Number(valueOf(".field-length"));
    if (["LongTextArea", "Html", "MultiselectPicklist"].includes(type)) metadata.visibleLines = Number(valueOf(".field-visible-lines", "visibleLines"));
    if (["Number", "Currency", "Percent"].includes(type)) {
      metadata.precision = Number(row.querySelector(".field-precision").value);
      metadata.scale = Number(row.querySelector(".field-scale").value);
    }
    if (["Picklist", "MultiselectPicklist"].includes(type)) metadata.valueSet = { restricted: true, valueSetDefinition: { value: picklistValues.map((value) => ({ fullName: value, label: value, default: false })) } };
    if (type === "AutoNumber") {
      metadata.displayFormat = valueOf(".field-auto-number-format", "displayFormat");
      metadata.startingNumber = Number(valueOf(".field-starting-number", "startingNumber"));
    }
    if (type === "EncryptedText") {
      metadata.maskType = { value: csvConfig.maskType || "all" };
      metadata.maskChar = csvConfig.maskChar || "asterisk";
    }
    if (type === "Location") {
      metadata.scale = Number(valueOf(".field-scale") || "5");
      metadata.displayLocationInDecimal = /^(true|yes|1)$/i.test(csvConfig.displayLocationInDecimal || "true");
    }
    if (["Lookup", "ExternalLookup", "MasterDetail"].includes(type)) {
      metadata.referenceTo = valueOf(".field-reference-to", "referenceTo");
      metadata.relationshipName = valueOf(".field-relationship-name", "relationshipName");
    }
    if (type === "Formula") {
      metadata.formula = valueOf(".field-formula", "formula");
      metadata.formulaTreatBlanksAs = "BlankAsZero";
      metadata.returnType = valueOf(".field-formula-return-type", "formulaReturnType");
    }
    if (type === "Summary") {
      metadata.summaryForeignKey = valueOf(".field-summary-foreign-key", "summaryForeignKey");
      metadata.summarizedField = valueOf(".field-summarized-field", "summarizedField");
      metadata.summaryOperation = valueOf(".field-summary-operation", "summaryOperation");
    }
    const optionalValues = {
      unique: row.querySelector(".field-unique")?.checked,
      externalId: row.querySelector(".field-external-id")?.checked,
      defaultValue: row.querySelector(".field-default-value")?.value.trim() || csvConfig.defaultValue,
      description: row.querySelector(".field-description")?.value.trim(),
      inlineHelpText: row.querySelector(".field-inline-help-text")?.value.trim()
    };
    Object.entries(optionalValues).forEach(([name, value]) => { if (value) metadata[name] = value; });
    return { row, fieldApiName, type, picklistValues, metadata };
  }

  function validateFieldDefinitions(rows) {
    const errors = [];
    const names = new Set();
    rows.forEach((row, index) => {
      const field = fieldRowData(row);
      const prefix = `Row ${index + 1}`;
      if (!field.metadata.label) errors.push(`${prefix}: Field Label is required.`);
      if (!field.type) errors.push(`${prefix}: select a Field Type.`);
      if (!/^[A-Za-z][A-Za-z0-9_]*__c$/.test(field.fieldApiName)) errors.push(`${prefix}: API Name must start with a letter and ends with __c.`);
      if (names.has(field.fieldApiName.toLowerCase())) errors.push(`${prefix}: duplicate field API name ${field.fieldApiName}.`);
      names.add(field.fieldApiName.toLowerCase());
      if (["Text", "LongTextArea", "Html", "EncryptedText"].includes(field.type) && (!Number.isInteger(field.metadata.length) || field.metadata.length < 1)) errors.push(`${prefix}: Length must be a positive whole number.`);
      if (["LongTextArea", "Html", "MultiselectPicklist"].includes(field.type) && (!Number.isInteger(field.metadata.visibleLines) || field.metadata.visibleLines < 1)) errors.push(`${prefix}: Visible Lines must be a positive whole number.`);
      if (["Number", "Currency", "Percent"].includes(field.type) && (!Number.isInteger(field.metadata.precision) || !Number.isInteger(field.metadata.scale) || field.metadata.precision < 1 || field.metadata.scale < 0 || field.metadata.scale > field.metadata.precision)) errors.push(`${prefix}: Precision must be positive and Scale must be between 0 and Precision.`);
      if (field.type === "Location" && (!Number.isInteger(field.metadata.scale) || field.metadata.scale < 0)) errors.push(`${prefix}: Location Scale must be a non-negative whole number.`);
      if (["Picklist", "MultiselectPicklist"].includes(field.type) && !field.picklistValues.length) errors.push(`${prefix}: enter at least one picklist value.`);
      if (field.type === "AutoNumber" && (!field.metadata.displayFormat || !Number.isInteger(field.metadata.startingNumber) || field.metadata.startingNumber < 0)) errors.push(`${prefix}: Display Format and Starting Number are required.`);
      if (["Lookup", "ExternalLookup", "MasterDetail"].includes(field.type) && (!field.metadata.referenceTo || !field.metadata.relationshipName)) errors.push(`${prefix}: Related To and Relationship Name are required.`);
      if (field.type === "Formula" && !field.metadata.formula) errors.push(`${prefix}: Formula is required.`);
      if (field.type === "Summary" && (!field.metadata.summaryForeignKey || (field.metadata.summaryOperation !== "count" && !field.metadata.summarizedField))) errors.push(`${prefix}: Summarized Object${field.metadata.summaryOperation === "count" ? "" : " and Field to Aggregate"} are required.`);
    });
    return errors;
  }

  function validateFieldRows(objectName, rows) {
    const errors = validateFieldDefinitions(rows);
    if (!/^[A-Za-z][A-Za-z0-9_]*(__c)?$/.test(objectName)) errors.unshift("Enter a valid target object API name.");
    return errors;
  }

  function updateFieldSaveButtonState() {
    if (fieldSaveInProgress) return;
    const objectName = fieldTargetObject.value.trim();
    const rows = getActiveFieldRows().filter((row) =>
      row.querySelector(".field-label-input").value.trim() || row.querySelector(".field-api-name").value.trim()
    );
    fieldSaveButton.disabled = !rows.length || validateFieldRows(objectName, rows).length > 0;
  }

  async function loadFieldCsv() {
    const file = fieldCsvFile?.files?.[0];
    if (!file) return;
    try {
      const rows = parseCsv(await file.text());
      if (rows.length < 2) throw new Error("CSV must contain a header row and at least one field row.");
      const headers = rows[0].map((header) => header.trim().toLowerCase());
      const labelIndex = csvColumnIndex(headers, /^field label$|^label$/);
      const apiNameIndex = csvColumnIndex(headers, /^api name$|^field api name$/);
      const typeIndex = csvColumnIndex(headers, /^field type$|^type$/);
      if (labelIndex < 0 || apiNameIndex < 0 || typeIndex < 0) throw new Error("CSV requires Field Label, API Name, and Type columns.");
      const valueAt = (row, expression) => { const index = csvColumnIndex(headers, expression); return index >= 0 ? String(row[index] || "").trim() : ""; };
      const imported = rows.slice(1).map((row) => ({
        label: String(row[labelIndex] || "").trim(), apiName: String(row[apiNameIndex] || "").trim(), type: String(row[typeIndex] || "").trim(),
        length: valueAt(row, /^length$/), precision: valueAt(row, /^precision$/), scale: valueAt(row, /^scale$|^decimal places$/),
        picklistValues: valueAt(row, /^picklist values?$/).replace(/[;|]/g, "\n"), required: /^(true|yes|1)$/i.test(valueAt(row, /^required$/)),
        config: {
          visibleLines: valueAt(row, /^visible lines?$/), displayFormat: valueAt(row, /^display format$/), startingNumber: valueAt(row, /^starting number$/),
          referenceTo: "", relationshipName: "", defaultValue: valueAt(row, /^default value$/), maskType: valueAt(row, /^mask type$/),
          maskChar: valueAt(row, /^mask (character|char)$/), displayLocationInDecimal: valueAt(row, /^display location in decimal$/),
          formulaReturnType: "", formula: "", summaryForeignKey: "", summarizedField: "", summaryOperation: ""
        }
      })).filter((row) => row.label || row.apiName);
      const unsupportedTypes = imported.filter((row) => ["Formula", "Summary", "Lookup", "ExternalLookup", "MasterDetail"].includes(row.type));
      if (unsupportedTypes.length) throw new Error("Formula, Roll-Up Summary, and relationship fields must be created in Single mode.");
      if (!imported.length) throw new Error("CSV contains no field rows.");
      fieldRows.textContent = "";
      imported.forEach(addFieldRow);
      const bulkMode = fieldModeControls?.querySelector('input[value="bulk"]');
      if (bulkMode) bulkMode.checked = true;
      updateFieldCreationMode();
      invalidateFieldValidation();
      setStatus(`${imported.length} field row(s) imported from ${file.name}. Validate fields before creating.`, false);
    } catch (error) {
      setStatus(error.message || "Could not read the CSV file.");
    }
  }

  if (fieldCsvChooseButton) fieldCsvChooseButton.addEventListener("click", () => { fieldCsvFile.value = ""; fieldCsvFile.click(); });
  if (fieldCsvFile) fieldCsvFile.addEventListener("change", loadFieldCsv);
  if (fieldCsvTemplateButton) fieldCsvTemplateButton.addEventListener("click", () => {
    const template = [
      ["Field Label", "API Name", "Type", "Length", "Precision", "Scale", "Picklist Values", "Required", "Visible Lines", "Display Format", "Starting Number", "Default Value", "Display Location In Decimal"],
      ["Customer Reference", "Customer_Reference", "Text", "80"],
      ["Internal Notes", "Internal_Notes", "TextArea"],
      ["Long Notes", "Long_Notes", "LongTextArea", "32768", "", "", "", "", "5"],
      ["Formatted Notes", "Formatted_Notes", "Html", "32768", "", "", "", "", "11"],
      ["Credit Limit", "Credit_Limit", "Number", "", "18", "2"],
      ["Annual Revenue", "Annual_Revenue", "Currency", "", "18", "2"],
      ["Discount", "Discount", "Percent", "", "5", "2"],
      ["Preferred Customer", "Preferred_Customer", "Checkbox", "", "", "", "", "", "", "", "", "false"],
      ["Renewal Date", "Renewal_Date", "Date"],
      ["Last Contacted", "Last_Contacted", "DateTime"],
      ["Contact Email", "Contact_Email", "Email"],
      ["Contact Phone", "Contact_Phone", "Phone"],
      ["Website", "Website", "Url"],
      ["Meeting Time", "Meeting_Time", "Time"],
      ["Location", "Location", "Location", "", "", "5", "", "", "", "", "", "", "true"],
      ["Record Number", "Record_Number", "AutoNumber", "", "", "", "", "", "", "REC-{0000}", "1"],
      ["Lifecycle Stage", "Lifecycle_Stage", "Picklist", "", "", "", "New;In Progress;Closed", "Yes"],
      ["Tags", "Tags", "MultiselectPicklist", "", "", "", "New;Priority;VIP", "", "4"]
    ].map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([template], { type: "text/csv;charset=utf-8" }));
    const download = document.createElement("a");
    download.href = url;
    download.download = "salesforce-fields-import-template.csv";
    download.click();
    URL.revokeObjectURL(url);
  });
  function scheduleFieldSettingsLoad() {
    clearTimeout(fieldSettingsLoadTimer);
    fieldSettingsLoadTimer = setTimeout(loadFieldSettings, 250);
  }

  fieldTargetObject.addEventListener("change", () => {
    invalidateFieldValidation();
    clearFieldSettings();
    scheduleFieldSettingsLoad();
  });
  const singleFieldSteps = Array.from(singleFieldDefinition.querySelectorAll(".single-field-step"));
  const fieldTypeSection = singleFieldSteps[0];
  const fieldOptionsSection = singleFieldDefinition.querySelector(".single-field-options-section");
  const fieldAccessSection = singleFieldDefinition.querySelector(".single-field-access-section");
  const fieldLayoutSection = singleFieldDefinition.querySelector(".single-field-layout-section");

  function syncFieldSecurityHeight() {
    const securityOwnsAvailableHeight = fieldAccessSection.open
      && !fieldTypeSection.open
      && !fieldOptionsSection.open
      && !fieldLayoutSection.open;
    fieldSecurityList.classList.toggle("field-security-list-expanded", securityOwnsAvailableHeight);
  }

  singleFieldSteps.forEach((section) => {
    section.addEventListener("toggle", () => {
      syncFieldSecurityHeight();
      if (section.open && section.matches(".single-field-access-section, .single-field-layout-section")) loadFieldSettings();
    });
  });
  syncFieldSecurityHeight();

  async function loadFieldTargetObjects() {
    try {
      const hostname = SFPanel.getHostname();
      if (!hostname) return;
      if (loadedFieldObjectHostname === hostname && fieldTargetObject.options.length > 1) return;
      const selectedObjectName = fieldTargetObject.value;
      fieldTargetObject.disabled = true;
      fieldTargetObject.textContent = "";
      const loadingOption = document.createElement("option");
      loadingOption.textContent = "Loading objects...";
      loadingOption.value = "";
      fieldTargetObject.appendChild(loadingOption);
      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      const activeObject = findObjectFromActiveTab(await getActiveTabContext(), objects);
      const selectedRelationshipObject = fieldRelationshipTarget.value;
      const fragment = document.createDocumentFragment();
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "Select an object";
      fragment.appendChild(placeholder);
      objects.slice().sort((left, right) => left.label.localeCompare(right.label)).forEach((object) => {
        const option = document.createElement("option");
        option.value = object.name;
        option.textContent = `${object.label} (${object.name})`;
        fragment.appendChild(option);
      });
      fieldTargetObject.textContent = "";
      fieldTargetObject.appendChild(fragment);
      fieldTargetObject.value = selectedObjectName || activeObject?.name || "";
      const relationshipFragment = document.createDocumentFragment();
      const relationshipPlaceholder = document.createElement("option");
      relationshipPlaceholder.value = "";
      relationshipPlaceholder.textContent = "Select related object";
      relationshipFragment.appendChild(relationshipPlaceholder);
      objects.slice().sort((left, right) => left.label.localeCompare(right.label)).forEach((object) => {
        const option = document.createElement("option");
        option.value = object.name;
        option.textContent = `${object.label} (${object.name})`;
        relationshipFragment.appendChild(option);
      });
      fieldRelationshipTarget.textContent = "";
      fieldRelationshipTarget.appendChild(relationshipFragment);
      fieldRelationshipTarget.value = selectedRelationshipObject;
      fieldRelationshipTarget.disabled = false;
      loadedFieldObjectHostname = hostname;
      fieldTargetObject.disabled = false;
      invalidateFieldValidation();
      scheduleFieldSettingsLoad();
    } catch (error) {
      fieldTargetObject.disabled = false;
      fieldRelationshipTarget.disabled = false;
      fieldRelationshipTarget.textContent = "";
      const failedRelationshipOption = document.createElement("option");
      failedRelationshipOption.value = "";
      failedRelationshipOption.textContent = "Could not load objects";
      fieldRelationshipTarget.appendChild(failedRelationshipOption);
      fieldTargetObject.textContent = "";
      const failedOption = document.createElement("option");
      failedOption.value = "";
      failedOption.textContent = "Could not load objects";
      fieldTargetObject.appendChild(failedOption);
      setStatus(error.message || "Could not load Salesforce objects.");
    }
  }

  async function submitToolingRequest(toolingObjectPath, body, method = "POST", showResponse = true) {
    lastToolingError = "";
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      lastToolingError = "No Salesforce tab detected.";
      setStatus(lastToolingError);
      return false;
    }

    setStatus("Submitting…", false);
    responseEl.textContent = "";

    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method,
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${toolingObjectPath}/`,
        body
      });
      setStatus(`Success (HTTP ${result.status}).`, false, true);
      if (showResponse) responseEl.textContent = JSON.stringify(result.data, null, 2);
      return true;
    } catch (err) {
      lastToolingError = displayErrorMessage(err);
      setStatus(lastToolingError);
      responseEl.textContent = "";
      return false;
    }
  }

  async function applyFieldSecurity(hostname, objectName, fieldApiName, securitySelections) {
    const fieldName = `${objectName}.${fieldApiName}`;
    for (const selection of securitySelections) {
      await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "POST",
        path: `/services/data/${SFPanel.API_VERSION}/sobjects/FieldPermissions/`,
        body: { ParentId: selection.permissionSetId, SobjectType: objectName, Field: fieldName, PermissionsRead: true, PermissionsEdit: selection.editable }
      });
    }
  }

  function layoutMetadataWithField(metadata, fieldApiName) {
    const updated = JSON.parse(JSON.stringify(metadata));
    const sections = Array.isArray(updated.layoutSections) ? updated.layoutSections : updated.layoutSections ? [updated.layoutSections] : [];
    const alreadyPresent = sections.some((section) => {
      const columns = Array.isArray(section.layoutColumns) ? section.layoutColumns : section.layoutColumns ? [section.layoutColumns] : [];
      return columns.some((column) => {
        const items = Array.isArray(column.layoutItems) ? column.layoutItems : column.layoutItems ? [column.layoutItems] : [];
        return items.some((item) => item.field === fieldApiName);
      });
    });
    if (alreadyPresent) return updated;
    let section = sections.find((candidate) => candidate.label === "Custom Fields");
    if (!section) {
      section = { label: "Custom Fields", style: "TwoColumnsTopToBottom", layoutColumns: [{ layoutItems: [] }, { layoutItems: [] }] };
      sections.push(section);
    }
    const columns = Array.isArray(section.layoutColumns) ? section.layoutColumns : [section.layoutColumns].filter(Boolean);
    if (!columns.length) columns.push({ layoutItems: [] });
    const targetColumn = columns.reduce((shortest, column) => {
      const count = (Array.isArray(column.layoutItems) ? column.layoutItems : column.layoutItems ? [column.layoutItems] : []).length;
      const shortestCount = (Array.isArray(shortest.layoutItems) ? shortest.layoutItems : shortest.layoutItems ? [shortest.layoutItems] : []).length;
      return count < shortestCount ? column : shortest;
    });
    const items = Array.isArray(targetColumn.layoutItems) ? targetColumn.layoutItems : targetColumn.layoutItems ? [targetColumn.layoutItems] : [];
    items.push({ behavior: "Edit", field: fieldApiName });
    targetColumn.layoutItems = items;
    section.layoutColumns = columns;
    updated.layoutSections = sections;
    return updated;
  }

  async function applyFieldLayouts(hostname, fieldApiName, layouts) {
    for (const layout of layouts) {
      await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "PATCH",
        path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/Layout/${encodeURIComponent(layout.id)}`,
        body: { Metadata: layoutMetadataWithField(layout.metadata, fieldApiName) }
      });
    }
  }

  createObjectForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const apiName = ensureSuffix(document.getElementById("objApiName").value.trim(), "__c");
    const description = document.getElementById("objDescription").value.trim();

    const body = {
      FullName: apiName,
      Metadata: {
        label: document.getElementById("objLabel").value.trim(),
        pluralLabel: document.getElementById("objPluralLabel").value.trim(),
        ...(description ? { description } : {}),
        nameField: {
          type: document.getElementById("objNameFieldType").value,
          label: document.getElementById("objNameFieldLabel").value.trim()
        },
        deploymentStatus: document.getElementById("objDeploymentStatus").value,
        sharingModel: document.getElementById("objSharingModel").value
      }
    };

    submitToolingRequest("CustomObject", body);
  });

  function saveFields() {
    const objectName = document.getElementById("fldObjectName").value.trim();
    const rows = getActiveFieldRows().filter((row) =>
      row.querySelector(".field-label-input").value.trim() || row.querySelector(".field-api-name").value.trim()
    );
    const localErrors = validateFieldRows(objectName, rows);
    if (!rows.length) localErrors.push("Enter or import at least one field.");
    if (localErrors.length) {
      setStatus(localErrors.join(" "));
      return;
    }

    if (fieldSaveInProgress) return;

    (async () => {
      fieldSaveInProgress = true;
      fieldSaveButton.disabled = true;
      const saveLabel = fieldSaveButton.textContent;
      fieldSaveButton.textContent = "Saving...";
      setStatus("Saving field...", false);
      let created = 0;
      const createdFields = [];
      const failedFields = [];
      const settingsFailedFields = [];
      try {
        const hostname = SFPanel.getHostname();
        const securitySelections = singleFieldDefinition.hidden ? [] : selectedFieldSecurity();
        const layoutSelections = singleFieldDefinition.hidden ? [] : selectedFieldLayouts();
        for (const row of rows) {
          const field = fieldRowData(row);
          const body = { FullName: `${objectName}.${field.fieldApiName}`, Metadata: field.metadata };
          const rowStatus = row.querySelector(".field-create-status");
          if (!await submitToolingRequest("CustomField", body, "POST", false)) {
            const message = lastToolingError || "Salesforce rejected this field.";
            if (rowStatus) {
              rowStatus.textContent = message;
              rowStatus.style.color = "#c00";
            }
            failedFields.push({ name: field.fieldApiName, message });
            continue;
          }
          created += 1;
          createdFields.push(field.fieldApiName);
          try {
            if (securitySelections.length) await applyFieldSecurity(hostname, objectName, field.fieldApiName, securitySelections);
            if (layoutSelections.length) await applyFieldLayouts(hostname, field.fieldApiName, layoutSelections);
          } catch (error) {
            const message = `Created, but security or layout settings failed: ${displayErrorMessage(error)}`;
            if (rowStatus) {
              rowStatus.textContent = message;
              rowStatus.style.color = "#c00";
            }
            settingsFailedFields.push(field.fieldApiName);
            continue;
          }
          if (rowStatus) {
            rowStatus.textContent = "Created.";
            rowStatus.style.color = "#107c10";
          }
        }
        responseEl.textContent = "";
        if (failedFields.length || settingsFailedFields.length) {
          const summary = [`${created} field${created === 1 ? "" : "s"} created.`];
          if (failedFields.length) summary.push(`${failedFields.length} creation failure${failedFields.length === 1 ? "" : "s"}.`);
          if (settingsFailedFields.length) summary.push(`${settingsFailedFields.length} created without all security/layout settings.`);
          summary.push("See error details on the rows.");
          setStatus(summary.join(" "));
        } else if (created) {
          setStatus(created === 1 ? `Field ${createdFields[0]} created.` : `${created} fields created: ${createdFields.join(", ")}.`, false, true);
        }
      } catch (error) {
        console.error("Field creation failed", error);
        setStatus(displayErrorMessage(error));
      } finally {
        fieldSaveInProgress = false;
        fieldSaveButton.textContent = saveLabel;
        updateFieldSaveButtonState();
      }
    })();
  }

  fieldSaveButton.addEventListener("click", saveFields);
  createFieldForm.addEventListener("submit", (event) => {
    event.preventDefault();
    saveFields();
  });

  SFPanel.registerTab("metadata", {
    onShow: loadFieldTargetObjects,
    onHostnameChange() {
      fieldTargetObject.value = "";
      loadedFieldObjectHostname = "";
      if (SFPanel.getActiveTab() === "metadata") loadFieldTargetObjects();
    }
  });
})(SFPanel.forTools("metadata"));
