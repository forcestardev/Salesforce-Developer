// js/package.js — "Build Manifest" (package.xml generator) tab:
// 3-pane package generator for selecting metadata types, picking individual members
// or wildcards (*), and generating package.xml in real time.

((SFPanel) => {
  const COMMON_TYPES = new Set([
    "apexclass",
    "apexpage",
    "apextrigger",
    "auradefinitionbundle",
    "customapplication",
    "customfield",
    "customlabel",
    "custommetadata",
    "customobject",
    "custompermission",
    "customtab",
    "dashboard",
    "emailtemplate",
    "fieldset",
    "flexipage",
    "flow",
    "globalvalueset",
    "layout",
    "lightningcomponentbundle",
    "permissionset",
    "permissionsetgroup",
    "profile",
    "quickaction",
    "recordtype",
    "report",
    "staticresource",
    "validationrule",
    "workflow",
    "workflowrule"
  ]);

  const TYPE_DISPLAY_NAMES = {
    apexclass: "Apex Class",
    apexpage: "Visualforce Page",
    apextrigger: "Apex Trigger",
    auradefinitionbundle: "Aura Component Bundle",
    customapplication: "Custom Application",
    customfield: "Custom Field",
    customlabel: "Custom Label",
    custommetadata: "Custom Metadata Type",
    customobject: "Custom Object / sObject",
    custompermission: "Custom Permission",
    customtab: "Custom Tab",
    dashboard: "Dashboard",
    emailtemplate: "Email Template",
    fieldset: "Field Set",
    flexipage: "Lightning Page (FlexiPage)",
    flow: "Flow / Process Builder",
    globalvalueset: "Global Value Set",
    layout: "Page Layout",
    lightningcomponentbundle: "Lightning Web Component",
    permissionset: "Permission Set",
    permissionsetgroup: "Permission Set Group",
    profile: "Profile",
    quickaction: "Quick Action",
    recordtype: "Record Type",
    report: "Report",
    staticresource: "Static Resource",
    validationrule: "Validation Rule",
    workflow: "Workflow",
    workflowrule: "Workflow Rule"
  };

  // Element references
  const typesCountEl = document.getElementById("pkgTypesCount");
  const typeSearchInput = document.getElementById("pkgTypeSearch");
  const commonTypesToggle = document.getElementById("pkgCommonTypesToggle");
  const selectAllTypesCheckbox = document.getElementById("pkgSelectAllTypes");
  const typeListEl = document.getElementById("pkgTypeList");

  const membersTitleEl = document.getElementById("pkgMembersTitle");
  const membersCountEl = document.getElementById("pkgMembersCount");
  const membersToolbar = document.getElementById("pkgMembersToolbar");
  const memberSearchInput = document.getElementById("pkgMemberSearch");
  const namespaceFilterSelect = document.getElementById("pkgNamespaceFilter");
  const selectAllRow = document.getElementById("pkgMembersSelectAllRow");
  const selectAllCheckbox = document.getElementById("pkgSelectAllMembers");
  const membersEmptyEl = document.getElementById("pkgMembersEmpty");
  const memberListEl = document.getElementById("pkgMemberList");

  const apiVersionSelect = document.getElementById("pkgApiVersion");
  const outputEl = document.getElementById("pkgOutput");
  const copyButton = document.getElementById("pkgCopy");
  const downloadButton = document.getElementById("pkgDownload");
  const statusEl = document.getElementById("pkgStatus");

  const resizeHandle1 = document.getElementById("pkgResizeHandle1");
  const resizeHandle2 = document.getElementById("pkgResizeHandle2");

  // State
  let loadedTypesHostname = null;
  let allMetadataTypes = []; // [{ xmlName, label, inFolder }]
  let activeTypeName = null;
  const memberCache = new Map(); // xmlName -> members[]: { name, label, namespace }
  const selectedState = new Map(); // xmlName -> { wildcard: boolean, members: Set<string> }

  function getSelectionForType(typeName) {
    if (!selectedState.has(typeName)) {
      selectedState.set(typeName, { wildcard: false, members: new Set() });
    }
    return selectedState.get(typeName);
  }

  function setStatus(message, isError = true) {
    if (!statusEl) return;
    statusEl.textContent = message || "";
    statusEl.style.color = isError ? "#c00" : "inherit";
  }

  function escapeXml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // Generate package.xml live
  function generatePackageXml() {
    const rawVersion = apiVersionSelect ? apiVersionSelect.value : "65.0";
    const version = (rawVersion || "65.0").trim().replace(/^v/i, "");
    const typeBlocks = [];
    let selectedTypeCount = 0;

    const activeTypes = Array.from(selectedState.keys()).sort();

    for (const typeName of activeTypes) {
      const state = selectedState.get(typeName);
      if (!state) continue;

      if (state.wildcard) {
        typeBlocks.push(`  <types>\n    <members>*</members>\n    <name>${escapeXml(typeName)}</name>\n  </types>`);
        selectedTypeCount++;
      } else if (state.members.size > 0) {
        const sortedMembers = Array.from(state.members).sort();
        const memberTags = sortedMembers.map((m) => `    <members>${escapeXml(m)}</members>`).join("\n");
        typeBlocks.push(`  <types>\n${memberTags}\n    <name>${escapeXml(typeName)}</name>\n  </types>`);
        selectedTypeCount++;
      }
    }

    typesCountEl.textContent = `${selectedTypeCount} selected`;

    if (typeBlocks.length === 0) {
      outputEl.value = `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata">\n  <version>${escapeXml(
        version
      )}</version>\n</Package>\n`;
      return;
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<Package xmlns="http://soap.sforce.com/2006/04/metadata">\n${typeBlocks.join(
      "\n"
    )}\n  <version>${escapeXml(version)}</version>\n</Package>\n`;

    outputEl.value = xml;
  }

  function cleanLabel(rawLabel, xmlName) {
    if (typeof rawLabel === "string" && rawLabel && !rawLabel.includes("__MISSING LABEL__")) {
      return rawLabel;
    }
    return xmlName;
  }

  function getVisibleMetadataTypes() {
    const term = (typeSearchInput.value || "").trim().toLowerCase();
    const commonOnly = commonTypesToggle ? commonTypesToggle.checked : true;
    let filtered = commonOnly
      ? allMetadataTypes.filter((t) => COMMON_TYPES.has(t.xmlName.toLowerCase()))
      : allMetadataTypes;
    if (term) {
      filtered = filtered.filter(
        (t) => t.xmlName.toLowerCase().includes(term) || (t.label && t.label.toLowerCase().includes(term))
      );
    }
    return filtered;
  }

  function updateSelectAllTypesState() {
    if (!selectAllTypesCheckbox) return;
    const visibleTypes = getVisibleMetadataTypes();
    const selectedCount = visibleTypes.filter((type) => {
      const state = getSelectionForType(type.xmlName);
      return state.wildcard || state.members.size > 0;
    }).length;
    selectAllTypesCheckbox.checked = visibleTypes.length > 0 && selectedCount === visibleTypes.length;
    selectAllTypesCheckbox.indeterminate = selectedCount > 0 && selectedCount < visibleTypes.length;
  }

  // Render Pane 1 (Metadata Types List)
  function renderTypesList() {
    typeListEl.textContent = "";
    const filtered = getVisibleMetadataTypes();

    filtered.forEach((t) => {
      const li = document.createElement("li");
      li.className = "pkg-list-item";
      if (t.xmlName === activeTypeName) li.classList.add("active");

      const cb = document.createElement("input");
      cb.type = "checkbox";
      const selState = getSelectionForType(t.xmlName);
      const cachedMembers = memberCache.get(t.xmlName) || [];
      const totalMembers = cachedMembers.length;

      if (selState.wildcard || (totalMembers > 0 && selState.members.size === totalMembers)) {
        cb.checked = true;
        cb.indeterminate = false;
      } else if (selState.members.size > 0) {
        cb.checked = false;
        cb.indeterminate = true;
      } else {
        cb.checked = false;
        cb.indeterminate = false;
      }

      cb.addEventListener("click", (e) => {
        e.stopPropagation();
        if (selState.wildcard || selState.members.size > 0) {
          selState.wildcard = false;
          selState.members.clear();
        } else {
          selState.wildcard = true;
        }
        renderTypesList();
        if (activeTypeName === t.xmlName) {
          updateMembersSelectAllRow();
          renderMembersList();
        }
        generatePackageXml();
      });

      const displayLabel = cleanLabel(t.label, t.xmlName);
      const labelSpan = document.createElement("span");
      labelSpan.className = "pkg-item-label";
      labelSpan.textContent = displayLabel && displayLabel !== t.xmlName ? `${displayLabel} (${t.xmlName})` : t.xmlName;

      const badgeSpan = document.createElement("span");
      badgeSpan.className = "pkg-item-badge";
      if (selState.wildcard) {
        badgeSpan.textContent = "(*)";
      } else if (selState.members.size > 0) {
        badgeSpan.textContent = `(${selState.members.size})`;
      } else {
        badgeSpan.textContent = "";
      }

      li.appendChild(cb);
      li.appendChild(labelSpan);
      li.appendChild(badgeSpan);

      li.addEventListener("click", () => selectMetadataType(t));
      typeListEl.appendChild(li);
    });
    updateSelectAllTypesState();
  }

  // Query mapping for Pane 2 member loading
  function getMemberQuery(xmlName) {
    switch (xmlName) {
      case "ApexClass": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM ApexClass ORDER BY Name" };
      case "ApexTrigger": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM ApexTrigger ORDER BY Name" };
      case "ApexPage": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM ApexPage ORDER BY Name" };
      case "ApexComponent": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM ApexComponent ORDER BY Name" };
      case "AuraDefinitionBundle": return { endpoint: "tooling", query: "SELECT Id, DeveloperName, NamespacePrefix FROM AuraDefinitionBundle ORDER BY DeveloperName" };
      case "LightningComponentBundle": return { endpoint: "tooling", query: "SELECT Id, DeveloperName, NamespacePrefix FROM LightningComponentBundle ORDER BY DeveloperName" };
      case "Flow": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM FlowDefinition ORDER BY DeveloperName" };
      case "PermissionSet": return { endpoint: "data", query: "SELECT Id, Name, Label, NamespacePrefix FROM PermissionSet WHERE IsOwnedByProfile = false ORDER BY Name" };
      case "PermissionSetGroup": return { endpoint: "data", query: "SELECT Id, DeveloperName, NamespacePrefix FROM PermissionSetGroup ORDER BY DeveloperName" };
      case "Profile": return { endpoint: "data", query: "SELECT Id, Name FROM Profile ORDER BY Name" };
      case "CustomTab": return { endpoint: "tooling", query: "SELECT Id, Name FROM CustomTab ORDER BY Name" };
      case "CustomPermission": return { endpoint: "data", query: "SELECT Id, DeveloperName, NamespacePrefix FROM CustomPermission ORDER BY DeveloperName" };
      case "Layout": return { endpoint: "tooling", query: "SELECT Id, Name, TableEnumOrId FROM Layout ORDER BY Name" };
      case "StaticResource": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM StaticResource ORDER BY Name" };
      case "CustomLabel": return { endpoint: "tooling", query: "SELECT Id, Name, NamespacePrefix FROM ExternalString ORDER BY Name" };
      case "GlobalValueSet": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM GlobalValueSet ORDER BY DeveloperName" };
      case "CompactLayout": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM CompactLayout ORDER BY DeveloperName" };
      case "FlexiPage": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM FlexiPage ORDER BY DeveloperName" };
      case "WorkflowRule": return { endpoint: "tooling", query: "SELECT Id, Name FROM WorkflowRule ORDER BY Name" };
      case "ValidationRule": return { endpoint: "tooling", query: "SELECT Id, ValidationName, EntityDefinition.QualifiedApiName FROM ValidationRule ORDER BY ValidationName" };
      case "CustomApplication": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM CustomApplication ORDER BY DeveloperName" };
      case "CustomField": return { endpoint: "tooling", query: "SELECT Id, DeveloperName, TableEnumOrId FROM CustomField ORDER BY DeveloperName" };
      case "FieldSet": return { endpoint: "tooling", query: "SELECT Id, DeveloperName, EntityDefinition.QualifiedApiName FROM FieldSet ORDER BY DeveloperName" };
      case "EmailTemplate": return { endpoint: "data", query: "SELECT Id, DeveloperName, Name FROM EmailTemplate ORDER BY Name" };
      case "Report": return { endpoint: "data", query: "SELECT Id, DeveloperName, Name FROM Report ORDER BY Name" };
      case "Dashboard": return { endpoint: "data", query: "SELECT Id, DeveloperName, Title FROM Dashboard ORDER BY Title" };
      case "RecordType": return { endpoint: "data", query: "SELECT Id, DeveloperName, SobjectType FROM RecordType ORDER BY DeveloperName" };
      case "QuickAction": return { endpoint: "tooling", query: "SELECT Id, DeveloperName FROM QuickActionDefinition ORDER BY DeveloperName" };
      default:
        return null;
    }
  }

  async function runQueryCandidate(hostname, endpoint, query) {
    const restPath = `/services/data/${SFPanel.API_VERSION}/${endpoint === "tooling" ? "tooling/" : ""}query/?q=${encodeURIComponent(query)}`;
    const res = await SFPanel.sendMessage({
      type: "restRequest",
      hostname,
      method: "GET",
      path: restPath
    });
    const records = (res.data && res.data.records) || [];
    return records.map((rec) => {
      let memberName = rec.Name || rec.DeveloperName || rec.ValidationName || rec.Title || rec.Id;
      if (rec.EntityDefinition && rec.EntityDefinition.QualifiedApiName && rec.ValidationName) {
        memberName = `${rec.EntityDefinition.QualifiedApiName}.${rec.ValidationName}`;
      } else if (rec.EntityDefinition && rec.EntityDefinition.QualifiedApiName && rec.DeveloperName) {
        memberName = `${rec.EntityDefinition.QualifiedApiName}.${rec.DeveloperName}`;
      } else if (rec.SobjectType && rec.DeveloperName) {
        memberName = `${rec.SobjectType}.${rec.DeveloperName}`;
      }
      const ns = rec.NamespacePrefix || "";
      return {
        name: memberName,
        label: rec.Label || rec.MasterLabel || rec.Title ? `${rec.Label || rec.MasterLabel || rec.Title} (${memberName})` : memberName,
        namespace: ns
      };
    }).sort((a, b) => a.name.localeCompare(b.name));
  }

  // Fetch members for a metadata type
  async function fetchMembers(typeObj, hostname) {
    const xmlName = typeObj.xmlName;

    if (xmlName === "CustomObject") {
      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      return (objects || []).map((o) => ({
        name: o.name,
        label: `${o.label} (${o.name})`,
        namespace: o.custom && o.name.includes("__") ? o.name.split("__")[0] : ""
      })).sort((a, b) => a.name.localeCompare(b.name));
    }

    if (xmlName === "CustomMetadata") {
      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      const mdtObjects = (objects || []).filter((o) => o.name.endsWith("__mdt"));
      return mdtObjects.map((o) => ({
        name: o.name,
        label: `${o.label} (${o.name})`,
        namespace: o.custom && o.name.includes("__") ? o.name.split("__")[0] : ""
      })).sort((a, b) => a.name.localeCompare(b.name));
    }

    const specificQuery = getMemberQuery(xmlName);
    if (specificQuery) {
      try {
        return await runQueryCandidate(hostname, specificQuery.endpoint, specificQuery.query);
      } catch {
        // fall through to candidate list
      }
    }

    // Candidate query fallback chain for generic or unhandled types
    const candidates = [
      { endpoint: "tooling", query: `SELECT Id, DeveloperName, NamespacePrefix FROM ${xmlName} ORDER BY DeveloperName` },
      { endpoint: "tooling", query: `SELECT Id, Name, NamespacePrefix FROM ${xmlName} ORDER BY Name` },
      { endpoint: "data", query: `SELECT Id, DeveloperName, NamespacePrefix FROM ${xmlName} ORDER BY DeveloperName` },
      { endpoint: "data", query: `SELECT Id, Name FROM ${xmlName} ORDER BY Name` },
      { endpoint: "data", query: `SELECT Id, MasterLabel FROM ${xmlName} ORDER BY MasterLabel` }
    ];

    for (const cand of candidates) {
      try {
        const results = await runQueryCandidate(hostname, cand.endpoint, cand.query);
        if (results && results.length > 0) return results;
      } catch {
        // try next candidate
      }
    }

    return [];
  }

  function updateMembersSelectAllRow() {
    if (!activeTypeName) return;
    const selState = getSelectionForType(activeTypeName);
    const members = memberCache.get(activeTypeName) || [];
    const totalCount = members.length;

    if (selState.wildcard || (totalCount > 0 && selState.members.size === totalCount)) {
      selectAllCheckbox.checked = true;
      selectAllCheckbox.indeterminate = false;
    } else if (selState.members.size > 0) {
      selectAllCheckbox.checked = false;
      selectAllCheckbox.indeterminate = true;
    } else {
      selectAllCheckbox.checked = false;
      selectAllCheckbox.indeterminate = false;
    }
  }

  function isNamespacedMember(member) {
    if (member.namespace) return true;
    return activeTypeName === "CustomObject"
      && (member.name.endsWith("__c") || member.name.includes("__"));
  }

  // Render Pane 2 (Members List)
  function renderMembersList() {
    if (!activeTypeName) return;
    memberListEl.textContent = "";

    const members = memberCache.get(activeTypeName) || [];
    const term = (memberSearchInput.value || "").trim().toLowerCase();
    const nsFilter = namespaceFilterSelect.value;
    const selState = getSelectionForType(activeTypeName);

    const filtered = members.filter((m) => {
      const matchesSearch = !term || m.name.toLowerCase().includes(term) || m.label.toLowerCase().includes(term);
      let matchesNs = true;
      if (nsFilter === "custom") {
        matchesNs = isNamespacedMember(m);
      } else if (nsFilter === "standard") {
        matchesNs = !isNamespacedMember(m);
      }
      return matchesSearch && matchesNs;
    });

    membersCountEl.textContent = `${filtered.length} members (${selState.members.size} selected)`;

    filtered.forEach((m) => {
      const li = document.createElement("li");
      li.className = "pkg-list-item";

      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = selState.wildcard || selState.members.has(m.name);

      cb.addEventListener("change", () => {
        if (cb.checked) {
          selState.members.add(m.name);
          if (members.length > 0 && selState.members.size === members.length) {
            selState.wildcard = true;
          }
        } else {
          selState.members.delete(m.name);
          selState.wildcard = false;
        }
        updateMembersSelectAllRow();
        renderTypesList();
        generatePackageXml();
      });

      const labelSpan = document.createElement("span");
      labelSpan.className = "pkg-item-label";
      labelSpan.textContent = m.label;

      li.appendChild(cb);
      li.appendChild(labelSpan);

      li.addEventListener("click", (e) => {
        if (e.target !== cb) {
          cb.checked = !cb.checked;
          cb.dispatchEvent(new Event("change"));
        }
      });

      memberListEl.appendChild(li);
    });
  }

  async function selectMetadataType(typeObj) {
    activeTypeName = typeObj.xmlName;
    renderTypesList();

    membersTitleEl.textContent = `Members — ${typeObj.label || typeObj.xmlName}`;
    membersEmptyEl.hidden = true;
    memberListEl.hidden = false;
    membersToolbar.hidden = false;
    selectAllRow.hidden = false;

    updateMembersSelectAllRow();

    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    if (memberCache.has(typeObj.xmlName)) {
      renderMembersList();
      return;
    }

    membersCountEl.textContent = "Loading members…";
    memberListEl.textContent = "";

    try {
      const fetched = await fetchMembers(typeObj, hostname);
      memberCache.set(typeObj.xmlName, fetched);
      renderMembersList();
      setStatus("", false);
    } catch (err) {
      membersCountEl.textContent = "0 members found";
      memberListEl.textContent = "";
      setStatus(`Failed to fetch members for ${typeObj.label || typeObj.xmlName}: ${err.message}`);
    }
  }

  // Load all metadata types from org
  async function loadMetadataTypes() {
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    setStatus("Loading metadata types from org…", false);

    try {
      const typeMap = new Map();

      // Seed with predefined common types so they are always present
      COMMON_TYPES.forEach((key) => {
        const displayLabel = TYPE_DISPLAY_NAMES[key] || key;
        const xmlName = Object.keys(TYPE_DISPLAY_NAMES).find((k) => k === key) ? TYPE_DISPLAY_NAMES[key] : key;
        // Find matching proper casing
        let properXmlName = xmlName;
        if (key === "apexclass") properXmlName = "ApexClass";
        else if (key === "apexpage") properXmlName = "ApexPage";
        else if (key === "apextrigger") properXmlName = "ApexTrigger";
        else if (key === "auradefinitionbundle") properXmlName = "AuraDefinitionBundle";
        else if (key === "customapplication") properXmlName = "CustomApplication";
        else if (key === "customfield") properXmlName = "CustomField";
        else if (key === "customlabel") properXmlName = "CustomLabel";
        else if (key === "custommetadata") properXmlName = "CustomMetadata";
        else if (key === "customobject") properXmlName = "CustomObject";
        else if (key === "custompermission") properXmlName = "CustomPermission";
        else if (key === "customtab") properXmlName = "CustomTab";
        else if (key === "dashboard") properXmlName = "Dashboard";
        else if (key === "emailtemplate") properXmlName = "EmailTemplate";
        else if (key === "fieldset") properXmlName = "FieldSet";
        else if (key === "flexipage") properXmlName = "FlexiPage";
        else if (key === "flow") properXmlName = "Flow";
        else if (key === "globalvalueset") properXmlName = "GlobalValueSet";
        else if (key === "layout") properXmlName = "Layout";
        else if (key === "lightningcomponentbundle") properXmlName = "LightningComponentBundle";
        else if (key === "permissionset") properXmlName = "PermissionSet";
        else if (key === "permissionsetgroup") properXmlName = "PermissionSetGroup";
        else if (key === "profile") properXmlName = "Profile";
        else if (key === "quickaction") properXmlName = "QuickAction";
        else if (key === "recordtype") properXmlName = "RecordType";
        else if (key === "report") properXmlName = "Report";
        else if (key === "staticresource") properXmlName = "StaticResource";
        else if (key === "validationrule") properXmlName = "ValidationRule";
        else if (key === "workflow") properXmlName = "Workflow";
        else if (key === "workflowrule") properXmlName = "WorkflowRule";

        typeMap.set(properXmlName, {
          xmlName: properXmlName,
          label: displayLabel
        });
      });

      // Fetch Tooling sObjects
      try {
        const toolingRes = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/`
        });
        const toolingList = (toolingRes.data && toolingRes.data.sobjects) || [];
        toolingList.forEach((o) => {
          const xmlName = o.name;
          if (!xmlName) return;
          const displayLabel = TYPE_DISPLAY_NAMES[xmlName.toLowerCase()] || cleanLabel(o.label, xmlName);
          typeMap.set(xmlName, {
            xmlName,
            label: displayLabel
          });
        });
      } catch {
        // ignore tooling fetch error
      }

      // Fetch Standard sObjects
      try {
        const stdRes = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/sobjects/`
        });
        const stdList = (stdRes.data && stdRes.data.sobjects) || [];
        stdList.forEach((o) => {
          const xmlName = o.name;
          if (!xmlName) return;
          if (!typeMap.has(xmlName)) {
            const displayLabel = TYPE_DISPLAY_NAMES[xmlName.toLowerCase()] || cleanLabel(o.label, xmlName);
            typeMap.set(xmlName, {
              xmlName,
              label: displayLabel
            });
          }
        });
      } catch {
        // ignore std fetch error
      }

      allMetadataTypes = Array.from(typeMap.values()).sort((a, b) =>
        (a.label || a.xmlName).localeCompare(b.label || b.xmlName)
      );

      loadedTypesHostname = hostname;
      renderTypesList();
      setStatus("", false);
    } catch (err) {
      setStatus(`Failed to load metadata types: ${err.message}`);
    }
  }

  // Load API versions for Pane 3 dropdown
  async function loadApiVersions(hostname) {
    if (!apiVersionSelect || !hostname) return;
    try {
      const result = await SFPanel.sendMessage({
        type: "restRequest",
        hostname,
        method: "GET",
        path: "/services/data/"
      });
      if (Array.isArray(result.data) && result.data.length > 0) {
        const versions = result.data
          .map((item) => item.version)
          .filter((v) => v && /^\d+\.\d+$/.test(v))
          .sort((a, b) => Number(b) - Number(a));

        if (versions.length > 0) {
          apiVersionSelect.textContent = "";
          versions.forEach((v) => {
            const opt = document.createElement("option");
            opt.value = v;
            opt.textContent = v;
            apiVersionSelect.appendChild(opt);
          });
          apiVersionSelect.value = versions[0];
          generatePackageXml();
        }
      }
    } catch {
      // Keep default options on error
    }
  }

  // Wire controls
  typeSearchInput.addEventListener("input", renderTypesList);
  if (commonTypesToggle) commonTypesToggle.addEventListener("change", renderTypesList);

  if (selectAllTypesCheckbox) {
    selectAllTypesCheckbox.addEventListener("change", () => {
      getVisibleMetadataTypes().forEach((type) => {
        const state = getSelectionForType(type.xmlName);
        state.wildcard = selectAllTypesCheckbox.checked;
        if (!selectAllTypesCheckbox.checked) state.members.clear();
      });
      renderTypesList();
      if (activeTypeName) {
        updateMembersSelectAllRow();
        renderMembersList();
      }
      generatePackageXml();
    });
  }

  memberSearchInput.addEventListener("input", renderMembersList);
  namespaceFilterSelect.addEventListener("change", renderMembersList);

  selectAllCheckbox.addEventListener("change", () => {
    if (!activeTypeName) return;
    const selState = getSelectionForType(activeTypeName);

    if (selectAllCheckbox.checked) {
      selState.wildcard = true;
      const members = memberCache.get(activeTypeName) || [];
      members.forEach((m) => selState.members.add(m.name));
    } else {
      selState.wildcard = false;
      selState.members.clear();
    }

    renderTypesList();
    renderMembersList();
    generatePackageXml();
  });

  if (apiVersionSelect) {
    apiVersionSelect.addEventListener("change", generatePackageXml);
  }

  copyButton.addEventListener("click", async () => {
    if (!outputEl.value) return;
    try {
      await navigator.clipboard.writeText(outputEl.value);
      setStatus("package.xml copied to clipboard.", false);
    } catch {
      outputEl.select();
      setStatus("Text selected for manual copy.");
    }
  });

  downloadButton.addEventListener("click", () => {
    if (!outputEl.value) return;
    const blob = new Blob([outputEl.value], { type: "application/xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "package.xml";
    a.click();
    URL.revokeObjectURL(url);
  });

  // Pane resizers
  (function initPkgResize() {
    const MIN_PANE_WIDTH = 150;
    const HANDLE_WIDTH = 5;
    const splitEl = document.querySelector(".pkg-split");
    if (!splitEl) return;

    let col1Width = 280;
    let col3Width = 280;

    function maxSidePaneWidth() {
      const totalWidth = splitEl.getBoundingClientRect().width;
      return Math.max(MIN_PANE_WIDTH, totalWidth - col1Width - (HANDLE_WIDTH * 2) - 180);
    }

    function applyGrid() {
      col3Width = Math.min(maxSidePaneWidth(), Math.max(MIN_PANE_WIDTH, col3Width));
      splitEl.style.gridTemplateColumns = `${col1Width}px ${HANDLE_WIDTH}px minmax(150px, 1fr) ${HANDLE_WIDTH}px ${col3Width}px`;
    }

    if (resizeHandle1) {
      let isDragging = false;
      let startX = 0;
      let startWidth = 0;

      resizeHandle1.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        isDragging = true;
        resizeHandle1.setPointerCapture?.(e.pointerId);
        startX = e.clientX;
        startWidth = col1Width;
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
      });

      document.addEventListener("pointermove", (e) => {
        if (!isDragging) return;
        col1Width = Math.max(MIN_PANE_WIDTH, startWidth + e.clientX - startX);
        applyGrid();
      });

      document.addEventListener("pointerup", () => {
        if (isDragging) {
          isDragging = false;
          document.body.style.cursor = "";
          document.body.style.userSelect = "";
        }
      });
    }

    if (resizeHandle2) {
      let isDragging = false;
      let startX = 0;
      let startWidth = 0;

      resizeHandle2.addEventListener("pointerdown", (e) => {
        e.preventDefault();
        isDragging = true;
        resizeHandle2.setPointerCapture?.(e.pointerId);
        startX = e.clientX;
        startWidth = col3Width;
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
      });

      document.addEventListener("pointermove", (e) => {
        if (!isDragging) return;
        col3Width = Math.min(maxSidePaneWidth(), Math.max(MIN_PANE_WIDTH, startWidth - (e.clientX - startX)));
        applyGrid();
      });

      document.addEventListener("pointerup", () => {
        if (isDragging) {
          isDragging = false;
          document.body.style.cursor = "";
          document.body.style.userSelect = "";
        }
      });
    }
  })();

  SFPanel.registerTab("package", {
    onShow(hostname) {
      if (hostname) {
        if (loadedTypesHostname !== hostname || allMetadataTypes.length === 0) {
          loadMetadataTypes();
        }
        loadApiVersions(hostname);
      }
      renderTypesList();
      generatePackageXml();
    },
    onHostnameChange(hostname) {
      if (hostname) {
        loadedTypesHostname = null;
        allMetadataTypes = [];
        memberCache.clear();
        loadMetadataTypes();
        loadApiVersions(hostname);
      }
    }
  });
})(SFPanel.forTools("package"));
