// js/soql.js — "SOQL Runner" tab: detects the Salesforce object/record/config
// context of the current browser tab (Lightning record/list/Object Manager
// pages, or Classic record/list-view URLs) to pre-build a starter query, or
// falls back to a manual object picker. Runs the query via the Tooling-free
// standard REST query endpoint and renders results as a table.

((SFPanel) => {
  const objectSelect = document.getElementById("soqlObjectSelect");
  const loadFieldsButton = document.getElementById("soqlLoadFields");
  const selectAllFieldsButton = document.getElementById("soqlSelectAllFields");
  const clearFieldsButton = document.getElementById("soqlClearFields");
  const fieldSearchInput = document.getElementById("soqlFieldSearch");
  const fieldList = document.getElementById("soqlFieldList");
  const addFilterButton = document.getElementById("soqlAddFilter");
  const filterList = document.getElementById("soqlFilterList");
  const contextInfoEl = document.getElementById("soqlContextInfo");
  const queryTextarea = document.getElementById("soqlQuery");
  const runButton = document.getElementById("soqlRun");
  const rowCountEl = document.getElementById("soqlRowCount");
  const statusEl = document.getElementById("soqlStatus");
  const loadMoreButton = document.getElementById("soqlLoadMore");
  const exportAllCheckbox = document.getElementById("soqlExportAll");
  const saveCsvButton = document.getElementById("soqlSaveCsv");
  const saveJsonButton = document.getElementById("soqlSaveJson");
  const copyCsvButton = document.getElementById("soqlCopyCsv");
  const copyJsonButton = document.getElementById("soqlCopyJson");
  const toast = document.getElementById("soqlToast");
  const splitHandle = document.getElementById("soqlSplitHandle");
  const resultsWrapper = document.querySelector(".soql-results-wrapper");
  const querySection = document.querySelector(".soql-query-section");
  const resultsSection = document.getElementById("soqlResultsSection");
  const table = document.getElementById("soqlResultsTable");
  const theadRow = table.querySelector("thead tr");
  const tbody = table.querySelector("tbody");

  let allObjects = [];
  let objectsLoaded = false;
  let contextDetected = false;
  let contextDetectionPromise = null;
  let contextGeneration = 0;
  let nextRecordsPath = null;
  let accumulatedRecords = [];
  let lastTotalSize = 0;
  let objectFields = [];
  const selectedFields = new Set();
  const resultFilters = new Map();
  let openResultFilterMenu = null;

  function syncSectionLayout() {
    const queryCollapsed = querySection.classList.contains("is-collapsed");
    const resultsCollapsed = resultsSection.classList.contains("is-collapsed");
    document.getElementById("tab-soql").classList.toggle("soql-query-expanded", !queryCollapsed && resultsCollapsed);
    splitHandle.hidden = queryCollapsed || resultsCollapsed;
    querySection.querySelector("[data-soql-section-toggle]").setAttribute("aria-expanded", String(!queryCollapsed));
    resultsSection.querySelector("[data-soql-section-toggle]").setAttribute("aria-expanded", String(!resultsCollapsed));
  }

  document.querySelectorAll("[data-soql-section-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const section = button.dataset.soqlSectionToggle === "query" ? querySection : resultsSection;
      section.classList.toggle("is-collapsed");
      syncSectionLayout();
    });
  });

  (function initSplitResize() {
    const MIN_QUERY_HEIGHT = 410;
    const MIN_RESULTS_HEIGHT = 150;
    const splitEl = querySection.parentElement;
    let dragStartY = 0;
    let dragStartHeight = 0;
    let isDragging = false;

    function maxQueryHeight() {
      return Math.max(MIN_QUERY_HEIGHT, splitEl.getBoundingClientRect().height - MIN_RESULTS_HEIGHT - splitHandle.getBoundingClientRect().height - 24);
    }

    function setQueryHeight(height) {
      const clamped = Math.min(maxQueryHeight(), Math.max(MIN_QUERY_HEIGHT, height));
      querySection.style.flexBasis = `${clamped}px`;
    }

    function beginDrag(clientY) {
      dragStartY = clientY;
      dragStartHeight = querySection.getBoundingClientRect().height;
      isDragging = true;
      document.body.style.cursor = "ns-resize";
      document.body.style.userSelect = "none";
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    splitHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientY);
      splitHandle.setPointerCapture?.(event.pointerId);
    });
    splitHandle.addEventListener("pointermove", (event) => {
      if (isDragging) setQueryHeight(dragStartHeight + event.clientY - dragStartY);
    });
    splitHandle.addEventListener("pointerup", endDrag);
    splitHandle.addEventListener("pointercancel", endDrag);
    splitHandle.addEventListener("keydown", (event) => {
      const movement = event.key === "ArrowUp" ? -20 : event.key === "ArrowDown" ? 20 : 0;
      if (!movement) return;
      event.preventDefault();
      setQueryHeight(querySection.getBoundingClientRect().height + movement);
    });
  })();

  function setStatus(message, isError = true) {
    statusEl.textContent = message || "";
    statusEl.style.color = isError ? "#c00" : "inherit";
    statusEl.setAttribute("role", message && isError ? "alert" : "status");
    if (message && resultsSection.classList.contains("is-collapsed")) {
      resultsSection.classList.remove("is-collapsed");
      syncSectionLayout();
    }
  }

  // The query box grows to fit its text until the user resizes it by hand.
  let queryAutoHeight = null;
  let queryManuallyResized = false;
  queryTextarea.addEventListener("pointerup", () => {
    if (queryAutoHeight !== null && Math.abs(queryTextarea.offsetHeight - queryAutoHeight) > 2) queryManuallyResized = true;
  });

  function autoSizeQuery() {
    if (queryManuallyResized) return;
    queryTextarea.style.height = "auto";
    queryTextarea.style.height = `${Math.min(queryTextarea.scrollHeight + 2, 200)}px`;
    queryAutoHeight = queryTextarea.offsetHeight;
  }

  function syncQueryObjectState() {
    querySection.classList.toggle("has-selected-object", Boolean(objectSelect.value));
  }

  function syncRunButtonState() {
    runButton.disabled = !queryTextarea.value.trim();
    autoSizeQuery();
  }

  function showToast(message) {
    toast.textContent = message;
    toast.hidden = false;
  }

  document.addEventListener("click", (event) => {
    if (!toast.hidden && !toast.contains(event.target)) toast.hidden = true;
  });

  async function querySalesforce(query, tooling = false) {
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/${tooling ? "tooling/" : ""}query/?q=${encodeURIComponent(query)}`
    });
    return result.data.records || [];
  }

  async function getToolingRecord(objectName, recordId) {
    const result = await SFPanel.sendMessage({
      type: "restRequest",
      hostname: SFPanel.getHostname(),
      method: "GET",
      path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${objectName}/${encodeURIComponent(recordId)}`
    });
    return result.data;
  }

  function populateObjectSelect(selectedName) {
    objectSelect.textContent = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Select an object…";
    objectSelect.appendChild(placeholder);

    for (const obj of allObjects) {
      if (obj.queryable !== true) continue;
      const option = document.createElement("option");
      option.value = obj.name;
      option.textContent = `${obj.label} (${obj.name})`;
      objectSelect.appendChild(option);
    }

    objectSelect.disabled = false;
    if (allObjects.some((object) => object.name === selectedName && object.queryable === true)) objectSelect.value = selectedName;
    syncQueryObjectState();
  }

  function showNonQueryableObject(objectName) {
    const message = objectName === "Activity"
      ? "Activity is not queryable. Select Task or Event explicitly to build a SOQL query."
      : `${objectName} is not queryable. Select a queryable object to build a SOQL query.`;
    objectSelect.value = "";
    objectFields = [];
    selectedFields.clear();
    filterList.textContent = "";
    queryTextarea.value = "";
    fieldList.textContent = message;
    contextInfoEl.textContent = message;
    fieldSearchInput.disabled = true;
    selectAllFieldsButton.disabled = true;
    clearFieldsButton.disabled = true;
    addFilterButton.disabled = true;
    syncQueryObjectState();
    syncRunButtonState();
    setStatus("", false);
  }

  function validFieldName(name) {
    return typeof name === "string" && /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
  }

  function renderFieldList() {
    fieldList.textContent = "";
    const term = fieldSearchInput.value.trim().toLowerCase();
    const fields = objectFields.filter((field) =>
      !term || field.name.toLowerCase().includes(term) || field.label.toLowerCase().includes(term)
    ).sort((left, right) =>
      (left.name === "Id" ? 0 : left.name === "Name" ? 1 : 2) -
        (right.name === "Id" ? 0 : right.name === "Name" ? 1 : 2) ||
      left.label.localeCompare(right.label) || left.name.localeCompare(right.name)
    );

    if (!fields.length) {
      fieldList.textContent = objectFields.length ? "No matching fields." : "Load an object to see its fields.";
      return;
    }

    const fragment = document.createDocumentFragment();
    for (const field of fields) {
      const label = document.createElement("label");
      label.className = "soql-field-option";
      label.title = `${field.label} (${field.name})`;
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.value = field.name;
      checkbox.checked = selectedFields.has(field.name);
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) selectedFields.add(field.name);
        else selectedFields.delete(field.name);
        updateGeneratedQuery();
      });
      const text = document.createElement("span");
      text.textContent = `${field.label} (${field.name})`;
      label.append(checkbox, text);
      fragment.appendChild(label);
    }
    fieldList.appendChild(fragment);
  }

  async function loadFields() {
    const objectName = objectSelect.value;
    if (!objectName) {
      return;
    }
    if (!allObjects.some((object) => object.name === objectName && object.queryable === true)) {
      showNonQueryableObject(objectName);
      return;
    }
    selectAllFieldsButton.disabled = false;
    clearFieldsButton.disabled = false;
    addFilterButton.disabled = false;
    contextInfoEl.textContent = "";

    loadFieldsButton.disabled = true;
    fieldList.textContent = "Loading fields…";
    try {
      const { fields } = await SFPanel.sendMessage({
        type: "getObjectFields",
        hostname: SFPanel.getHostname(),
        objectName
      });
      objectFields = fields.filter((field) => validFieldName(field.name));
      selectedFields.clear();
      objectFields.forEach((field) => {
        if (field.name === "Id" || field.name === "Name") selectedFields.add(field.name);
      });
      fieldSearchInput.disabled = false;
      renderFieldList();
      updateGeneratedQuery();
      setStatus("", false);
    } catch (err) {
      objectFields = [];
      selectedFields.clear();
      fieldList.textContent = "Unable to load fields.";
      setStatus(err.message);
    } finally {
      loadFieldsButton.disabled = false;
    }
  }

  function createFilterRow() {
    const row = document.createElement("div");
    row.className = "soql-filter-row";

    const field = document.createElement("select");
    objectFields.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.name;
      option.textContent = item.name;
      field.appendChild(option);
    });

    const operator = document.createElement("select");
    ["=", "!=", ">", "<", ">=", "<=", "LIKE", "IN"].forEach((value) => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      operator.appendChild(option);
    });

    const value = document.createElement("input");
    value.type = "text";
    value.placeholder = "Value";
    value.setAttribute("aria-label", "Filter value");

    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Remove";
    remove.addEventListener("click", () => {
      row.remove();
      updateGeneratedQuery();
    });

    row.append(field, operator, value, remove);
    filterList.appendChild(row);
    field.addEventListener("change", updateGeneratedQuery);
    operator.addEventListener("change", updateGeneratedQuery);
    value.addEventListener("input", updateGeneratedQuery);
  }

  function escapeSoqlValue(value) {
    return value.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  }

  function buildQueryFromBuilder() {
    const objectName = objectSelect.value;
    const fields = [...selectedFields].filter(validFieldName);
    if (!objectName) throw new Error("Select an object first.");
    if (!allObjects.some((object) => object.name === objectName && object.queryable === true)) {
      throw new Error(`${objectName} is not queryable. Select a queryable object.`);
    }
    if (!fields.length) throw new Error("Select at least one field.");

    const conditions = [...filterList.querySelectorAll(".soql-filter-row")].map((row) => {
      const field = row.children[0].value;
      const operator = row.children[1].value;
      const rawValue = row.children[2].value.trim();
      if (!rawValue) throw new Error(`Enter a value for ${field}.`);
      if (operator !== "IN" && /^null$/i.test(rawValue)) return `${field} ${operator} NULL`;
      const values = operator === "IN" ? rawValue.split(",").map((item) => item.trim()).filter(Boolean) : [rawValue];
      const formatted = values.map((item) => `'${escapeSoqlValue(item)}'`).join(", ");
      return operator === "IN"
        ? `${field} IN (${formatted})`
        : `${field} ${operator} ${formatted}`;
    });

    return `SELECT ${fields.join(", ")} FROM ${objectName}${conditions.length ? ` WHERE ${conditions.join(" AND ")}` : ""}`;
  }

  function updateGeneratedQuery() {
    if (!objectSelect.value || !selectedFields.size) { syncRunButtonState(); return; }
    try {
      queryTextarea.value = buildQueryFromBuilder();
      setStatus("", false);
    } catch (err) {
      if (!/Enter a value for/.test(err.message)) setStatus(err.message);
    }
    syncRunButtonState();
  }

  async function loadObjectsIfNeeded() {
    if (objectsLoaded) return;
    const hostname = SFPanel.getHostname();
    if (!hostname) return;

    try {
      const { objects } = await SFPanel.sendMessage({ type: "getObjects", hostname });
      if (!objects.some((object) => object.name === "Activity") &&
          ["Task", "Event"].every((name) => objects.some((object) => object.name === name))) {
        objects.push({ name: "Activity", label: "Activity", custom: false, queryable: false, keyPrefix: "" });
      }
      allObjects = objects.sort((a, b) => a.label.localeCompare(b.label));
      objectsLoaded = true;
    } catch (err) {
      setStatus(`Couldn't load object list: ${err.message}`);
    }
  }

  function resolveByKeyPrefix(prefix) {
    return allObjects.find((o) => o.keyPrefix && o.keyPrefix === prefix) || null;
  }

  function resolveObjectName(objectApiName) {
    if (!objectApiName) return null;
    const normalized = objectApiName.toLowerCase();
    const match = allObjects.find(
      (object) => object.name.toLowerCase() === normalized || object.label.toLowerCase() === normalized
    );
    return match ? match.name : null;
  }

  async function getActiveTabContext(tabOverride) {
    if (tabOverride) return { url: tabOverride.url || "", title: tabOverride.title || "" };
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ? { url: tab.url || "", title: tab.title || "" } : null;
  }

  // Recognizes: Lightning record / object home / Object Manager pages, and
  // Classic record-by-Id / list-view-by-keyPrefix URLs.
  function detectContext(urlString) {
    let url;
    try {
      url = new URL(urlString);
    } catch {
      return null;
    }
    const path = url.pathname;
    let m;

    m = path.match(/^\/lightning\/r\/([A-Za-z0-9_]+)\/([a-zA-Z0-9]{15,18})(?:\/|$)/);
    if (m) return { kind: "record", label: "record page", objectApiName: m[1], recordId: m[2] };

    m = path.match(/^\/lightning\/o\/([A-Za-z0-9_]+)\b/);
    if (m) return { kind: "list", label: "list/home view", objectApiName: m[1] };

    m = path.match(/^\/lightning\/setup\/ObjectManager\/([A-Za-z0-9_]+)\b/);
    if (m) return { kind: "config", label: "Object Manager page", objectDefinitionId: m[1] };

    m = path.match(/^\/([a-zA-Z0-9]{15,18})$/);
    if (m) return { kind: "record", label: "record page", recordId: m[1] };

    m = path.match(/^\/([a-zA-Z0-9]{3})\/o$/);
    if (m) return { kind: "list", label: "list view", keyPrefix: m[1] };

    return null;
  }

  function detectObjectFromTitle(title) {
    const normalizedTitle = title.toLowerCase();
    const match = allObjects.find((object) => {
      const label = object.label.toLowerCase();
      const name = object.name.toLowerCase();
      return normalizedTitle.includes(label) || normalizedTitle.includes(name);
    });
    return match ? { kind: "title", label: "active Salesforce page", objectApiName: match.name } : null;
  }

  async function resolveObjectDefinition(id) {
    if (!/^01I[A-Za-z0-9]+$/.test(id)) return null;
    try {
      const definition = await getToolingRecord("EntityDefinition", id);
      return resolveObjectName(definition.QualifiedApiName);
    } catch {
      return null;
    }
  }

  function detectContextOnce(tabOverride) {
    if (contextDetected || !SFPanel.getHostname()) return;
    if (contextDetectionPromise) return contextDetectionPromise;
    const generation = contextGeneration;
    const request = detectAndBuild(tabOverride, generation).then(() => {
      if (generation === contextGeneration && objectsLoaded) contextDetected = true;
    }).catch((err) => {
      if (generation === contextGeneration) setStatus(err.message);
    }).finally(() => {
      if (contextDetectionPromise === request) contextDetectionPromise = null;
    });
    contextDetectionPromise = request;
    return request;
  }

  async function detectAndBuild(tabOverride, generation = contextGeneration) {
    await loadObjectsIfNeeded();
    if (!objectsLoaded || generation !== contextGeneration) return;
    populateObjectSelect();

    const tabContext = tabOverride ? await getActiveTabContext(tabOverride) : await getActiveTabContext();
    if (generation !== contextGeneration) return;
    const urlContext = tabContext ? detectContext(tabContext.url) : null;
    const context = tabContext ? urlContext || detectObjectFromTitle(tabContext.title) : null;

    let resolvedObject = null;
    let recordId = null;
    let description = "No object context detected on this page — pick an object below.";

    if (context) {
      if (context.objectApiName) {
        resolvedObject = resolveObjectName(context.objectApiName);
        recordId = context.recordId || null;
      } else if (context.objectDefinitionId) {
        resolvedObject = resolveObjectName(context.objectDefinitionId);
        if (!resolvedObject) resolvedObject = await resolveObjectDefinition(context.objectDefinitionId);
        if (!resolvedObject && tabContext) {
          const titleContext = detectObjectFromTitle(tabContext.title);
          if (titleContext) resolvedObject = titleContext.objectApiName;
        }
      } else if (context.recordId) {
        const match = resolveByKeyPrefix(context.recordId.slice(0, 3));
        if (match) {
          resolvedObject = match.name;
          recordId = context.recordId;
        }
      } else if (context.keyPrefix) {
        const match = resolveByKeyPrefix(context.keyPrefix);
        if (match) resolvedObject = match.name;
      }
    }

    if (generation !== contextGeneration) return;
    if (resolvedObject) {
      if (!allObjects.some((object) => object.name === resolvedObject && object.queryable === true)) {
        showNonQueryableObject(resolvedObject);
        return;
      }
      description = recordId
        ? `Detected ${context.label} for ${resolvedObject} (Id: ${recordId}).`
        : `Detected ${context.label} for ${resolvedObject}.`;
      populateObjectSelect(resolvedObject);
      await loadFields();
    }

    if (resolvedObject) {
      contextInfoEl.textContent = "";
    } else {
      let page = "Active tab URL unavailable";
      try {
        const url = new URL(tabContext?.url);
        page = `${url.hostname}${url.pathname}`;
      } catch {}
      contextInfoEl.textContent = `Auto-select: no match. Page: ${page}. Catalog: ${allObjects.length} objects. Context: ${context?.kind || "unrecognized"}.`;
    }
  }

  loadFieldsButton.addEventListener("click", loadFields);
  queryTextarea.addEventListener("input", syncRunButtonState);
  fieldSearchInput.addEventListener("input", renderFieldList);
  selectAllFieldsButton.addEventListener("click", () => {
    objectFields.forEach((field) => selectedFields.add(field.name));
    renderFieldList();
    updateGeneratedQuery();
  });
  clearFieldsButton.addEventListener("click", () => {
    selectedFields.clear();
    renderFieldList();
    queryTextarea.value = "";
    syncRunButtonState();
  });
  addFilterButton.addEventListener("click", () => {
    if (!objectFields.length) {
      setStatus("Load fields before adding a filter.");
      return;
    }
    createFilterRow();
    setStatus("", false);
  });
  objectSelect.addEventListener("change", async () => {
    objectFields = [];
    selectedFields.clear();
    accumulatedRecords = [];
    resultFilters.clear();
    nextRecordsPath = null;
    theadRow.textContent = "";
    tbody.textContent = "";
    table.hidden = true;
    rowCountEl.textContent = "";
    loadMoreButton.hidden = true;
    fieldSearchInput.value = "";
    fieldSearchInput.disabled = true;
    filterList.textContent = "";
    fieldList.textContent = "";
    syncQueryObjectState();
    syncRunButtonState();
    if (objectSelect.value) await loadFields();
  });

  function isSalesforceId(str) {
    return typeof str === "string" && /^[a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?$/.test(str);
  }

  function formatResultValue(value) {
    if (value === null || value === undefined) return "";
    if (typeof value === "object") return typeof value.Name === "string" ? value.Name : JSON.stringify(value);
    return String(value);
  }

  function filteredRecords() {
    return accumulatedRecords.filter((record) => [...resultFilters.entries()].every(([column, values]) =>
      !values.size || values.has(formatResultValue(record[column]))
    ));
  }

  function closeResultFilterMenu() {
    if (openResultFilterMenu) openResultFilterMenu.remove();
    openResultFilterMenu = null;
  }

  function updateResultCount() {
    const visibleCount = filteredRecords().length;
    const filterSuffix = resultFilters.size ? ` (${visibleCount} shown)` : "";
    rowCountEl.textContent = `${accumulatedRecords.length} of ${lastTotalSize} record(s) returned${filterSuffix}`;
  }

  function renderResults() {
    const records = filteredRecords();
    theadRow.textContent = "";
    tbody.textContent = "";

    if (!accumulatedRecords.length) {
      resultsWrapper.classList.remove("has-results");
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 1;
      cell.textContent = "No records returned.";
      row.appendChild(cell);
      tbody.appendChild(row);
      table.hidden = false;
      return;
    }

    resultsWrapper.classList.add("has-results");
    const columns = Object.keys(accumulatedRecords[0]).filter((key) => key !== "attributes");
    for (const col of columns) {
      const th = document.createElement("th");
      const label = document.createElement("span");
      label.textContent = col;
      const filterButton = document.createElement("button");
      filterButton.type = "button";
      filterButton.className = "soql-column-filter-button";
      filterButton.title = `Filter ${col}`;
      filterButton.setAttribute("aria-label", `Filter ${col}`);
      filterButton.textContent = resultFilters.has(col) ? "▼*" : "▼";
      filterButton.addEventListener("click", (event) => {
        event.stopPropagation();
        if (openResultFilterMenu?.dataset.column === col) return closeResultFilterMenu();
        closeResultFilterMenu();
        const values = [...new Set(accumulatedRecords.map((record) => formatResultValue(record[col])))].sort((left, right) => left.localeCompare(right));
        const selectedValues = new Set(resultFilters.get(col) || values);
        const menu = document.createElement("div");
        menu.className = "soql-column-filter-menu";
        menu.dataset.column = col;
        menu.addEventListener("click", (menuEvent) => menuEvent.stopPropagation());
        const selectAll = document.createElement("label");
        const selectAllInput = document.createElement("input");
        selectAllInput.type = "checkbox";
        selectAllInput.checked = selectedValues.size === values.length;
        selectAll.append(selectAllInput, document.createTextNode(" Select all"));
        menu.appendChild(selectAll);
        const valueList = document.createElement("div");
        valueList.className = "soql-column-filter-values";
        values.forEach((value) => {
          const option = document.createElement("label");
          const input = document.createElement("input");
          input.type = "checkbox";
          input.value = value;
          input.checked = selectedValues.has(value);
          option.append(input, document.createTextNode(` ${value || "(Blank)"}`));
          valueList.appendChild(option);
        });
        selectAllInput.addEventListener("change", () => valueList.querySelectorAll("input").forEach((input) => { input.checked = selectAllInput.checked; }));
        const actions = document.createElement("div");
        actions.className = "soql-column-filter-actions";
        const clear = document.createElement("button");
        clear.type = "button";
        clear.textContent = "Clear";
        clear.addEventListener("click", () => { resultFilters.delete(col); closeResultFilterMenu(); renderResults(); updateResultCount(); });
        const apply = document.createElement("button");
        apply.type = "button";
        apply.textContent = "Apply";
        apply.addEventListener("click", () => {
          const checked = new Set([...valueList.querySelectorAll("input:checked")].map((input) => input.value));
          if (checked.size === values.length) resultFilters.delete(col);
          else resultFilters.set(col, checked);
          closeResultFilterMenu();
          renderResults();
          updateResultCount();
        });
        actions.append(clear, apply);
        menu.append(selectAll, valueList, actions);
        th.append(label, filterButton, menu);
        openResultFilterMenu = menu;
      });
      th.append(label, filterButton);
      theadRow.appendChild(th);
    }

    if (!records.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = columns.length;
      cell.textContent = "No records match the selected column filters.";
      row.appendChild(cell);
      tbody.appendChild(row);
      table.hidden = false;
      return;
    }

    for (const record of records) {
      const tr = document.createElement("tr");
      for (const col of columns) {
        const td = document.createElement("td");
        const value = record[col];
        if (value === null || value === undefined) {
          td.textContent = "";
        } else if (typeof value === "object") {
          td.textContent = formatResultValue(value);
        } else {
          const strVal = String(value).trim();
          if (isSalesforceId(strVal)) {
            const hostname = SFPanel.getHostname();
            const link = document.createElement("a");
            link.className = "soql-id-link";
            link.textContent = strVal;
            link.title = `Open record ${strVal} in Salesforce UI`;

            if (hostname) {
              let sObjType = "Record";
              if (col === "Id" && record.attributes?.type) {
                sObjType = record.attributes.type;
              } else {
                const relObjKey = col.replace(/Id$/i, "");
                if (record[relObjKey]?.attributes?.type) {
                  sObjType = record[relObjKey].attributes.type;
                }
              }
              const targetUrl = `https://${hostname}/lightning/r/${sObjType}/${strVal}/view`;
              link.href = targetUrl;
              link.target = "_blank";
              link.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
                  chrome.tabs.create({ url: targetUrl });
                } else {
                  window.open(targetUrl, "_blank");
                }
              });
            } else {
              link.href = "#";
            }
            td.appendChild(link);
          } else {
            td.textContent = strVal;
          }
        }
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }

    table.hidden = false;
  }

  document.addEventListener("click", closeResultFilterMenu);

  function getResultColumns() {
    return [...new Set(accumulatedRecords.flatMap((record) => Object.keys(record)))].filter(
      (column) => column !== "attributes"
    );
  }

  function exportRecords() {
    return exportAllCheckbox.checked ? accumulatedRecords : filteredRecords();
  }

  function createCsv(records = exportRecords()) {
    const columns = getResultColumns();
    const escapeCell = (value) => `"${formatResultValue(value).replace(/"/g, '""')}"`;
    return [
      columns.map(escapeCell).join(","),
      ...records.map((record) => columns.map((column) => escapeCell(record[column])).join(","))
    ].join("\r\n");
  }

  function resultFilename(extension) {
    const objectName = (objectSelect.value || "soql-results").replace(/[^A-Za-z0-9_-]/g, "_");
    return `${objectName}-results.${extension}`;
  }

  function ensureResultsToSave() {
    if (!accumulatedRecords.length) {
      setStatus("Run a query with results first.");
      return false;
    }
    return true;
  }

  function downloadResults(content, mimeType, filename) {
    const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  saveCsvButton.addEventListener("click", () => {
    if (!ensureResultsToSave()) return;
    downloadResults(createCsv(), "text/csv", resultFilename("csv"));
  });

  saveJsonButton.addEventListener("click", () => {
    if (!ensureResultsToSave()) return;
    downloadResults(JSON.stringify(exportRecords(), null, 2), "application/json", resultFilename("json"));
  });

  copyCsvButton.addEventListener("click", async () => {
    if (!ensureResultsToSave()) return;
    try {
      await navigator.clipboard.writeText(createCsv());
      setTimeout(() => showToast("CSV copied to clipboard."), 0);
    } catch {
      setTimeout(() => showToast("Unable to copy CSV to the clipboard."), 0);
    }
  });

  if (copyJsonButton) {
    copyJsonButton.addEventListener("click", async () => {
      if (!ensureResultsToSave()) return;
      try {
        await navigator.clipboard.writeText(JSON.stringify(exportRecords(), null, 2));
        setTimeout(() => showToast("JSON copied to clipboard."), 0);
      } catch {
        setTimeout(() => showToast("Unable to copy JSON to the clipboard."), 0);
      }
    });
  }

  async function runQuery(path, { append = false } = {}) {
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    setStatus("Running…", false);
    resultsSection.classList.remove("has-query-error");
    runButton.disabled = true;
    loadMoreButton.disabled = true;

    try {
      const result = await SFPanel.sendMessage({ type: "restRequest", hostname, method: "GET", path });
      const data = result.data;
      const records = data.records || [];
      accumulatedRecords = append ? accumulatedRecords.concat(records) : records;
      if (!append) resultFilters.clear();
      lastTotalSize = data.totalSize || accumulatedRecords.length;

      renderResults();
      updateResultCount();
      nextRecordsPath = data.done ? null : data.nextRecordsUrl || null;
      loadMoreButton.hidden = !nextRecordsPath;
      setStatus("", false);
    } catch (err) {
      setStatus(err.message);
      resultsSection.classList.add("has-query-error");
      if (!append) {
        accumulatedRecords = [];
        table.hidden = true;
        rowCountEl.textContent = "";
        loadMoreButton.hidden = true;
      }
    } finally {
      syncRunButtonState();
      loadMoreButton.disabled = false;
    }
  }

  runButton.addEventListener("click", () => {
    const soql = queryTextarea.value.trim();
    if (!soql) {
      setStatus("Enter a SOQL query.");
      return;
    }
    const path = `/services/data/${SFPanel.API_VERSION}/query/?q=${encodeURIComponent(soql)}`;
    runQuery(path, { append: false });
  });

  syncRunButtonState();

  loadMoreButton.addEventListener("click", () => {
    if (nextRecordsPath) runQuery(nextRecordsPath, { append: true });
  });

  SFPanel.registerTab("soql", {
    onStartup(_hostname, tabContext) { return detectContextOnce(tabContext); },
    onShow(_hostname, tabContext) {
      return detectContextOnce(tabContext);
    },
    onHostnameChange() {
      contextGeneration += 1;
      contextDetected = false;
      contextDetectionPromise = null;
      objectsLoaded = false;
      allObjects = [];
      if (SFPanel.getActiveTab() === "soql") return detectContextOnce();
    }
  });
})(SFPanel.forTools("soql"));
