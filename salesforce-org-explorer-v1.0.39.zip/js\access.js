const SFAccess = (() => {
  const features = Object.freeze({
    objects: "object_explorer",
    soql: "soql_runner",
    apex: "apex_explorer",
    debugLogs: "debug_logs",
    permissionsExplorer: "permissions_explorer",
    rest: "rest_explorer",
    package: "manifest_builder",
    metadataExplorer: "metadata_type_explorer",
    metadata: "create_metadata",
    import: "import_configuration",
    export: "export_configuration",
    compareOrgs: "compare_metadata",
    compareObjects: "compare_objects",
    deploy: "deploy_metadata",
    configSwitch: "config_switch",
    dataTransfer: "data_importer_exporter"
  });
  const updateMessage = "This version of SF Developer is no longer supported. Update it from Microsoft Edge Add-ons, or open edge://extensions, turn on Developer mode, and click Update. Then close and reopen SF Developer.";

  function evaluate(trial, license, errors = []) {
    const blocked = license && (["app-version-too-old", "machine-switch-otp-required",
      "machine-switch-otp-invalid", "machine-switch-cooldown"].includes(license.reason) ||
      license.machineMismatch === true || license.machineSwitchRequired === true);
    let allowed = [];
    if (!blocked) {
      if (trial && trial.expired === false) {
        allowed = Object.values(features);
      } else if (license && license.valid === true) {
        allowed = license.plan.isFullAccess
          ? Object.values(features)
          : Object.values(features).filter((feature) => license.plan.features.includes(feature));
      }
    }
    const catalog = license?.valid === true
      ? license.plan.activeFeatureKeys ?? trial?.activeFeatureKeys
      : trial?.activeFeatureKeys;
    if (Array.isArray(catalog)) allowed = allowed.filter((feature) => catalog.includes(feature));
    return { trial, license, errors, features: allowed, activeFeatureKeys: catalog };
  }

  function formatErrors(errors) {
    const groups = new Map();
    for (const message of new Set(errors)) {
      const match = /^(Trial connection\/check|License connection\/verification) error: (.*)$/.exec(message);
      const cause = match ? match[2] : message;
      const group = groups.get(cause) || { messages: [], checks: new Set() };
      group.messages.push(message);
      if (match) group.checks.add(match[1].startsWith("Trial") ? "trial" : "subscription");
      groups.set(cause, group);
    }
    return [...groups].map(([cause, group]) => {
      if (cause === "Failed to fetch") return "Cannot reach the account service. Trial/subscription access could not be verified. Check your connection and try again.";
      return group.checks.size > 1 ? `Trial/subscription check failed: ${cause}` : group.messages.join(" ");
    }).join(" ");
  }

  function denial(access, feature) {
    const license = access.license;
    const accountAction = access.account?.connected ? "My account" : "Log in";
    if (license?.reason === "app-version-too-old") return updateMessage;
    if (license?.machineMismatch || license?.machineSwitchRequired ||
      ["machine-switch-otp-required", "machine-switch-otp-invalid", "machine-switch-cooldown"].includes(license?.reason)) return "Installation verification required. Open Home to confirm the machine switch or enter your verification code.";
    if (access.errors.length) return formatErrors(access.errors);
    if (license?.valid) return `Your subscription does not include ${feature}. Open Home and click ${accountAction} to change your subscription.`;
    if (access.trial?.expired) return access.account?.connected
      ? "Your trial has ended. Open My account to choose a plan and restore access."
      : "Your trial has ended. Log in to choose a plan and restore access.";
    return `An active trial or subscription is required. Open Home and click ${accountAction}.`;
  }

  function allowsRequest(message) {
    const feature = message.feature;
    if (message.type === "getObjects" || message.type === "getObjectFields") return true;
    if (message.type === "restRequest") {
      if (feature === "data_importer_exporter" && (message.method || "GET").toUpperCase() !== "GET") {
        // SECURITY_NOTE: Record import can write only through Salesforce collection endpoints, never Tooling or Apex.
        const path = message.path || "";
        return (message.method === "POST" || message.method === "PATCH") && /^\/services\/data\/v\d+\.\d+\/composite\/sobjects$/.test(path) ||
          message.method === "PATCH" && /^\/services\/data\/v\d+\.\d+\/composite\/sobjects\/[A-Za-z_][A-Za-z0-9_]*\/[A-Za-z_][A-Za-z0-9_]*$/.test(path) ||
          message.method === "DELETE" && /^\/services\/data\/v\d+\.\d+\/composite\/sobjects\?ids=[A-Za-z0-9]+(?:,[A-Za-z0-9]+)*&allOrNone=false$/.test(path);
      }
      const writable = ["apex_explorer", "debug_logs", "rest_explorer",
        "create_metadata", "import_configuration", "config_switch"];
      if (/\/executeAnonymous(?:\/|\?|$)/i.test(message.path || "")) {
        return ["apex_explorer", "rest_explorer"].includes(feature);
      }
      return (message.method || "GET").toUpperCase() === "GET" || writable.includes(feature);
    }
    if (message.type === "metadataDeployRequest" || message.type === "metadataStatusRequest") {
      return ["import_configuration", "deploy_metadata", "config_switch"].includes(feature);
    }
    if (message.type === "metadataRequest") {
      const action = String(message.action || message.body?.match(/<met:([A-Za-z]+)>/)?.[1] || "");
      if (["deploy", "deployRecentValidation", "checkDeployStatus", "cancelDeploy"].includes(action)) {
        return ["deploy_metadata", "import_configuration", "config_switch"].includes(feature);
      }
      if (action === "updateMetadata") return feature === "config_switch";
      return ["describeMetadata", "listMetadata", "readMetadata", "retrieve", "checkRetrieveStatus"].includes(action) &&
        ["manifest_builder", "metadata_type_explorer", "import_configuration",
          "export_configuration", "compare_metadata", "deploy_metadata", "config_switch"].includes(feature);
    }
    return false;
  }

  function availability(access, name, label, connected) {
    if (name === "home" || name === "help") return { unavailable: false, locked: false, message: label, action: "" };
    if (!access.features.includes(features[name])) {
      const restricted = access.license?.valid && !access.errors.length &&
        !access.license.machineMismatch && !access.license.machineSwitchRequired &&
        !access.license.reason;
      const action = access.account?.connected ? "My account" : "Log in";
      return {
        unavailable: true, locked: Boolean(restricted),
        message: restricted ? `${label} isn't included in your plan. Open ${action} to view plans.` : denial(access, features[name]),
        action: access.errors.length || access.license?.reason || access.license?.machineMismatch || access.license?.machineSwitchRequired ? "Open Home" : action
      };
    }
    return connected
      ? { unavailable: false, locked: false, message: label, action: "" }
      : { unavailable: true, locked: false, message: `Connect a Salesforce org to use ${label}.`, action: "Open Home" };
  }

  return { features, evaluate, denial, allowsRequest, updateMessage, availability, formatErrors };
})();
