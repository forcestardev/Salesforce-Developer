const DataImportCore = (() => {
  const MAX_BYTES = 10 * 1024 * 1024;
  const MAX_ROWS = 10000;
  const operations = ["insert", "update", "upsert", "delete"];
  const supported = new Set(["string", "textarea", "email", "url", "phone", "picklist", "multipicklist", "combobox", "encryptedstring", "boolean", "int", "long", "double", "currency", "percent", "date", "datetime", "time", "id", "reference"]);
  const idPattern = /^[A-Za-z0-9]{15}(?:[A-Za-z0-9]{3})?$/;
  function identifier(value) {
    if (typeof value !== "string" || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(value)) throw new Error("Invalid Salesforce API name.");
    return value;
  }
  function parseCSV(input) {
    if (typeof input !== "string" || new TextEncoder().encode(input).length > MAX_BYTES) throw new Error("Choose a UTF-8 CSV file no larger than 10 MiB.");
    const text = input.replace(/^\uFEFF/, "");
    const records = [];
    let row = [], cell = "", quoted = false, closed = false, started = false;
    function endCell() { row.push(cell); cell = ""; closed = false; started = false; }
    function endRow() {
      endCell();
      if (row.some(value => value !== "")) records.push(row);
      row = [];
      if (records.length > MAX_ROWS + 1) throw new Error("CSV files are limited to 10,000 data rows.");
    }
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (quoted) {
        if (ch === '"') {
          if (text[i + 1] === '"') { cell += '"'; i++; } else { quoted = false; closed = true; }
        } else cell += ch;
      } else if (ch === ",") endCell();
      else if (ch === "\r" || ch === "\n") {
        if (ch === "\r" && text[i + 1] === "\n") i++;
        endRow();
      } else if (ch === '"' && !started && !closed) { quoted = true; started = true; }
      else {
        if (closed || ch === '"') throw new Error(`Malformed CSV near character ${i + 1}. Check quoting and delimiters.`);
        cell += ch; started = true;
      }
    }
    if (quoted) throw new Error("CSV contains an unterminated quoted value.");
    if (started || closed || cell || row.length) endRow();
    if (records.length < 2) throw new Error("CSV must contain a header and at least one data row.");
    const headers = records.shift().map(value => value.trim());
    if (headers.some(value => !value) || new Set(headers.map(value => value.toLowerCase())).size !== headers.length) throw new Error("CSV headers must be non-empty and unique (case-insensitive).");
    records.forEach((values, index) => {
      if (values.length !== headers.length) throw new Error(`CSV data row ${index + 1} has ${values.length} columns; expected ${headers.length}.`);
    });
    return { headers, rows: records };
  }
  function writable(field, operation, key) {
    if (field.deprecatedAndHidden || !supported.has(field.type)) return false;
    if (operation === "delete") return field.name === "Id";
    if (field.name === "Id") return operation === "update" || (operation === "upsert" && key === "Id");
    if (operation === "insert") return field.createable === true;
    if (operation === "update") return field.updateable === true;
    return field.createable === true && field.updateable === true;
  }
  function valueFor(field, value) {
    if (Number.isInteger(field.length) && field.length > 0 && value.length > field.length) throw new Error(`${field.name} exceeds ${field.length} characters.`);
    const trimmed = value.trim();
    if (field.type === "boolean") {
      if (!/^(true|false)$/i.test(trimmed)) throw new Error(`${field.name} must be true or false.`);
      return trimmed.toLowerCase() === "true";
    }
    if (["int", "long", "double", "currency", "percent"].includes(field.type)) {
      if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(trimmed) || !Number.isFinite(Number(trimmed))) throw new Error(`${field.name} must be a finite number.`);
      const number = Number(trimmed);
      if (Math.abs(number) > Number.MAX_SAFE_INTEGER) throw new Error(`${field.name} exceeds the safely supported numeric range.`);
      if (["int", "long"].includes(field.type) && !Number.isSafeInteger(number)) throw new Error(`${field.name} must be a safe integer.`);
      if (field.type === "int" && (number < -2147483648 || number > 2147483647)) throw new Error(`${field.name} is outside the integer range.`);
      return number;
    }
    if (["id", "reference"].includes(field.type)) {
      if (!idPattern.test(trimmed)) throw new Error(`${field.name} must be a 15- or 18-character Salesforce Id.`);
      return trimmed;
    }
    if (field.type === "date") {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed) || !Number.isFinite(Date.parse(trimmed)) || new Date(trimmed).toISOString().slice(0, 10) !== trimmed) throw new Error(`${field.name} must be a valid YYYY-MM-DD date.`);
      return trimmed;
    }
    if (field.type === "datetime") {
      const match = /^(\d{4}-\d{2}-\d{2})T([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,3})?(Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/.exec(trimmed);
      if (!match || !Number.isFinite(Date.parse(trimmed))) throw new Error(`${field.name} must be an ISO date/time with seconds and a timezone.`);
      valueFor({ name: field.name, type: "date" }, match[1]);
      return trimmed;
    }
    if (field.type === "time") {
      if (!/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,3})?Z$/.test(trimmed)) throw new Error(`${field.name} must be HH:mm:ss.SSSZ (UTC).`);
      return trimmed;
    }
    if (field.restrictedPicklist && ["picklist", "multipicklist"].includes(field.type)) {
      const allowed = new Set((field.picklistValues || []).filter(item => item.active).map(item => item.value));
      if ((field.type === "multipicklist" ? value.split(";") : [value]).some(item => !allowed.has(item))) throw new Error(`${field.name} contains an unavailable picklist value.`);
    }
    return value;
  }
  function prepare({ csv, describe, operation, key = "Id", mapping, blanksAsNull = false }) {
    if (!operations.includes(operation)) throw new Error("Choose a valid import operation.");
    identifier(describe.name);
    if (describe[operation === "insert" ? "createable" : operation === "delete" ? "deletable" : "updateable"] !== true ||
      (operation === "upsert" && describe.createable !== true)) throw new Error(`Your Salesforce permissions do not allow ${operation} on this object.`);
    const fields = new Map(describe.fields.map(field => [field.name, field]));
    if (operation === "upsert" && key !== "Id" && fields.get(key)?.externalId !== true) throw new Error("Choose an external ID field for upsert.");
    const targets = mapping.filter(Boolean);
    if (!targets.length) throw new Error("Map at least one CSV column.");
    if (mapping.length !== csv.headers.length || new Set(targets).size !== targets.length) throw new Error("Each Salesforce field can be mapped only once.");
    targets.forEach(name => {
      identifier(name);
      if (!fields.has(name) || !writable(fields.get(name), operation, key)) throw new Error(`${name} is not writable for ${operation}.`);
    });
    const identity = operation === "update" || operation === "delete" ? "Id" : operation === "upsert" ? key : null;
    if (identity && !targets.includes(identity)) throw new Error(`Map ${identity} before continuing.`);
    const required = ["insert", "upsert"].includes(operation) ? describe.fields.filter(field => field.createable && field.nillable === false && !field.defaultedOnCreate) : [];
    required.forEach(field => { if (!targets.includes(field.name)) throw new Error(`Map required field ${field.name}.`); });
    const seen = new Set();
    return csv.rows.map((values, index) => {
      const record = Object.create(null), errors = [];
      mapping.forEach((name, column) => {
        if (!name) return;
        const field = fields.get(name), value = values[column];
        try {
          if (value === "") {
            if (name === identity || required.some(item => item.name === name)) throw new Error(`${name} is required.`);
            if (blanksAsNull) {
              if (!field.nillable) throw new Error(`${name} cannot be cleared.`);
              record[name] = null;
            }
          } else record[name] = valueFor(field, value);
        } catch (error) { errors.push(error.message); }
      });
      if (identity && record[identity] != null) {
        const rawIdentity = String(record[identity]);
        const identityValue = identity === "Id" ? rawIdentity.slice(0, 15) : fields.get(identity).caseSensitive === false ? rawIdentity.toLowerCase() : rawIdentity;
        if (seen.has(identityValue)) errors.push(`Duplicate ${identity} in CSV; split repeated identities into separate imports.`);
        seen.add(identityValue);
      }
      if (operation === "update" && Object.keys(record).every(name => name === "Id")) errors.push("No field values to update.");
      return { row: index + 1, record, errors };
    });
  }
  async function execute({ send, hostname, apiVersion, object, operation, key = "Id", rows, check = () => {}, progress = () => {} }) {
    identifier(object); identifier(key);
    if (!/^v\d+\.\d+$/.test(apiVersion) || !operations.includes(operation)) throw new Error("Invalid import request.");
    if (!rows.length || rows.some(row => row.errors.length)) throw new Error("Fix all validation errors before importing.");
    const results = rows.map(row => ({ row: row.row, status: "not attempted", id: "", message: "" }));
    const base = `/services/data/${apiVersion}/composite/sobjects`;
    for (let start = 0; start < rows.length; start += 200) {
      try { check(); } catch (error) {
        results.slice(start).forEach(result => { result.message = error.message; });
        break;
      }
      const batch = rows.slice(start, start + 200);
      const message = { type: "restRequest", hostname, method: operation === "insert" ? "POST" : operation === "delete" ? "DELETE" : "PATCH", path: base };
      if (operation === "delete") message.path += `?ids=${batch.map(row => encodeURIComponent(row.record.Id)).join(",")}&allOrNone=false`;
      else {
        if (operation === "upsert") message.path += `/${object}/${key}`;
        message.body = { allOrNone: false, records: batch.map(row => ({ ...row.record, attributes: { type: object } })) };
      }
      // SECURITY_NOTE: Writes use fixed collection endpoints and JSON, never CSV-derived URL paths or executable text.
      try {
        const response = await send(message);
        if (!Array.isArray(response.data) || response.data.length !== batch.length ||
          response.data.some(item => !item || typeof item.success !== "boolean" || !Array.isArray(item.errors) ||
            (item.success && (typeof item.id !== "string" || !idPattern.test(item.id))))) throw new Error("Salesforce returned an invalid write result.");
        response.data.forEach((item, index) => {
          Object.assign(results[start + index], {
            status: item.success ? "success" : "failed",
            id: item.id || batch[index].record.Id || "",
            message: item.success ? (operation === "upsert" ? (item.created ? "Created" : "Updated") : operation) : item.errors.map(error => `${error.statusCode || "ERROR"}: ${error.message || "Salesforce rejected the row."}`).join("; ") || "Salesforce rejected the row without an error description."
          });
        });
      } catch (error) {
        // Older workers return only the exact denial text; both forms are rejected before Salesforce dispatch.
        if (error.code === "TOOL_ACTION_DENIED" || error.message === "This action is not available through the specified tool entitlement.") {
          results.slice(start).forEach(result => {
            result.message = "The extension blocked this request before sending records to Salesforce. Reload SF Developer at edge://extensions, then close and reopen its panels. The running background worker may be outdated. Validate again before retrying. If this persists, check tool access.";
          });
          progress(results);
          break;
        }
        batch.forEach((row, index) => Object.assign(results[start + index], { status: "unknown", id: row.record.Id || "", message: `${error.message} Outcome uncertain; verify in Salesforce before retrying.` }));
        results.slice(start + batch.length).forEach(result => { result.message = "Stopped after an uncertain batch. No automatic retry."; });
        progress(results);
        break;
      }
      progress(results);
    }
    return results;
  }
  function report(csv, results) {
    function cell(value) {
      let text = String(value ?? "");
      // SECURITY_NOTE: Reports may be opened in spreadsheets; neutralize formula-like text.
      if (/^\s*[=+@\-\t\r]/.test(text)) text = `'${text}`;
      return `"${text.replace(/"/g, '""')}"`;
    }
    return "\uFEFF" + [
      ["Data row", "Status", "Salesforce Id", "Message", ...csv.headers],
      ...results.map(result => [result.row, result.status, result.id, result.message, ...csv.rows[result.row - 1]])
    ].map(row => row.map(cell).join(",")).join("\r\n");
  }
  return { MAX_BYTES, MAX_ROWS, parseCSV, writable, prepare, execute, report };
})();

if (typeof module !== "undefined" && module.exports) module.exports = DataImportCore;

const DataImportPanel = typeof document !== "undefined" && typeof SFPanel !== "undefined" ? ((SFPanel) => {
  const panel = document.getElementById("dataImportPanel");
  const core = DataImportCore;
  const state = { hostname: null, objects: [], describe: null, csv: null, mapping: [], prepared: null, results: null, busy: false, generation: 0, cancelled: false };
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.assign(node, props);
    children.forEach(child => node.appendChild(child));
    return node;
  }
  function button(text, handler) {
    const node = el("button", { type: "button", textContent: text });
    node.addEventListener("click", handler);
    return node;
  }
  function option(value, text) { return el("option", { value, textContent: text }); }
  const operation = el("select", { ariaLabel: "Import operation" }, ["insert", "update", "upsert", "delete"].map(name => option(name, name[0].toUpperCase() + name.slice(1))));
  const object = el("select", { ariaLabel: "Target Salesforce object", size: 10 });
  const search = el("input", { id: "dataImportObjectSearch", type: "search", placeholder: "Search by label or API name", ariaLabel: "Find target object" });
  const objectCount = el("span", { className: "data-export-object-count", role: "status", ariaLive: "polite" });
  const key = el("select", { ariaLabel: "Upsert matching field" });
  const keyLabel = el("label", { className: "data-import-field", textContent: "Match upsert by " }, [key]);
  const file = el("input", { type: "file", accept: ".csv,text/csv", ariaLabel: "UTF-8 CSV file" });
  const blanks = el("input", { type: "checkbox" });
  const controls = el("fieldset", { className: "data-import-controls" });
  const mapping = el("fieldset", { className: "data-import-mapping" });
  const status = el("div", { className: "status", role: "status", ariaLive: "polite" });
  const preview = el("div", { className: "data-export-preview" });
  const resultView = el("div", { className: "data-export-preview" });
  const selectedObject = el("h3", { className: "data-import-selected-object", textContent: "No target object selected" });
  const validationIssues = el("div", { className: "data-import-validation-issues", hidden: true, tabIndex: -1 });
  const validate = button("Validate and preview", validateRows);
  const run = button("Import records", execute);
  const cancel = button("Stop after current batch", () => {
    state.cancelled = true; cancel.disabled = true;
    setStatus("Stopping after the in-flight batch. Changes already sent cannot be undone.");
  });
  const download = button("Download row results", () => {
    if (!state.csv || !state.results) return;
    const url = URL.createObjectURL(new Blob([core.report(state.csv, state.results)], { type: "text/csv;charset=utf-8" }));
    el("a", { href: url, download: `${state.hostname}_${object.value}_${operation.value}_results.csv` }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  const refresh = button("Refresh objects", loadObjects);
  controls.append(
    el("div", { className: "data-import-operation" }, [el("label", { className: "data-import-field" }, [
      el("span", { className: "data-import-setup-heading", textContent: "Operation" }), operation
    ]), keyLabel]),
    el("div", { className: "data-import-object-picker" }, [
      el("div", { className: "data-import-field" }, [
        el("div", { className: "data-import-object-heading data-import-setup-heading" }, [
          el("label", { htmlFor: search.id, textContent: "Target object" }), objectCount
        ]), search, object
      ]),
      el("div", { className: "data-import-search" }, [refresh])
    ]),
    el("label", { className: "data-import-field" }, [
      el("span", { className: "data-import-setup-heading", textContent: "Source file" }), file
    ]),
    el("label", {}, [blanks, el("span", { textContent: " Clear mapped fields when CSV cells are empty (send null)" })]),
    el("div", { className: "data-export-toolbar" }, [validate])
  );
  const mappingSection = el("details", { className: "data-import-section", open: true }, [
    el("summary", { textContent: "Column mapping" }), mapping
  ]);
  const previewSection = el("details", { className: "data-import-section", open: true }, [
    el("summary", { textContent: "Data preview and validation" }), preview
  ]);
  const review = el("div", { className: "data-import-review" }, [validationIssues, mappingSection, previewSection]);
  const views = new Map();
  const tabs = el("nav", { className: "placeholder-tabs", role: "tablist", ariaLabel: "Import data workspace" });
  for (const [name, content] of [["Review", review], ["Results", resultView]]) {
    const tab = button(name, () => selectView(name));
    tab.id = `dataImport${name}Tab`;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-controls", `dataImport${name}View`);
    const view = el("div", { id: `dataImport${name}View`, className: "data-import-view", role: "tabpanel", tabIndex: 0 }, name === "Results" ? [el("div", { className: "data-export-toolbar" }, [download]), content] : [content]);
    view.setAttribute("aria-labelledby", tab.id);
    views.set(name, { tab, view });
    tab.addEventListener("keydown", event => {
      const names = [...views.keys()], index = names.indexOf(name);
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === "Home" ? 0 : event.key === "End" ? names.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + names.length) % names.length;
      selectView(names[next]); views.get(names[next]).tab.focus();
    });
    tabs.appendChild(tab);
  }
  function selectView(name) {
    views.forEach(({ tab, view }, key) => {
      const selected = key === name;
      tab.setAttribute("aria-selected", String(selected));
      tab.tabIndex = selected ? 0 : -1;
      view.hidden = !selected;
    });
  }
  const divider = el("div", { className: "data-export-divider data-import-divider", tabIndex: 0 });
  for (const [name, value] of Object.entries({ role: "separator", "aria-orientation": "vertical", "aria-label": "Resize import setup and data", "aria-valuemin": "240", "aria-valuemax": "560", "aria-valuenow": "320" })) divider.setAttribute(name, value);
  const workspace = el("div", { className: "data-import-workspace" }, [
    el("div", { className: "data-import-setup" }, [el("h3", { textContent: "Import setup" }), controls, el("div", { className: "data-export-toolbar" }, [run, cancel]), status]),
    divider,
    el("div", { className: "data-import-data" }, [selectedObject, tabs, ...[...views.values()].map(item => item.view)])
  ]);
  let leftWidth = 320, drag = null;
  function resizeSetup(width) {
    const max = Math.min(560, Math.max(240, workspace.getBoundingClientRect().width - 300));
    leftWidth = Math.max(240, Math.min(max, width));
    workspace.style.setProperty("--data-import-left", `${leftWidth}px`);
    divider.setAttribute("aria-valuemax", String(Math.round(max)));
    divider.setAttribute("aria-valuenow", String(Math.round(leftWidth)));
  }
  divider.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    event.preventDefault();
    drag = { id: event.pointerId, x: event.clientX, width: workspace.children[0].getBoundingClientRect().width };
    divider.setPointerCapture(event.pointerId);
  });
  divider.addEventListener("pointermove", event => {
    if (drag && drag.id === event.pointerId) resizeSetup(drag.width + event.clientX - drag.x);
  });
  for (const name of ["pointerup", "pointercancel", "lostpointercapture"]) divider.addEventListener(name, () => { drag = null; });
  divider.addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    resizeSetup(event.key === "Home" ? 240 : event.key === "End" ? 560 : leftWidth + (event.key === "ArrowRight" ? 20 : -20));
  });
  panel.append(
    el("ul", { className: "tab-help" }, [
      "Import a UTF-8, comma-delimited CSV into one object (10 MiB / 10,000 rows maximum).",
      "Map headers to Salesforce fields, validate, then confirm. All validation errors must be fixed.",
      "Empty cells are omitted unless clearing is selected.",
      "Delete requires Id only and uses Salesforce's normal delete, not hard delete.",
      "Writes can run automations and cannot be undone here.",
      "Switching orgs clears results and stops future batches, but an in-flight batch may still commit in the previous org."
    ].map(text => el("li", { textContent: text }))),
    workspace
  );
  function setStatus(text, error = false) { status.textContent = text; status.style.color = error ? "#c00" : "inherit"; }
  function update() {
    const target = state.objects.find(item => item.name === object.value);
    selectedObject.textContent = target ? `${target.label} (${target.name})` : "No target object selected";
    controls.disabled = state.busy;
    mapping.disabled = state.busy;
    run.disabled = state.busy || !state.prepared || state.prepared.some(row => row.errors.length);
    run.textContent = operation.value === "delete" ? "Delete records" : "Import records";
    validate.disabled = state.busy || !state.csv || !state.describe;
    cancel.hidden = !state.busy || !state.prepared;
    cancel.disabled = state.cancelled;
    download.disabled = state.busy || !state.results;
    keyLabel.hidden = operation.value !== "upsert";
  }
  function invalidate() {
    state.prepared = null; state.results = null;
    validationIssues.textContent = ""; validationIssues.hidden = true;
    preview.textContent = "Validate the CSV to preview mapped values and validation errors.";
    resultView.textContent = "Import results will appear here after validation errors or a confirmed import.";
    selectView("Review"); setStatus(""); update();
  }
  function renderObjects() {
    const previous = object.value;
    object.textContent = "";
    const term = search.value.trim().toLowerCase();
    const matches = state.objects.filter(item => `${item.label} ${item.name}`.toLowerCase().includes(term));
    const selectedOutsideFilter = state.objects.find(item => item.name === previous && !matches.includes(item));
    if (selectedOutsideFilter) object.appendChild(option(selectedOutsideFilter.name, `${selectedOutsideFilter.label} (${selectedOutsideFilter.name}) - current selection, outside filter`));
    matches
      .forEach(item => object.appendChild(option(item.name, `${item.label} (${item.name})`)));
    object.value = previous;
    if (!previous) object.selectedIndex = -1;
    objectCount.textContent = term
      ? `${matches.length.toLocaleString()} / ${state.objects.length.toLocaleString()} objects`
      : `${state.objects.length.toLocaleString()} objects`;
  }
  function renderMapping(auto = false) {
    mapping.textContent = "";
    if (!state.csv || !state.describe) {
      mapping.appendChild(el("p", { textContent: "Choose a target object and CSV file in Import setup to map columns." }));
      return;
    }
    const fields = state.describe.fields.filter(field => core.writable(field, operation.value, key.value));
    if (auto) state.mapping = state.csv.headers.map(header => fields.find(field => field.name.toLowerCase() === header.toLowerCase())?.name || "");
    const body = el("tbody");
    state.csv.headers.forEach((header, index) => {
      const select = el("select", { ariaLabel: `Map CSV column ${header}` }, [option("", "Ignore column"), ...fields.map(field => option(field.name, `${field.label || field.name} (${field.name})`))]);
      select.value = state.mapping[index] || "";
      select.addEventListener("change", () => { state.mapping[index] = select.value; invalidate(); });
      body.appendChild(el("tr", {}, [el("td", { textContent: header }), el("td", {}, [select])]));
    });
    mapping.appendChild(el("table", { className: "configuration-table" }, [el("thead", {}, [el("tr", {}, [el("th", { textContent: "CSV column" }), el("th", { textContent: "Salesforce field" })])]), body]));
  }
  function showRows(rows, results = null) {
    const target = results ? resultView : preview;
    target.textContent = "";
    const names = state.mapping.filter(Boolean);
    const body = el("tbody");
    rows.slice(0, 20).forEach((row, index) => {
      const result = results?.[index];
      body.appendChild(el("tr", {}, [row.row, result ? `${result.status}: ${result.message}` : row.errors.join("; ") || "Valid", ...names.map(name => row.record[name] === null ? "(null)" : row.record[name] ?? "(omitted)")].map(value => el("td", { textContent: String(value) }))));
    });
    target.append(el("p", { textContent: results ? "Showing the first 20 rows. Download row results for the full report." : "Showing the first 20 validated rows. Import results and downloadable error reports are available in Results." }), el("table", { className: "configuration-table" }, [
      el("thead", {}, [el("tr", {}, ["Data row", results ? "Result" : "Validation", ...names].map(name => el("th", { textContent: name })))]), body
    ]));
  }
  function validateRows() {
    invalidate();
    try {
      if (!state.csv || !state.describe) throw new Error("Choose an object and CSV file first.");
      state.prepared = core.prepare({ csv: state.csv, describe: state.describe, operation: operation.value, key: key.value, mapping: state.mapping, blanksAsNull: blanks.checked });
      const invalid = state.prepared.filter(row => row.errors.length);
      if (invalid.length) {
        state.results = state.prepared.map(row => ({ row: row.row, status: row.errors.length ? "invalid" : "not attempted", id: "", message: row.errors.join("; ") }));
        showRows(state.prepared, state.results);
        showValidationIssues(
          `${invalid.length} row(s) have validation errors. No records were sent to Salesforce.`,
          invalid.map(row => `Data row ${row.row}: ${row.errors.join("; ")}`)
        );
      }
      showRows(state.prepared);
      previewSection.open = true;
      selectView("Review");
      setStatus(`${state.prepared.length} rows validated; ${invalid.length} invalid. ${invalid.length ? "See Validation errors in Review for row numbers and reasons. Fix the file or mapping, then validate again." : "Ready for confirmation."}`, invalid.length > 0);
    } catch (error) {
      showValidationIssues("Validation could not complete. No records were sent to Salesforce.", [error.message]);
      setStatus(error.message, true);
    }
    update();
  }
  function showValidationIssues(summary, issues) {
    validationIssues.textContent = "";
    validationIssues.append(
      el("h4", { textContent: "Validation errors" }),
      el("p", { textContent: summary }),
      el("p", { textContent: "Data row numbers exclude the CSV header and empty records." }),
      el("ul", {}, issues.map(message => el("li", { textContent: message })))
    );
    validationIssues.hidden = false;
    selectView("Review");
    validationIssues.focus();
  }
  async function execute() {
    if (state.busy || !state.prepared || state.prepared.some(row => row.errors.length)) return;
    const hostname = state.hostname, generation = state.generation;
    if (hostname !== SFPanel.getHostname()) { setStatus("Org changed. Reload objects and validate again.", true); return; }
    if (!confirm(`${operation.value.toUpperCase()} ${state.prepared.length} ${object.value} records in ${hostname}?\n\n${operation.value === "upsert" ? `Matching field: ${key.value}\n` : ""}${blanks.checked ? "Empty mapped cells will clear fields.\n" : "Empty mapped cells are omitted.\n"}${operation.value === "delete" ? "Records will be deleted.\n" : ""}Salesforce automations may run. Partial success is possible; no rollback or automatic retries. Verify you have an appropriate backup before proceeding.`)) return;
    state.busy = true; state.cancelled = false;
    resultView.textContent = "Import in progress. Row outcomes will appear after Salesforce responds.";
    selectView("Results"); update();
    const rows = state.prepared;
    const check = () => {
      if (state.cancelled || generation !== state.generation || hostname !== SFPanel.getHostname()) throw new Error("Stopped: cancelled or connected org changed.");
    };
    try {
      const results = await core.execute({
        send: message => SFPanel.sendMessage(message), hostname, apiVersion: SFPanel.API_VERSION,
        object: object.value, operation: operation.value, key: key.value || "Id", rows, check,
        progress(results) {
          if (generation === state.generation) setStatus(`${results.filter(row => row.status === "success").length} succeeded; ${results.filter(row => row.status === "failed").length} failed; ${results.filter(row => row.status === "unknown").length} uncertain.`);
        }
      });
      if (generation !== state.generation) return;
      state.results = results;
      showRows(rows, results);
      selectView("Results");
      const counts = ["success", "failed", "unknown", "not attempted"].map(name => `${results.filter(row => row.status === name).length} ${name}`).join("; ");
      setStatus(`${counts}. Download row results before changing the setup.${results.some(row => row.status === "unknown") ? " Verify uncertain outcomes in Salesforce before retrying." : ""}`, results.some(row => row.status !== "success"));
      state.prepared = null;
    } catch (error) {
      if (generation === state.generation) { state.prepared = null; setStatus(error.message, true); }
    } finally {
      if (generation === state.generation) { state.busy = false; update(); }
    }
  }
  async function loadObjects() {
    if (state.busy) return;
    const generation = ++state.generation;
    state.hostname = SFPanel.getHostname(); state.describe = null; state.objects = [];
    object.value = ""; renderObjects(); invalidate(); renderMapping();
    if (!state.hostname) { setStatus("Connect to a Salesforce org to import records.", true); return; }
    state.busy = true; update(); setStatus("Loading objects...");
    try {
      const response = await SFPanel.sendMessage({ type: "getObjects", hostname: state.hostname });
      if (generation !== state.generation) return;
      if (!Array.isArray(response.objects)) throw new Error("Salesforce returned no object catalog.");
      state.objects = response.objects; renderObjects(); setStatus("Choose a target object and CSV file.");
    } catch (error) { if (generation === state.generation) { state.hostname = null; setStatus(error.message, true); } }
    finally { if (generation === state.generation) { state.busy = false; update(); } }
  }
  async function loadDescribe() {
    const generation = ++state.generation;
    state.describe = null; invalidate(); renderMapping(); key.textContent = "";
    if (!object.value) return;
    state.busy = true; update(); setStatus("Loading writable fields...");
    try {
      const response = await SFPanel.sendMessage({ type: "restRequest", hostname: state.hostname, method: "GET", path: `/services/data/${SFPanel.API_VERSION}/sobjects/${encodeURIComponent(object.value)}/describe/` });
      if (generation !== state.generation) return;
      if (!response.data || !Array.isArray(response.data.fields) || response.data.name !== object.value) throw new Error("Salesforce returned an invalid object description.");
      state.describe = response.data;
      key.appendChild(option("Id", "Salesforce Id"));
      state.describe.fields.filter(field => field.externalId && core.writable(field, "upsert", field.name)).forEach(field => key.appendChild(option(field.name, field.name)));
      key.value = "Id"; renderMapping(true); setStatus("");
    } catch (error) { if (generation === state.generation) setStatus(error.message, true); }
    finally { if (generation === state.generation) { state.busy = false; update(); } }
  }
  file.addEventListener("change", async () => {
    const selected = file.files[0], generation = state.generation;
    state.csv = null; invalidate(); renderMapping();
    if (!selected) return;
    state.busy = true; update();
    try {
      if (!/\.csv$/i.test(selected.name) || selected.size > core.MAX_BYTES) throw new Error("Choose a .csv file no larger than 10 MiB.");
      const text = new TextDecoder("utf-8", { fatal: true }).decode(await selected.arrayBuffer());
      if (generation !== state.generation) return;
      state.csv = core.parseCSV(text); renderMapping(true); setStatus(`${state.csv.rows.length} data rows loaded. Review mappings, then validate.`);
    } catch (error) { if (generation === state.generation) setStatus(`Couldn't read CSV: ${error.message}`, true); }
    finally { if (generation === state.generation) { state.busy = false; update(); } }
  });
  operation.addEventListener("change", () => { invalidate(); renderMapping(true); });
  key.addEventListener("change", () => { invalidate(); renderMapping(true); });
  blanks.addEventListener("change", invalidate);
  search.addEventListener("input", renderObjects);
  object.addEventListener("change", () => { renderObjects(); loadDescribe(); });
  function onShow() { if (!panel.hidden && !state.hostname && !state.busy) loadObjects(); }
  function onHostnameChange() {
    state.generation++; state.cancelled = true; state.busy = false; state.hostname = null;
    state.describe = null; state.csv = null; state.objects = []; state.mapping = []; file.value = ""; object.value = ""; search.value = ""; key.textContent = "";
    invalidate(); renderObjects(); renderMapping();
    setStatus("Org changed. Pending batches stopped; an in-flight batch may still commit in the previous org. Verify previous-org results before retrying.");
    if (SFPanel.getActiveTab() === "dataTransfer" && !panel.hidden) loadObjects();
  }
  panel.addEventListener("tabpanelshow", onShow);
  invalidate(); renderMapping();
  return { onShow, onHostnameChange };
})(SFPanel.forTools("dataTransfer")) : null;
