// js/metadataExplorer.js — "Metadata Type Explorer" tab: browse and inspect metadata types
((SFPanel) => {
  const searchInput = document.getElementById("metaSearch");
  const refreshButton = document.getElementById("metaRefresh");
  const listEl = document.getElementById("metaList");
  const resizeHandle = document.getElementById("metaResizeHandle");
  const emptyStateEl = document.getElementById("metaEmptyState");
  const detailEl = document.getElementById("metaDetail");
  const titleEl = document.getElementById("metaTitle");
  const prefixEl = document.getElementById("metaKeyPrefix");
  const badgesEl = document.getElementById("metaBadges");
  const statusEl = document.getElementById("metaExplorerStatus");
  const treeControlsEl = document.getElementById("metaTreeControls");
  const expandAllBtn = document.getElementById("metaExpandAll");
  const collapseAllBtn = document.getElementById("metaCollapseAll");
  const jsonResponseEl = document.getElementById("metaJsonResponse");
  const treeResponseEl = document.getElementById("metaTreeResponse");
  const viewBtns = document.querySelectorAll(".meta-view-btn");

  let loadedHostname = null;
  let allTypes = [];
  let selectedTypeName = null;
  const describeCache = new Map();
  let currentViewMode = "tree";

  function setStatus(message, isError = true) {
    if (!statusEl) return;
    statusEl.textContent = message || "";
    statusEl.style.color = isError ? "#c00" : "inherit";
  }

  function setViewMode(mode) {
    currentViewMode = mode;
    viewBtns.forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.view === mode);
    });
    if (jsonResponseEl) jsonResponseEl.hidden = mode !== "json";
    if (treeResponseEl) treeResponseEl.hidden = mode !== "tree";
  }

  function setTreeCollapseAll(container, collapse) {
    if (!container) return;
    container.querySelectorAll(".json-tree-node").forEach((node) => {
      const isRoot = node.classList.contains("json-tree-root");
      const children = node.querySelector(":scope > .json-tree-children");
      const toggle = node.querySelector(":scope > .json-tree-row > .json-tree-toggle");
      if (children && toggle) {
        const shouldHide = collapse ? !isRoot : false;
        children.hidden = shouldHide;
        toggle.textContent = shouldHide ? "▶" : "▼";
      }
    });
  }

  function setRawJsonCollapseAll(container, collapse) {
    if (!container) return;
    container.querySelectorAll(".json-raw-node").forEach((node) => {
      const isRoot = node.classList.contains("json-raw-root");
      const children = node.querySelector(":scope > .json-raw-children");
      const footer = node.querySelector(":scope > .json-raw-node-footer");
      const headerRow = node.querySelector(":scope > .json-raw-line.collapsible");
      if (headerRow && children) {
        const toggle = headerRow.querySelector(".json-tree-toggle");
        const summary = headerRow.querySelector(".json-syntax-summary");
        const shouldHide = collapse ? !isRoot : false;
        children.hidden = shouldHide;
        if (footer) footer.hidden = shouldHide;
        if (summary) summary.hidden = !shouldHide;
        if (toggle) toggle.textContent = shouldHide ? "▶" : "▼";
      }
    });
  }

  if (expandAllBtn) {
    expandAllBtn.addEventListener("click", () => {
      if (currentViewMode === "tree") setTreeCollapseAll(treeResponseEl, false);
      else setRawJsonCollapseAll(jsonResponseEl, false);
    });
  }
  if (collapseAllBtn) {
    collapseAllBtn.addEventListener("click", () => {
      if (currentViewMode === "tree") setTreeCollapseAll(treeResponseEl, true);
      else setRawJsonCollapseAll(jsonResponseEl, true);
    });
  }

  viewBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      setViewMode(btn.dataset.view);
    });
  });

  function getObjectLabel(obj) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
    if (typeof obj.name === "string" && obj.name) return obj.name;
    if (typeof obj.Name === "string" && obj.Name) return obj.Name;
    if (typeof obj.label === "string" && obj.label) return obj.label;
    if (typeof obj.Label === "string" && obj.Label) return obj.Label;
    if (typeof obj.developerName === "string" && obj.developerName) return obj.developerName;
    if (typeof obj.DeveloperName === "string" && obj.DeveloperName) return obj.DeveloperName;
    if (typeof obj.fullName === "string" && obj.fullName) return obj.fullName;
    if (typeof obj.childSObject === "string" && obj.childSObject) return obj.childSObject;
    if (typeof obj.relationshipName === "string" && obj.relationshipName) return obj.relationshipName;
    if (typeof obj.attributes === "object" && obj.attributes && typeof obj.attributes.type === "string") {
      if (typeof obj.Id === "string" && obj.Id) return `${obj.attributes.type} (${obj.Id})`;
    }
    if (typeof obj.Id === "string" && obj.Id) return obj.Id;
    if (typeof obj.id === "string" && obj.id) return obj.id;
    return null;
  }

  function formatNodeKey(key) {
    if (key === null || key === undefined) return key;
    if (typeof key === "number") return String(key + 1);
    if (typeof key === "string" && /^\d+$/.test(key)) return String(Number(key) + 1);
    return key;
  }

  function renderJsonTree(data, parentContainer, rootLabel = null) {
    parentContainer.textContent = "";

    function buildNode(key, value, isRoot = false) {
      const container = document.createElement("div");
      container.className = isRoot ? "json-tree-node json-tree-root" : "json-tree-node";

      const row = document.createElement("div");
      row.className = "json-tree-row";

      const isObject = value !== null && typeof value === "object";

      if (isObject) {
        row.classList.add("collapsible");
        const keys = Object.keys(value);
        const shouldCollapse = !isRoot;
        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.textContent = shouldCollapse ? "▶" : "▼";

        const childrenContainer = document.createElement("div");
        childrenContainer.className = "json-tree-children";
        if (shouldCollapse) {
          childrenContainer.hidden = true;
        }

        const toggleHandler = (e) => {
          e.stopPropagation();
          const isCollapsed = childrenContainer.hidden;
          childrenContainer.hidden = !isCollapsed;
          toggle.textContent = isCollapsed ? "▼" : "▶";
        };

        row.addEventListener("click", toggleHandler);

        row.appendChild(toggle);

        const nodeKey = isRoot ? rootLabel : key;
        if (nodeKey !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-tree-key";

          const formattedKey = isRoot ? nodeKey : formatNodeKey(nodeKey);
          let displayKey = formattedKey;
          const objLabel = getObjectLabel(value);
          if (objLabel && objLabel !== formattedKey) {
            displayKey = `${formattedKey} (${objLabel})`;
          }

          keyEl.textContent = `${displayKey} (${keys.length})`;
          row.appendChild(keyEl);
        }

        container.appendChild(row);

        keys.forEach((childKey) => {
          childrenContainer.appendChild(buildNode(childKey, value[childKey]));
        });

        container.appendChild(childrenContainer);
      } else {
        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.style.visibility = "hidden";
        row.appendChild(toggle);

        const nodeKey = isRoot ? rootLabel : key;
        if (nodeKey !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-tree-key";
          keyEl.textContent = isRoot ? nodeKey : formatNodeKey(nodeKey);
          const colonEl = document.createElement("span");
          colonEl.className = "json-tree-colon";
          colonEl.textContent = ": ";
          row.appendChild(keyEl);
          row.appendChild(colonEl);
        }

        const valEl = document.createElement("span");
        const valType = value === null ? "null" : typeof value;
        valEl.className = `json-tree-value ${valType}`;
        valEl.textContent = value === null ? "null" : JSON.stringify(value);
        row.appendChild(valEl);

        container.appendChild(row);
      }

      return container;
    }

    parentContainer.appendChild(buildNode(null, data, true));
  }

  function renderPlainTextWithLinks(rawText, containerEl, followLink) {
    containerEl.textContent = "";
    const urlPattern = /(https?:\/\/[^\s"'<>]+|\/services\/[^\s"'<>]+)/g;
    let lastIndex = 0;
    let match;
    while ((match = urlPattern.exec(rawText))) {
      if (match.index > lastIndex) {
        containerEl.appendChild(document.createTextNode(rawText.slice(lastIndex, match.index)));
      }
      const matchedText = match[0];
      const link = document.createElement("span");
      link.className = "rest-response-link";
      link.textContent = matchedText;
      link.setAttribute("role", "link");
      link.tabIndex = 0;
      link.title = "Click to inspect this path in REST Explorer";
      if (followLink) {
        link.addEventListener("click", (e) => {
          e.stopPropagation();
          followLink(matchedText);
        });
      }
      containerEl.appendChild(link);
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < rawText.length) {
      containerEl.appendChild(document.createTextNode(rawText.slice(lastIndex)));
    }
  }

  function renderStringValue(textContainer, strValue, followLink) {
    const urlPattern = /(https?:\/\/[^\s"'<>]+|\/services\/[^\s"'<>]+)/g;
    let lastIndex = 0;
    let match;
    const formatted = JSON.stringify(strValue);
    while ((match = urlPattern.exec(formatted))) {
      if (match.index > lastIndex) {
        textContainer.appendChild(document.createTextNode(formatted.slice(lastIndex, match.index)));
      }
      const matchedText = match[0];
      const cleanUrl = matchedText.replace(/"$/, "");
      const link = document.createElement("span");
      link.className = "rest-response-link";
      link.textContent = cleanUrl;
      link.setAttribute("role", "link");
      link.tabIndex = 0;
      link.title = "Click to inspect this path in REST Explorer";
      if (followLink) {
        link.addEventListener("click", (e) => {
          e.stopPropagation();
          followLink(cleanUrl);
        });
      }
      textContainer.appendChild(link);
      lastIndex = match.index + cleanUrl.length;
    }
    if (lastIndex < formatted.length) {
      textContainer.appendChild(document.createTextNode(formatted.slice(lastIndex)));
    }
  }

  function renderCollapsibleJson(data, parentContainer, followLink) {
    parentContainer.textContent = "";

    function buildNode(key, value, isLast, isRoot = false) {
      const container = document.createElement("div");
      container.className = isRoot ? "json-raw-node json-raw-root" : "json-raw-node";

      const isObject = value !== null && typeof value === "object";

      if (isObject) {
        const isArray = Array.isArray(value);
        const keys = Object.keys(value);
        const openBracket = isArray ? "[" : "{";
        const closeBracket = isArray ? "]" : "}";
        const trailingComma = isLast ? "" : ",";
        const shouldCollapse = isRoot;

        const headerRow = document.createElement("div");
        headerRow.className = "json-raw-line collapsible";

        const toggle = document.createElement("span");
        toggle.className = "json-tree-toggle";
        toggle.textContent = shouldCollapse ? "▶" : "▼";
        headerRow.appendChild(toggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-syntax-key";
          keyEl.textContent = JSON.stringify(key) + ": ";
          headerRow.appendChild(keyEl);
        }

        const openSpan = document.createElement("span");
        openSpan.className = "json-syntax-bracket";
        openSpan.textContent = openBracket;
        headerRow.appendChild(openSpan);

        const summarySpan = document.createElement("span");
        summarySpan.className = "json-syntax-summary";
        summarySpan.textContent = ` ... ${closeBracket}${trailingComma}`;
        summarySpan.hidden = !shouldCollapse;
        headerRow.appendChild(summarySpan);

        if (keys.length === 0) {
          toggle.style.visibility = "hidden";
          headerRow.classList.remove("collapsible");
          summarySpan.textContent = `${closeBracket}${trailingComma}`;
          summarySpan.hidden = false;
          container.appendChild(headerRow);
          return container;
        }

        const childrenContainer = document.createElement("div");
        childrenContainer.className = "json-raw-children";
        if (shouldCollapse) {
          childrenContainer.hidden = true;
        }

        const footerRow = document.createElement("div");
        footerRow.className = "json-raw-line json-raw-node-footer";
        if (shouldCollapse) {
          footerRow.hidden = true;
        }
        const dummyToggle = document.createElement("span");
        dummyToggle.className = "json-tree-toggle";
        dummyToggle.style.visibility = "hidden";
        footerRow.appendChild(dummyToggle);

        const closeSpan = document.createElement("span");
        closeSpan.className = "json-syntax-bracket";
        closeSpan.textContent = closeBracket + trailingComma;
        footerRow.appendChild(closeSpan);

        headerRow.addEventListener("click", (e) => {
          e.stopPropagation();
          const isCollapsed = childrenContainer.hidden;
          childrenContainer.hidden = !isCollapsed;
          footerRow.hidden = !isCollapsed;
          summarySpan.hidden = !isCollapsed;
          toggle.textContent = isCollapsed ? "▼" : "▶";
        });

        container.appendChild(headerRow);

        keys.forEach((childKey, idx) => {
          const childIsLast = idx === keys.length - 1;
          const childVal = isArray ? value[childKey] : value[childKey];
          const childKeyName = isArray ? null : childKey;
          childrenContainer.appendChild(buildNode(childKeyName, childVal, childIsLast, false));
        });

        container.appendChild(childrenContainer);
        container.appendChild(footerRow);
      } else {
        const line = document.createElement("div");
        line.className = "json-raw-line";

        const dummyToggle = document.createElement("span");
        dummyToggle.className = "json-tree-toggle";
        dummyToggle.style.visibility = "hidden";
        line.appendChild(dummyToggle);

        if (key !== null) {
          const keyEl = document.createElement("span");
          keyEl.className = "json-syntax-key";
          keyEl.textContent = JSON.stringify(key) + ": ";
          line.appendChild(keyEl);
        }

        const valSpan = document.createElement("span");
        const valType = value === null ? "null" : typeof value;
        valSpan.className = `json-syntax-value ${valType}`;

        if (typeof value === "string") {
          renderStringValue(valSpan, value, followLink);
        } else {
          valSpan.textContent = value === null ? "null" : JSON.stringify(value);
        }
        line.appendChild(valSpan);

        if (!isLast) {
          const commaSpan = document.createElement("span");
          commaSpan.className = "json-syntax-comma";
          commaSpan.textContent = ",";
          line.appendChild(commaSpan);
        }

        container.appendChild(line);
      }

      return container;
    }

    parentContainer.appendChild(buildNode(null, data, true, true));
  }

  function displayResponseData(data, label = null) {
    const rawText = typeof data === "string" ? data : JSON.stringify(data, null, 2);
    if (jsonResponseEl) {
      let dataToRender = data;
      if (typeof data === "string") {
        try {
          dataToRender = JSON.parse(data);
        } catch {
          dataToRender = null;
        }
      }
      if (dataToRender !== null && typeof dataToRender === "object") {
        renderCollapsibleJson(dataToRender, jsonResponseEl, () => SFPanel.showTab("rest"));
      } else {
        renderPlainTextWithLinks(rawText, jsonResponseEl, () => SFPanel.showTab("rest"));
      }
    }

    if (treeResponseEl) {
      if (typeof data === "object" && data !== null) {
        renderJsonTree(data, treeResponseEl, label);
      } else {
        try {
          const parsed = JSON.parse(data);
          renderJsonTree(parsed, treeResponseEl, label);
        } catch {
          treeResponseEl.textContent = rawText;
        }
      }
    }
  }

  function renderBadges(data) {
    if (!badgesEl) return;
    badgesEl.textContent = "";
    if (!data || typeof data !== "object") return;

    const props = [
      { key: "queryable", label: "Queryable" },
      { key: "createable", label: "Createable" },
      { key: "updateable", label: "Updateable" },
      { key: "deletable", label: "Deletable" },
      { key: "custom", label: "Custom" },
      { key: "customSetting", label: "Custom Setting" },
      { key: "layoutable", label: "Layoutable" },
      { key: "searchable", label: "Searchable" },
      { key: "triggerable", label: "Triggerable" }
    ];

    props.forEach(({ key, label }) => {
      if (data[key] === true) {
        const badge = document.createElement("span");
        badge.className = "meta-badge";
        badge.textContent = label;
        badgesEl.appendChild(badge);
      }
    });

    if (data.fields && Array.isArray(data.fields)) {
      const badge = document.createElement("span");
      badge.className = "meta-badge";
      badge.textContent = `${data.fields.length} Fields`;
      badgesEl.appendChild(badge);
    }
    if (data.childRelationships && Array.isArray(data.childRelationships)) {
      const badge = document.createElement("span");
      badge.className = "meta-badge";
      badge.textContent = `${data.childRelationships.length} Child Relationships`;
      badgesEl.appendChild(badge);
    }
  }

  function cleanLabel(label, fallback) {
    if (typeof label === "string" && label && !label.includes("__MISSING LABEL__")) {
      return label;
    }
    return fallback;
  }

  function renderList() {
    listEl.textContent = "";
    const term = (searchInput.value || "").trim().toLowerCase();
    const filtered = term
      ? allTypes.filter(
          (t) => (t.label && t.label.toLowerCase().includes(term)) || t.name.toLowerCase().includes(term)
        )
      : allTypes;

    filtered.forEach((item) => {
      const li = document.createElement("li");
      li.className = "object-row";

      const mainDiv = document.createElement("div");
      mainDiv.className = "object-row-main";
      if (item.name === selectedTypeName) {
        mainDiv.classList.add("active");
      }

      const labelSpan = document.createElement("span");
      labelSpan.className = "object-label";
      labelSpan.textContent = item.label || item.name;
      mainDiv.appendChild(labelSpan);

      if (item.label && item.label !== item.name) {
        const nameSpan = document.createElement("span");
        nameSpan.className = "object-name";
        nameSpan.textContent = item.name;
        mainDiv.appendChild(nameSpan);
      }

      mainDiv.addEventListener("click", () => selectType(item));
      li.appendChild(mainDiv);
      listEl.appendChild(li);
    });
  }

  async function selectType(item) {
    selectedTypeName = item.name;
    renderList();

    emptyStateEl.hidden = true;
    detailEl.hidden = false;

    titleEl.textContent = `${item.label || item.name} (${item.name})`;
    if (prefixEl) {
      prefixEl.textContent = item.keyPrefix ? `Prefix: ${item.keyPrefix}` : "";
      prefixEl.hidden = !item.keyPrefix;
    }

    const itemLabel = item.label || item.name;
    if (describeCache.has(item.name)) {
      const cachedData = describeCache.get(item.name);
      renderBadges(cachedData);
      displayResponseData(cachedData, itemLabel);
      setStatus("", false);
      return;
    }

    setStatus("Loading describe…", false);
    if (jsonResponseEl) jsonResponseEl.textContent = "";
    if (treeResponseEl) treeResponseEl.textContent = "";
    if (badgesEl) badgesEl.textContent = "";

    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    try {
      // Try Tooling API describe first
      let data = null;
      try {
        const toolingResult = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/${encodeURIComponent(item.name)}/describe/`
        });
        data = toolingResult.data;
      } catch {
        // Fall back to standard Data API describe
        const stdResult = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/sobjects/${encodeURIComponent(item.name)}/describe/`
        });
        data = stdResult.data;
      }

      describeCache.set(item.name, data);
      renderBadges(data);
      displayResponseData(data, itemLabel);
      setStatus("", false);
    } catch (err) {
      setStatus(`Failed to load describe: ${err.message}`);
    }
  }

  async function loadMetadataTypes() {
    const hostname = SFPanel.getHostname();
    if (!hostname) {
      setStatus("No Salesforce tab detected.");
      return;
    }

    refreshButton.disabled = true;
    setStatus("Loading metadata types…", false);

    try {
      const typeMap = new Map();

      // Fetch Tooling sObjects
      try {
        const toolingRes = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/tooling/sobjects/`
        });
        const toolingList = (toolingRes.data && toolingRes.data.sobjects) || [];
        toolingList.forEach((o) => {
          typeMap.set(o.name, {
            name: o.name,
            label: cleanLabel(o.label, o.name),
            keyPrefix: o.keyPrefix || "",
            isTooling: true,
            isCustom: !!o.custom
          });
        });
      } catch {
        // ignore tooling fetch error
      }

      // Fetch Standard sObjects
      try {
        const stdRes = await SFPanel.sendMessage({
          type: "restRequest",
          hostname,
          method: "GET",
          path: `/services/data/${SFPanel.API_VERSION}/sobjects/`
        });
        const stdList = (stdRes.data && stdRes.data.sobjects) || [];
        stdList.forEach((o) => {
          if (!typeMap.has(o.name)) {
            typeMap.set(o.name, {
              name: o.name,
              label: cleanLabel(o.label, o.name),
              keyPrefix: o.keyPrefix || "",
              isTooling: false,
              isCustom: !!o.custom
            });
          }
        });
      } catch {
        // ignore std fetch error
      }

      allTypes = Array.from(typeMap.values()).sort((a, b) =>
        (a.label || a.name).localeCompare(b.label || b.name)
      );

      loadedHostname = hostname;
      searchInput.disabled = false;
      renderList();
      setStatus("", false);

      if (!selectedTypeName) {
        emptyStateEl.hidden = false;
        detailEl.hidden = true;
      }
    } catch (err) {
      setStatus(`Error loading metadata types: ${err.message}`);
    } finally {
      refreshButton.disabled = false;
    }
  }

  searchInput.addEventListener("input", renderList);
  refreshButton.addEventListener("click", () => {
    describeCache.clear();
    loadMetadataTypes();
  });

  (function initResize() {
    const MIN_WIDTH = 120;
    const MIN_PANE_WIDTH = 200;
    const HANDLE_WIDTH = 5;
    const splitEl = listEl.parentElement;
    let dragStartX = 0;
    let dragStartWidth = 0;
    let isDragging = false;

    function maxWidth() {
      return Math.max(MIN_WIDTH, splitEl.getBoundingClientRect().width - HANDLE_WIDTH - MIN_PANE_WIDTH);
    }

    function setWidth(width) {
      const clamped = Math.min(maxWidth(), Math.max(MIN_WIDTH, width));
      splitEl.style.gridTemplateColumns = `${clamped}px ${HANDLE_WIDTH}px minmax(0, 1fr)`;
      return clamped;
    }

    function beginDrag(clientX) {
      dragStartX = clientX;
      dragStartWidth = listEl.getBoundingClientRect().width;
      isDragging = true;
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    function moveDrag(clientX) {
      if (!isDragging) return;
      setWidth(dragStartWidth + clientX - dragStartX);
    }

    function endDrag() {
      isDragging = false;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }

    resizeHandle.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
    document.addEventListener("pointermove", (event) => moveDrag(event.clientX));
    document.addEventListener("pointerup", endDrag);
    resizeHandle.addEventListener("mousedown", (event) => {
      event.preventDefault();
      beginDrag(event.clientX);
    });
  })();

  SFPanel.registerTab("metadataExplorer", {
    onShow(hostname) {
      if (hostname && (loadedHostname !== hostname || allTypes.length === 0)) {
        loadMetadataTypes();
      }
    },
    onHostnameChange(hostname) {
      if (hostname) {
        loadedHostname = null;
        allTypes = [];
        describeCache.clear();
        loadMetadataTypes();
      }
    }
  });
})(SFPanel.forTools("metadataExplorer"));
