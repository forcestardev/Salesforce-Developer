// SECURITY_NOTE: Org configuration and errors are rendered as literal text, never HTML.
const ObjectConfigCompare = ((SFPanel) => {
  const panel = document.getElementById("compareObjectConfigPanel");
  const core = ObjectConfigCore;
  const state = { source: "", target: "", generation: 0, catalog: [], loaded: false, busy: false, selected: new Set(), categories: new Set(["fields"]), results: [], activeCategory: "", resultStatus: "All" };
  const statuses = ["Same", "Different", "Source only", "Target only", "Unable to compare"];
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.assign(node, props);
    children.forEach(child => node.appendChild(child));
    return node;
  }
  function button(text, action) {
    const node = el("button", { type: "button", textContent: text });
    node.addEventListener("click", action);
    return node;
  }
  const status = el("div", { className: "status", role: "status", ariaLive: "polite" });
  const search = el("input", { type: "search", placeholder: "Filter objects by label or API name", ariaLabel: "Filter configuration comparison objects" });
  const objects = el("div", { className: "object-config-object-list" });
  const objectHeading = el("h3", { className: "object-config-heading" }, [
    el("span", { textContent: "Objects and configuration" }),
    el("span", { className: "object-config-count", ariaLabel: "Selected objects / available objects", textContent: "0/0" })
  ]);
  const categoryList = el("fieldset", { className: "object-config-categories" }, [el("legend", { textContent: "Configuration categories" })]);
  core.categories.forEach(([name, label]) => {
    const input = el("input", { type: "checkbox", checked: state.categories.has(name) });
    input.addEventListener("change", () => {
      if (input.checked) state.categories.add(name); else state.categories.delete(name);
      clearResults(); update();
    });
    categoryList.appendChild(el("label", {}, [input, el("span", { textContent: label })]));
  });
  const summary = el("div", { className: "object-config-summary" });
  const selectedObjects = el("div", { className: "object-config-selected-objects", ariaLive: "polite" });
  const resultList = el("div", { className: "object-config-results" });
  const categoryTabs = el("nav", { className: "object-config-result-tabs", role: "tablist", ariaLabel: "Configuration result categories", hidden: true });
  const filters = el("fieldset", { className: "object-config-result-filters", hidden: true });
  filters.appendChild(el("legend", { textContent: "Result status" }));
  const compare = button("Compare object configuration", run);
  const refresh = button("Refresh", () => loadCatalog(true));
  const cancel = button("Cancel comparison", () => {
    state.generation++; state.busy = false;
    setStatus("Comparison cancelled. No Salesforce configuration was changed.");
    update();
  });
  const download = button("Download comparison JSON", () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify({ source: state.source, target: state.target, results: state.results }, null, 2)], { type: "application/json" }));
    el("a", { href: url, download: "object-configuration-comparison.json" }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  const resultToolbar = el("div", { className: "data-export-toolbar", hidden: true }, [download]);
  const selectVisible = button("Select All", () => {
    visibleObjects().forEach(item => state.selected.add(item.name));
    clearResults(); update();
  });
  const clearSelection = button("Deselect All", () => { state.selected.clear(); clearResults(); update(); });
  const divider = el("div", { className: "data-export-divider object-config-divider", tabIndex: 0 });
  for (const [name, value] of Object.entries({ role: "separator", "aria-orientation": "vertical", "aria-label": "Resize comparison setup and results", "aria-valuemin": "240", "aria-valuemax": "560", "aria-valuenow": "280" })) divider.setAttribute(name, value);
  const setupPane = el("div", { className: "object-config-setup" }, [
    objectHeading, search,
    el("div", { className: "data-export-toolbar" }, [refresh, selectVisible, clearSelection]), objects,
    categoryList, el("div", { className: "data-export-toolbar" }, [compare, cancel]), status
  ]);
  const workspace = el("div", { className: "object-config-workspace" }, [
    setupPane, divider,
    el("div", { className: "object-config-data" }, [
      selectedObjects, summary, resultToolbar, categoryTabs, filters, resultList
    ])
  ]);
  let leftWidth = 280, drag = null;
  function resizeSetup(width) {
    const max = Math.min(560, Math.max(240, workspace.getBoundingClientRect().width - 320));
    leftWidth = Math.round(Math.max(240, Math.min(max, width)));
    workspace.style.setProperty("--object-config-left", `${leftWidth}px`);
    divider.setAttribute("aria-valuemax", String(Math.round(max)));
    divider.setAttribute("aria-valuenow", String(leftWidth));
  }
  divider.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    event.preventDefault();
    drag = { id: event.pointerId, x: event.clientX, width: setupPane.getBoundingClientRect().width };
    divider.setPointerCapture(event.pointerId);
  });
  divider.addEventListener("pointermove", event => {
    if (drag && drag.id === event.pointerId) resizeSetup(drag.width + event.clientX - drag.x);
  });
  for (const name of ["pointerup", "pointercancel", "lostpointercapture"]) divider.addEventListener(name, () => { drag = null; });
  divider.addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    resizeSetup(event.key === "Home" ? 240 : event.key === "End" ? 560 : leftWidth + (event.key === "ArrowRight" ? 20 : -20));
  });
  panel.append(
    el("p", { className: "tab-help", textContent: "Read-only comparison of the properties shown in Object Explorer, not record data or complete metadata XML. Match objects and components by API name; ignore org-specific IDs and audit timestamps. Access results reflect explicit profile/permission-set grants, not effective user access. Missing permissions or retrieval errors are reported as Unable to compare." }),
    workspace
  );
  function setStatus(message, error = false) { status.textContent = message; status.style.color = error ? "#c00" : "inherit"; }
  function visibleObjects() {
    const term = search.value.trim().toLowerCase();
    return state.catalog.filter(item => `${item.label} ${item.name}`.toLowerCase().includes(term));
  }
  function renderObjects() {
    objects.textContent = "";
    visibleObjects().forEach(item => {
      const checkbox = el("input", { type: "checkbox", checked: state.selected.has(item.name), disabled: state.busy });
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) state.selected.add(item.name); else state.selected.delete(item.name);
        clearResults(); update();
      });
      objects.appendChild(el("label", {}, [checkbox, el("span", { textContent: `${item.label} (${item.name})${!item.source ? " — target only" : !item.target ? " — source only" : ""}` })]));
    });
    if (!objects.children.length) objects.appendChild(el("p", { textContent: state.loaded ? "No matching objects." : "Connect both orgs and refresh objects." }));
  }
  function update() {
    objectHeading.children[1].textContent = `${state.selected.size}/${state.loaded ? state.catalog.length : 0}`;
    selectedObjects.textContent = "";
    selectedObjects.appendChild(el("h3", { textContent: state.selected.size === 1 ? "Selected object" : `Selected objects (${state.selected.size})` }));
    if (!state.selected.size) selectedObjects.appendChild(el("p", { textContent: "No objects selected." }));
    else selectedObjects.appendChild(el("ul", {}, [...state.selected].map(name => {
      const item = state.catalog.find(entry => entry.name === name);
      return el("li", { textContent: item && item.label !== name ? `${item.label} (${name})` : name });
    })));
    summary.hidden = resultToolbar.hidden = !state.results.length;
    compare.disabled = state.busy || !state.loaded || !state.selected.size || !state.categories.size;
    refresh.disabled = state.busy || !state.source || !state.target || state.source === state.target;
    selectVisible.disabled = clearSelection.disabled = state.busy || !state.loaded;
    categoryList.disabled = state.busy;
    download.disabled = !state.results.length || state.busy;
    cancel.hidden = !state.busy;
    renderObjects();
  }
  function clearResults() {
    state.results = []; summary.textContent = ""; resultList.textContent = "";
    state.activeCategory = ""; state.resultStatus = "All";
    categoryTabs.textContent = ""; filters.textContent = "";
    categoryTabs.hidden = filters.hidden = true;
    summary.hidden = resultToolbar.hidden = true;
    resultList.textContent = "Select objects and categories, then compare to review configuration tables.";
    download.disabled = true;
  }
  function renderResults(focusStatus) {
    summary.hidden = resultToolbar.hidden = !state.results.length;
    resultList.textContent = "";
    const available = core.categories.filter(([name]) => state.results.some(result => result.category === name));
    if (!available.some(([name]) => name === state.activeCategory)) state.activeCategory = available[0]?.[0] || "";
    categoryTabs.textContent = "";
    categoryTabs.hidden = filters.hidden = !available.length;
    available.forEach(([name, label], index) => {
      const tab = button(label, () => {
        state.activeCategory = name; state.resultStatus = "All"; renderResults();
        categoryTabs.children[index].focus();
      });
      tab.id = `objectConfigResultTab-${name}`;
      tab.setAttribute("role", "tab");
      tab.setAttribute("aria-selected", String(state.activeCategory === name));
      tab.setAttribute("aria-controls", "objectConfigResultTable");
      tab.tabIndex = state.activeCategory === name ? 0 : -1;
      tab.addEventListener("keydown", event => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        const next = event.key === "Home" ? 0 : event.key === "End" ? available.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + available.length) % available.length;
        state.activeCategory = available[next][0]; state.resultStatus = "All"; renderResults();
        categoryTabs.children[next].focus();
      });
      categoryTabs.appendChild(tab);
    });
    const entries = state.results.filter(result => result.category === state.activeCategory).flatMap(result => {
      if (result.error || !result.rows.length) return [{ object: result.object, key: "(category)", status: result.status, reason: result.error || result.note || "No configuration entries in either org.", source: null, target: null, differences: [] }];
      return result.rows.map(row => ({ ...row, object: result.object, reason: row.reason || result.note || "" }));
    });
    summary.textContent = `${state.results.length} object/category comparisons. ${entries.length} entries in the selected category. Select Detail to review actual source and target values.`;
    filters.textContent = ""; filters.appendChild(el("legend", { textContent: "Result status" }));
    ["All", ...statuses].forEach(name => {
      const count = name === "All" ? entries.length : entries.filter(row => row.status === name).length;
      const radio = el("input", { type: "radio", name: "objectConfigResultStatus", value: name, checked: state.resultStatus === name, ariaLabel: `Show ${name} configuration results` });
      radio.addEventListener("change", () => { if (radio.checked) { state.resultStatus = name; renderResults(name); } });
      filters.appendChild(el("label", {}, [radio, el("span", { textContent: `${name} (${count})` })]));
      if (focusStatus === name) radio.focus();
    });
    resultList.id = "objectConfigResultTable"; resultList.setAttribute("role", "tabpanel");
    if (state.activeCategory) resultList.setAttribute("aria-labelledby", `objectConfigResultTab-${state.activeCategory}`);
    const shown = entries.filter(row => state.resultStatus === "All" || row.status === state.resultStatus);
    if (!shown.length) { resultList.textContent = "No comparison results match this filter."; return; }
    const excluded = new Set(["attributes", "Id", "CreatedDate", "LastModifiedDate", "API Name"]);
    const body = el("tbody");
    shown.forEach((row, index) => {
      const line = el("tr");
      [row.object, row.key, row.status].forEach(text => line.appendChild(el("td", { textContent: text })));
      line.appendChild(el("td", { textContent: row.reason || "" }));
      const detailRow = el("tr", { hidden: true });
      const detailId = `objectConfigComponentDetail-${index}`;
      const detailCell = el("td", { colSpan: 5, id: detailId });
      detailRow.appendChild(detailCell);
      const detailButton = button("Detail", () => {
        const opening = detailRow.hidden;
        if (opening && !detailCell.children.length) {
          const properties = [...new Set([...Object.keys(row.source || {}), ...Object.keys(row.target || {})])].filter(property => !excluded.has(property));
          detailCell.appendChild(el("h4", { textContent: `${row.object} / ${row.key}` }));
          if (properties.length) detailCell.appendChild(el("table", { className: "configuration-table" }, [
            el("thead", {}, [el("tr", {}, ["Property", "Source value", "Target value"].map(text => el("th", { textContent: text })))]),
            el("tbody", {}, properties.map(property => el("tr", { className: row.differences.some(item => item.property === property) ? "object-config-value-different" : "" }, [
              el("th", { textContent: property, scope: "row" }),
              el("td", { textContent: formatValue(row.source?.[property]) }),
              el("td", { textContent: formatValue(row.target?.[property]) })
            ])))
          ]));
          else detailCell.appendChild(el("p", { textContent: row.reason || "No property values were returned for this entry." }));
        }
        detailRow.hidden = !opening;
        detailButton.textContent = opening ? "Hide detail" : "Detail";
        detailButton.setAttribute("aria-expanded", String(opening));
      });
      detailButton.setAttribute("aria-expanded", "false");
      detailButton.setAttribute("aria-controls", detailId);
      detailButton.setAttribute("aria-label", `Detail for ${row.object} / ${row.key}`);
      line.appendChild(el("td", {}, [detailButton]));
      body.appendChild(line);
      body.appendChild(detailRow);
    });
    const resultTable = el("table", { className: "configuration-table" }, [
      el("thead", {}, [el("tr", {}, ["Object", "Component / API name", "Status", "Notes", "Details"].map(text => el("th", { textContent: text })))]), body
    ]);
    resultList.appendChild(resultTable);
  }
  function formatValue(value) { return value == null ? "(not returned)" : typeof value === "object" ? JSON.stringify(value) : String(value); }
  async function loadCatalog(force = false) {
    if (state.busy || (!force && state.loaded)) return;
    clearResults();
    if (!state.source || !state.target || state.source === state.target) { setStatus("Connect two different Salesforce orgs using the controls above.", true); update(); return; }
    const generation = ++state.generation;
    state.busy = true; state.loaded = false; update(); setStatus("Loading objects from both orgs...");
    try {
      const responses = await Promise.all([state.source, state.target].map(hostname => SFPanel.sendMessage({ type: "getObjects", hostname })));
      if (generation !== state.generation) return;
      if (responses.some(response => !Array.isArray(response.objects))) throw new Error("Salesforce returned an invalid object catalog. Missing objects cannot be determined.");
      const catalog = new Map();
      responses.forEach((response, index) => {
        const objects = [...response.objects];
        if (!objects.some(item => item.name === "Activity") && ["Task", "Event"].every(name => objects.some(item => item.name === name))) objects.push({ name: "Activity", label: "Activity" });
        objects.forEach(item => {
          if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(item.name)) throw new Error("Salesforce returned an invalid object API name.");
          const entry = catalog.get(item.name) || { name: item.name, label: item.label || item.name, source: false, target: false };
          entry[index === 0 ? "source" : "target"] = true; catalog.set(item.name, entry);
        });
      });
      state.catalog = [...catalog.values()].sort((a, b) => a.name.localeCompare(b.name));
      state.selected.forEach(name => { if (!catalog.has(name)) state.selected.delete(name); });
      state.loaded = true;
      setStatus("");
    } catch (error) {
      if (generation === state.generation) { state.catalog = []; setStatus(`Unable to load object catalogs: ${error.message}`, true); }
    } finally { if (generation === state.generation) { state.busy = false; update(); } }
  }
  async function run() {
    if (compare.disabled) return;
    const generation = ++state.generation, source = state.source, target = state.target;
    const names = [...state.selected], categories = [...state.categories];
    const check = () => { if (generation !== state.generation) throw new Error("Comparison cancelled or orgs changed."); };
    state.busy = true; clearResults(); update();
    try {
      for (const name of names) {
        const entry = state.catalog.find(item => item.name === name);
        if (!entry) throw new Error(`Object ${name} is not in the accessible catalogs. Refresh objects and select again.`);
        for (const category of categories) {
          check();
          const label = core.categories.find(item => item[0] === category)[1];
          setStatus(`Comparing ${name}: ${label}...`);
          const responses = await Promise.all([source, target].map(async (host, index) => {
            if (!entry[index === 0 ? "source" : "target"]) return { rows: [] };
            try { return await core.load(message => SFPanel.sendMessage(message), host, SFPanel.API_VERSION, name, category, check); }
            catch (error) { return { error: `${index === 0 ? "Source" : "Target"} (${host}): ${error.message}` }; }
          }));
          check();
          const result = { object: name, category, label, rows: [], status: "Unable to compare", error: "" };
          if (responses.some(response => response.error)) result.error = responses.map(response => response.error).filter(Boolean).join("\n");
          else {
            try {
              result.rows = core.compare(category, responses[0].rows, responses[1].rows);
              if (category === "fields" && entry.source && entry.target && result.rows.some(row => ["Source only", "Target only"].includes(row.status))) {
                if (name === "Activity") throw new Error("One-sided Activity fields cannot be verified. Compare Task and Event separately.");
                const inventories = await Promise.all([source, target].map(async (host, index) => {
                  try { return await core.load(message => SFPanel.sendMessage(message), host, SFPanel.API_VERSION, name, "fieldInventory", check); }
                  catch (error) { throw new Error(`${index === 0 ? "Source" : "Target"} field inventory (${host}): ${error.message}`); }
                }));
                check();
                result.rows = core.verifyFieldPresence(result.rows, inventories[0].rows, inventories[1].rows);
              }
              result.status = !entry.source ? "Target only" : !entry.target ? "Source only" : result.rows.some(row => row.status === "Unable to compare") ? "Unable to compare" : result.rows.every(row => row.status === "Same") ? "Same" : "Different";
              if (!entry.source || !entry.target) result.note = `Object is absent from the ${!entry.source ? "source" : "target"} accessible catalog. This does not prove it does not exist outside the connected user's access.`;
            } catch (error) { result.rows = []; result.error = error.message; }
          }
          check();
          state.results.push(result); renderResults();
        }
      }
      setStatus("Configuration comparison complete. Choose a category tab and result status to review the tables.", state.results.some(result => result.error || result.status === "Unable to compare"));
    } catch (error) { if (generation === state.generation) setStatus(error.message, true); }
    finally { if (generation === state.generation) { state.busy = false; update(); } }
  }
  function setContext(source, target) {
    if (source !== state.source || target !== state.target) {
      state.generation++; state.busy = false; state.loaded = false; state.catalog = [];
      state.source = source; state.target = target; clearResults();
      setStatus("Org context changed. Select objects and compare again.");
    }
    update();
    if (!panel.hidden) loadCatalog();
  }
  function activate(objectName) {
    if (typeof objectName === "string" && /^[A-Za-z_][A-Za-z0-9_]*$/.test(objectName)) {
      state.selected.clear(); clearResults();
      if (state.loaded && !state.catalog.some(item => item.name === objectName)) {
        setStatus(`Object ${objectName} is not in either accessible catalog. Refresh objects to retry.`, true);
        update(); return;
      }
      state.selected.add(objectName);
    }
    update(); loadCatalog();
  }
  function connectionError(message) {
    state.generation++; state.busy = false; state.loaded = false;
    clearResults(); setStatus(message, true); update();
  }
  search.addEventListener("input", renderObjects);
  clearResults(); update();
  return { setContext, activate, connectionError };
})(SFPanel.forTools("compareObjects"));
