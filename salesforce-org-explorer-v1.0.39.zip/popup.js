// popup.js — panel shell
//
// Defines the shared `SFPanel` namespace used by every tab module
// (js/objects.js, js/rest.js, js/package.js, js/metadata.js): a message
// helper, active-tab hostname tracking, and tab-switching UI. Each module
// calls `SFPanel.registerTab(name, handlers)` at load time and receives
// `onShow(hostname)` / `onHostnameChange(hostname)` callbacks, so new tools
// can be added later without touching this file.
//
// SECURITY_NOTE: All data received from the background service worker
// (object/field names, API responses, etc.) must be inserted using
// textContent/value, never innerHTML, to avoid any XSS via reflected API
// data. This rule applies to every tab module.

const SFPanel = (() => {
  const API_VERSION = "v65.0"; // keep in sync with API_VERSION in background.js
  // keep in sync with ALLOWED_HOST_PATTERN in background.js
  const ALLOWED_HOST_PATTERN =
    /(\.salesforce\.com|\.force\.com|\.cloudforce\.com|\.visualforce\.com|\.salesforce-setup\.com|\.my\.site\.com)$/i;

  function normalizeApiHostname(hostname) {
    if (typeof hostname !== "string") return hostname;
    return hostname
      .replace(/\.lightning\.force\.com$/i, ".my.salesforce.com")
      .replace(/\.salesforce-setup\.com$/i, ".salesforce.com");
  }

  const tabs = new Map(); // name -> { onShow?, onStartup?, onHostnameChange? }
  let hostname = null;
  let activeTab = null;
  let access = { trial: null, license: null, errors: ["Checking access."], features: [] };
  let accessRefresh;
  let accessEpoch = 0;
  let showLoginHelperForConnectedOrg = false;
  const launchParameters = new URLSearchParams(window.location.search);
  const pinnedHostname = normalizeApiHostname(launchParameters.get("hostname"));
  const handoffToken = launchParameters.get("handoff");
  const HANDOFF_STORAGE_PREFIX = "sfPanelHandoff:";

  registerTab("home", {});
  registerTab("configSwitch", {}); // handlers are supplied by js/configSwitch.js
  registerTab("dataTransfer", {});

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response || !response.ok) {
          if (response?.access) applyAccess(response.access);
          const error = (response && response.error) || "Unknown error";
          const failure = new Error(message.type?.startsWith("license.") &&
            error.includes("This doesn't look like a Salesforce page")
            ? "Extension worker is outdated. Reload SF Developer at edge://extensions, then close and reopen its panels."
            : error);
          if (response?.code === "TOOL_ACTION_DENIED") failure.code = response.code;
          reject(failure);
          return;
        }
        resolve(response);
      });
    });
  }

  function forTools(...names) {
    return {
      ...SFPanel,
      sendMessage(message) {
        const feature = message.feature || SFAccess.features[names[0]];
        if (!names.some((name) => SFAccess.features[name] === feature)) {
          return Promise.reject(new Error("This request does not belong to the specified tool."));
        }
        return sendMessage({ ...message, feature });
      }
    };
  }

  function canUseTab(name) {
    return name === "home" || name === "help" || access.features.includes(SFAccess.features[name]);
  }

  function applyAccess(next) {
    access = next;
    updateToolAvailability();
    if (activeTab && !canUseTab(activeTab)) showTab("home");
    document.dispatchEvent(new CustomEvent("licenseaccesschange", { detail: access }));
  }

  function updateToolAvailability() {
    document.querySelectorAll(".tab-btn, [data-open-tab]").forEach((button) => {
      const name = button.dataset.tab || button.dataset.openTab;
      const label = button.querySelector(".tab-label, strong")?.textContent || button.getAttribute("aria-label") || name;
      const info = SFAccess.availability(access, name, label, Boolean(hostname));
      const feature = SFAccess.features[name];
      button.hidden = Boolean(feature && Array.isArray(access.activeFeatureKeys) && !access.activeFeatureKeys.includes(feature));
      button.disabled = false;
      button.setAttribute("aria-disabled", String(info.unavailable));
      button.classList.toggle("tool-plan-locked", info.locked);
      button.title = info.unavailable ? "" : info.message;
      button.setAttribute("aria-description", info.message);
      button.setAttribute("aria-describedby", info.unavailable ? "toolAccessTooltip" : "");
    });
  }

  async function refreshAccess() {
    if (accessRefresh) return accessRefresh;
    const epoch = accessEpoch;
    const pending = (async () => {
      try {
        const { data } = await sendMessage({ type: "license.getAccess" });
        if (epoch === accessEpoch) applyAccess(data);
        return data;
      } catch (error) {
        if (epoch === accessEpoch) applyAccess({ trial: null, license: null, errors: [`Connection error: ${error.message}`], features: [] });
        throw error;
      }
    })();
    accessRefresh = pending;
    try {
      return await pending;
    } finally {
      if (accessRefresh === pending) accessRefresh = undefined;
    }
  }

  async function getActiveTabHostname() {
    const queries = [
      { active: true, currentWindow: true },
      { active: true, lastFocusedWindow: true },
      { active: true },
      {}
    ];
    const seenTabIds = new Set();
    for (const [queryIndex, query] of queries.entries()) {
      const tabsForQuery = await chrome.tabs.query(query);
      console.debug("[SF Tool] Salesforce tab scan", { queryIndex, tabCount: tabsForQuery.length, hosts: tabsForQuery.map((tab) => { try { return new URL(tab.url || "").hostname; } catch { return "(unavailable)"; } }).filter(Boolean) });
      for (const tab of tabsForQuery) {
        if (seenTabIds.has(tab.id)) continue;
        seenTabIds.add(tab.id);
        if (!tab.url || tab.url.startsWith(chrome.runtime.getURL(""))) continue;
        try {
          const rawHostname = new URL(tab.url).hostname;
          // These are Salesforce-owned marketing/docs/login sites, never a real org host.
          if (/^(login|test|developer|help|trailhead|admin|status|success|appexchange|www)\.salesforce\.com$/i.test(rawHostname)) continue;
          if (ALLOWED_HOST_PATTERN.test(rawHostname)) return normalizeApiHostname(rawHostname);
        } catch {
          // Ignore tabs with non-URL or restricted schemes.
        }
      }
    }
    return null;
  }

  async function getConnectedSalesforceTab() {
    const connectedHostname = hostname || pinnedHostname;
    if (!connectedHostname) return null;
    const tabsForQuery = await chrome.tabs.query({});
    const matchingTabs = tabsForQuery.filter((tab) => {
      try {
        return normalizeApiHostname(new URL(tab.url || "").hostname) === connectedHostname;
      } catch {
        return false;
      }
    });
    return matchingTabs.find((tab) => tab.active) || matchingTabs[0] || null;
  }

  async function hasActiveSalesforceSession(candidateHostname) {
    if (!candidateHostname) return false;
    try {
      const response = await sendMessage({ type: "checkSession", hostname: candidateHostname });
      return Boolean(response.hasSession);
    } catch {
      return false;
    }
  }

  const orgInfoCache = new Map();
  async function getConnectedUsername(candidateHostname) {
    if (orgInfoCache.has(candidateHostname)) return orgInfoCache.get(candidateHostname);
    try {
      const response = await sendMessage({ type: "getOrgInfo", hostname: candidateHostname });
      const username = response.username || null;
      orgInfoCache.set(candidateHostname, username);
      return username;
    } catch {
      return null;
    }
  }

  function registerTab(name, handlers) {
    tabs.set(name, handlers || {});
  }

  function captureCurrentTabState() {
    const panel = document.querySelector(`.tab-panel.active`);
    if (!panel || !activeTab) return null;
    const controls = Array.from(panel.querySelectorAll("input, textarea, select"))
      .map((control, index) => ({
        index,
        type: control.type,
        value: control.type === "file" ? "" : control.value,
        checked: "checked" in control ? control.checked : undefined
      }))
      .filter((control) => control.type !== "file" && control.type !== "password");
    const details = Array.from(panel.querySelectorAll("details")).map((detail, index) => ({ index, open: detail.open }));
    return { tab: activeTab, controls, details };
  }

  function createTabHandoff() {
    const state = captureCurrentTabState();
    if (!state) return "";
    const token = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
    localStorage.setItem(`${HANDOFF_STORAGE_PREFIX}${token}`, JSON.stringify(state));
    return token;
  }

  function consumeTabHandoff() {
    if (!handoffToken) return null;
    const storageKey = `${HANDOFF_STORAGE_PREFIX}${handoffToken}`;
    const serialized = localStorage.getItem(storageKey);
    localStorage.removeItem(storageKey);
    if (!serialized) return null;
    try {
      const state = JSON.parse(serialized);
      return state && typeof state.tab === "string" ? state : null;
    } catch {
      return null;
    }
  }

  function restoreTabState(state) {
    if (!state) return;
    const panel = document.querySelector(`.tab-panel.active`);
    if (!panel) return;
    const controls = Array.from(panel.querySelectorAll("input, textarea, select"));
    state.controls?.forEach((saved) => {
      const control = controls[saved.index];
      if (!control || control.type === "file" || control.type === "password") return;
      control.value = saved.value;
      if (typeof saved.checked === "boolean") control.checked = saved.checked;
      control.dispatchEvent(new Event("input", { bubbles: true }));
      control.dispatchEvent(new Event("change", { bubbles: true }));
    });
    const details = Array.from(panel.querySelectorAll("details"));
    state.details?.forEach((saved) => {
      if (details[saved.index]) details[saved.index].open = Boolean(saved.open);
    });
  }

  function showTab(name, tabContext) {
    if (!tabs.has(name)) return;
    if (!canUseTab(name)) {
      const status = document.getElementById("licenseAccessStatus");
      if (status) status.textContent = SFAccess.denial(access, SFAccess.features[name]);
      name = "home";
    }
    if (activeTab && activeTab !== name && canUseTab(activeTab)) {
      const currentHandlers = tabs.get(activeTab);
      if (currentHandlers.onBeforeHide && currentHandlers.onBeforeHide() === false) return;
    }
    activeTab = name;

    const activeTitleEl = document.getElementById("activeTabTitle");

    document.querySelectorAll(".tab-btn").forEach((btn) => {
      const isActive = btn.dataset.tab === name;
      btn.classList.toggle("active", isActive);
      if (isActive && activeTitleEl) {
        const labelEl = btn.querySelector(".tab-label");
        activeTitleEl.textContent = labelEl ? labelEl.textContent : (btn.title || name);
      }
    });
    if (activeTitleEl && name === "help") {
      activeTitleEl.textContent = document.getElementById("tab-help")?.dataset.tabTitle || "Help";
    }
    document.querySelectorAll(".tab-panel").forEach((panel) => {
      panel.classList.toggle("active", panel.id === `tab-${name}` || panel.dataset.tabAlias === name);
      panel.classList.toggle("deploy-mode", panel.dataset.tabAlias === name);
    });

    const handlers = tabs.get(name);
    if (handlers.onShow) handlers.onShow(hostname, tabContext);
  }

  async function refreshHostname() {
    const candidateHostname = (await getActiveTabHostname()) || pinnedHostname;
    const sessionActive = candidateHostname ? await hasActiveSalesforceSession(candidateHostname) : false;
    const newHostname = sessionActive ? candidateHostname : null;
    const changed = newHostname !== hostname;
    hostname = newHostname;
    const orgHost = document.getElementById("orgHost");
    if (orgHost) orgHost.textContent = hostname || (candidateHostname ? `${candidateHostname} (not logged in)` : "No Salesforce tab detected");
    const homeConnectionStatus = document.getElementById("homeConnectionStatus");
    const homeConnectionHost = document.getElementById("homeConnectionHost");
    if (homeConnectionStatus && homeConnectionHost) {
      homeConnectionStatus.closest(".landing-status")?.classList.toggle("connected", Boolean(hostname));
      if (hostname) {
        homeConnectionStatus.textContent = "Salesforce org connected";
        homeConnectionHost.textContent = hostname;
        getConnectedUsername(hostname).then((username) => {
          if (username && hostname === newHostname) homeConnectionHost.textContent = username;
        });
      } else if (candidateHostname) {
        homeConnectionStatus.textContent = "Salesforce tab open, but not logged in";
        homeConnectionHost.textContent = `Log in to ${candidateHostname} — this panel connects automatically once you do.`;
      } else {
        homeConnectionStatus.textContent = "No Salesforce org connected";
        homeConnectionHost.textContent = "Open a Salesforce tab and log in, or use \"Open Salesforce Login\" below.";
      }
    }

    updateToolAvailability();

    const loginHelper = document.getElementById("homeLoginHelper");
    const changeConnectionButton = document.getElementById("homeChangeConnection");
    if (!hostname) showLoginHelperForConnectedOrg = false;
    if (loginHelper) loginHelper.hidden = Boolean(hostname) && !showLoginHelperForConnectedOrg;
    if (changeConnectionButton) changeConnectionButton.hidden = !hostname || showLoginHelperForConnectedOrg;

    if (changed) {
      for (const handlers of tabs.values()) {
        if (handlers.onHostnameChange) handlers.onHostnameChange(hostname);
      }
    }
    return changed;
  }

  // The side panel's width is user-controlled (drag-resized) with no manifest
  // API to set a default. As a workaround, offer opening the same UI in a
  // regular popup window using the current browser window's full dimensions.
  async function openInWindow() {
    const currentHostname = hostname || (await getActiveTabHostname());
    const query = currentHostname ? `?hostname=${encodeURIComponent(currentHostname)}` : "";
    let width = 480;
    let height = 720;
    try {
      const current = await chrome.windows.getCurrent();
      if (current.width) width = current.width;
      if (current.height) height = current.height;
    } catch {
      // Fall back to the defaults above if window info isn't available.
    }

    chrome.windows.create({
      url: `${chrome.runtime.getURL("popup.html")}${query}`,
      type: "popup",
      width,
      height
    });
  }

  async function openInTab() {
    const currentHostname = hostname || (await getActiveTabHostname());
    const parameters = new URLSearchParams();
    if (currentHostname) parameters.set("hostname", currentHostname);
    const handoff = createTabHandoff();
    if (handoff) parameters.set("handoff", handoff);
    const query = parameters.size ? `?${parameters}` : "";
    chrome.tabs.create({ url: `${chrome.runtime.getURL("popup.html")}${query}` });
  }

  function init() {
    const version = chrome.runtime.getManifest().version;
    document.title = "SF Developer";
    const appVersion = document.getElementById("appVersion");
    if (appVersion) {
      appVersion.textContent = `v${version}`;
      appVersion.title = `SF Developer v${version}`;
    }

    const termsUrl = window.SF_EXTENSION_CONFIG?.termsOfServiceUrl;
    if (termsUrl) {
      try {
        const parsedTermsUrl = new URL(termsUrl);
        if (parsedTermsUrl.protocol === "https:" && !parsedTermsUrl.username && !parsedTermsUrl.password) {
          const termsLink = document.getElementById("termsOfServiceLink");
          termsLink.href = parsedTermsUrl.href;
          termsLink.hidden = false;
          document.getElementById("termsOfServiceText").hidden = true;
        }
      } catch {}
    }

    const activityBar = document.getElementById("tabNav");
    const activityToggle = document.getElementById("toggleActivityBar");
    const activityResizeHandle = document.getElementById("activityResizeHandle");
    const savedActivityBarState = localStorage.getItem("activityBarExpanded") === "true";
    let activityBarWidth = Number(localStorage.getItem("activityBarWidth")) || 220;

    function setActivityBarExpanded(expanded) {
      activityBar.classList.toggle("expanded", expanded);
      activityBar.style.width = expanded ? `${activityBarWidth}px` : "44px";
      activityToggle.setAttribute("aria-expanded", String(expanded));
      activityToggle.setAttribute("aria-label", expanded ? "Collapse activity bar" : "Expand activity bar");
      activityToggle.title = expanded ? "Collapse activity bar" : "Expand activity bar";
      localStorage.setItem("activityBarExpanded", String(expanded));
    }

    setActivityBarExpanded(savedActivityBarState);
    activityToggle.addEventListener("click", () => {
      setActivityBarExpanded(!activityBar.classList.contains("expanded"));
    });

    let dragStartX = 0;
    let dragStartWidth = 0;
    activityResizeHandle.addEventListener("pointerdown", (event) => {
      if (!activityBar.classList.contains("expanded")) return;
      dragStartX = event.clientX;
      dragStartWidth = activityBar.getBoundingClientRect().width;
      activityResizeHandle.setPointerCapture(event.pointerId);
      activityBar.classList.add("resizing");
    });
    activityResizeHandle.addEventListener("pointermove", (event) => {
      if (!activityResizeHandle.hasPointerCapture(event.pointerId)) return;
      const width = Math.min(320, Math.max(180, dragStartWidth + event.clientX - dragStartX));
      activityBarWidth = width;
      activityBar.style.width = `${width}px`;
      localStorage.setItem("activityBarWidth", String(Math.round(width)));
    });
    activityResizeHandle.addEventListener("pointerup", (event) => {
      if (activityResizeHandle.hasPointerCapture(event.pointerId)) {
        activityResizeHandle.releasePointerCapture(event.pointerId);
      }
      activityBar.classList.remove("resizing");
    });
    activityResizeHandle.addEventListener("keydown", (event) => {
      if (!activityBar.classList.contains("expanded")) return;
      const step = event.key === "ArrowLeft" ? -10 : event.key === "ArrowRight" ? 10 : 0;
      if (!step) return;
      event.preventDefault();
      const width = Math.min(320, Math.max(180, activityBar.getBoundingClientRect().width + step));
      activityBarWidth = width;
      activityBar.style.width = `${width}px`;
      localStorage.setItem("activityBarWidth", String(Math.round(width)));
    });

    async function openTool(name) {
      if (SFAccess.features[name]) {
        try {
          await refreshAccess();
        } catch (error) {
          console.error("[SF Tool] Access check failed:", error.message);
        }
      }
      const tool = [...document.querySelectorAll(".tab-btn")].find(button => button.dataset.tab === name);
      const label = tool?.querySelector(".tab-label")?.textContent || name;
      const info = SFAccess.availability(access, name, label, Boolean(hostname));
      if (info.unavailable) return;
      showTab(name);
    }

    const tooltip = document.getElementById("toolAccessTooltip");
    document.querySelectorAll(".tab-btn, [data-open-tab]").forEach(button => {
      const showExplanation = () => {
        if (button.getAttribute("aria-disabled") !== "true") return;
        tooltip.textContent = button.getAttribute("aria-description");
        tooltip.hidden = false;
        const rect = button.getBoundingClientRect();
        tooltip.style.left = `${Math.min(rect.right + 8, Math.max(8, window.innerWidth - tooltip.offsetWidth - 8))}px`;
        tooltip.style.top = `${Math.max(8, Math.min(rect.top, window.innerHeight - tooltip.offsetHeight - 8))}px`;
      };
      button.addEventListener("focus", showExplanation);
      button.addEventListener("mouseenter", showExplanation);
      for (const event of ["blur", "mouseleave", "click"]) button.addEventListener(event, () => { tooltip.hidden = true; });
      button.addEventListener("keydown", event => { if (event.key === "Escape") tooltip.hidden = true; });
    });
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => openTool(btn.dataset.tab));
    });

    document.querySelectorAll(".placeholder-tabs").forEach((tablist) => {
      const buttons = Array.from(tablist.querySelectorAll('[role="tab"]'));
      const select = (selected) => {
        buttons.forEach((button) => {
          const active = button === selected;
          button.setAttribute("aria-selected", String(active));
          button.tabIndex = active ? 0 : -1;
          document.getElementById(button.getAttribute("aria-controls")).hidden = !active;
        });
        document.getElementById(selected.getAttribute("aria-controls")).dispatchEvent(new CustomEvent("tabpanelshow"));
      };
      buttons.forEach((button, index) => {
        button.addEventListener("click", () => select(button));
        button.addEventListener("keydown", (event) => {
          let next;
          if (event.key === "ArrowRight") next = (index + 1) % buttons.length;
          else if (event.key === "ArrowLeft") next = (index + buttons.length - 1) % buttons.length;
          else if (event.key === "Home") next = 0;
          else if (event.key === "End") next = buttons.length - 1;
          else return;
          event.preventDefault();
          select(buttons[next]);
          buttons[next].focus();
        });
      });
    });

    document.getElementById("openInWindow").addEventListener("click", openInWindow);
    document.getElementById("openInTab").addEventListener("click", openInTab);
    document.getElementById("openHelp").addEventListener("click", () => {
      const currentTab = activeTab;
      if (window.SFHelp) window.SFHelp.open(currentTab);
    });

    document.querySelectorAll("[data-open-tab]").forEach((button) => {
      button.addEventListener("click", () => openTool(button.dataset.openTab));
    });

    const loginEnvSelect = document.getElementById("loginEnvSelect");
    const loginCustomDomain = document.getElementById("loginCustomDomain");
    const loginHelperStatus = document.getElementById("loginHelperStatus");
    const openLoginButton = document.getElementById("openLoginButton");
    const changeConnectionButton = document.getElementById("homeChangeConnection");

    changeConnectionButton?.addEventListener("click", () => {
      showLoginHelperForConnectedOrg = true;
      refreshHostname();
      loginEnvSelect.focus();
    });

    loginEnvSelect.addEventListener("change", () => {
      loginCustomDomain.hidden = loginEnvSelect.value !== "custom";
      loginHelperStatus.textContent = "";
    });

    openLoginButton.addEventListener("click", () => {
      loginHelperStatus.textContent = "";
      let url;
      if (loginEnvSelect.value === "production") {
        url = "https://login.salesforce.com";
      } else if (loginEnvSelect.value === "sandbox") {
        url = "https://test.salesforce.com";
      } else {
        // SECURITY_NOTE: only a validated DNS-label is interpolated into a fixed,
        // known Salesforce domain suffix — never navigate to a raw user-supplied URL.
        const domainLabel = loginCustomDomain.value.trim().toLowerCase();
        if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(domainLabel)) {
          loginHelperStatus.textContent = "Enter a valid My Domain name (letters, numbers, hyphens).";
          loginCustomDomain.focus();
          return;
        }
        url = `https://${domainLabel}.my.salesforce.com`;
      }
      chrome.tabs.create({ url });
    });

    const restoredState = consumeTabHandoff();
    const startupTabRequest = chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => tab || null).catch(() => null);
    Promise.all([
      startupTabRequest,
      refreshHostname(),
      refreshAccess().catch((error) => console.error("[SF Tool] Access check failed:", error.message))
    ]).then(([startupTab]) => {
      showTab(restoredState?.tab || "home", startupTab);
      for (const [name, handlers] of tabs) {
        if (name !== activeTab && canUseTab(name)) handlers.onStartup?.(hostname, startupTab);
      }
      if (restoredState && activeTab === restoredState.tab) {
        requestAnimationFrame(() => restoreTabState(restoredState));
      }
    });

    // The panel stays open (side panel) as the user switches/navigates/closes
    // tabs, so re-detect the org on every event that could change the answer.
    chrome.tabs.onActivated.addListener(() => refreshHostname());
    chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
      if (changeInfo.status === "complete" && tab.active) {
        refreshHostname();
        // Salesforce's post-login redirect can finish loading just before the
        // session cookie is written, so check again shortly after.
        setTimeout(() => refreshHostname(), 1200);
      }
    });
    chrome.tabs.onRemoved.addListener(() => refreshHostname());
    chrome.windows.onFocusChanged.addListener(() => refreshHostname());
    // Safety net: some login redirects don't produce a clean onUpdated
    // "complete" event, so poll while the panel is open.
    setInterval(() => refreshHostname(), 4000);
    window.addEventListener("focus", () => {
      refreshAccess().catch((error) => console.error("[SF Tool] Access check failed:", error.message));
    });
    setInterval(() => {
      refreshAccess().catch((error) => console.error("[SF Tool] Access check failed:", error.message));
    }, 60000);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "session" && changes.licenseApiKey) {
        accessEpoch++;
        accessRefresh = undefined;
        applyAccess({ trial: null, license: null, errors: ["License key changed. Checking access."], features: [] });
        refreshAccess().catch((error) => console.error("[SF Tool] Access check failed:", error.message));
      }
    });
  }

  return {
    API_VERSION,
    sendMessage,
    forTools,
    canUseTab,
    refreshAccess,
    getAccess: () => access,
    registerTab,
    showTab,
    getHostname: () => hostname,
    getConnectedSalesforceTab,
    getActiveTab: () => activeTab,
    init
  };
})();

document.addEventListener("DOMContentLoaded", () => SFPanel.init());
