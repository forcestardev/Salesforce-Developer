// background.js — Manifest V3 service worker
//
// Reads the Salesforce session cookie ("sid") for the org loaded in the
// active tab and exposes a small, generic authenticated REST/Tooling API
// proxy (`restRequest`) that every panel tab (Objects, REST Explorer,
// Package.xml builder, Create Metadata, and any future tab) is built on
// top of, plus two convenience wrappers (`getObjects`, `getObjectFields`)
// used by the Objects tab.
//
// SECURITY_NOTE: We never store, log, or forward the session id anywhere
// outside of a same-origin HTTPS request to the Salesforce instance that
// issued it. Requests are only made to hostnames that match the
// Salesforce domain allow-list below (which mirrors host_permissions in
// manifest.json), and only to paths under /services/, preventing the
// extension from being used to leak the cookie to an arbitrary host or
// route.

importScripts("config.js", "js/access.js");

const ALLOWED_HOST_PATTERN =
  /(\.salesforce\.com|\.force\.com|\.cloudforce\.com|\.visualforce\.com|\.salesforce-setup\.com|\.my\.site\.com)$/i;
const API_VERSION = "v65.0"; // keep in sync with SFPanel.API_VERSION in popup.js
const ALLOWED_METHODS = new Set(["GET", "POST", "PATCH", "PUT", "DELETE"]);
const apiVersionCache = new Map();
console.info("[SF Tool] Service worker source build 1.0.39 loaded");

// Make a single click on the toolbar icon open the side panel directly.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
  // Older Edge/Chrome versions without this API use the default panel behavior.
});

// License backend client. These requests never use the Salesforce sid
// cookie or sfFetch.
const LICENSE_SERVER = globalThis.SF_EXTENSION_CONFIG.licenseServer;
const LICENSE_APP_SLUG = "sf-tool-ext";
const ACCOUNT_WEBSITE = globalThis.SF_EXTENSION_CONFIG.accountWebsite;

let installationIdPromise;
let licenseRevision = 0;
let accessRequest;
const OFFLINE_GRACE_MS = 72 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

async function clearOfflineAccess() {
  await chrome.storage.local.remove("offlineAccess");
}

function offlineEntry(value, expiresAt, now) {
  return Number.isFinite(expiresAt) && expiresAt > now
    ? { value, verifiedAt: now, expiresAt: Math.min(expiresAt, now + OFFLINE_GRACE_MS) }
    : null;
}

function usableOfflineEntry(entry, now) {
  return entry && Number.isFinite(entry.verifiedAt) && Number.isFinite(entry.expiresAt) &&
    entry.verifiedAt <= now && now < entry.expiresAt &&
    entry.expiresAt <= entry.verifiedAt + OFFLINE_GRACE_MS;
}

function outageDuringRetry(until, now) {
  if (Number.isFinite(until) && now < until && until <= now + 60000) {
    const error = new Error("Account service unavailable; retrying shortly.");
    error.offlineEligible = true;
    return Promise.reject(error);
  }
  return null;
}

function getInstallationId() {
  if (!installationIdPromise) {
    installationIdPromise = (async () => {
      const stored = await chrome.storage.local.get("installationId");
      if (stored.installationId) return stored.installationId;

      const id = crypto.randomUUID();
      await chrome.storage.local.set({ installationId: id });
      return id;
    })().catch((error) => {
      installationIdPromise = undefined;
      throw error;
    });
  }

  return installationIdPromise;
}

async function licensePost(path, body, headers = {}) {
  let response;
  try {
    response = await fetch(`${LICENSE_SERVER}${path}`, {
      method: "POST",
      credentials: "omit",
      headers: {
        "Content-Type": "application/json",
        ...headers
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000)
    });
  } catch (error) {
    if (["TypeError", "TimeoutError", "AbortError"].includes(error.name)) error.offlineEligible = true;
    throw error;
  }

  if (response.status >= 500 || response.status === 408) {
    const error = new Error(`Account service unavailable: HTTP ${response.status}`);
    error.offlineEligible = true;
    throw error;
  }

  const text = await response.text();

  if (!text.trim()) {
    throw new Error(`Empty backend response: HTTP ${response.status}`);
  }

  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Invalid backend JSON: HTTP ${response.status}`);
  }

  return { ok: response.ok, status: response.status, data };
}

async function checkTrial() {
  const result = await licensePost("/api/trial/check", {
    machineId: await getInstallationId(),
    appSlug: LICENSE_APP_SLUG
  });

  if (!result.ok) {
    throw new Error(result.data?.error || `HTTP ${result.status}`);
  }

  const trial = result.data;

  if (
    !trial ||
    typeof trial.daysRemaining !== "number" ||
    typeof trial.trialDays !== "number" ||
    typeof trial.expired !== "boolean" ||
    typeof trial.firstSeenDate !== "string"
  ) {
    throw new Error("Unexpected trial response");
  }

  return trial;
}

async function verifyLicense(options = {}) {
  const { accountConnectionToken } =
    await chrome.storage.local.get("accountConnectionToken");

  if (!accountConnectionToken) {
    throw new Error("Log in to use your subscription.");
  }

  const result = await licensePost(
    "/api/extension/verify",
    {
      machineId: await getInstallationId(),
      appVersion: chrome.runtime.getManifest().version,
      ...(options.confirmMachineSwitch === true ? { confirmMachineSwitch: true } : {}),
      ...(typeof options.machineSwitchOtp === "string" && options.confirmMachineSwitch === true
        ? { machineSwitchOtp: options.machineSwitchOtp.trim() } : {})
    },
    { Authorization: `Bearer ${accountConnectionToken}` }
  );

  // License denials can use HTTP 401/403; OTP challenges can use 202.
  // Preserve the JSON so the panel can explain the result.
  if (typeof result.data?.valid !== "boolean") {
    throw new Error(
      result.data?.error || `License verification failed: HTTP ${result.status}`
    );
  }

  if (result.data.valid && (!result.ok ||
    result.data.plan?.appSlug !== LICENSE_APP_SLUG ||
    typeof result.data.plan?.isFullAccess !== "boolean" ||
    !Array.isArray(result.data.plan?.features) ||
    !result.data.plan.features.every((feature) => typeof feature === "string"))) {
    throw new Error("Unexpected license entitlements or app mismatch");
  }
  return result.data;
}

async function getAccess() {
  if (accessRequest) return accessRequest;
  const revision = licenseRevision;
  const pending = (async () => {
    const { accountConnectionToken, offlineAccess } =
      await chrome.storage.local.get(["accountConnectionToken", "offlineAccess"]);
    const installationId = await getInstallationId();
    const version = chrome.runtime.getManifest().version;
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(accountConnectionToken || ""));
    const accountHash = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
    const now = Date.now();
    // SECURITY_NOTE: Cached grants are installation/account/version-bound and never renewed by an outage.
    const cache = offlineAccess?.installationId === installationId &&
      offlineAccess.accountHash === accountHash && offlineAccess.version === version &&
      offlineAccess.server === LICENSE_SERVER && Number.isFinite(offlineAccess.checkedAt) &&
      offlineAccess.checkedAt <= now ? offlineAccess : {};
    let account = { connected: false, pending: false };
    const [trialResult, licenseResult] = await Promise.allSettled([
      outageDuringRetry(cache.retryTrialAt, now) || checkTrial(),
      accountConnectionToken ? outageDuringRetry(cache.retryLicenseAt, now) || (async () => {
        const result = await licensePost("/api/extension/connect/status", {},
          { Authorization: `Bearer ${accountConnectionToken}` });
        if (!result.ok) throw new Error(result.data?.error || "Log in again to use your subscription.");
        if (typeof result.data.connected !== "boolean") throw new Error("Unexpected account connection status");
        account = {
          connected: result.data.connected === true,
          pending: result.data.connected === false,
          email: result.data.connected && typeof result.data.email === "string" ? result.data.email : null
        };
        return account.connected ? verifyLicense() : null;
      })() : Promise.resolve(null)
    ]);
    if (revision !== licenseRevision) throw new Error("License key changed. Check access again.");
    const errors = [];
    if (trialResult.status === "rejected") errors.push(`Trial connection/check error: ${trialResult.reason.message}`);
    if (licenseResult.status === "rejected") errors.push(`License connection/verification error: ${licenseResult.reason.message}`);
    let trial = trialResult.status === "fulfilled" ? trialResult.value : null;
    let license = licenseResult.status === "fulfilled" ? licenseResult.value : null;
    let trialEntry = trial
      ? offlineEntry(trial, Date.parse(trial.firstSeenDate) + trial.trialDays * DAY_MS, now) : null;
    let licenseEntry = license?.valid === true
      ? offlineEntry({ valid: true, plan: license.plan, subscription: license.subscription },
        license.subscription?.accessEndsAt === null ? now + OFFLINE_GRACE_MS
          : Date.parse(license.subscription?.accessEndsAt), now) : null;
    if (trial?.expired !== false) trialEntry = null;
    const blocked = license && SFAccess.evaluate(null, license).features.length === 0 &&
      (license.reason || license.machineMismatch || license.machineSwitchRequired);
    const offlineUntil = [];
    if (!blocked && trialResult.status === "rejected" && trialResult.reason.offlineEligible &&
      usableOfflineEntry(cache.trial, now)) {
      trialEntry = cache.trial;
      trial = { ...trialEntry.value, daysRemaining: Math.ceil(
        (Date.parse(trialEntry.value.firstSeenDate) + trialEntry.value.trialDays * DAY_MS - now) / DAY_MS
      ) };
      offlineUntil.push(trialEntry.expiresAt);
    }
    if (!blocked && licenseResult.status === "rejected" && licenseResult.reason.offlineEligible &&
      usableOfflineEntry(cache.license, now)) {
      licenseEntry = cache.license;
      license = licenseEntry.value;
      account = cache.account;
      offlineUntil.push(licenseEntry.expiresAt);
    }
    const result = { ...SFAccess.evaluate(trial, license, errors), account };
    if (offlineUntil.length && result.features.length) {
      result.offline = { expiresAt: new Date(Math.min(...offlineUntil)).toISOString() };
    }
    await chrome.storage.local.set({ offlineAccess: {
      installationId, accountHash, version, server: LICENSE_SERVER, checkedAt: now,
      trial: blocked ? null : trialEntry, license: blocked ? null : licenseEntry, account,
      retryTrialAt: trialResult.status === "rejected" && trialResult.reason.offlineEligible
        ? cache.retryTrialAt > now ? cache.retryTrialAt : now + 60000 : null,
      retryLicenseAt: licenseResult.status === "rejected" && licenseResult.reason.offlineEligible
        ? cache.retryLicenseAt > now ? cache.retryLicenseAt : now + 60000 : null
    } });
    if (revision !== licenseRevision) {
      await clearOfflineAccess();
      throw new Error("Account changed. Check access again.");
    }
    return result;
  })();
  accessRequest = pending;
  try {
    return await pending;
  } finally {
    if (accessRequest === pending) accessRequest = undefined;
  }
}

function isAllowedHost(hostname) {
  return typeof hostname === "string" && ALLOWED_HOST_PATTERN.test(hostname);
}

function displayLabel(label, fallback) {
  return typeof label === "string" && !label.includes("__MISSING LABEL__") ? label : fallback;
}

async function getSessionId(hostname) {
  console.info("[SF Tool] Session step 1: looking up sid cookie", { hostname, url: `https://${hostname}` });
  // SECURITY_NOTE: chrome.cookies requires the "cookies" permission plus a
  // matching host_permissions entry; it is not reachable from web page JS.
  const cookie = await chrome.cookies.get({ url: `https://${hostname}`, name: "sid" });
  if (!cookie) {
    console.warn("[SF Tool] Session step 1 failed: sid cookie not found", { hostname });
    return null;
  }
  console.info("[SF Tool] Session step 1 passed: sid cookie found", {
    hostname,
    domain: cookie.domain,
    path: cookie.path,
    secure: cookie.secure,
    sessionCookie: cookie.session,
    expirationDatePresent: typeof cookie.expirationDate === "number",
    tokenLength: String(cookie.value || "").length
  });
  return cookie.value;
}

async function getSupportedApiVersion(hostname, sessionId) {
  if (apiVersionCache.has(hostname)) {
    const cachedVersion = apiVersionCache.get(hostname);
    console.info("[SF Tool] Session step 2 skipped: using cached API version", { hostname, apiVersion: cachedVersion });
    return cachedVersion;
  }

  console.info("[SF Tool] Session step 2: validating sid against Salesforce REST API", { hostname });
  const response = await fetch(`https://${hostname}/services/data/`, {
    headers: { Authorization: `Bearer ${sessionId}`, Accept: "application/json" }
  });
  if (!response.ok) {
    console.error("[SF Tool] Session step 2 failed: REST API rejected sid", { hostname, status: response.status });
    return API_VERSION;
  }

  const versions = await response.json();
  const supported = versions
    .map((version) => version.version)
    .filter((version) => /^\d+\.\d+$/.test(version))
    .sort((left, right) => Number(right) - Number(left));
  const resolved = supported.length > 0 ? `v${supported[0]}` : API_VERSION;
  apiVersionCache.set(hostname, resolved);
  console.info("[SF Tool] Session step 2 passed: REST API accepted sid", { hostname, apiVersion: resolved });
  return resolved;
}

async function sfFetch(hostname, path, sessionId, { method = "GET", body } = {}) {
  const apiVersion = await getSupportedApiVersion(hostname, sessionId);
  let requestPath = path;
  if (requestPath.includes(`/services/data/${API_VERSION}/`)) {
    requestPath = requestPath.replace(`/services/data/${API_VERSION}/`, `/services/data/${apiVersion}/`);
  }
  const init = {
    method,
    headers: {
      Authorization: `Bearer ${sessionId}`,
      Accept: "application/json"
    }
  };

  if (body !== undefined && body !== null) {
    init.headers["Content-Type"] = "application/json";
    init.body = typeof body === "string" ? body : JSON.stringify(body);
  }

  const response = await fetch(`https://${hostname}${requestPath}`, init);

  // SECURITY_NOTE: only a truncated snippet of the response body is ever
  // surfaced to the UI; the session token itself is never included.
  const text = await response.text().catch(() => "");
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!response.ok) {
    const message = typeof data === "string" ? data : JSON.stringify(data);
    throw new Error(`Salesforce API error ${response.status}: ${message.slice(0, 400)}`);
  }

  return { status: response.status, data };
}

function extractSoapValue(xml, name) {
  const match = String(xml).match(new RegExp(`<\\/?(?:\\w+:)?${name}\\b[^>]*>([\\s\\S]*?)<\\/(?:\\w+:)?${name}>`, "i"));
  return match ? match[1].trim() : "";
}

async function getCurrentUserInfo(hostname, sessionId) {
  const apiVersion = await getSupportedApiVersion(hostname, sessionId);
  const soapBody = `<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:partner.soap.sforce.com">
  <env:Header><urn:SessionHeader><urn:sessionId>${sessionId}</urn:sessionId></urn:SessionHeader></env:Header>
  <env:Body><urn:getUserInfo /></env:Body>
</env:Envelope>`;
  const response = await fetch(`https://${hostname}/services/Soap/u/${apiVersion.slice(1)}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${sessionId}`,
      "Content-Type": "text/xml; charset=UTF-8",
      SOAPAction: "getUserInfo"
    },
    body: soapBody
  });
  const responseText = await response.text().catch(() => "");
  if (!response.ok) {
    throw new Error(`Salesforce Partner API error ${response.status}: ${responseText.slice(0, 400)}`);
  }
  const userId = extractSoapValue(responseText, "userId");
  if (!/^005[A-Za-z0-9]{12}(?:[A-Za-z0-9]{3})?$/.test(userId)) {
    throw new Error("Salesforce Partner API returned no valid user ID.");
  }
  return { userId, username: extractSoapValue(responseText, "userName") };
}

async function handleMessage(message) {
  if (!message || !message.type) {
    console.error("[SF Tool] Rejected message without a type", { hasMessage: !!message });
    throw new Error("Invalid request");
  }

  if (message.type === "license.checkTrial") {
    return { data: await checkTrial() };
  }

  if (message.type === "license.getAccess") {
    return { data: await getAccess() };
  }

  if (message.type === "license.manageAccount") {
    const { accountConnectionToken } = await chrome.storage.local.get("accountConnectionToken");
    if (accountConnectionToken) {
      const status = await licensePost("/api/extension/connect/status", {},
        { Authorization: `Bearer ${accountConnectionToken}` });
      if (status.ok && status.data.connected === true) {
        const url = new URL(status.data.managementUrl);
        if (url.origin !== ACCOUNT_WEBSITE || url.pathname !== "/login" || url.username || url.password) {
          throw new Error("Unexpected account management URL");
        }
        await chrome.tabs.create({ url: url.href });
        return { data: { connected: true } };
      }
      if (!status.ok && status.status !== 401) {
        throw new Error(status.data?.error || "Cannot check account connection");
      }
    }
    const result = await licensePost("/api/extension/connect/start", {
      appSlug: LICENSE_APP_SLUG, machineId: await getInstallationId()
    });
    if (!result.ok) throw new Error(result.data?.error || "Cannot connect account");
    const url = new URL(result.data.approvalUrl);
    if (url.origin !== ACCOUNT_WEBSITE || url.pathname !== "/login" || url.username || url.password ||
      !/^[A-Za-z0-9_-]{43}$/.test(result.data.token)) {
      throw new Error("Unexpected account connection response");
    }
    await chrome.storage.local.set({ accountConnectionToken: result.data.token });
    await clearOfflineAccess();
    licenseRevision++;
    accessRequest = undefined;
    await chrome.tabs.create({ url: url.href });
    return { data: { pending: true } };
  }

  if (message.type === "license.switchAccount") {
    licenseRevision++;
    accessRequest = undefined;
    await clearOfflineAccess();
    const { accountConnectionToken } = await chrome.storage.local.get("accountConnectionToken");
    if (accountConnectionToken) {
      const disconnected = await licensePost("/api/extension/disconnect", {},
        { Authorization: "Bearer " + accountConnectionToken });
      if (!disconnected.ok && disconnected.status !== 401) {
        throw new Error(disconnected.data?.error || "Cannot disconnect current account");
      }
    }
    await chrome.storage.local.remove("accountConnectionToken");

    const result = await licensePost("/api/extension/connect/start", {
      appSlug: LICENSE_APP_SLUG, machineId: await getInstallationId()
    });
    if (!result.ok) throw new Error(result.data?.error || "Cannot start account switch");
    const url = new URL(result.data.approvalUrl);
    if (url.origin !== ACCOUNT_WEBSITE || url.pathname !== "/login" || url.username || url.password ||
      !/^[A-Za-z0-9_-]{43}$/.test(result.data.token)) {
      throw new Error("Unexpected account connection response");
    }
    url.searchParams.set("switchAccount", "1");
    await chrome.storage.local.set({ accountConnectionToken: result.data.token });
    licenseRevision++;
    accessRequest = undefined;
    await chrome.tabs.create({ url: url.href });
    return { data: { pending: true } };
  }

  if (message.type === "license.verify") {
    try {
      const license = await verifyLicense(message);
      if (!license.valid) await clearOfflineAccess();
      return { data: license };
    } catch (error) {
      if (!error.offlineEligible) await clearOfflineAccess();
      throw error;
    }
  }

  if (message.type === "license.clearKey") {
    licenseRevision++;
    accessRequest = undefined;
    await clearOfflineAccess();
    const { accountConnectionToken } = await chrome.storage.local.get("accountConnectionToken");
    if (accountConnectionToken) {
      const result = await licensePost("/api/extension/disconnect", {},
        { Authorization: `Bearer ${accountConnectionToken}` });
      if (!result.ok && result.status !== 401) {
        throw new Error(result.data?.error || "Cannot disconnect account");
      }
    }
    await chrome.storage.local.remove("accountConnectionToken");
    licenseRevision++;
    accessRequest = undefined;
    return { data: { cleared: true } };
  }

  const hostname = message.hostname;
  console.info("[SF Tool] Session step 0: request received", { type: message?.type || "(missing)", hostname });
  if (!isAllowedHost(hostname)) {
    throw new Error(
      "This doesn't look like a Salesforce page. Open a Salesforce tab (Lightning, Classic, or Visualforce) and try again."
    );
  }

  const protectedRequest = message.type !== "checkSession" && message.type !== "getOrgInfo";
  const requestRevision = licenseRevision;
  if (protectedRequest) {
    if (!Object.values(SFAccess.features).includes(message.feature)) {
      throw new Error("A recognized tool entitlement is required for this request.");
    }
    if (!SFAccess.allowsRequest(message)) {
      const error = new Error("This action is not available through the specified tool entitlement.");
      error.code = "TOOL_ACTION_DENIED";
      throw error;
    }
    const revision = licenseRevision;
    const access = await getAccess();
    if (revision !== licenseRevision) throw new Error("License key changed. Check access again.");
    if (!access.features.includes(message.feature)) {
      const error = new Error(SFAccess.denial(access, message.feature));
      error.access = access;
      throw error;
    }
  }

  const sessionId = await getSessionId(hostname);
  if (protectedRequest && requestRevision !== licenseRevision) {
    throw new Error("License key changed. Check access again.");
  }
  if (message.type === "checkSession") {
    return { hasSession: !!sessionId };
  }
  if (!sessionId) {
    throw new Error("No active Salesforce session found for this tab. Log in to Salesforce and try again.");
  }
  console.info("[SF Tool] Session step 3 passed: authenticated session available for request", { type: message.type, hostname });

  if (message.type === "getObjects") {
    const { data } = await sfFetch(hostname, `/services/data/${API_VERSION}/sobjects/`, sessionId);
    const objects = (data.sobjects || []).map((o) => ({
      name: o.name,
      label: displayLabel(o.label, o.name),
      custom: !!o.custom,
      queryable: !!o.queryable,
      keyPrefix: o.keyPrefix || ""
    }));
    return { objects };
  }

  if (message.type === "getOrgInfo") {
    const result = await sfFetch(hostname, `/services/data/${API_VERSION}/query/?q=${encodeURIComponent("SELECT Id, Name, IsSandbox FROM Organization LIMIT 1")}`, sessionId);
    const organization = result.data?.records?.[0] || {};
    let username = "";
    let userId = "";
    let userInfoError = "";
    try {
      const userInfo = await getCurrentUserInfo(hostname, sessionId);
      userId = userInfo.userId;
      username = userInfo.username;
    } catch (error) {
      userInfoError = error.message || String(error);
    }
    return {
      orgId: organization.Id || "",
      name: organization.Name || hostname,
      isSandbox: organization.IsSandbox === true,
      username,
      userId,
      userInfoError,
      hostname
    };
  }

  if (message.type === "getObjectFields") {
    if (!message.objectName || typeof message.objectName !== "string") {
      throw new Error("Missing object name");
    }
    const { data } = await sfFetch(
      hostname,
      `/services/data/${API_VERSION}/sobjects/${encodeURIComponent(message.objectName)}/describe/`,
      sessionId
    );
    const fields = (data.fields || []).map((f) => ({
      name: f.name,
      label: displayLabel(f.label, f.name),
      type: f.type,
      required: !f.nillable && !f.defaultedOnCreate,
      custom: !!f.custom,
      length: f.length,
      precision: f.precision,
      scale: f.scale,
      unique: !!f.unique,
      externalId: !!f.externalId,
      defaultValue: f.defaultValue,
      referenceTo: Array.isArray(f.referenceTo) ? f.referenceTo : [],
      picklistValues: Array.isArray(f.picklistValues) ? f.picklistValues.map((value) => ({
        value: value.value,
        label: value.label,
        active: value.active !== false,
        defaultValue: !!value.defaultValue
      })) : []
    }));
    return { fields };
  }

  if (message.type === "restRequest") {
    const method = (message.method || "GET").toUpperCase();
    if (!ALLOWED_METHODS.has(method)) {
      throw new Error(`Unsupported HTTP method: ${method}`);
    }
    if (typeof message.path !== "string" || !message.path.startsWith("/services/")) {
      throw new Error("Path must start with /services/ (e.g. /services/data/v65.0/sobjects/Account/describe/).");
    }
    const result = await sfFetch(hostname, message.path, sessionId, { method, body: message.body });
    return { status: result.status, data: result.data };
  }

  if (message.type === "metadataDeployRequest") {
    if (typeof message.zipBase64 !== "string" || !message.zipBase64) throw new Error("Metadata deployment ZIP is required.");
    const apiVersion = await getSupportedApiVersion(hostname, sessionId);
    const boundary = `----SFToolMetadata${crypto.randomUUID()}`;
    const multipart = [
      `--${boundary}\r\nContent-Disposition: form-data; name="json"\r\nContent-Type: application/json\r\n\r\n${JSON.stringify({ deployOptions: { rollbackOnError: true, singlePackage: true, checkOnly: !!message.checkOnly } })}\r\n`,
      `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="deploy.zip"\r\nContent-Type: application/zip\r\n\r\n`
    ];
    const prefix = new TextEncoder().encode(multipart.join(""));
    const zipBytes = Uint8Array.from(atob(message.zipBase64), (character) => character.charCodeAt(0));
    const suffix = new TextEncoder().encode(`\r\n--${boundary}--\r\n`);
    const body = new Uint8Array(prefix.length + zipBytes.length + suffix.length);
    body.set(prefix); body.set(zipBytes, prefix.length); body.set(suffix, prefix.length + zipBytes.length);
    const response = await fetch(`https://${hostname}/services/data/${apiVersion}/metadata/deployRequest`, {
      method: "POST",
      headers: { Authorization: `Bearer ${sessionId}`, "Content-Type": `multipart/form-data; boundary=${boundary}`, Accept: "application/json" },
      body
    });
    const text = await response.text().catch(() => "");
    let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) {
      if (/INVALID_SESSION_ID|Illegal Session/i.test(text)) {
        apiVersionCache.delete(hostname);
        throw new Error("Salesforce session expired or is invalid. Sign in to Salesforce again, then retry the import.");
      }
      throw new Error(`Salesforce Metadata API error ${response.status}: ${text.slice(0, 500)}`);
    }
    return { status: response.status, data };
  }

  if (message.type === "metadataStatusRequest") {
    if (typeof message.id !== "string" || !message.id) throw new Error("Metadata deployment ID is required.");
    const result = await sfFetch(hostname, `/services/data/${API_VERSION}/metadata/deployRequest/${encodeURIComponent(message.id)}?includeDetails=true`, sessionId);
    return { status: result.status, data: result.data };
  }

  if (message.type === "metadataRequest") {
    if (typeof message.body !== "string" || !message.body.trim()) {
      throw new Error("Metadata API request body is required.");
    }
    const apiVersion = await getSupportedApiVersion(hostname, sessionId);
    const endpoint = `/services/Soap/m/${apiVersion.slice(1)}`;
    const action = String(message.action || message.body.match(/<met:([A-Za-z]+)>/)?.[1] || "").trim();
    if (!action) throw new Error("Metadata API SOAP action is required.");
    console.info("[SF Tool] Metadata API request", { action, endpoint });
    const escapedSessionId = String(sessionId).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
    const soapBody = message.body.replace(
      /<env:Header\s*\/>/i,
      `<env:Header><met:SessionHeader><met:sessionId>${escapedSessionId}</met:sessionId></met:SessionHeader></env:Header>`
    );
    const response = await fetch(`https://${hostname}${endpoint}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${sessionId}`,
        "Content-Type": "text/xml; charset=UTF-8",
        SOAPAction: action
      },
      body: soapBody
    });
    const text = await response.text().catch(() => "");
    console.info("[SF Tool] Metadata API response", { status: response.status, bodyLength: text.length });
    if (!response.ok) throw new Error(`Salesforce Metadata API error ${response.status}: ${text.slice(0, 500)}`);
    return { status: response.status, data: text };
  }

  console.error("[SF Tool] Unknown request type", { type: String(message.type), keys: Object.keys(message) });
  throw new Error(`Unknown request type: ${String(message.type)}`);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type?.startsWith("license.") &&
    (_sender.id !== chrome.runtime.id || !_sender.url?.startsWith(chrome.runtime.getURL("")))) {
    sendResponse({ ok: false, error: "Account requests must originate from the extension panel." });
    return false;
  }
  console.debug("[SF Tool] Message received", { type: message?.type || "(missing)" });
  handleMessage(message)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message || String(err), ...(err.code === "TOOL_ACTION_DENIED" ? { code: err.code } : {}), ...(err.access ? { access: err.access } : {}) }));
  return true; // keep the message channel open for the async sendResponse above
});
