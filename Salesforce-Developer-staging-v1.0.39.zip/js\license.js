(() => {
  document.addEventListener("DOMContentLoaded", () => {
    const panel = document.getElementById("licensePanel");
    const trialStatus = document.getElementById("licenseTrialStatus");
    const status = document.getElementById("licenseStatus");
    const accessStatus = document.getElementById("licenseAccessStatus");
    const confirm = document.getElementById("licenseMachineConfirm");
    const otpForm = document.getElementById("licenseOtpForm");
    const otpInput = document.getElementById("licenseOtp");
    const controls = panel.querySelectorAll("button, input");
    document.getElementById("licenseManageAccount").href = new URL("/login", globalThis.SF_EXTENSION_CONFIG.accountWebsite).href;
    let busy = false;
    let awaitingConsent = false;
    let awaitingOtp = false;

    function resetFlow() {
      awaitingConsent = false;
      awaitingOtp = false;
      confirm.hidden = true;
      otpForm.hidden = true;
      otpInput.value = "";
    }

    function showLicense(license) {
      resetFlow();
      status.hidden = false;
      if (!license) {
        status.textContent = "Log in to use your subscription.";
        return;
      }
      const messages = [...new Set([license.error, license.message]
        .filter((value) => typeof value === "string" && value.trim()))];
      if (license.valid && !messages.length) messages.push("Subscription active.");
      status.textContent = messages.join(" ") || "License is not active.";
      if (license.reason === "app-version-too-old") {
        status.textContent = SFAccess.updateMessage;
      } else if (license.reason === "machine-switch-cooldown") {
        status.textContent += typeof license.machineSwitchCooldownUntil === "string"
          ? ` Retry after ${license.machineSwitchCooldownUntil}.` : " Machine switching is on cooldown.";
      } else if (license.reason === "machine-switch-otp-required" ||
        license.reason === "machine-switch-otp-invalid") {
        awaitingOtp = true;
        otpForm.hidden = false;
      } else if (license.machineMismatch || license.machineSwitchRequired) {
        awaitingConsent = true;
        confirm.hidden = false;
      }
    }

    function showAccess(access) {
      const connected = access.account?.connected === true;
      document.getElementById("licenseAccountIdentity").textContent = connected
        ? access.account.email ? `Extension account: ${access.account.email}` : "Extension account: signed in (email unavailable)."
        : access.account?.pending ? "Extension account: awaiting sign-in approval."
          : "Not logged in to the extension.";
      document.getElementById("licenseAccountIdentity").hidden = !connected && !access.account?.pending;
      accessStatus.hidden = false;
      const license = access.license;
      const unavailableSubscription = !license || (
        license.valid !== true &&
        [license.message, license.error].some((message) =>
          typeof message === "string" && /^(no active subscription|subscription is inactive)\b/i.test(message.trim())
        )
      );
      const summarizeExpiredTrial = Boolean(
        access.trial?.expired &&
        unavailableSubscription &&
        access.errors.length === 0 &&
        !license?.reason &&
        !license?.machineMismatch &&
        !license?.machineSwitchRequired
      );
      document.getElementById("licenseManageAccount").textContent = connected ? "My account" : "Log in";
      document.getElementById("licenseSwitchAccount").hidden = !connected;
      if (access.account?.pending) {
        status.textContent = "Finish logging in in the browser tab, then return here.";
      }
      trialStatus.hidden = Boolean(access.license?.valid) || summarizeExpiredTrial;
      if (access.trial) {
        trialStatus.textContent = access.trial.expired
          ? "Trial expired."
          : `${access.trial.daysRemaining} trial days remaining.`;
      } else {
        trialStatus.textContent = "Cannot check trial. See connection/check errors below.";
      }
      if (!(awaitingOtp && access.license?.machineMismatch &&
        access.license.reason !== "machine-switch-cooldown")) {
        if (!access.account?.pending) showLicense(access.license);
      }
      const granted = Object.entries(SFAccess.features)
        .filter(([, feature]) => access.features.includes(feature))
        .map(([, feature]) => feature);
      accessStatus.hidden = granted.length > 0;
      accessStatus.textContent = granted.length ? "" : SFAccess.denial(access, "the selected tool");
      if (summarizeExpiredTrial) status.hidden = true;
      if (access.errors.length) {
        if (!access.trial) trialStatus.hidden = true;
        const errors = [...new Set(access.errors)];
        const loginExpired = !connected && errors.every(message =>
          /^License connection\/verification error: Log in again to continue\.?$/.test(message)
        );
        if (loginExpired && !license && access.trial?.expired) {
          trialStatus.hidden = status.hidden = true;
          accessStatus.textContent = "Trial expired. Your extension login has expired; log in again to check your subscription.";
        } else if (loginExpired && !license && !access.account?.pending) {
          status.hidden = true;
          accessStatus.textContent = "Your extension login has expired; log in again to check your subscription.";
        } else {
          const context = license ? status.textContent : access.account?.pending
            ? "Finish logging in in the browser tab, then return here." : "";
          status.textContent = [context, SFAccess.formatErrors(errors)].filter(Boolean).join(" ");
          status.hidden = false;
          if (!granted.length) accessStatus.hidden = true;
        }
      }
      if (access.offline && granted.length) {
        status.textContent = `Using previously verified access; account service unavailable. Offline access ends ${new Date(access.offline.expiresAt).toLocaleString()}.`;
        status.hidden = false;
      }
    }

    document.addEventListener("licenseaccesschange", (event) => showAccess(event.detail));

    async function run(action) {
      if (busy) return;
      busy = true;
      controls.forEach((control) => { control.disabled = true; });
      panel.setAttribute("aria-busy", "true");
      try {
        await action();
      } catch (error) {
        status.hidden = false;
        status.textContent = `Cannot complete license action: ${error.message}`;
        console.error("[SF Tool] License action failed:", error.message);
      } finally {
        busy = false;
        controls.forEach((control) => { control.disabled = false; });
        panel.setAttribute("aria-busy", "false");
      }
    }

    async function verify(options = {}) {
      status.textContent = "Verifying license...";
      let license;
      try {
        ({ data: license } = await SFPanel.sendMessage({ type: "license.verify", ...options }));
      } catch (error) {
        try {
          await SFPanel.refreshAccess();
        } catch (refreshError) {
          console.error("[SF Tool] Access check failed:", refreshError.message);
        }
        throw error;
      }
      showLicense(license);
      await SFPanel.refreshAccess();
      showLicense(license);
    }

    let approvalPoll;
    async function startAccountFlow(messageType, waitingMessage) {
      return run(async () => {
        resetFlow();
        const { data } = await SFPanel.sendMessage({ type: messageType });
        if (!data.pending) return SFPanel.refreshAccess();
        status.textContent = waitingMessage;
        clearInterval(approvalPoll);
        const deadline = Date.now() + 10 * 60 * 1000;
        approvalPoll = setInterval(() => run(async () => {
          if (Date.now() >= deadline) {
            clearInterval(approvalPoll);
            throw new Error("Login timed out. Try again.");
          }
          const access = await SFPanel.refreshAccess();
          if (access.account?.connected) clearInterval(approvalPoll);
        }), 5000);
      });
    }
    document.getElementById("licenseManageAccount").addEventListener("click", (event) => {
      event.preventDefault();
      return startAccountFlow("license.manageAccount", "Finish logging in in the browser tab, then return here.");
    });
    document.getElementById("licenseSwitchAccount").addEventListener("click", () =>
      startAccountFlow("license.switchAccount", "Signing out of this account. Sign in with the other account in the browser tab."));
    window.addEventListener("pagehide", () => clearInterval(approvalPoll));
    document.getElementById("licenseConfirmSwitch").addEventListener("click", () => run(async () => {
      if (!awaitingConsent) throw new Error("Check the license before confirming a machine switch.");
      awaitingConsent = false;
      confirm.hidden = true;
      await verify({ confirmMachineSwitch: true });
    }));
    document.getElementById("licenseOtpForm").addEventListener("submit", (event) => {
      event.preventDefault();
      return run(async () => {
        if (!awaitingOtp) throw new Error("Confirm the machine switch before submitting a code.");
        const code = otpInput.value.trim();
        if (!code) throw new Error("Verification code is required.");
        otpInput.value = "";
        await verify({ confirmMachineSwitch: true, machineSwitchOtp: code });
      });
    });
    function cancelSwitch() {
      resetFlow();
      status.textContent = "Machine switch cancelled. The license was not moved.";
    }
    document.getElementById("licenseCancelSwitch").addEventListener("click", cancelSwitch);
    document.getElementById("licenseCancelOtp").addEventListener("click", cancelSwitch);
    run(() => SFPanel.refreshAccess());
  });
})();
